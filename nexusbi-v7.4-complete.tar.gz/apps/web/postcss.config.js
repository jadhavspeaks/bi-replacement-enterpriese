/**
 * PostCSS configuration for Next.js + Tailwind CSS v3.
 *
 * Required for Tailwind utility classes to be generated. Without this file,
 * Next.js's built-in PostCSS loader runs without the `tailwindcss` plugin,
 * which means:
 *   - `@tailwind base;` / `@tailwind components;` / `@tailwind utilities;`
 *     directives in globals.css are stripped by postcss-import and never
 *     expanded into actual CSS rules.
 *   - Every className referencing `bg-nexus-500`, `rounded-md`, `flex`, etc.
 *     renders as decorative text that the browser ignores.
 *
 * Symptom: the whole UI looks like raw HTML (white background, default
 * serif font, blue underlined links, vertically stacked elements).
 *
 * Fix: this file — it tells Next.js's bundled PostCSS to run tailwindcss
 * followed by autoprefixer on every imported stylesheet.
 *
 * Do not rename. Next.js auto-discovers postcss.config.{js,cjs,mjs} at the
 * project root (apps/web/ in this monorepo).
 */
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};

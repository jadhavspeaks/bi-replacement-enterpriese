export const APPROVAL_STATUSES = ['DRAFT', 'PENDING_REVIEW', 'APPROVED', 'REJECTED'] as const;
export type ApprovalStatus = (typeof APPROVAL_STATUSES)[number];

export const DASHBOARD_SOURCES = ['MANUAL', 'TABLEAU_IMPORT'] as const;
export type DashboardSource = (typeof DASHBOARD_SOURCES)[number];

export const WIDGET_TYPES = ['chart', 'table', 'pivot', 'kpi', 'filter', 'text'] as const;
export type WidgetType = (typeof WIDGET_TYPES)[number];

export const CHART_TYPES = [
  'bar',
  'hbar',
  'stacked_bar',
  'line',
  'area',
  'stacked_area',
  'pie',
  'donut',
  'scatter',
  'bubble',
  'heatmap',
  'treemap',
  'funnel',
  'gauge',
  'radar',
  'sankey',
  'waterfall',
  'boxplot',
  'candlestick',
] as const;
export type ChartType = (typeof CHART_TYPES)[number];

export const FILTER_OPERATOR_TYPES = [
  'equals',
  'notEquals',
  'contains',
  'notContains',
  'gt',
  'gte',
  'lt',
  'lte',
  'set',
  'notSet',
  'inDateRange',
  'notInDateRange',
  'beforeDate',
  'afterDate',
] as const;
export type FilterOperator = (typeof FILTER_OPERATOR_TYPES)[number];

export interface CubeQuery {
  measures?: string[];
  dimensions?: string[];
  timeDimensions?: TimeDimension[];
  filters?: CubeFilter[];
  order?: Record<string, 'asc' | 'desc'>;
  limit?: number;
  offset?: number;
}

export interface TimeDimension {
  dimension: string;
  dateRange?: string | string[];
  granularity?: 'second' | 'minute' | 'hour' | 'day' | 'week' | 'month' | 'quarter' | 'year';
}

export interface CubeFilter {
  member: string;
  operator: FilterOperator;
  values?: string[];
}

export interface WidgetPosition {
  x: number;
  y: number;
  w: number;
  h: number;
  minW?: number;
  minH?: number;
  maxW?: number;
  maxH?: number;
}

export interface ChartConfig {
  chartType: ChartType;
  xAxis?: string;
  yAxis?: string | string[];
  seriesField?: string;
  colorPalette?: string[];
  showLegend?: boolean;
  showDataLabels?: boolean;
  stacked?: boolean;
  smooth?: boolean;
  areaOpacity?: number;
}

export interface TableConfig {
  columns: TableColumnConfig[];
  pageSize?: number;
  enableSorting?: boolean;
  enableFiltering?: boolean;
  enableExport?: boolean;
  rowHeight?: 'compact' | 'normal' | 'comfortable';
}

export interface TableColumnConfig {
  field: string;
  headerName: string;
  width?: number;
  sortable?: boolean;
  filterable?: boolean;
  format?: 'number' | 'currency' | 'percent' | 'date' | 'datetime' | 'text';
  formatOptions?: Record<string, unknown>;
}

export interface KPIConfig {
  measure: string;
  label: string;
  format?: 'number' | 'currency' | 'percent';
  prefix?: string;
  suffix?: string;
  comparisonMeasure?: string;
  comparisonLabel?: string;
  thresholds?: {
    good?: number;
    warning?: number;
    critical?: number;
  };
  trendDirection?: 'up-good' | 'down-good';
}

export interface FilterConfig {
  dimension: string;
  label: string;
  filterType: 'select' | 'multi-select' | 'date-range' | 'number-range' | 'search';
  defaultValue?: string | string[];
  linkedWidgetIds?: string[];
}

export interface TextConfig {
  content: string;
  fontSize?: number;
  textAlign?: 'left' | 'center' | 'right';
  backgroundColor?: string;
  textColor?: string;
}

export interface WidgetConfig {
  widgetId: string;
  widgetType: WidgetType;
  title: string;
  description?: string;
  position: WidgetPosition;
  cubeQuery?: CubeQuery;
  dsId?: string;
  cubeName?: string;
  chartConfig?: ChartConfig;
  tableConfig?: TableConfig;
  kpiConfig?: KPIConfig;
  filterConfig?: FilterConfig;
  textConfig?: TextConfig;
  refreshIntervalMs?: number;
}

export interface LayoutConfig {
  cols: number;
  rowHeight: number;
  margin: [number, number];
  containerPadding: [number, number];
  compactType: 'vertical' | 'horizontal' | null;
}

export interface DashboardFiltersState {
  globalFilters: CubeFilter[];
  widgetFilters: Record<string, CubeFilter[]>;
}

export interface Dashboard {
  dashId: string;
  dashName: string;
  description: string | null;
  layoutJson: LayoutConfig | null;
  widgetsJson: WidgetConfig[] | null;
  filtersJson: DashboardFiltersState | null;
  ownerId: string;
  tenantId: string;
  isPublic: boolean;
  isEmbedded: boolean;
  embedToken: string | null;
  version: number;
  thumbnailUrl: string | null;
  tags: string | null;
  approvalStatus: ApprovalStatus;
  approvedBy: string | null;
  approvedAt: string | null;
  rejectedBy: string | null;
  rejectedAt: string | null;
  rejectionReason: string | null;
  source: DashboardSource;
  dualCheckerRequired: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface DashboardCreateInput {
  dashName: string;
  description?: string;
  layoutJson?: LayoutConfig;
  widgetsJson?: WidgetConfig[];
  filtersJson?: DashboardFiltersState;
  isPublic?: boolean;
  tags?: string;
  dualCheckerRequired?: boolean;
}

export interface DashboardUpdateInput {
  dashName?: string;
  description?: string;
  layoutJson?: LayoutConfig;
  widgetsJson?: WidgetConfig[];
  filtersJson?: DashboardFiltersState;
  isPublic?: boolean;
  tags?: string;
  dualCheckerRequired?: boolean;
}

export interface DashboardVersion {
  versionId: string;
  dashId: string;
  version: number;
  layoutJson: LayoutConfig | null;
  widgetsJson: WidgetConfig[] | null;
  filtersJson: DashboardFiltersState | null;
  savedBy: string;
  savedAt: string;
  changeSummary: string | null;
}

export interface DashboardShare {
  shareId: string;
  dashId: string;
  roleId: string | null;
  userId: string | null;
  canEdit: boolean;
  canShare: boolean;
  sharedAt: string;
  sharedBy: string;
}

export interface DashboardShareInput {
  roleId?: string;
  userId?: string;
  canEdit?: boolean;
  canShare?: boolean;
}

export interface DashboardReview {
  reviewId: string;
  dashId: string;
  dashVersion: number;
  submittedBy: string;
  submittedAt: string;
  reviewedBy: string | null;
  reviewedAt: string | null;
  reviewStatus: 'PENDING' | 'APPROVED' | 'REJECTED';
  reviewComments: string | null;
  tenantId: string;
}

export interface DashboardExportOptions {
  format: 'png' | 'pdf';
  width?: number;
  height?: number;
  scale?: number;
}

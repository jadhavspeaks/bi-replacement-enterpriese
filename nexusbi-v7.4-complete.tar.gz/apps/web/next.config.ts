import type { NextConfig } from 'next';

/**
 * NOTE: typescript.ignoreBuildErrors and eslint.ignoreDuringBuilds are enabled
 * because the v6/v7 codebase has ~200 pre-existing type errors inherited from
 * before the monorepo was fixed. See KNOWN_ISSUES.md for the list and fixes.
 */
const nextConfig: NextConfig = {
  reactStrictMode: true,
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  experimental: {
    /**
     * Maximum request body size that Next.js will buffer for routes covered by
     * middleware (which in this app is everything via the catch-all matcher).
     * Default is 10 MB; bumped to 100 MB so file-upload routes accept large
     * Tableau workbooks (.twb / .twbx can easily exceed 10 MB) and large CSV /
     * Excel ingest files via /api/files/upload and /api/tableau/import.
     *
     * Note: this controls only the buffered-for-middleware portion. The route
     * handler still streams the body afterward, so memory cost scales with
     * concurrent uploads — keep an eye on Node heap if many large uploads
     * happen at once. If the figure ever needs to grow past ~250 MB, prefer
     * presigned-URL direct uploads to MinIO/S3 instead of routing through Node.
     */
    middlewareClientMaxBodySize: '100mb',
  },
  serverExternalPackages: [
    // Native modules and large optional packages that should never be bundled
    // by webpack — Node loads them at runtime instead.
    'oracledb',
    'nodemailer',
    'adm-zip',
    'bcryptjs',
    'mongodb',
    'hive-driver',
    // node:sqlite is a Node.js built-in (Node 22+ with --experimental-sqlite,
    // stable in Node 23+). Listing it here prevents webpack from attempting to
    // resolve "node:sqlite" as an npm package during bundle compilation.
    // Without this entry, the API route bundle for /api/auth/callback/credentials
    // throws "node:sqlite is not available" because webpack rewrites the
    // dynamic import to something it can statically analyze.
    'node:sqlite',
  ],
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
  output: 'standalone',
};

export default nextConfig;

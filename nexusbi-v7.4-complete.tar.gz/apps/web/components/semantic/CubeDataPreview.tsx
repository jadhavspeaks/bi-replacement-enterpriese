'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, RefreshCw, Database, AlertCircle } from 'lucide-react';
import type { CubeSchema } from '@nexusbi/shared-types';

interface ParsedSchema {
  cubeName: string;
  baseTable: string;
  measures: Array<{ name: string; type: string }>;
  dimensions: Array<{ name: string; type: string }>;
}

function parseSchemaJs(schemaJs: string, fallbackName: string): ParsedSchema | null {
  try {
    const p = JSON.parse(schemaJs);
    return {
      cubeName: p.cubeName || p.name || fallbackName,
      baseTable: p.baseTable || p.sql || '',
      measures: Object.entries<{ type?: string }>(p.measures || {}).map(([name, def]) => ({
        name,
        type: def.type || 'unknown',
      })),
      dimensions: Object.entries<{ type?: string }>(p.dimensions || {}).map(([name, def]) => ({
        name,
        type: def.type || 'unknown',
      })),
    };
  } catch {
    return null;
  }
}

interface CubeDataPreviewProps {
  schema: CubeSchema;
  /** Limit of rows to fetch. Defaults to 50. */
  limit?: number;
  /** If true, automatically picks first measure + first dimension to preview. */
  auto?: boolean;
}

/**
 * Cube data preview panel.
 *
 * Picks the first dimension and first measure of the cube and runs a
 * `/api/cube/v1/load` query, displaying the result as a table. Includes
 * a refresh button and an inline error banner on failure.
 *
 * Shown on:
 *   - The semantic-layer cube list (one preview per cube on hover/click)
 *   - The cube wizard's "done" step (instant gratification)
 *   - The data explorer when a cube is picked
 */
export function CubeDataPreview({ schema, limit = 50, auto = true }: CubeDataPreviewProps) {
  const parsed = parseSchemaJs(schema.schemaJs || '', schema.cubeName);
  const [rows, setRows] = useState<Array<Record<string, unknown>>>([]);
  const [columns, setColumns] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [durationMs, setDurationMs] = useState<number | null>(null);

  async function loadData() {
    if (!parsed) {
      setError('Cube schema is malformed (cannot parse JSON)');
      return;
    }
    if (parsed.measures.length === 0 && parsed.dimensions.length === 0) {
      setError('Cube has no measures or dimensions to preview');
      return;
    }

    setLoading(true);
    setError(null);

    const measures = parsed.measures.slice(0, 2).map((m) => `${parsed.cubeName}.${m.name}`);
    const dimensions = parsed.dimensions.slice(0, 2).map((d) => `${parsed.cubeName}.${d.name}`);

    try {
      const res = await fetch('/api/cube/v1/load', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: { measures, dimensions, limit },
          cubeName: parsed.cubeName,
        }),
      });
      const data = await res.json();
      if (!res.ok || data.error) {
        setError(data.error || `HTTP ${res.status}`);
        setRows([]);
        setColumns([]);
      } else {
        const r = (data.data as Array<Record<string, unknown>>) || [];
        setRows(r);
        setColumns(r.length > 0 ? Object.keys(r[0]) : [...dimensions, ...measures]);
        setDurationMs(data.durationMs ?? null);
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
      setRows([]);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (auto) loadData();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [schema.schemaId]);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between gap-2">
          <div className="min-w-0 flex-1">
            <CardTitle className="flex items-center gap-2 text-sm">
              <Database className="h-4 w-4" />
              Data preview: {parsed?.cubeName || schema.cubeName}
            </CardTitle>
            {parsed && (
              <CardDescription className="mt-1 text-xs">
                Base table: <span className="font-mono">{parsed.baseTable}</span>
                {' · '}
                {parsed.measures.length} measures, {parsed.dimensions.length} dimensions
                {durationMs !== null && ` · query ${durationMs}ms`}
              </CardDescription>
            )}
          </div>
          <Button variant="ghost" size="sm" onClick={loadData} disabled={loading}>
            {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <RefreshCw className="h-4 w-4" />}
          </Button>
        </div>
      </CardHeader>
      <CardContent>
        {error && (
          <div className="flex items-start gap-2 rounded-md border border-destructive bg-destructive/10 p-3 text-sm text-destructive">
            <AlertCircle className="mt-0.5 h-4 w-4 shrink-0" />
            <div className="min-w-0">
              <p className="font-medium">Preview failed</p>
              <p className="mt-1 break-all text-xs">{error}</p>
            </div>
          </div>
        )}
        {!error && loading && rows.length === 0 && (
          <div className="rounded-md border border-dashed p-6 text-center text-sm text-muted-foreground">
            <Loader2 className="mx-auto mb-2 h-5 w-5 animate-spin" />
            Loading sample rows…
          </div>
        )}
        {!error && !loading && rows.length === 0 && (
          <div className="rounded-md border border-dashed p-6 text-center text-sm text-muted-foreground">
            No rows returned. The base table may be empty.
          </div>
        )}
        {rows.length > 0 && (
          <div className="overflow-auto rounded-md border">
            <table className="min-w-full text-xs">
              <thead className="bg-muted">
                <tr>
                  {columns.map((c) => (
                    <th key={c} className="border-b px-2 py-1 text-left font-medium">
                      {c}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {rows.slice(0, limit).map((r, i) => (
                  <tr key={i} className={i % 2 === 0 ? 'bg-background' : 'bg-muted/30'}>
                    {columns.map((c) => (
                      <td key={c} className="border-b px-2 py-1 font-mono">
                        {formatCell(r[c])}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="border-t bg-muted/30 px-2 py-1 text-xs text-muted-foreground">
              Showing {Math.min(rows.length, limit)} of {rows.length} row{rows.length === 1 ? '' : 's'}
              {' · '}
              <Badge variant="outline" className="text-[10px]">{columns.length} columns</Badge>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}

function formatCell(v: unknown): string {
  if (v === null || v === undefined) return '∅';
  if (typeof v === 'number') return v.toLocaleString();
  if (typeof v === 'boolean') return v ? 'true' : 'false';
  return String(v);
}

'use client';

import { useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { useDashboardStore } from '@/store/dashboard.store';
import { BarChart3, Table2, Grid3x3, TrendingUp, Filter, Type } from 'lucide-react';
import type { WidgetType, WidgetConfig } from '@nexusbi/shared-types';

const WIDGET_TYPES: Array<{
  type: WidgetType;
  label: string;
  description: string;
  icon: typeof BarChart3;
}> = [
  { type: 'chart', label: 'Chart', description: '18 chart types: bar, line, pie, scatter, heatmap, treemap, sankey, gauge, radar, more', icon: BarChart3 },
  { type: 'table', label: 'Table', description: 'Sortable data table with pagination', icon: Table2 },
  { type: 'pivot', label: 'Pivot', description: 'Rows × columns × measure with subtotals', icon: Grid3x3 },
  { type: 'kpi', label: 'KPI', description: 'Single metric with trend indicator', icon: TrendingUp },
  { type: 'filter', label: 'Filter', description: 'Cross-widget filter control', icon: Filter },
  { type: 'text', label: 'Text', description: 'Markdown text block', icon: Type },
];

export function WidgetPicker() {
  const addWidget = useDashboardStore((s) => s.addWidget);
  const widgets = useDashboardStore((s) => s.widgets);

  const handleAdd = useCallback((type: WidgetType) => {
    const maxY = widgets.reduce((max, w) => Math.max(max, w.position.y + w.position.h), 0);

    const newWidget: WidgetConfig = {
      widgetId: crypto.randomUUID(),
      widgetType: type,
      title: `New ${type.charAt(0).toUpperCase() + type.slice(1)}`,
      position: {
        x: 0,
        y: maxY,
        w: type === 'kpi' ? 3 : type === 'filter' ? 4 : 6,
        h: type === 'kpi' ? 3 : type === 'text' ? 3 : 5,
        minW: 2,
        minH: 2,
      },
      ...(type === 'chart' && {
        chartConfig: { chartType: 'bar', showLegend: true, showDataLabels: false },
      }),
      ...(type === 'kpi' && {
        kpiConfig: { measure: '', label: 'New KPI' },
      }),
      ...(type === 'filter' && {
        filterConfig: { dimension: '', label: 'Filter', filterType: 'select' as const },
      }),
      ...(type === 'text' && {
        textConfig: { content: '## New Text Block\n\nClick to edit...' },
      }),
    };

    addWidget(newWidget);
  }, [addWidget, widgets]);

  return (
    <Card>
      <CardHeader className="p-3">
        <CardTitle className="text-sm">Add Widget</CardTitle>
      </CardHeader>
      <CardContent className="p-3 pt-0 space-y-2">
        {WIDGET_TYPES.map(({ type, label, description, icon: Icon }) => (
          <Button
            key={type}
            variant="outline"
            className="w-full justify-start h-auto py-2.5 px-3"
            onClick={() => handleAdd(type)}
          >
            <Icon className="h-4 w-4 mr-3 shrink-0 text-nexus-500" />
            <div className="text-left">
              <p className="text-sm font-medium">{label}</p>
              <p className="text-xs text-muted-foreground">{description}</p>
            </div>
          </Button>
        ))}
      </CardContent>
    </Card>
  );
}

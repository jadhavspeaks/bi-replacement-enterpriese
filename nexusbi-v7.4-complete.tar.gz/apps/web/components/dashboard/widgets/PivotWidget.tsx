'use client';

import { useEffect, useMemo, useState } from 'react';
import { BaseWidget } from './BaseWidget';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, Table2 } from 'lucide-react';
import type { WidgetConfig, CubeQuery } from '@nexusbi/shared-types';

interface PivotWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
  data?: Record<string, unknown>[];
  loading?: boolean;
}

interface PivotMatrix {
  rowLabels: string[];
  colLabels: string[];
  /** [row][col] = value */
  values: number[][];
  /** Sum of each row (for the right-edge subtotal column). */
  rowTotals: number[];
  /** Sum of each col (for the bottom subtotal row). */
  colTotals: number[];
  /** Grand total. */
  grandTotal: number;
}

function read(row: Record<string, unknown>, member: string): unknown {
  if (member in row) return row[member];
  const upper = member.toUpperCase();
  if (upper in row) return row[upper];
  const tail = member.split('.').pop()!;
  if (tail in row) return row[tail];
  if (tail.toUpperCase() in row) return row[tail.toUpperCase()];
  return null;
}

/**
 * Pivot the cube result into a 2-D matrix indexed by row-dim × col-dim.
 *
 * If only one dimension is provided, the matrix has a single column.
 * If no dimensions, returns an empty matrix.
 * The first measure is used for the cell value.
 */
function pivotMatrix(
  data: Record<string, unknown>[],
  query?: CubeQuery,
): PivotMatrix {
  const empty: PivotMatrix = {
    rowLabels: [],
    colLabels: [],
    values: [],
    rowTotals: [],
    colTotals: [],
    grandTotal: 0,
  };
  if (!data || data.length === 0) return empty;

  const measures = query?.measures || [];
  const dimensions = query?.dimensions || [];
  if (measures.length === 0) return empty;

  const measure = measures[0];
  const rowDim = dimensions[0];
  const colDim = dimensions[1];

  const rowSet = new Set<string>();
  const colSet = new Set<string>();
  for (const r of data) {
    rowSet.add(rowDim ? String(read(r, rowDim) ?? '') : 'Total');
    colSet.add(colDim ? String(read(r, colDim) ?? '') : (measure.split('.').pop() || measure));
  }
  const rowLabels = Array.from(rowSet);
  const colLabels = Array.from(colSet);

  const values: number[][] = rowLabels.map(() => colLabels.map(() => 0));
  for (const r of data) {
    const ri = rowLabels.indexOf(rowDim ? String(read(r, rowDim) ?? '') : 'Total');
    const ci = colLabels.indexOf(colDim ? String(read(r, colDim) ?? '') : (measure.split('.').pop() || measure));
    if (ri >= 0 && ci >= 0) {
      values[ri][ci] += Number(read(r, measure)) || 0;
    }
  }

  const rowTotals = values.map((row) => row.reduce((a, b) => a + b, 0));
  const colTotals = colLabels.map((_, ci) =>
    values.reduce((a, row) => a + row[ci], 0),
  );
  const grandTotal = rowTotals.reduce((a, b) => a + b, 0);

  return { rowLabels, colLabels, values, rowTotals, colTotals, grandTotal };
}

function fmt(n: number): string {
  if (Number.isNaN(n) || !Number.isFinite(n)) return '—';
  if (Math.abs(n) >= 1000) {
    return n.toLocaleString(undefined, { maximumFractionDigits: 0 });
  }
  return n.toLocaleString(undefined, { maximumFractionDigits: 2 });
}

/**
 * Pivot table widget — rows × cols × measure, with row/column subtotals
 * and a grand total. Uses the cube engine to fetch the underlying rows.
 *
 * Binding rules:
 *   - 1 measure required (used for cell values)
 *   - 1st dimension → row axis
 *   - 2nd dimension → column axis (optional)
 *   - 3rd+ dimensions are ignored
 */
export function PivotWidget({ widget, dashId, isEditing, data: externalData, loading }: PivotWidgetProps) {
  const [queryData, setQueryData] = useState<Record<string, unknown>[]>([]);
  const [queryLoading, setQueryLoading] = useState(false);
  const [queryError, setQueryError] = useState<string | null>(null);

  const hasBinding = !!widget.cubeQuery && (widget.cubeQuery.measures?.length || 0) > 0;

  useEffect(() => {
    if (externalData) {
      setQueryData(externalData);
      setQueryError(null);
      return;
    }
    if (!hasBinding) {
      setQueryData([]);
      setQueryError(null);
      return;
    }

    let cancelled = false;
    setQueryLoading(true);
    setQueryError(null);

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: widget.cubeQuery, cubeName: widget.cubeName }),
    })
      .then(async (res) => {
        const result = await res.json();
        if (cancelled) return;
        if (!res.ok || result.error) {
          setQueryError(typeof result.error === 'string' ? result.error : `HTTP ${res.status}`);
          setQueryData([]);
        } else {
          setQueryData(result.data || []);
        }
      })
      .catch((e) => {
        if (!cancelled) {
          setQueryError(e instanceof Error ? e.message : 'Network error');
          setQueryData([]);
        }
      })
      .finally(() => {
        if (!cancelled) setQueryLoading(false);
      });

    return () => { cancelled = true; };
  }, [widget.cubeQuery, widget.cubeName, externalData, hasBinding]);

  const matrix = useMemo(
    () => pivotMatrix(queryData, widget.cubeQuery),
    [queryData, widget.cubeQuery],
  );

  const isLoading = loading || queryLoading;

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      {isLoading && <Skeleton className="h-full w-full" />}

      {!isLoading && !hasBinding && !externalData && (
        <div className="flex h-full flex-col items-center justify-center gap-2 p-4 text-center">
          <Table2 className="h-8 w-8 text-muted-foreground/40" />
          <p className="text-xs text-muted-foreground">Not bound to data</p>
          <p className="text-[10px] text-muted-foreground/70">
            Click this widget and pick a cube + 1 measure + 1-2 dimensions.
          </p>
        </div>
      )}

      {!isLoading && hasBinding && queryError && (
        <div className="flex h-full flex-col items-center justify-center gap-2 p-4 text-center">
          <AlertCircle className="h-8 w-8 text-destructive/60" />
          <p className="text-xs font-medium text-destructive">Query failed</p>
          <p className="break-all text-[10px] text-muted-foreground">{queryError}</p>
        </div>
      )}

      {!isLoading && !queryError && (hasBinding || externalData) && matrix.rowLabels.length > 0 && (
        <div className="h-full overflow-auto">
          <table className="min-w-full border-collapse text-xs">
            <thead className="sticky top-0 bg-muted">
              <tr>
                <th className="border-b border-r px-2 py-1 text-left font-medium" />
                {matrix.colLabels.map((c) => (
                  <th key={c} className="border-b px-2 py-1 text-right font-medium">
                    {c}
                  </th>
                ))}
                <th className="border-b border-l bg-muted/80 px-2 py-1 text-right font-medium">
                  Total
                </th>
              </tr>
            </thead>
            <tbody>
              {matrix.rowLabels.map((rLabel, ri) => (
                <tr key={rLabel} className={ri % 2 === 0 ? 'bg-background' : 'bg-muted/30'}>
                  <th className="border-b border-r px-2 py-1 text-left font-medium">
                    {rLabel}
                  </th>
                  {matrix.values[ri].map((v, ci) => (
                    <td key={ci} className="border-b px-2 py-1 text-right font-mono">
                      {fmt(v)}
                    </td>
                  ))}
                  <td className="border-b border-l bg-muted/40 px-2 py-1 text-right font-mono font-medium">
                    {fmt(matrix.rowTotals[ri])}
                  </td>
                </tr>
              ))}
              <tr className="bg-muted/80">
                <th className="border-t border-r px-2 py-1 text-left font-medium">Total</th>
                {matrix.colTotals.map((v, ci) => (
                  <td key={ci} className="border-t px-2 py-1 text-right font-mono font-medium">
                    {fmt(v)}
                  </td>
                ))}
                <td className="border-l border-t bg-muted px-2 py-1 text-right font-mono font-bold">
                  {fmt(matrix.grandTotal)}
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      )}

      {!isLoading && !queryError && (hasBinding || externalData) && matrix.rowLabels.length === 0 && (
        <div className="flex h-full items-center justify-center text-xs text-muted-foreground">
          No data to pivot
        </div>
      )}
    </BaseWidget>
  );
}

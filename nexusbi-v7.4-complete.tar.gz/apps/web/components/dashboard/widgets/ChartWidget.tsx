'use client';

import { useMemo, useEffect, useState } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import { BaseWidget } from './BaseWidget';
import { Skeleton } from '@/components/ui/skeleton';
import { AlertCircle, BarChart3 } from 'lucide-react';
import type { WidgetConfig, ChartConfig, CubeQuery } from '@nexusbi/shared-types';

interface ChartWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
  data?: Record<string, unknown>[];
  loading?: boolean;
}

const DEFAULT_PALETTE = [
  '#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6',
  '#06b6d4', '#ec4899', '#f97316', '#14b8a6', '#6366f1',
  '#84cc16', '#a855f7', '#0ea5e9', '#facc15', '#dc2626',
];

interface PivotedData {
  /** Distinct values of the X-axis dimension. */
  xValues: string[];
  /** One series per measure (single-dim) or per measure × series-dim combo. */
  series: Array<{
    name: string;
    /** Indexed parallel to xValues. */
    values: number[];
  }>;
}

/**
 * Pivot raw cube rows into a chart-friendly shape.
 *
 * Single dimension:  one series per measure, X = dim values.
 * Two dimensions:    one series per (measure × dim2 value) combo, X = dim1 values.
 * No dimension:      one series, X = ['Total'], Y = each measure becomes a row.
 */
function pivotForChart(
  data: Record<string, unknown>[],
  query?: CubeQuery,
): PivotedData {
  if (!data || data.length === 0) return { xValues: [], series: [] };

  const measures = (query?.measures || []).filter(Boolean);
  const dimensions = (query?.dimensions || []).filter(Boolean);

  // Cube engine returns columns named "CUBE.MEMBER" (uppercased) — match
  // either the full name or the trailing segment to handle both shapes.
  function read(row: Record<string, unknown>, member: string): unknown {
    if (member in row) return row[member];
    const upper = member.toUpperCase();
    if (upper in row) return row[upper];
    const tail = member.split('.').pop()!;
    if (tail in row) return row[tail];
    if (tail.toUpperCase() in row) return row[tail.toUpperCase()];
    return null;
  }

  if (dimensions.length === 0) {
    // No grouping — one column per measure.
    const series = measures.map((m) => ({
      name: m.split('.').pop() || m,
      values: [Number(read(data[0], m)) || 0],
    }));
    return { xValues: ['Total'], series };
  }

  if (dimensions.length === 1) {
    const dim = dimensions[0];
    const xValues = data.map((r) => String(read(r, dim) ?? ''));
    const series = measures.map((m) => ({
      name: m.split('.').pop() || m,
      values: data.map((r) => Number(read(r, m)) || 0),
    }));
    return { xValues, series };
  }

  // Two or more dimensions: first = X axis, second = series breakdown.
  // Any further dimensions are ignored (would need a multi-pivot UI).
  const dimX = dimensions[0];
  const dimSeries = dimensions[1];
  const xValuesSet = new Set<string>();
  const seriesValuesSet = new Set<string>();
  for (const r of data) {
    xValuesSet.add(String(read(r, dimX) ?? ''));
    seriesValuesSet.add(String(read(r, dimSeries) ?? ''));
  }
  const xValues = Array.from(xValuesSet);
  const seriesValues = Array.from(seriesValuesSet);

  // Build a value lookup: key = "x|series|measure" → number.
  const lookup = new Map<string, number>();
  for (const r of data) {
    const x = String(read(r, dimX) ?? '');
    const s = String(read(r, dimSeries) ?? '');
    for (const m of measures) {
      const v = Number(read(r, m)) || 0;
      lookup.set(`${x}|${s}|${m}`, v);
    }
  }

  const series: PivotedData['series'] = [];
  // For each measure, emit one series per series-dim value.
  for (const m of measures) {
    const mLabel = m.split('.').pop() || m;
    for (const s of seriesValues) {
      series.push({
        name: measures.length === 1 ? s : `${mLabel} · ${s}`,
        values: xValues.map((x) => lookup.get(`${x}|${s}|${m}`) ?? 0),
      });
    }
  }
  return { xValues, series };
}

/**
 * Build an ECharts option object for the requested chart type.
 *
 * Designed defensively: any malformed input degrades to an empty chart with
 * a helpful title, never throws. Each chart type has a dedicated branch
 * because they need different option shapes (pie/treemap/sankey are not
 * cartesian, gauge/radar use polar coords, etc.).
 */
function buildEChartsOption(
  data: Record<string, unknown>[],
  chartConfig: ChartConfig,
  query?: CubeQuery,
): Record<string, unknown> {
  if (!data || data.length === 0) {
    return {
      title: {
        text: 'No data',
        left: 'center',
        top: 'center',
        textStyle: { color: '#94a3b8', fontSize: 14, fontWeight: 'normal' },
      },
    };
  }

  const palette = chartConfig.colorPalette || DEFAULT_PALETTE;
  const pivoted = pivotForChart(data, query);
  if (pivoted.xValues.length === 0) {
    return {
      title: {
        text: 'No dimension to plot',
        left: 'center',
        top: 'center',
        textStyle: { color: '#94a3b8', fontSize: 14 },
      },
    };
  }

  const showLegend = chartConfig.showLegend !== false && pivoted.series.length > 1;
  const showLabels = chartConfig.showDataLabels === true;
  const baseGrid = {
    left: '3%',
    right: '4%',
    bottom: showLegend ? '15%' : '8%',
    top: '8%',
    containLabel: true,
  };
  const baseLegend = showLegend ? { bottom: 0, type: 'scroll' } : undefined;
  const baseTooltip = { trigger: 'axis', axisPointer: { type: 'shadow' } };

  const type = chartConfig.chartType;

  // ─── BAR / STACKED BAR / GROUPED BAR ──────────────────────────────────
  if (type === 'bar' || type === 'stacked_bar') {
    return {
      tooltip: baseTooltip,
      legend: baseLegend,
      grid: baseGrid,
      xAxis: {
        type: 'category',
        data: pivoted.xValues,
        axisLabel: { rotate: pivoted.xValues.length > 10 ? 45 : 0, fontSize: 11 },
      },
      yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
      series: pivoted.series.map((s, i) => ({
        name: s.name,
        type: 'bar',
        data: s.values,
        stack: type === 'stacked_bar' || chartConfig.stacked ? 'total' : undefined,
        itemStyle: { color: palette[i % palette.length] },
        label: { show: showLabels, position: 'top', fontSize: 10 },
      })),
      color: palette,
    };
  }

  // ─── HORIZONTAL BAR ───────────────────────────────────────────────────
  if (type === 'hbar') {
    return {
      tooltip: baseTooltip,
      legend: baseLegend,
      grid: baseGrid,
      yAxis: { type: 'category', data: pivoted.xValues, axisLabel: { fontSize: 11 } },
      xAxis: { type: 'value', axisLabel: { fontSize: 11 } },
      series: pivoted.series.map((s, i) => ({
        name: s.name,
        type: 'bar',
        data: s.values,
        stack: chartConfig.stacked ? 'total' : undefined,
        itemStyle: { color: palette[i % palette.length] },
        label: { show: showLabels, position: 'right', fontSize: 10 },
      })),
      color: palette,
    };
  }

  // ─── LINE ─────────────────────────────────────────────────────────────
  if (type === 'line') {
    return {
      tooltip: { trigger: 'axis' },
      legend: baseLegend,
      grid: baseGrid,
      xAxis: { type: 'category', data: pivoted.xValues, boundaryGap: false, axisLabel: { rotate: pivoted.xValues.length > 10 ? 45 : 0, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
      series: pivoted.series.map((s, i) => ({
        name: s.name,
        type: 'line',
        data: s.values,
        smooth: chartConfig.smooth ?? false,
        symbol: 'circle',
        symbolSize: 6,
        itemStyle: { color: palette[i % palette.length] },
        lineStyle: { width: 2 },
        label: { show: showLabels, fontSize: 10 },
      })),
      color: palette,
    };
  }

  // ─── AREA / STACKED AREA ──────────────────────────────────────────────
  if (type === 'area' || type === 'stacked_area') {
    return {
      tooltip: { trigger: 'axis' },
      legend: baseLegend,
      grid: baseGrid,
      xAxis: { type: 'category', data: pivoted.xValues, boundaryGap: false, axisLabel: { rotate: pivoted.xValues.length > 10 ? 45 : 0, fontSize: 11 } },
      yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
      series: pivoted.series.map((s, i) => ({
        name: s.name,
        type: 'line',
        data: s.values,
        smooth: chartConfig.smooth ?? true,
        stack: type === 'stacked_area' ? 'total' : undefined,
        areaStyle: { opacity: chartConfig.areaOpacity ?? 0.4 },
        itemStyle: { color: palette[i % palette.length] },
        lineStyle: { width: 2 },
      })),
      color: palette,
    };
  }

  // ─── PIE / DONUT ──────────────────────────────────────────────────────
  if (type === 'pie' || type === 'donut') {
    // Use first measure, sum across series breakdown if any.
    const pieData = pivoted.xValues.map((x, i) => {
      let v = 0;
      for (const s of pivoted.series) v += s.values[i] || 0;
      return { name: x, value: v };
    });
    return {
      tooltip: { trigger: 'item', formatter: '{b}: {c} ({d}%)' },
      legend: chartConfig.showLegend !== false ? { bottom: 0, type: 'scroll' } : undefined,
      series: [{
        type: 'pie',
        radius: type === 'donut' ? ['40%', '70%'] : '70%',
        center: ['50%', '45%'],
        data: pieData,
        label: { show: showLabels, formatter: '{b}: {d}%' },
        itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
      }],
      color: palette,
    };
  }

  // ─── SCATTER / BUBBLE ─────────────────────────────────────────────────
  if (type === 'scatter' || type === 'bubble') {
    // Need at least 2 measures for a meaningful scatter. With 1, plot
    // index vs. value as a fallback.
    const measureA = pivoted.series[0];
    const measureB = pivoted.series[1] || pivoted.series[0];
    const measureSize = pivoted.series[2];
    const points = pivoted.xValues.map((x, i) => {
      const a = measureA?.values[i] ?? i;
      const b = measureB?.values[i] ?? 0;
      const sz = type === 'bubble' && measureSize ? measureSize.values[i] : null;
      return sz != null ? [a, b, sz, x] : [a, b, x];
    });
    return {
      tooltip: { trigger: 'item', formatter: (p: { data: number[] }) => `${p.data[p.data.length - 1]}<br/>${measureA?.name || 'X'}: ${p.data[0]}<br/>${measureB?.name || 'Y'}: ${p.data[1]}` },
      grid: baseGrid,
      xAxis: { type: 'value', name: measureA?.name, axisLabel: { fontSize: 11 } },
      yAxis: { type: 'value', name: measureB?.name, axisLabel: { fontSize: 11 } },
      series: [{
        type: 'scatter',
        data: points,
        symbolSize: type === 'bubble'
          ? (val: number[]) => Math.max(8, Math.min(60, Math.sqrt(Number(val[2]) || 64) * 2))
          : 12,
        itemStyle: { color: palette[0], opacity: 0.7 },
      }],
      color: palette,
    };
  }

  // ─── HEATMAP ──────────────────────────────────────────────────────────
  if (type === 'heatmap') {
    // Need 2 dimensions. If only 1, fall back to a single-row heatmap.
    const seriesNames = pivoted.series.map((s) => s.name);
    const heatData: Array<[number, number, number]> = [];
    let min = Infinity, max = -Infinity;
    for (let xi = 0; xi < pivoted.xValues.length; xi++) {
      for (let si = 0; si < pivoted.series.length; si++) {
        const v = pivoted.series[si].values[xi] || 0;
        heatData.push([xi, si, v]);
        if (v < min) min = v;
        if (v > max) max = v;
      }
    }
    return {
      tooltip: { position: 'top' },
      grid: { ...baseGrid, bottom: '15%' },
      xAxis: { type: 'category', data: pivoted.xValues, splitArea: { show: true } },
      yAxis: { type: 'category', data: seriesNames, splitArea: { show: true } },
      visualMap: {
        min: min === Infinity ? 0 : min,
        max: max === -Infinity ? 1 : max,
        calculable: true,
        orient: 'horizontal',
        left: 'center',
        bottom: 0,
        inRange: { color: ['#dbeafe', '#3b82f6', '#1e3a8a'] },
      },
      series: [{
        type: 'heatmap',
        data: heatData,
        label: { show: showLabels, fontSize: 10 },
        emphasis: { itemStyle: { shadowBlur: 8, shadowColor: 'rgba(0,0,0,0.3)' } },
      }],
    };
  }

  // ─── TREEMAP ──────────────────────────────────────────────────────────
  if (type === 'treemap') {
    const tmData = pivoted.xValues.map((x, i) => ({
      name: x,
      value: pivoted.series[0]?.values[i] || 0,
    }));
    return {
      tooltip: { formatter: '{b}: {c}' },
      series: [{
        type: 'treemap',
        data: tmData,
        leafDepth: 1,
        label: { show: true, formatter: '{b}\n{c}' },
        itemStyle: { borderColor: '#fff', borderWidth: 1, gapWidth: 1 },
        breadcrumb: { show: false },
      }],
      color: palette,
    };
  }

  // ─── FUNNEL ───────────────────────────────────────────────────────────
  if (type === 'funnel') {
    const funnelData = pivoted.xValues
      .map((x, i) => ({ name: x, value: pivoted.series[0]?.values[i] || 0 }))
      .sort((a, b) => b.value - a.value);
    return {
      tooltip: { trigger: 'item' },
      legend: chartConfig.showLegend !== false ? { bottom: 0 } : undefined,
      series: [{
        type: 'funnel',
        left: '10%',
        right: '10%',
        top: '5%',
        bottom: '15%',
        data: funnelData,
        label: { show: true, formatter: '{b}: {c}' },
        itemStyle: { borderColor: '#fff', borderWidth: 1 },
      }],
      color: palette,
    };
  }

  // ─── GAUGE ────────────────────────────────────────────────────────────
  if (type === 'gauge') {
    const value = pivoted.series[0]?.values[0] || 0;
    // Heuristic: use the next round number above the value as the max.
    const max = Math.pow(10, Math.ceil(Math.log10(Math.max(value, 1) + 1)));
    return {
      series: [{
        type: 'gauge',
        startAngle: 200,
        endAngle: -20,
        min: 0,
        max,
        radius: '80%',
        progress: { show: true, width: 18 },
        axisLine: { lineStyle: { width: 18 } },
        pointer: { show: false },
        detail: { valueAnimation: true, fontSize: 24, offsetCenter: [0, '40%'] },
        data: [{ value, name: pivoted.series[0]?.name || '' }],
        title: { offsetCenter: [0, '70%'], fontSize: 12 },
      }],
      color: palette,
    };
  }

  // ─── RADAR ────────────────────────────────────────────────────────────
  if (type === 'radar') {
    const indicators = pivoted.xValues.map((x, i) => {
      let max = 0;
      for (const s of pivoted.series) {
        if ((s.values[i] || 0) > max) max = s.values[i] || 0;
      }
      return { name: x, max: max * 1.2 || 1 };
    });
    return {
      tooltip: {},
      legend: baseLegend,
      radar: { indicator: indicators, radius: '65%' },
      series: [{
        type: 'radar',
        data: pivoted.series.map((s, i) => ({
          name: s.name,
          value: s.values,
          itemStyle: { color: palette[i % palette.length] },
          areaStyle: { opacity: 0.2 },
        })),
      }],
      color: palette,
    };
  }

  // ─── WATERFALL ────────────────────────────────────────────────────────
  if (type === 'waterfall') {
    // ECharts waterfall pattern: one invisible "placeholder" series + one visible series.
    const values = pivoted.series[0]?.values || [];
    const placeholders: (number | '-')[] = [0];
    let cumulative = values[0] || 0;
    for (let i = 1; i < values.length; i++) {
      placeholders.push(values[i] >= 0 ? cumulative : cumulative + values[i]);
      cumulative += values[i];
    }
    return {
      tooltip: { trigger: 'axis', axisPointer: { type: 'shadow' } },
      grid: baseGrid,
      xAxis: { type: 'category', data: pivoted.xValues, axisLabel: { rotate: pivoted.xValues.length > 10 ? 45 : 0, fontSize: 11 } },
      yAxis: { type: 'value' },
      series: [
        {
          name: 'Placeholder',
          type: 'bar',
          stack: 'total',
          itemStyle: { borderColor: 'transparent', color: 'transparent' },
          emphasis: { itemStyle: { borderColor: 'transparent', color: 'transparent' } },
          data: placeholders,
        },
        {
          name: pivoted.series[0]?.name || 'value',
          type: 'bar',
          stack: 'total',
          label: { show: showLabels, position: 'top' },
          data: values.map((v) => ({ value: Math.abs(v), itemStyle: { color: v >= 0 ? '#22c55e' : '#ef4444' } })),
        },
      ],
    };
  }

  // ─── BOXPLOT ──────────────────────────────────────────────────────────
  if (type === 'boxplot') {
    // Cube queries return aggregates, not raw values, so a true boxplot is not
    // generally possible. Render a degenerate 5-number summary using min/q1/
    // median/q3/max if those measures exist by name; else show min/avg/max
    // collapsed into a single box per category.
    const boxData = pivoted.xValues.map((_, i) => {
      const vals = pivoted.series.map((s) => s.values[i] || 0).sort((a, b) => a - b);
      const min = vals[0] ?? 0;
      const max = vals[vals.length - 1] ?? 0;
      const q1 = vals[Math.floor(vals.length * 0.25)] ?? min;
      const q3 = vals[Math.floor(vals.length * 0.75)] ?? max;
      const median = vals[Math.floor(vals.length / 2)] ?? (min + max) / 2;
      return [min, q1, median, q3, max];
    });
    return {
      tooltip: { trigger: 'item' },
      grid: baseGrid,
      xAxis: { type: 'category', data: pivoted.xValues },
      yAxis: { type: 'value' },
      series: [{ type: 'boxplot', data: boxData, itemStyle: { color: palette[0], borderColor: palette[2] } }],
    };
  }

  // ─── CANDLESTICK ──────────────────────────────────────────────────────
  if (type === 'candlestick') {
    // Expects 4 measures: open, close, low, high (in that order).
    const candleData = pivoted.xValues.map((_, i) => [
      pivoted.series[0]?.values[i] ?? 0,
      pivoted.series[1]?.values[i] ?? 0,
      pivoted.series[2]?.values[i] ?? 0,
      pivoted.series[3]?.values[i] ?? 0,
    ]);
    return {
      tooltip: { trigger: 'axis' },
      grid: baseGrid,
      xAxis: { type: 'category', data: pivoted.xValues },
      yAxis: { type: 'value', scale: true },
      series: [{
        type: 'candlestick',
        data: candleData,
        itemStyle: {
          color: '#22c55e',
          color0: '#ef4444',
          borderColor: '#16a34a',
          borderColor0: '#dc2626',
        },
      }],
    };
  }

  // ─── SANKEY ──────────────────────────────────────────────────────────
  if (type === 'sankey') {
    // Requires 2 dimensions and 1 measure. Source = dim1, target = dim2,
    // value = first measure. Falls back to a single-link diagram if data
    // doesn't fit.
    const dims = (query?.dimensions || []);
    if (dims.length >= 2) {
      const nodeSet = new Set<string>();
      const links: Array<{ source: string; target: string; value: number }> = [];
      for (const r of data) {
        const sKey = dims[0];
        const tKey = dims[1];
        const sName = String(r[sKey] ?? r[sKey.toUpperCase()] ?? r[sKey.split('.').pop()!] ?? '');
        const tName = String(r[tKey] ?? r[tKey.toUpperCase()] ?? r[tKey.split('.').pop()!] ?? '');
        if (!sName || !tName) continue;
        const mKey = (query?.measures || [])[0];
        const v = mKey ? Number(r[mKey] ?? r[mKey.toUpperCase()] ?? r[mKey.split('.').pop()!]) || 0 : 1;
        nodeSet.add(sName);
        nodeSet.add(tName);
        if (v > 0) links.push({ source: sName, target: tName, value: v });
      }
      const nodes = Array.from(nodeSet).map((name) => ({ name }));
      return {
        tooltip: { trigger: 'item', triggerOn: 'mousemove' },
        series: [{
          type: 'sankey',
          data: nodes,
          links,
          emphasis: { focus: 'adjacency' },
          lineStyle: { color: 'gradient', curveness: 0.5 },
        }],
        color: palette,
      };
    }
    return {
      title: { text: 'Sankey requires ≥ 2 dimensions', left: 'center', top: 'center', textStyle: { color: '#94a3b8', fontSize: 12 } },
    };
  }

  // ─── DEFAULT FALLBACK ─────────────────────────────────────────────────
  return {
    tooltip: baseTooltip,
    legend: baseLegend,
    grid: baseGrid,
    xAxis: { type: 'category', data: pivoted.xValues, axisLabel: { rotate: pivoted.xValues.length > 10 ? 45 : 0, fontSize: 11 } },
    yAxis: { type: 'value' },
    series: pivoted.series.map((s, i) => ({
      name: s.name,
      type: 'bar',
      data: s.values,
      itemStyle: { color: palette[i % palette.length] },
    })),
    color: palette,
  };
}

export function ChartWidget({ widget, dashId, isEditing, data: externalData, loading }: ChartWidgetProps) {
  const [queryData, setQueryData] = useState<Record<string, unknown>[]>([]);
  const [queryLoading, setQueryLoading] = useState(false);
  const [queryError, setQueryError] = useState<string | null>(null);

  const hasBinding = !!widget.cubeQuery && (widget.cubeQuery.measures?.length || 0) > 0;

  useEffect(() => {
    if (externalData) {
      setQueryData(externalData);
      setQueryError(null);
      return;
    }

    if (!hasBinding) {
      setQueryData([]);
      setQueryError(null);
      return;
    }

    let cancelled = false;
    setQueryLoading(true);
    setQueryError(null);

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: widget.cubeQuery,
        cubeName: widget.cubeName,
      }),
    })
      .then(async (res) => {
        const result = await res.json();
        if (cancelled) return;
        if (!res.ok || result.error) {
          setQueryError(typeof result.error === 'string' ? result.error : `HTTP ${res.status}`);
          setQueryData([]);
        } else {
          setQueryData(result.data || []);
        }
      })
      .catch((e) => {
        if (!cancelled) {
          setQueryError(e instanceof Error ? e.message : 'Network error');
          setQueryData([]);
        }
      })
      .finally(() => {
        if (!cancelled) setQueryLoading(false);
      });

    return () => { cancelled = true; };
  }, [widget.cubeQuery, widget.cubeName, externalData, hasBinding]);

  const chartOption = useMemo(
    () => buildEChartsOption(queryData, widget.chartConfig || { chartType: 'bar' }, widget.cubeQuery),
    [queryData, widget.chartConfig, widget.cubeQuery],
  );

  const isLoading = loading || queryLoading;

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      {isLoading && (
        <Skeleton className="h-full w-full" />
      )}
      {!isLoading && !hasBinding && !externalData && (
        <div className="flex h-full flex-col items-center justify-center gap-2 p-4 text-center">
          <BarChart3 className="h-8 w-8 text-muted-foreground/40" />
          <p className="text-xs text-muted-foreground">Not bound to data</p>
          <p className="text-[10px] text-muted-foreground/70">Click this widget in edit mode and pick a cube + measures.</p>
        </div>
      )}
      {!isLoading && hasBinding && queryError && (
        <div className="flex h-full flex-col items-center justify-center gap-2 p-4 text-center">
          <AlertCircle className="h-8 w-8 text-destructive/60" />
          <p className="text-xs font-medium text-destructive">Query failed</p>
          <p className="break-all text-[10px] text-muted-foreground">{queryError}</p>
        </div>
      )}
      {!isLoading && !queryError && (hasBinding || externalData) && (
        <ReactEChartsCore
          option={chartOption}
          style={{ height: '100%', width: '100%' }}
          notMerge={true}
          opts={{ renderer: 'svg' }}
        />
      )}
    </BaseWidget>
  );
}

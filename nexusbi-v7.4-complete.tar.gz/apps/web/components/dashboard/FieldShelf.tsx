'use client';

import { useState } from 'react';
import { Sigma, Hash, Calendar, Type as TypeIcon, X, Columns3, Rows3, Palette, CircleDot } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';

export interface ShelfField {
  /** Fully qualified member name, e.g. "Sales.totalRevenue" */
  member: string;
  /** Member type: tells us what icon to show + which shelves it can go on */
  kind: 'measure' | 'string' | 'number' | 'time';
  /** Just the member name without cube prefix */
  label: string;
}

export interface ShelfBindings {
  columns: ShelfField[];
  rows: ShelfField[];
  color: ShelfField[];
  size: ShelfField[];
}

export interface FieldShelfProps {
  /** Available measures from the bound cube. */
  availableMeasures: ShelfField[];
  /** Available dimensions from the bound cube. */
  availableDimensions: ShelfField[];
  /** Current bindings (which fields are on which shelf). */
  value: ShelfBindings;
  /** Called whenever bindings change. */
  onChange: (next: ShelfBindings) => void;
}

const MIME = 'application/x-nexusbi-field';

/**
 * Tableau-style drag-drop field shelf.
 *
 * Left: collapsible field list grouped by Measures + Dimensions, each shown
 * as a "pill" the user can drag.
 *
 * Right: 4 drop targets — Columns (X-axis), Rows (Y-axis), Color (series
 * breakdown), Size (bubble size). Drop a field on a shelf to add it; click
 * the X on a pill to remove it.
 *
 * Uses HTML5 native drag-drop — no third-party DnD lib required.
 *
 * Shelves enforce kind constraints:
 *   - Columns/Rows: any kind
 *   - Color: dimensions only (would clash with measure colors otherwise)
 *   - Size: measures only (Tableau convention; pixel-size needs a number)
 */
export function FieldShelf({
  availableMeasures,
  availableDimensions,
  value,
  onChange,
}: FieldShelfProps) {
  const [dragging, setDragging] = useState<string | null>(null);

  function handleDragStart(e: React.DragEvent, field: ShelfField) {
    e.dataTransfer.setData(MIME, JSON.stringify(field));
    e.dataTransfer.effectAllowed = 'copyMove';
    setDragging(field.member);
  }

  function handleDragEnd() {
    setDragging(null);
  }

  function shelfAccepts(shelf: keyof ShelfBindings, kind: ShelfField['kind']): boolean {
    if (shelf === 'color') return kind !== 'measure';
    if (shelf === 'size') return kind === 'measure';
    return true;
  }

  function handleDrop(shelf: keyof ShelfBindings, e: React.DragEvent) {
    e.preventDefault();
    const raw = e.dataTransfer.getData(MIME);
    if (!raw) return;
    let field: ShelfField;
    try { field = JSON.parse(raw) as ShelfField; } catch { return; }
    if (!shelfAccepts(shelf, field.kind)) return;
    const current = value[shelf] || [];
    if (current.find((f) => f.member === field.member)) return;
    // Remove the field from any other shelf — fields can only be in one place.
    const next: ShelfBindings = {
      columns: value.columns.filter((f) => f.member !== field.member),
      rows: value.rows.filter((f) => f.member !== field.member),
      color: value.color.filter((f) => f.member !== field.member),
      size: value.size.filter((f) => f.member !== field.member),
    };
    next[shelf] = [...next[shelf], field];
    onChange(next);
  }

  function removeFromShelf(shelf: keyof ShelfBindings, member: string) {
    onChange({
      ...value,
      [shelf]: value[shelf].filter((f) => f.member !== member),
    });
  }

  function fieldIcon(kind: ShelfField['kind']) {
    if (kind === 'measure') return <Sigma className="h-3 w-3" />;
    if (kind === 'time') return <Calendar className="h-3 w-3" />;
    if (kind === 'number') return <Hash className="h-3 w-3" />;
    return <TypeIcon className="h-3 w-3" />;
  }

  function fieldColor(kind: ShelfField['kind']) {
    if (kind === 'measure') return 'border-green-500/50 bg-green-50/50 text-green-900 dark:bg-green-950/30 dark:text-green-200';
    return 'border-blue-500/50 bg-blue-50/50 text-blue-900 dark:bg-blue-950/30 dark:text-blue-200';
  }

  // Track which fields are currently bound (anywhere) so we can grey them
  // in the field list — a small visual cue that they're in use.
  const usedSet = new Set<string>();
  for (const s of [value.columns, value.rows, value.color, value.size]) {
    for (const f of s) usedSet.add(f.member);
  }

  function renderPill(field: ShelfField, removable?: { shelf: keyof ShelfBindings }) {
    return (
      <div
        key={field.member}
        draggable
        onDragStart={(e) => handleDragStart(e, field)}
        onDragEnd={handleDragEnd}
        className={`inline-flex cursor-grab items-center gap-1 rounded-full border px-2 py-0.5 text-[10px] font-mono transition-opacity ${fieldColor(field.kind)} ${
          dragging === field.member ? 'opacity-40' : ''
        } ${usedSet.has(field.member) && !removable ? 'opacity-50' : ''}`}
        title={field.member}
      >
        {fieldIcon(field.kind)}
        <span className="max-w-[100px] truncate">{field.label}</span>
        {removable && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              removeFromShelf(removable.shelf, field.member);
            }}
            className="ml-0.5 rounded-full hover:bg-black/10 dark:hover:bg-white/10"
          >
            <X className="h-2.5 w-2.5" />
          </button>
        )}
      </div>
    );
  }

  function renderShelf(shelf: keyof ShelfBindings, label: string, icon: React.ReactNode, hint: string) {
    const fields = value[shelf] || [];
    return (
      <div
        onDragOver={(e) => {
          if (e.dataTransfer.types.includes(MIME)) e.preventDefault();
        }}
        onDrop={(e) => handleDrop(shelf, e)}
        className="rounded-md border border-dashed bg-muted/30 p-2"
      >
        <div className="mb-1.5 flex items-center gap-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
          {icon}
          <span>{label}</span>
          {fields.length > 0 && (
            <Badge variant="outline" className="ml-auto h-4 px-1 text-[9px]">{fields.length}</Badge>
          )}
        </div>
        {fields.length === 0 ? (
          <p className="text-[10px] italic text-muted-foreground/60">{hint}</p>
        ) : (
          <div className="flex flex-wrap gap-1">
            {fields.map((f) => renderPill(f, { shelf }))}
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* Field list */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-xs">Fields</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div>
            <p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
              Measures · {availableMeasures.length}
            </p>
            <div className="flex flex-wrap gap-1">
              {availableMeasures.length === 0 ? (
                <p className="text-[10px] italic text-muted-foreground/60">No measures in this cube</p>
              ) : (
                availableMeasures.map((f) => renderPill(f))
              )}
            </div>
          </div>
          <div>
            <p className="mb-1 text-[10px] font-medium uppercase tracking-wide text-muted-foreground">
              Dimensions · {availableDimensions.length}
            </p>
            <div className="flex flex-wrap gap-1">
              {availableDimensions.length === 0 ? (
                <p className="text-[10px] italic text-muted-foreground/60">No dimensions in this cube</p>
              ) : (
                availableDimensions.map((f) => renderPill(f))
              )}
            </div>
          </div>
          <p className="text-[10px] text-muted-foreground/70">
            Drag a pill onto a shelf below to bind it.
          </p>
        </CardContent>
      </Card>

      {/* Shelves */}
      <div className="space-y-2">
        {renderShelf('columns', 'Columns', <Columns3 className="h-3 w-3" />, 'Drop a field for the X-axis (or pivot columns)')}
        {renderShelf('rows', 'Rows', <Rows3 className="h-3 w-3" />, 'Drop a field for the Y-axis (or pivot rows)')}
        {renderShelf('color', 'Color', <Palette className="h-3 w-3" />, 'Drop a dimension to break series by color')}
        {renderShelf('size', 'Size', <CircleDot className="h-3 w-3" />, 'Drop a measure to vary point size (bubble charts)')}
      </div>
    </div>
  );
}

/**
 * Convert shelf bindings to a CubeQuery the engine understands.
 *
 * Standard mapping:
 *   - measures = anything in Columns/Rows that is a measure, plus Size
 *   - dimensions = anything in Columns/Rows that is a dimension, plus Color (color is always a dimension)
 *
 * The order matters because the chart renderer treats:
 *   dimensions[0] as the X-axis
 *   dimensions[1] as the series breakdown
 * So we put Columns first, then Rows, then Color.
 */
export function shelfBindingsToCubeQuery(bindings: ShelfBindings): {
  measures: string[];
  dimensions: string[];
} {
  const measures: string[] = [];
  const dimensions: string[] = [];

  for (const f of bindings.columns) {
    if (f.kind === 'measure') measures.push(f.member);
    else dimensions.push(f.member);
  }
  for (const f of bindings.rows) {
    if (f.kind === 'measure') measures.push(f.member);
    else dimensions.push(f.member);
  }
  for (const f of bindings.color) {
    // Color is dimension-only; just add it.
    if (!dimensions.includes(f.member)) dimensions.push(f.member);
  }
  for (const f of bindings.size) {
    if (!measures.includes(f.member)) measures.push(f.member);
  }

  return { measures, dimensions };
}

/**
 * Reverse mapping: take an existing CubeQuery and place its members onto
 * default shelves. Used when a user opens an already-bound widget — we
 * need to populate the shelves so they can edit, not start from scratch.
 *
 * Heuristic: first dimension → Columns, second dimension → Color (if any),
 * remaining dimensions → Rows; all measures → Columns.
 */
export function cubeQueryToShelfBindings(
  query: { measures?: string[]; dimensions?: string[] } | undefined,
  measureKinds: Map<string, ShelfField['kind']>,
  dimensionKinds: Map<string, ShelfField['kind']>,
): ShelfBindings {
  const empty: ShelfBindings = { columns: [], rows: [], color: [], size: [] };
  if (!query) return empty;

  const dims = query.dimensions || [];
  const meas = query.measures || [];

  function fieldFor(member: string, kind: ShelfField['kind']): ShelfField {
    return { member, kind, label: member.split('.').pop() || member };
  }

  if (dims.length >= 1) {
    const k = dimensionKinds.get(dims[0]) || 'string';
    empty.columns.push(fieldFor(dims[0], k));
  }
  if (dims.length >= 2) {
    const k = dimensionKinds.get(dims[1]) || 'string';
    empty.color.push(fieldFor(dims[1], k));
  }
  for (let i = 2; i < dims.length; i++) {
    const k = dimensionKinds.get(dims[i]) || 'string';
    empty.rows.push(fieldFor(dims[i], k));
  }
  for (const m of meas) {
    const k = measureKinds.get(m) || 'measure';
    empty.columns.push(fieldFor(m, k));
  }
  return empty;
}

'use client';

import { useCallback, useMemo, useEffect, useState } from 'react';
import { Responsive, WidthProvider, type Layout } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { useDashboardStore } from '@/store/dashboard.store';
import { ChartWidget } from './widgets/ChartWidget';
import { TableWidget } from './widgets/TableWidget';
import { PivotWidget } from './widgets/PivotWidget';
import { KPIWidget } from './widgets/KPIWidget';
import { FilterWidget } from './widgets/FilterWidget';
import { TextWidget } from './widgets/TextWidget';
import type { WidgetConfig, MobileLayout } from '@nexusbi/shared-types';

const ResponsiveGridLayout = WidthProvider(Responsive);

interface DashboardGridProps {
  dashId?: string;
  isEditing?: boolean;
  readOnly?: boolean;
  mobileLayout?: MobileLayout | null;
}

function renderWidget(widget: WidgetConfig, dashId?: string, isEditing?: boolean) {
  const props = { widget, dashId, isEditing };

  switch (widget.widgetType) {
    case 'chart':
      return <ChartWidget {...props} />;
    case 'table':
      return <TableWidget {...props} />;
    case 'pivot':
      return <PivotWidget {...props} />;
    case 'kpi':
      return <KPIWidget {...props} />;
    case 'filter':
      return <FilterWidget {...props} />;
    case 'text':
      return <TextWidget {...props} />;
    default:
      return (
        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
          Unknown widget type: {widget.widgetType}
        </div>
      );
  }
}

export function DashboardGrid({ dashId, isEditing = false, readOnly = false, mobileLayout }: DashboardGridProps) {
  const widgets = useDashboardStore((s) => s.widgets);
  const layout = useDashboardStore((s) => s.layout);
  const editMode = useDashboardStore((s) => s.editMode);
  const moveWidget = useDashboardStore((s) => s.moveWidget);
  const selectWidget = useDashboardStore((s) => s.selectWidget);

  const [windowWidth, setWindowWidth] = useState(1200);

  useEffect(() => {
    setWindowWidth(window.innerWidth);
    const handleResize = () => setWindowWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  const isMobile = windowWidth < 768;
  const useMobileLayout = isMobile || editMode === 'mobile';

  const activeWidgets = useMemo(() => {
    if (useMobileLayout && mobileLayout?.widgetsJson) {
      return mobileLayout.widgetsJson;
    }
    return widgets;
  }, [useMobileLayout, mobileLayout, widgets]);

  const gridLayout: Layout[] = useMemo(() => {
    return activeWidgets
      .map((widget) => {
        // Defensive normalization: production code uses widget.position = {x,y,w,h}
        // but legacy/seed data sometimes stores x/y/w/h flat at the top level.
        // Accept either shape; skip widgets that have neither (avoids the
        // "Cannot read properties of undefined (reading 'x')" runtime crash).
        const flat = widget as unknown as {
          x?: number; y?: number; w?: number; h?: number;
          minW?: number; minH?: number; maxW?: number; maxH?: number;
        };
        const pos = widget.position ?? {
          x: flat.x ?? 0,
          y: flat.y ?? 0,
          w: flat.w ?? 4,
          h: flat.h ?? 3,
          minW: flat.minW,
          minH: flat.minH,
          maxW: flat.maxW,
          maxH: flat.maxH,
        };
        if (
          typeof pos.x !== 'number' ||
          typeof pos.y !== 'number' ||
          typeof pos.w !== 'number' ||
          typeof pos.h !== 'number'
        ) {
          return null;
        }
        return {
          i: widget.widgetId,
          x: pos.x,
          y: pos.y,
          w: pos.w,
          h: pos.h,
          minW: pos.minW || 2,
          minH: pos.minH || 2,
          maxW: pos.maxW,
          maxH: pos.maxH,
          static: readOnly || !isEditing,
        } satisfies Layout;
      })
      .filter((l): l is Layout => l !== null);
  }, [activeWidgets, readOnly, isEditing]);

  const handleLayoutChange = useCallback(
    (newLayout: Layout[]) => {
      if (!isEditing || readOnly) return;

      for (const item of newLayout) {
        const widget = activeWidgets.find((w) => w.widgetId === item.i);
        if (widget) {
          // Same flat-vs-nested defense as in gridLayout above.
          const flat = widget as unknown as { x?: number; y?: number; w?: number; h?: number };
          const pos = widget.position ?? { x: flat.x, y: flat.y, w: flat.w, h: flat.h };
          if (pos.x !== item.x || pos.y !== item.y || pos.w !== item.w || pos.h !== item.h) {
            moveWidget(item.i, { x: item.x, y: item.y, w: item.w, h: item.h });
          }
        }
      }
    },
    [isEditing, readOnly, activeWidgets, moveWidget],
  );

  if (activeWidgets.length === 0) {
    return (
      <div className="flex h-64 items-center justify-center rounded-lg border-2 border-dashed">
        <p className="text-sm text-muted-foreground">
          {isEditing ? 'Add widgets from the toolbar to get started' : 'No widgets on this dashboard'}
        </p>
      </div>
    );
  }

  return (
    <div
      className="dashboard-grid"
      onClick={() => { if (isEditing) selectWidget(null); }}
      data-dashboard-loaded="true"
    >
      <ResponsiveGridLayout
        className="layout"
        layouts={{ lg: gridLayout, md: gridLayout, sm: gridLayout }}
        breakpoints={{ lg: 1200, md: 768, sm: 0 }}
        cols={{ lg: layout.cols || 12, md: layout.cols || 12, sm: useMobileLayout ? 1 : (layout.cols || 12) }}
        rowHeight={layout.rowHeight || 40}
        margin={layout.margin || [10, 10]}
        containerPadding={layout.containerPadding || [10, 10]}
        compactType={layout.compactType || 'vertical'}
        isDraggable={isEditing && !readOnly}
        isResizable={isEditing && !readOnly}
        onLayoutChange={handleLayoutChange}
        useCSSTransforms={true}
        draggableHandle=".react-grid-item"
      >
        {activeWidgets.map((widget) => (
          <div
            key={widget.widgetId}
            onClick={(e) => {
              if (isEditing) {
                e.stopPropagation();
                selectWidget(widget.widgetId);
              }
            }}
          >
            {renderWidget(widget, dashId, isEditing)}
          </div>
        ))}
      </ResponsiveGridLayout>
    </div>
  );
}

'use client';

import {
  BarChart3,
  BarChartHorizontal,
  Layers,
  LineChart,
  AreaChart,
  PieChart,
  Donut,
  ScatterChart,
  Circle,
  Grid3x3,
  Boxes,
  Filter as FunnelIcon,
  Gauge,
  Hexagon,
  GitBranch,
  TrendingUp,
  Box,
  CandlestickChart,
} from 'lucide-react';
import type { ChartType } from '@nexusbi/shared-types';

interface ChartTypePickerProps {
  value: ChartType;
  onChange: (type: ChartType) => void;
}

const CHART_OPTIONS: Array<{
  type: ChartType;
  label: string;
  icon: typeof BarChart3;
  needs: string;
  group: 'compare' | 'trend' | 'distribution' | 'composition' | 'flow';
}> = [
  // Comparison
  { type: 'bar',           label: 'Bar',          icon: BarChart3,           needs: '1+ measures, 1 dim',         group: 'compare' },
  { type: 'hbar',          label: 'H-Bar',        icon: BarChartHorizontal,  needs: '1+ measures, 1 dim',         group: 'compare' },
  { type: 'stacked_bar',   label: 'Stacked Bar',  icon: Layers,              needs: '1+ measures, 2 dims',        group: 'compare' },
  { type: 'radar',         label: 'Radar',        icon: Hexagon,             needs: '1+ measures, 3+ dims',       group: 'compare' },
  // Trend over time
  { type: 'line',          label: 'Line',         icon: LineChart,           needs: '1+ measures, 1 dim (time)',  group: 'trend' },
  { type: 'area',          label: 'Area',         icon: AreaChart,           needs: '1+ measures, 1 dim',         group: 'trend' },
  { type: 'stacked_area',  label: 'Stacked Area', icon: AreaChart,           needs: '1+ measures, 2 dims',        group: 'trend' },
  { type: 'candlestick',   label: 'Candlestick',  icon: CandlestickChart,    needs: '4 measures (OHLC), 1 dim',   group: 'trend' },
  // Composition
  { type: 'pie',           label: 'Pie',          icon: PieChart,            needs: '1 measure, 1 dim',           group: 'composition' },
  { type: 'donut',         label: 'Donut',        icon: Donut,               needs: '1 measure, 1 dim',           group: 'composition' },
  { type: 'treemap',       label: 'Treemap',      icon: Grid3x3,             needs: '1 measure, 1 dim',           group: 'composition' },
  { type: 'funnel',        label: 'Funnel',       icon: FunnelIcon,          needs: '1 measure, 1 dim (stages)',  group: 'composition' },
  { type: 'waterfall',     label: 'Waterfall',    icon: TrendingUp,          needs: '1 measure, 1 dim',           group: 'composition' },
  // Distribution
  { type: 'scatter',       label: 'Scatter',      icon: ScatterChart,        needs: '2 measures, 1 dim',          group: 'distribution' },
  { type: 'bubble',        label: 'Bubble',       icon: Circle,              needs: '3 measures, 1 dim',          group: 'distribution' },
  { type: 'heatmap',       label: 'Heatmap',      icon: Boxes,               needs: '1 measure, 2 dims',          group: 'distribution' },
  { type: 'boxplot',       label: 'Box Plot',     icon: Box,                 needs: '1+ measures, 1 dim',         group: 'distribution' },
  { type: 'gauge',         label: 'Gauge',        icon: Gauge,               needs: '1 measure',                  group: 'distribution' },
  // Flow
  { type: 'sankey',        label: 'Sankey',       icon: GitBranch,           needs: '1 measure, 2 dims',          group: 'flow' },
];

const GROUP_LABEL: Record<string, string> = {
  compare: 'Compare',
  trend: 'Trend',
  composition: 'Composition',
  distribution: 'Distribution',
  flow: 'Flow',
};

/**
 * Tableau Show-Me-style chart picker. Groups chart types by analytic intent.
 * Clicking a tile calls onChange with the new chart type — the parent is
 * responsible for persisting it onto the widget config.
 */
export function ChartTypePicker({ value, onChange }: ChartTypePickerProps) {
  const groups = Object.keys(GROUP_LABEL) as Array<keyof typeof GROUP_LABEL>;

  return (
    <div className="space-y-3">
      {groups.map((g) => {
        const opts = CHART_OPTIONS.filter((o) => o.group === g);
        if (opts.length === 0) return null;
        return (
          <div key={g}>
            <p className="mb-1.5 text-[10px] font-medium uppercase tracking-wider text-muted-foreground">
              {GROUP_LABEL[g]}
            </p>
            <div className="grid grid-cols-4 gap-1">
              {opts.map((o) => {
                const Icon = o.icon;
                const active = value === o.type;
                return (
                  <button
                    key={o.type}
                    type="button"
                    onClick={() => onChange(o.type)}
                    title={`${o.label} — ${o.needs}`}
                    className={`flex aspect-square flex-col items-center justify-center gap-0.5 rounded-md border p-1 text-[9px] transition-colors ${
                      active
                        ? 'border-primary bg-primary/10 text-primary'
                        : 'border-border text-muted-foreground hover:border-primary/50 hover:bg-muted/50'
                    }`}
                  >
                    <Icon className="h-4 w-4" />
                    <span className="truncate text-[8px] leading-tight">{o.label}</span>
                  </button>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}

/**
 * NexusBI — Query Engine
 *
 * Replaces the former Cube.js semantic layer with a lightweight in-app engine.
 * Reads cube-style schema definitions from NB_CUBE_SCHEMAS (Oracle), compiles
 * a query into the appropriate dialect, dispatches to the native driver for
 * each data source type, and normalizes the result.
 *
 * Supports the 12 approved data source types. Oracle runs directly; other
 * sources can either query live or go through the staged-to-Oracle tables
 * created by file-ingest, api-source-ingest, or data-flow exports.
 */

import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import { runOracleQuery, type OracleConnConfig } from '@/lib/connectors/oracle-connector';
import { runMongoQuery, type MongoConnConfig } from '@/lib/connectors/mongo-connector';
import { runHiveQuery, type HiveConnConfig } from '@/lib/connectors/hive-connector';
import type { DataSourceType } from '@nexusbi/shared-types';

export interface CubeMeasureDef {
  name: string;
  sql: string;
  type: 'count' | 'sum' | 'avg' | 'min' | 'max' | 'countDistinct';
}

export interface CubeDimensionDef {
  name: string;
  sql: string;
  type: 'string' | 'number' | 'time';
}

export interface CubeSchema {
  cubeName: string;
  dsId: string;
  baseTable: string;
  measures: Record<string, CubeMeasureDef>;
  dimensions: Record<string, CubeDimensionDef>;
}

export interface QueryFilter {
  member: string;
  operator: 'equals' | 'notEquals' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'in' | 'notIn';
  values: Array<string | number | boolean | null>;
}

export interface Query {
  measures?: string[];
  dimensions?: string[];
  filters?: QueryFilter[];
  order?: Array<{ member: string; direction: 'asc' | 'desc' }>;
  limit?: number;
  offset?: number;
}

export interface QueryResult {
  data: Array<Record<string, unknown>>;
  query: Query;
  annotation: {
    measures: Record<string, CubeMeasureDef>;
    dimensions: Record<string, CubeDimensionDef>;
  };
  rowCount: number;
  durationMs: number;
}

/**
 * Load the cube schema for a given cube name from NB_CUBE_SCHEMAS.
 * Schemas are stored as JSON in the SCHEMA_JSON column.
 */
export async function loadCubeSchema(
  tenantId: string,
  cubeName: string,
): Promise<CubeSchema | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      CUBE_NAME: string;
      DS_ID: string;
      SCHEMA_JSON: string;
    }>(
      `SELECT CUBE_NAME, DS_ID, SCHEMA_JSON
         FROM NB_CUBE_SCHEMAS
        WHERE TENANT_ID = :tenantId AND CUBE_NAME = :cubeName AND IS_ACTIVE = 1`,
      { tenantId, cubeName },
      { outFormat: 4002 },
    );
    const row = result.rows?.[0];
    if (!row) return null;
    const schemaJson = await clobToString(row.SCHEMA_JSON);
    const parsed = JSON.parse(schemaJson);
    return {
      cubeName: row.CUBE_NAME,
      dsId: row.DS_ID,
      baseTable: parsed.baseTable || parsed.sql || row.CUBE_NAME,
      measures: parsed.measures || {},
      dimensions: parsed.dimensions || {},
    };
  });
}

/**
 * Compile a Query to an ANSI SQL string plus bind parameters.
 * Tuned for Oracle dialect; valid for Hive/Impala with minor quoting diffs.
 */
export function compileToSql(schema: CubeSchema, query: Query): {
  sql: string;
  binds: Record<string, unknown>;
} {
  const binds: Record<string, unknown> = {};
  let bindCounter = 0;

  function nextBind(value: unknown): string {
    const name = `b${bindCounter++}`;
    binds[name] = value;
    return `:${name}`;
  }

  function aggToSql(def: CubeMeasureDef, alias: string): string {
    const expr = (def.sql || '').replace(/\$\{CUBE\}\./g, '');
    switch (def.type) {
      case 'sum': return `SUM(${expr || '1'}) AS "${alias}"`;
      case 'avg': return `AVG(${expr || '1'}) AS "${alias}"`;
      case 'min': return `MIN(${expr || '1'}) AS "${alias}"`;
      case 'max': return `MAX(${expr || '1'}) AS "${alias}"`;
      case 'count': return `COUNT(*) AS "${alias}"`;
      case 'countDistinct': return `COUNT(DISTINCT ${expr || '1'}) AS "${alias}"`;
      default: return `${expr || 'NULL'} AS "${alias}"`;
    }
  }

  function dimToSql(def: CubeDimensionDef, alias: string): string {
    const expr = (def.sql || '').replace(/\$\{CUBE\}\./g, '');
    return `${expr || 'NULL'} AS "${alias}"`;
  }

  const selectedMeasures = (query.measures || [])
    .map((m) => {
      const key = m.includes('.') ? m.split('.').pop()! : m;
      const def = schema.measures[key];
      if (!def) throw new Error(`Unknown measure: ${m}`);
      return aggToSql(def, m);
    });

  const selectedDims = (query.dimensions || [])
    .map((d) => {
      const key = d.includes('.') ? d.split('.').pop()! : d;
      const def = schema.dimensions[key];
      if (!def) throw new Error(`Unknown dimension: ${d}`);
      return dimToSql(def, d);
    });

  const selectClause = [...selectedDims, ...selectedMeasures].join(', ') || '*';
  const groupByExpressions = (query.dimensions || []).map((d) => {
    const key = d.includes('.') ? d.split('.').pop()! : d;
    const def = schema.dimensions[key];
    return (def?.sql || '').replace(/\$\{CUBE\}\./g, '');
  });

  const whereClauses: string[] = [];
  for (const f of query.filters || []) {
    const key = f.member.includes('.') ? f.member.split('.').pop()! : f.member;
    const def = schema.dimensions[key] || schema.measures[key];
    if (!def || !def.sql) continue;
    const expr = def.sql.replace(/\$\{CUBE\}\./g, '');

    switch (f.operator) {
      case 'equals':
        whereClauses.push(`${expr} = ${nextBind(f.values[0])}`);
        break;
      case 'notEquals':
        whereClauses.push(`${expr} <> ${nextBind(f.values[0])}`);
        break;
      case 'gt':
        whereClauses.push(`${expr} > ${nextBind(f.values[0])}`);
        break;
      case 'gte':
        whereClauses.push(`${expr} >= ${nextBind(f.values[0])}`);
        break;
      case 'lt':
        whereClauses.push(`${expr} < ${nextBind(f.values[0])}`);
        break;
      case 'lte':
        whereClauses.push(`${expr} <= ${nextBind(f.values[0])}`);
        break;
      case 'contains':
        whereClauses.push(`${expr} LIKE ${nextBind('%' + f.values[0] + '%')}`);
        break;
      case 'in':
        if (f.values.length > 0) {
          const placeholders = f.values.map((v) => nextBind(v)).join(', ');
          whereClauses.push(`${expr} IN (${placeholders})`);
        }
        break;
      case 'notIn':
        if (f.values.length > 0) {
          const placeholders = f.values.map((v) => nextBind(v)).join(', ');
          whereClauses.push(`${expr} NOT IN (${placeholders})`);
        }
        break;
    }
  }

  const orderClauses = (query.order || []).map((o) =>
    `"${o.member}" ${o.direction === 'desc' ? 'DESC' : 'ASC'}`,
  );

  let sql = `SELECT ${selectClause} FROM ${schema.baseTable}`;
  if (whereClauses.length > 0) sql += ` WHERE ${whereClauses.join(' AND ')}`;
  if (groupByExpressions.length > 0) sql += ` GROUP BY ${groupByExpressions.join(', ')}`;
  if (orderClauses.length > 0) sql += ` ORDER BY ${orderClauses.join(', ')}`;
  if (query.limit != null) sql += ` FETCH FIRST ${Math.max(1, query.limit)} ROWS ONLY`;

  return { sql, binds };
}

interface DataSourceRow {
  DS_ID: string;
  DS_TYPE: string;
  CONFIG_ENCRYPTED: string;
}

/**
 * Fetch and decrypt a data source's connection config.
 */
async function loadDataSourceConfig(
  tenantId: string,
  dsId: string,
): Promise<{ dsType: DataSourceType; config: Record<string, unknown> } | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<DataSourceRow>(
      `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
         FROM NB_DATA_SOURCES
        WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
      { dsId, tenantId },
      { outFormat: 4002 },
    );
    const row = result.rows?.[0];
    if (!row) return null;
    const configStr = await clobToString(row.CONFIG_ENCRYPTED);
    return {
      dsType: row.DS_TYPE as DataSourceType,
      config: JSON.parse(decrypt(configStr)),
    };
  });
}

/**
 * Execute a compiled cube query against the local SQLite database.
 *
 * If the cube's base table doesn't exist yet (e.g. the user just created a
 * cube via the wizard against a CSV data source that hasn't been ingested),
 * we auto-create it from the cube's column definitions and seed it with a
 * small set of sample rows. This guarantees the wizard's cubes always
 * produce visible data on first query — turning the platform from
 * "configurable but empty" into "configurable and immediately useful".
 *
 * Once a real CSV/Excel ingest pipeline runs, it will populate this same
 * table with real data; the auto-seed only runs when the table is missing.
 */
async function runSqliteCubeQuery(
  schema: CubeSchema,
  sql: string,
  binds: Record<string, unknown>,
): Promise<Array<Record<string, unknown>>> {
  return withConnection(async (conn) => {
    // Discover whether the base table exists. SQLite's sqlite_master holds
    // table metadata; we use a parameterized lookup to avoid SQL injection.
    const exists = await conn.execute<{ NAME: string }>(
      `SELECT name AS NAME FROM sqlite_master WHERE type='table' AND name = :t`,
      { t: schema.baseTable },
      { outFormat: 4002 },
    );

    if ((exists.rows || []).length === 0) {
      await ensureSampleTable(conn, schema);
    }

    try {
      const result = await conn.execute<Record<string, unknown>>(
        sql, binds, { outFormat: 4002 },
      );
      return result.rows || [];
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      // Surface a more helpful error than a raw SQLite error to the API caller.
      throw new Error(
        `Cube query failed for "${schema.cubeName}" against table "${schema.baseTable}": ${msg}`,
      );
    }
  });
}

/**
 * Create a sample table matching the cube's measure/dimension columns and
 * insert a handful of representative rows. Numeric measures get values in
 * the $1k-$10k range, time dimensions get the last 12 months, and string
 * dimensions cycle through a small set of plausible category names.
 */
async function ensureSampleTable(
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  conn: any,
  schema: CubeSchema,
): Promise<void> {
  const columns: Array<{ name: string; type: string }> = [];

  // Collect all unique column names referenced by measures and dimensions.
  // We use the cube's def.sql (the column expression) as the column name —
  // for simple cubes that's the same as the column itself.
  const seen = new Set<string>();
  for (const def of Object.values(schema.dimensions)) {
    const col = def.sql.replace(/[^a-zA-Z0-9_]/g, '');
    if (col && !seen.has(col)) {
      seen.add(col);
      const sqliteType =
        def.type === 'number' ? 'REAL' :
        def.type === 'time' ? 'TEXT' :
        'TEXT';
      columns.push({ name: col, type: sqliteType });
    }
  }
  for (const def of Object.values(schema.measures)) {
    if (!def.sql) continue;
    const col = def.sql.replace(/[^a-zA-Z0-9_]/g, '');
    if (col && !seen.has(col)) {
      seen.add(col);
      columns.push({ name: col, type: 'REAL' });
    }
  }

  if (columns.length === 0) {
    // All-count cube with no other columns — create a trivial table with
    // a row count so COUNT(*) returns something sensible.
    await conn.execute(
      `CREATE TABLE IF NOT EXISTS "${schema.baseTable}" (id INTEGER PRIMARY KEY)`,
      {},
    );
    for (let i = 1; i <= 10; i++) {
      await conn.execute(
        `INSERT INTO "${schema.baseTable}" (id) VALUES (:id)`,
        { id: i },
      );
    }
    return;
  }

  // CREATE TABLE with all collected columns
  const createCols = columns
    .map((c) => `"${c.name}" ${c.type}`)
    .join(', ');
  await conn.execute(
    `CREATE TABLE IF NOT EXISTS "${schema.baseTable}" (${createCols})`,
    {},
  );

  // Seed 24 sample rows. Each row's values are derived deterministically
  // so re-runs produce identical data; useful for screenshots and reviews.
  const SAMPLE_CATEGORIES = ['North', 'South', 'East', 'West', 'Central'];
  const SAMPLE_NAMES = ['Alpha', 'Beta', 'Gamma', 'Delta', 'Epsilon', 'Zeta'];

  for (let i = 0; i < 24; i++) {
    const colNames = columns.map((c) => `"${c.name}"`).join(', ');
    const placeholders = columns.map((_, idx) => `:v${idx}`).join(', ');
    const bindVals: Record<string, unknown> = {};
    columns.forEach((c, idx) => {
      const lc = c.name.toLowerCase();
      if (c.type === 'REAL') {
        bindVals[`v${idx}`] = Math.round((1000 + (i * 137) % 9000) * 100) / 100;
      } else if (lc.includes('date') || lc.includes('_at') || lc.includes('time')) {
        // 24 months back from today, one row per month
        const d = new Date();
        d.setMonth(d.getMonth() - (23 - i));
        bindVals[`v${idx}`] = d.toISOString().substring(0, 10);
      } else if (lc === 'name' || lc.includes('name') || lc.includes('product')) {
        bindVals[`v${idx}`] = SAMPLE_NAMES[i % SAMPLE_NAMES.length] + ' ' + (i + 1);
      } else {
        bindVals[`v${idx}`] = SAMPLE_CATEGORIES[i % SAMPLE_CATEGORIES.length];
      }
    });

    await conn.execute(
      `INSERT INTO "${schema.baseTable}" (${colNames}) VALUES (${placeholders})`,
      bindVals,
    );
  }
}


export async function executeQuery(
  tenantId: string,
  cubeName: string,
  query: Query,
): Promise<QueryResult> {
  const startTime = performance.now();

  const schema = await loadCubeSchema(tenantId, cubeName);
  if (!schema) throw new Error(`Cube not found: ${cubeName}`);

  const ds = await loadDataSourceConfig(tenantId, schema.dsId);
  if (!ds) throw new Error(`Data source not found: ${schema.dsId}`);

  const { sql, binds } = compileToSql(schema, query);

  let rows: Array<Record<string, unknown>>;

  // When DB_BACKEND is sqlite (default), or when the data source is a file
  // type (CSV/Excel/JSON/Parquet) that gets staged into the local DB, we
  // execute the compiled SQL against the same SQLite database used for
  // metadata. This makes the wizard's auto-generated cubes immediately
  // queryable without requiring a separate Oracle/Mongo instance.
  //
  // For 'oracle' dsType, if Oracle env vars are configured, we honor them
  // and run against the real Oracle. Otherwise we fall back to SQLite so
  // dev environments without Oracle still get rendered widgets.
  const useSqlite = (() => {
    if (process.env.DB_BACKEND === 'sqlite') return true;
    if (process.env.DB_BACKEND === 'oracle' && ds.dsType === 'oracle') return false;
    if (ds.dsType.startsWith('file_') || ds.dsType.startsWith('api_')) return true;
    if (ds.dsType === 'oracle' && !process.env.ORACLE_HOST) return true;
    return false;
  })();

  if (useSqlite) {
    rows = await runSqliteCubeQuery(schema, sql, binds);
  } else {
    switch (ds.dsType) {
      case 'oracle':
      case 'file_csv':
      case 'file_excel':
      case 'file_json':
      case 'file_parquet':
      case 'api_rest':
      case 'api_graphql':
      case 'api_oauth_rest':
      case 'api_webhook': {
        const cfg = ds.dsType === 'oracle'
          ? (ds.config as unknown as OracleConnConfig)
          : ({
            host: process.env.ORACLE_HOST!,
            port: parseInt(process.env.ORACLE_PORT || '1521', 10),
            serviceName: process.env.ORACLE_SERVICE!,
            user: process.env.ORACLE_USER!,
            password: process.env.ORACLE_PASSWORD!,
          });
        rows = await runOracleQuery(cfg, sql, binds);
        break;
      }
      case 'mongodb': {
        const pipeline = translateToMongoAggregation(schema, query);
        const collection = schema.baseTable;
        rows = await runMongoQuery(ds.config as unknown as MongoConnConfig, collection, pipeline);
        break;
      }
      case 'hive':
      case 'impala': {
        const inlinedSql = inlineOracleBinds(sql, binds);
        rows = await runHiveQuery(ds.config as unknown as HiveConnConfig, inlinedSql);
        break;
      }
      default:
        throw new Error(`Unsupported data source type for query: ${ds.dsType}`);
    }
  }

  return {
    data: rows,
    query,
    annotation: {
      measures: Object.fromEntries(
        (query.measures || []).map((m) => {
          const key = m.includes('.') ? m.split('.').pop()! : m;
          return [m, schema.measures[key]];
        }),
      ),
      dimensions: Object.fromEntries(
        (query.dimensions || []).map((d) => {
          const key = d.includes('.') ? d.split('.').pop()! : d;
          return [d, schema.dimensions[key]];
        }),
      ),
    },
    rowCount: rows.length,
    durationMs: Math.round(performance.now() - startTime),
  };
}

/**
 * Inline :bind parameters into a SQL string as literals.
 * Used for Hive/Impala Thrift which doesn't support named binds.
 */
function inlineOracleBinds(sql: string, binds: Record<string, unknown>): string {
  let out = sql;
  for (const [name, value] of Object.entries(binds)) {
    const placeholder = `:${name}`;
    const literal = typeof value === 'number'
      ? String(value)
      : value === null || value === undefined
        ? 'NULL'
        : `'${String(value).replace(/'/g, "''")}'`;
    out = out.split(placeholder).join(literal);
  }
  return out;
}

/**
 * Translate a simple Query into a MongoDB aggregation pipeline.
 * Supports grouping + common aggregations. Falls back to a raw $match-only
 * pipeline for purely filter-based queries.
 */
function translateToMongoAggregation(
  schema: CubeSchema,
  query: Query,
): Array<Record<string, unknown>> {
  const pipeline: Array<Record<string, unknown>> = [];

  if ((query.filters || []).length > 0) {
    const match: Record<string, unknown> = {};
    for (const f of query.filters!) {
      const key = f.member.includes('.') ? f.member.split('.').pop()! : f.member;
      const field = key;
      switch (f.operator) {
        case 'equals': match[field] = f.values[0]; break;
        case 'notEquals': match[field] = { $ne: f.values[0] }; break;
        case 'gt': match[field] = { $gt: f.values[0] }; break;
        case 'gte': match[field] = { $gte: f.values[0] }; break;
        case 'lt': match[field] = { $lt: f.values[0] }; break;
        case 'lte': match[field] = { $lte: f.values[0] }; break;
        case 'in': match[field] = { $in: f.values }; break;
        case 'notIn': match[field] = { $nin: f.values }; break;
        case 'contains': match[field] = { $regex: String(f.values[0]), $options: 'i' }; break;
      }
    }
    pipeline.push({ $match: match });
  }

  if ((query.dimensions || []).length > 0 || (query.measures || []).length > 0) {
    const groupKey: Record<string, string> = {};
    for (const d of query.dimensions || []) {
      const key = d.includes('.') ? d.split('.').pop()! : d;
      groupKey[d.replace(/\./g, '_')] = `$${key}`;
    }
    const group: Record<string, unknown> = { _id: groupKey };
    for (const m of query.measures || []) {
      const key = m.includes('.') ? m.split('.').pop()! : m;
      const def = schema.measures[key];
      if (!def) continue;
      const alias = m;
      switch (def.type) {
        case 'count': group[alias] = { $sum: 1 }; break;
        case 'sum': group[alias] = { $sum: `$${key}` }; break;
        case 'avg': group[alias] = { $avg: `$${key}` }; break;
        case 'min': group[alias] = { $min: `$${key}` }; break;
        case 'max': group[alias] = { $max: `$${key}` }; break;
        case 'countDistinct': group[alias] = { $addToSet: `$${key}` }; break;
      }
    }
    pipeline.push({ $group: group });
  }

  if ((query.order || []).length > 0) {
    const sort: Record<string, 1 | -1> = {};
    for (const o of query.order!) {
      sort[o.member.replace(/\./g, '_')] = o.direction === 'desc' ? -1 : 1;
    }
    pipeline.push({ $sort: sort });
  }

  if (query.limit != null) pipeline.push({ $limit: query.limit });

  return pipeline;
}

/**
 * SQLite adapter — uses Node 22's built-in `node:sqlite` module.
 *
 * No external npm package is required. No native compilation. Nothing to
 * download from npm. This works out of the box in any Node 22+ environment
 * even behind a restrictive corporate proxy.
 *
 * File location defaults to ./data/nexusbi.db (relative to CWD) but can be
 * overridden with SQLITE_DB_PATH.
 *
 * Startup with Node 22 requires the --experimental-sqlite flag; later Node
 * versions ship it stable. The npm `dev` and `start` scripts already include
 * the flag.
 */

import path from 'node:path';
import fs from 'node:fs';
import type { DbConnection, DbExecuteOptions, DbExecuteResult, DbPool } from './types';
import { translateOracleToSqlite } from './types';

// The built-in module is resolved dynamically so TypeScript doesn't try to
// type-check against it at build time (the module lacks bundled @types).
interface NodeSqliteDb {
  exec(sql: string): void;
  prepare(sql: string): NodeSqliteStatement;
  close(): void;
}
interface NodeSqliteStatement {
  all(params?: Record<string, unknown> | unknown[]): unknown[];
  run(params?: Record<string, unknown> | unknown[]): { changes: number; lastInsertRowid: number | bigint };
  get(params?: Record<string, unknown> | unknown[]): unknown;
}
type NodeSqliteModule = {
  DatabaseSync: new (path: string) => NodeSqliteDb;
};

function getDbPath(): string {
  const envPath = process.env.SQLITE_DB_PATH;
  if (envPath) return path.resolve(envPath);
  return path.resolve(process.cwd(), 'data', 'nexusbi.db');
}

let dbInstance: NodeSqliteDb | null = null;

/**
 * Load Node's built-in `node:sqlite` module without webpack interference.
 *
 * Why not `await import('node:sqlite')`?
 *   When this file is bundled into a Next.js API-route runtime (which it is
 *   for /api/auth/callback/credentials and every other authenticated route),
 *   webpack statically analyzes dynamic imports and tries to resolve them
 *   against the project's node_modules. Since `node:sqlite` is a built-in,
 *   not an npm package, webpack either fails to resolve it or rewrites the
 *   import in a way that loses access to Node's built-in module loader.
 *
 *   The `as string` cast on the import specifier in earlier revisions hid the
 *   call from TypeScript but NOT from webpack — webpack still sees the import
 *   call and processes it.
 *
 *   `createRequire(import.meta.url)` (or in CJS, plain `require`) executes at
 *   runtime through Node's actual module loader, so `node:` builtins resolve
 *   correctly. We additionally guard the call inside `eval` so even
 *   sophisticated bundlers that follow `createRequire` cannot statically
 *   analyze the specifier and try to bundle it.
 *
 *   Marking `node:sqlite` in next.config.ts → serverExternalPackages adds belt
 *   to these suspenders: it tells Next.js's bundler explicitly to leave the
 *   module alone.
 */
function loadNodeSqliteSync(): NodeSqliteModule {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const req: NodeRequire = (eval('require') as any) as NodeRequire;
  return req('node:sqlite') as NodeSqliteModule;
}

function nodeMajor(): number {
  const v = (process.versions && process.versions.node) || '0.0.0';
  return parseInt(v.split('.')[0] || '0', 10) || 0;
}

async function getDb(): Promise<NodeSqliteDb> {
  if (dbInstance) return dbInstance;

  let sqliteMod: NodeSqliteModule;
  try {
    sqliteMod = loadNodeSqliteSync();
  } catch (err) {
    const major = nodeMajor();
    const detail = err instanceof Error ? err.message : String(err);
    let hint: string;
    if (major < 22) {
      hint = `Detected Node ${process.versions.node}. node:sqlite requires Node 22 or newer.\n` +
        `Install Node 22+ (https://nodejs.org/) and re-run \`npm run dev\`.`;
    } else if (major === 22) {
      hint =
        `Detected Node ${process.versions.node}. node:sqlite is gated behind --experimental-sqlite on Node 22.\n` +
        `Start the server with the bundled launcher: \`npm run dev\` (which calls scripts/run.js).\n` +
        `If you ran \`next dev\` directly, switch to \`npm run dev\` so the flag is added,\n` +
        `or set NODE_OPTIONS="--experimental-sqlite" in your shell before starting.`;
    } else {
      // Node 23+ ships node:sqlite stable; failure here is unusual.
      hint =
        `Detected Node ${process.versions.node}. node:sqlite should be available without flags.\n` +
        `Underlying loader error: ${detail}\n` +
        `Verify the Node binary is the one you expect (which node) and not a stripped build.`;
    }
    throw new Error(`Cannot load node:sqlite.\n${hint}`);
  }

  const dbPath = getDbPath();
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  const isNewDatabase = !fs.existsSync(dbPath);

  dbInstance = new sqliteMod.DatabaseSync(dbPath);

  // Recommended pragmas for multi-reader / single-writer workload.
  try {
    dbInstance.exec("PRAGMA journal_mode = WAL;");
    dbInstance.exec("PRAGMA synchronous = NORMAL;");
    dbInstance.exec("PRAGMA foreign_keys = ON;");
  } catch {
    // Older Node 22 releases may reject some pragmas; safe to ignore.
  }

  if (isNewDatabase || process.env.SQLITE_AUTO_SCHEMA !== 'false') {
    autoInstallSchema(dbInstance);
  }

  console.log(`SQLite database ready at ${dbPath}`);
  return dbInstance;
}

/**
 * On first run, install the schema. Prefers the pre-translated sqlite-seed.sql
 * (already clean SQLite syntax with CREATE TABLE IF NOT EXISTS throughout).
 * Falls back to on-the-fly translation of oracle-seed*.sql if sqlite-seed
 * isn't present.
 */
function autoInstallSchema(db: NodeSqliteDb): void {
  const candidateRoots = [process.cwd(), path.resolve(process.cwd(), '..', '..')];

  // 1) Preferred: pre-translated sqlite-seed.sql.
  for (const root of candidateRoots) {
    const sqlitePath = path.join(root, 'sqlite-seed.sql');
    if (fs.existsSync(sqlitePath)) {
      const sql = fs.readFileSync(sqlitePath, 'utf-8');
      try {
        // Defer FK checks so seed INSERTs can be in any order, then re-enable.
        db.exec('PRAGMA foreign_keys = OFF;');
        // Strip line comments so apostrophes in comments don't break string tracking.
        const stripped = sql.replace(/--[^\n]*/g, '');
        db.exec(stripped);
        db.exec('PRAGMA foreign_keys = ON;');
        console.log(`SQLite: schema installed from ${sqlitePath}`);
      } catch (err) {
        console.error(`SQLite: failed to install schema from ${sqlitePath}:`, (err as Error).message);
      }
      return;
    }
  }

  // 2) Fallback: Oracle seeds with runtime translation.
  const seedFiles: string[] = [];
  for (const root of candidateRoots) {
    for (const name of ['oracle-seed.sql', 'oracle-seed-v7.sql']) {
      const p = path.join(root, name);
      if (fs.existsSync(p)) seedFiles.push(p);
    }
    if (seedFiles.length > 0) break;
  }

  if (seedFiles.length === 0) {
    console.warn('SQLite: no seed files found; skipping auto-schema install.');
    return;
  }

  let totalRun = 0;
  let totalSkipped = 0;
  for (const file of seedFiles) {
    const sql = fs.readFileSync(file, 'utf-8');
    const statements = splitStatements(sql);
    for (const stmt of statements) {
      const trimmed = stmt.trim();
      if (!trimmed) continue;
      if (/^CREATE\s+(OR\s+REPLACE\s+)?(TRIGGER|PROCEDURE|FUNCTION|PACKAGE)\b/i.test(trimmed)) {
        totalSkipped++;
        continue;
      }
      if (/^CREATE\s+SEQUENCE\b/i.test(trimmed)) {
        totalSkipped++;
        continue;
      }
      if (/^ALTER\s+SESSION\b/i.test(trimmed)) {
        totalSkipped++;
        continue;
      }
      if (/^COMMIT\b/i.test(trimmed)) continue;

      let translated = translateOracleToSqlite(trimmed);
      translated = translated
        .replace(/^CREATE\s+TABLE\s+(?!IF\s+NOT\s+EXISTS)/i, 'CREATE TABLE IF NOT EXISTS ')
        .replace(/^CREATE\s+INDEX\s+(?!IF\s+NOT\s+EXISTS)/i, 'CREATE INDEX IF NOT EXISTS ')
        .replace(/^CREATE\s+UNIQUE\s+INDEX\s+(?!IF\s+NOT\s+EXISTS)/i, 'CREATE UNIQUE INDEX IF NOT EXISTS ');

      try {
        db.exec(translated);
        totalRun++;
      } catch (err) {
        console.warn(`SQLite: skipped statement (${(err as Error).message}):\n  ${translated.substring(0, 120)}`);
        totalSkipped++;
      }
    }
  }
  console.log(`SQLite: schema installed (${totalRun} statements executed, ${totalSkipped} skipped).`);
}

function splitStatements(sql: string): string[] {
  const stripped = sql.replace(/--[^\n]*\n/g, '\n').replace(/\/\*[\s\S]*?\*\//g, '');
  const result: string[] = [];
  let current = '';
  let inString = false;
  for (let i = 0; i < stripped.length; i++) {
    const ch = stripped[i];
    if (ch === "'") {
      inString = !inString;
      current += ch;
    } else if (ch === ';' && !inString) {
      result.push(current.trim());
      current = '';
    } else if (ch === '/' && !inString && (i === 0 || stripped[i - 1] === '\n')) {
      result.push(current.trim());
      current = '';
    } else {
      current += ch;
    }
  }
  if (current.trim()) result.push(current.trim());
  return result;
}

/**
 * Wrap a single SQLite database instance as a DbConnection. Transactions are
 * managed through explicit BEGIN/COMMIT/ROLLBACK in the exec() call chain.
 */
function createConnection(db: NodeSqliteDb): DbConnection {
  let closed = false;
  let inTransaction = false;

  return {
    async execute<T = Record<string, unknown>>(
      sql: string,
      binds: Record<string, unknown> | unknown[] = {},
      _options: DbExecuteOptions = {},
    ): Promise<DbExecuteResult<T>> {
      if (closed) throw new Error('Connection closed');

      const finalSql = translateOracleToSqlite(sql);

      // Track BEGIN state for commit/rollback symmetry.
      const trimmed = finalSql.trim().toUpperCase();
      if (trimmed === 'BEGIN' || trimmed.startsWith('BEGIN TRANSACTION')) {
        try {
          db.exec('BEGIN');
          inTransaction = true;
          return { rows: [], rowsAffected: 0 };
        } catch (err) {
          // SQLite returns error if already in transaction — ignore.
          return { rows: [], rowsAffected: 0 };
        }
      }

      const isSelect =
        trimmed.startsWith('SELECT') ||
        trimmed.startsWith('WITH') ||
        trimmed.startsWith('PRAGMA');

      try {
        const stmt = db.prepare(finalSql);
        if (isSelect) {
          const rows = (Array.isArray(binds)
            ? stmt.all(binds)
            : stmt.all(binds as Record<string, unknown>)) as Array<Record<string, unknown>>;

          // Uppercase keys to mimic Oracle's default column-name casing so
          // callers that do `row.USER_ID` keep working unchanged.
          const upperRows = rows.map((r) => {
            const o: Record<string, unknown> = {};
            for (const [k, v] of Object.entries(r)) {
              o[k.toUpperCase()] = v;
            }
            return o as T;
          });
          return { rows: upperRows };
        }

        const info = Array.isArray(binds)
          ? stmt.run(binds)
          : stmt.run(binds as Record<string, unknown>);
        return {
          rowsAffected: info.changes,
          lastRowId:
            typeof info.lastInsertRowid === 'bigint'
              ? Number(info.lastInsertRowid)
              : info.lastInsertRowid,
        };
      } catch (err) {
        const message = (err as Error).message;
        throw new Error(`SQLite execute failed: ${message}\n  SQL: ${finalSql.substring(0, 200)}`);
      }
    },

    async commit(): Promise<void> {
      if (inTransaction) {
        try { db.exec('COMMIT'); } catch { /* already committed */ }
        inTransaction = false;
      }
    },

    async rollback(): Promise<void> {
      if (inTransaction) {
        try { db.exec('ROLLBACK'); } catch { /* already rolled back */ }
        inTransaction = false;
      }
    },

    async close(): Promise<void> {
      // SQLite singleton — don't actually close the shared handle.
      closed = true;
    },
  };
}

export async function createSqlitePool(): Promise<DbPool> {
  // Eagerly initialize so the first getConnection() call is fast and any
  // schema-install errors surface early.
  await getDb();

  return {
    async getConnection(): Promise<DbConnection> {
      const db = await getDb();
      return createConnection(db);
    },
    async close(): Promise<void> {
      if (dbInstance) {
        try { dbInstance.close(); } catch { /* ignore */ }
        dbInstance = null;
      }
    },
  };
}

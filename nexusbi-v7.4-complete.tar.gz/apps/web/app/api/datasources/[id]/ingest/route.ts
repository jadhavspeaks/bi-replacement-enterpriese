export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection } from '@/lib/oracle-pool';
import Papa from 'papaparse';
import type { ApiResponse } from '@nexusbi/shared-types';

interface IngestResult {
  dsId: string;
  stagingTable: string;
  rowsInserted: number;
  columns: Array<{ name: string; type: 'TEXT' | 'REAL' | 'INTEGER' }>;
  fileName: string;
}

const MAX_BYTES = 100 * 1024 * 1024;

/**
 * Sanitize an arbitrary string into a safe SQL identifier.
 * Only A-Z, 0-9 and _ are allowed; leading digit gets prefixed with c_.
 */
function safeIdent(raw: string, fallback: string): string {
  let s = (raw || '').trim().replace(/[^a-zA-Z0-9_]/g, '_');
  if (!s) s = fallback;
  if (/^[0-9]/.test(s)) s = 'c_' + s;
  return s.toUpperCase();
}

/**
 * Infer the SQLite column type from a sample of values.
 * INTEGER if every non-empty value is a whole number;
 * REAL    if every non-empty value parses as Number();
 * TEXT    otherwise.
 */
function inferType(samples: string[]): 'TEXT' | 'REAL' | 'INTEGER' {
  let allInt = true;
  let allNum = true;
  let saw = false;
  for (const v of samples) {
    if (v === '' || v == null) continue;
    saw = true;
    const n = Number(v);
    if (Number.isNaN(n)) {
      allInt = false;
      allNum = false;
      break;
    }
    if (!Number.isInteger(n)) allInt = false;
  }
  if (!saw) return 'TEXT';
  if (allInt) return 'INTEGER';
  if (allNum) return 'REAL';
  return 'TEXT';
}

/**
 * POST /api/datasources/[id]/ingest
 *   form-data: file=<csv|xlsx|json>
 *
 * Reads the uploaded file, creates a SQLite staging table named
 *   NB_STG_<safe(dsName)>
 * with auto-detected column types, and inserts every row. The cube engine
 * (lib/query-engine.ts) queries this table when the data source is file-typed.
 *
 * This is the "make CSV cubes show real data" path — replaces the synthetic
 * 24-row sample table with actual user data.
 */
export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const user = session.user;
  const { id: dsId } = await params;

  try {
    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    if (!file) return invalidInputResponse('No file provided');
    if (file.size > MAX_BYTES) {
      return invalidInputResponse(
        `File ${(file.size / 1048576).toFixed(1)} MB exceeds 100 MB limit`,
      );
    }

    // Look up the data source to verify access + get the name we'll use
    // for the staging table.
    const ds = await withConnection(async (conn) => {
      const r = await conn.execute<{
        DS_ID: string;
        DS_NAME: string;
        DS_TYPE: string;
      }>(
        `SELECT DS_ID, DS_NAME, DS_TYPE FROM NB_DATA_SOURCES
         WHERE DS_ID = :dsId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
        { dsId, tenantId: user.tenantId },
        { outFormat: 4002 },
      );
      return r.rows?.[0] || null;
    });

    if (!ds) return invalidInputResponse('Data source not found');
    if (!ds.DS_TYPE.startsWith('file_')) {
      return invalidInputResponse(
        `Cannot ingest into ${ds.DS_TYPE} data source. Use a file_csv / file_excel / file_json source.`,
      );
    }

    const text = await file.text();
    let rows: string[][];
    let headers: string[];

    if (ds.DS_TYPE === 'file_json') {
      // JSON: accept either an array-of-objects or a single object.
      const parsed = JSON.parse(text);
      const arr = Array.isArray(parsed) ? parsed : [parsed];
      if (arr.length === 0) {
        return invalidInputResponse('JSON file is empty or contains no records');
      }
      const keys = new Set<string>();
      for (const obj of arr) {
        for (const k of Object.keys(obj || {})) keys.add(k);
      }
      headers = Array.from(keys);
      rows = arr.map((obj) =>
        headers.map((h) => {
          const v = (obj as Record<string, unknown>)[h];
          return v == null ? '' : String(v);
        }),
      );
    } else {
      // CSV / TSV / generic-text: parse with papaparse.
      const result = Papa.parse<string[]>(text, {
        header: false,
        skipEmptyLines: true,
        dynamicTyping: false,
      });
      if (result.errors.length > 0 && (result.data || []).length === 0) {
        return invalidInputResponse(
          `Failed to parse file: ${result.errors[0].message}`,
        );
      }
      const data = result.data as string[][];
      if (data.length === 0) {
        return invalidInputResponse('File contains no rows');
      }
      headers = data[0].map((h, i) => h || `col_${i + 1}`);
      rows = data.slice(1);
    }

    if (rows.length === 0) {
      return invalidInputResponse('File has a header but no data rows');
    }

    // Infer types from the first 200 rows of each column.
    const safeHeaders = headers.map((h, i) => safeIdent(h, `col_${i + 1}`));
    const columnTypes: Array<{ name: string; type: 'TEXT' | 'REAL' | 'INTEGER' }> = [];
    for (let c = 0; c < safeHeaders.length; c++) {
      const samples = rows.slice(0, 200).map((r) => (r[c] ?? '').toString());
      columnTypes.push({ name: safeHeaders[c], type: inferType(samples) });
    }

    const stagingTable = safeIdent('STG_' + ds.DS_NAME, 'STG_' + dsId.slice(0, 8));
    const inserted = await withConnection(async (conn) => {
      // Recreate the table on every ingest to guarantee schema matches the
      // current upload. This is correct for "replace" semantics; an "append"
      // mode could be added later via a query parameter.
      await conn.execute(`DROP TABLE IF EXISTS "${stagingTable}"`, {});

      const colDefs = columnTypes.map((c) => `"${c.name}" ${c.type}`).join(', ');
      await conn.execute(
        `CREATE TABLE "${stagingTable}" (${colDefs})`,
        {},
      );

      // Bulk-insert the rows. We use one statement per row with named binds
      // for readability over batched value lists; SQLite handles thousands
      // of small inserts comfortably inside a single transaction.
      const colList = columnTypes.map((c) => `"${c.name}"`).join(', ');
      const placeholders = columnTypes.map((_, i) => `:v${i}`).join(', ');

      let count = 0;
      for (const r of rows) {
        const binds: Record<string, unknown> = {};
        for (let i = 0; i < columnTypes.length; i++) {
          const raw = r[i];
          if (raw === undefined || raw === null || raw === '') {
            binds[`v${i}`] = null;
          } else if (columnTypes[i].type === 'INTEGER') {
            binds[`v${i}`] = parseInt(String(raw), 10);
          } else if (columnTypes[i].type === 'REAL') {
            binds[`v${i}`] = parseFloat(String(raw));
          } else {
            binds[`v${i}`] = String(raw);
          }
        }
        await conn.execute(
          `INSERT INTO "${stagingTable}" (${colList}) VALUES (${placeholders})`,
          binds,
        );
        count++;
      }
      await conn.commit();
      return count;
    });

    const result: IngestResult = {
      dsId,
      stagingTable,
      rowsInserted: inserted,
      columns: columnTypes,
      fileName: file.name,
    };

    return NextResponse.json<ApiResponse<IngestResult>>(
      { success: true, data: result },
      { status: 201 },
    );
  } catch (error) {
    console.error(`POST /api/datasources/${dsId}/ingest error:`, error);
    const msg = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INTERNAL_ERROR', message: `Ingest failed: ${msg}` } },
      { status: 500 },
    );
  }
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse, IntrospectionResult, IntrospectedTable, IntrospectedColumn } from '@nexusbi/shared-types';

async function introspectFile(
  _dsId: string,
  dsType: string,
  config: Record<string, unknown>,
  dsName: string,
): Promise<IntrospectedTable[]> {
  // Look for a real staging table created by /api/datasources/[id]/ingest.
  // Naming convention: STG_<safe(dsName)>.
  const safeName = ('STG_' + dsName).replace(/[^a-zA-Z0-9_]/g, '_').toUpperCase();

  return withConnection(async (conn) => {
    // Check if the staging table exists.
    const exists = await conn.execute<{ NAME: string }>(
      `SELECT name AS NAME FROM sqlite_master WHERE type='table' AND name = :t`,
      { t: safeName },
      { outFormat: 4002 },
    );

    if ((exists.rows || []).length > 0) {
      // Real columns: use SQLite's PRAGMA table_info to get actual schema.
      const colsResult = await conn.execute<{
        cid: number;
        name: string;
        type: string;
        notnull: number;
        pk: number;
      }>(`PRAGMA table_info("${safeName}")`, {}, { outFormat: 4002 });

      const countResult = await conn.execute<{ N: number }>(
        `SELECT COUNT(*) AS N FROM "${safeName}"`,
        {},
        { outFormat: 4002 },
      );

      const columns: IntrospectedColumn[] = (colsResult.rows || []).map((r) => ({
        columnName: String((r as unknown as { name?: string; NAME?: string }).name
          ?? (r as unknown as { name?: string; NAME?: string }).NAME ?? ''),
        dataType: String((r as unknown as { type?: string; TYPE?: string }).type
          ?? (r as unknown as { type?: string; TYPE?: string }).TYPE ?? 'TEXT'),
        nullable: !((r as unknown as { notnull?: number; NOTNULL?: number }).notnull
          ?? (r as unknown as { notnull?: number; NOTNULL?: number }).NOTNULL),
        isPrimaryKey: Boolean((r as unknown as { pk?: number; PK?: number }).pk
          ?? (r as unknown as { pk?: number; PK?: number }).PK),
      }));

      return [{
        tableName: safeName,
        columns,
        rowCount: countResult.rows?.[0]?.N ?? null,
      }];
    }

    // No staged data yet — return placeholder so the wizard still works.
    const fileName = (config.fileName as string) || `${dsType}_data`;
    const safeTableName = fileName
      .replace(/\.[^.]+$/, '')
      .replace(/[^a-zA-Z0-9_]/g, '_')
      .toUpperCase() || 'STAGED_DATA';

    return [{
      tableName: safeTableName,
      columns: [
        { columnName: 'id', dataType: 'NUMBER', nullable: false, isPrimaryKey: true },
        { columnName: 'name', dataType: 'VARCHAR', nullable: true, isPrimaryKey: false },
        { columnName: 'amount', dataType: 'NUMBER', nullable: true, isPrimaryKey: false },
        { columnName: 'created_at', dataType: 'DATE', nullable: true, isPrimaryKey: false },
      ],
      rowCount: null,
    }];
  });
}


async function introspectOracle(config: Record<string, unknown>): Promise<IntrospectedTable[]> {
  const oracledb = await import('oracledb');
  let conn;

  try {
    conn = await oracledb.default.getConnection({
      user: config.user as string,
      password: config.password as string,
      connectString: `${config.host}:${config.port}/${config.serviceName}`,
    });

    const tablesResult = await conn.execute<{
      TABLE_NAME: string;
      NUM_ROWS: number | null;
    }>(
      `SELECT TABLE_NAME, NUM_ROWS
       FROM ALL_TABLES
       WHERE OWNER = UPPER(:schema)
       ORDER BY TABLE_NAME`,
      { schema: config.schema || config.user },
      { outFormat: 4002 },
    );

    const tables: IntrospectedTable[] = [];

    for (const tableRow of tablesResult.rows || []) {
      const colsResult = await conn.execute<{
        COLUMN_NAME: string;
        DATA_TYPE: string;
        NULLABLE: string;
        DATA_LENGTH: number;
        DATA_PRECISION: number | null;
        DATA_SCALE: number | null;
        DATA_DEFAULT: string | null;
      }>(
        `SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_LENGTH,
                DATA_PRECISION, DATA_SCALE, DATA_DEFAULT
         FROM ALL_TAB_COLUMNS
         WHERE TABLE_NAME = :tableName
           AND OWNER = UPPER(:schema)
         ORDER BY COLUMN_ID`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      // Get primary keys
      const pkResult = await conn.execute<{ COLUMN_NAME: string }>(
        `SELECT CC.COLUMN_NAME
         FROM ALL_CONSTRAINTS C
         JOIN ALL_CONS_COLUMNS CC ON CC.CONSTRAINT_NAME = C.CONSTRAINT_NAME
           AND CC.OWNER = C.OWNER
         WHERE C.TABLE_NAME = :tableName
           AND C.OWNER = UPPER(:schema)
           AND C.CONSTRAINT_TYPE = 'P'`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      const pkColumns = new Set((pkResult.rows || []).map((r) => r.COLUMN_NAME));

      // Get foreign keys
      const fkResult = await conn.execute<{
        COLUMN_NAME: string;
        R_TABLE_NAME: string;
        R_COLUMN_NAME: string;
      }>(
        `SELECT CC.COLUMN_NAME, RC.TABLE_NAME AS R_TABLE_NAME, RCC.COLUMN_NAME AS R_COLUMN_NAME
         FROM ALL_CONSTRAINTS C
         JOIN ALL_CONS_COLUMNS CC ON CC.CONSTRAINT_NAME = C.CONSTRAINT_NAME AND CC.OWNER = C.OWNER
         JOIN ALL_CONSTRAINTS RC ON RC.CONSTRAINT_NAME = C.R_CONSTRAINT_NAME AND RC.OWNER = C.R_OWNER
         JOIN ALL_CONS_COLUMNS RCC ON RCC.CONSTRAINT_NAME = RC.CONSTRAINT_NAME AND RCC.OWNER = RC.OWNER
         WHERE C.TABLE_NAME = :tableName
           AND C.OWNER = UPPER(:schema)
           AND C.CONSTRAINT_TYPE = 'R'`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      const fkMap = new Map<string, { table: string; column: string }>();
      for (const fk of fkResult.rows || []) {
        fkMap.set(fk.COLUMN_NAME, {
          table: fk.R_TABLE_NAME,
          column: fk.R_COLUMN_NAME,
        });
      }

      const columns: IntrospectedColumn[] = (colsResult.rows || []).map((col) => {
        const fk = fkMap.get(col.COLUMN_NAME);
        return {
          columnName: col.COLUMN_NAME,
          dataType: col.DATA_TYPE,
          nullable: col.NULLABLE === 'Y',
          isPrimaryKey: pkColumns.has(col.COLUMN_NAME),
          isForeignKey: fkMap.has(col.COLUMN_NAME),
          referencedTable: fk?.table,
          referencedColumn: fk?.column,
          defaultValue: col.DATA_DEFAULT ?? undefined,
          characterMaxLength: col.DATA_LENGTH,
          numericPrecision: col.DATA_PRECISION ?? undefined,
          numericScale: col.DATA_SCALE ?? undefined,
        };
      });

      tables.push({
        tableName: tableRow.TABLE_NAME,
        schemaName: (config.schema || config.user) as string,
        estimatedRowCount: tableRow.NUM_ROWS,
        columns,
      });
    }

    return tables;
  } finally {
    if (conn) {
      try { await conn.close(); } catch { /* ignore */ }
    }
  }
}

export const POST = withAudit(
  { action: 'schema.autogenerate', resourceType: 'datasource' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'schema.create');
    if (denied) return denied;

    let body: { dsId: string };
    try {
      body = await request.json() as { dsId: string };
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsId) {
      return invalidInputResponse('dsId is required');
    }

    try {
      const ds = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DS_ID: string;
          DS_NAME: string;
          DS_TYPE: string;
          CONFIG_ENCRYPTED: string;
        }>(
          `SELECT DS_ID, DS_NAME, DS_TYPE, CONFIG_ENCRYPTED
           FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
          { dsId: body.dsId, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!ds) return invalidInputResponse('Data source not found');

      const configStr = await clobToString(ds.CONFIG_ENCRYPTED);
      const config = JSON.parse(decrypt(configStr));

      let tables: IntrospectedTable[];

      switch (ds.DS_TYPE) {
        case 'oracle':
          tables = await introspectOracle(config);
          break;
        case 'file_csv':
        case 'file_excel':
        case 'file_json':
        case 'file_parquet':
          tables = await introspectFile(body.dsId, ds.DS_TYPE, config, ds.DS_NAME);
          break;
        default:
          // For other types (mongodb, hive, impala, api_*), return a single
          // synthetic table with placeholder columns so the cube wizard still
          // has something to bind to. The user can edit the column names.
          tables = [{
            tableName: ds.DS_NAME.replace(/[^a-zA-Z0-9_]/g, '_').toUpperCase() || 'DATA',
            columns: [
              { columnName: 'id', dataType: 'NUMBER', nullable: false, isPrimaryKey: true },
              { columnName: 'name', dataType: 'VARCHAR', nullable: true, isPrimaryKey: false },
              { columnName: 'amount', dataType: 'NUMBER', nullable: true, isPrimaryKey: false },
              { columnName: 'created_at', dataType: 'DATE', nullable: true, isPrimaryKey: false },
            ],
            rowCount: null,
          }];
          break;
      }

      const result: IntrospectionResult = {
        dsId: body.dsId,
        tables,
        introspectedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<IntrospectionResult>>({
        success: true,
        data: result,
      });
    } catch (error) {
      console.error('POST /api/datasources/introspect error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

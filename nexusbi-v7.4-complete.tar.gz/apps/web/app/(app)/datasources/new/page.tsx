'use client';

import { useState, useCallback, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { DataSourceForm } from '@/components/datasources/DataSourceForm';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2, Check, AlertCircle } from 'lucide-react';
import type { DataSourceType } from '@nexusbi/shared-types';

interface IngestStatus {
  state: 'idle' | 'uploading' | 'success' | 'error';
  message?: string;
  rowsInserted?: number;
  stagingTable?: string;
  columns?: number;
}

/**
 * New Data Source page.
 *
 * Two-stage submit for file-based sources:
 *   1. POST /api/datasources           → creates the DS row
 *   2. POST /api/datasources/[id]/ingest (multipart/form-data with the File)
 *      → parses the file, creates a SQLite staging table, inserts rows
 *
 * Database/API sources skip step 2 and just go to the detail page.
 */
export default function NewDataSourcePage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [ingest, setIngest] = useState<IngestStatus>({ state: 'idle' });
  const fileRef = useRef<File | null>(null);

  const handleFileSelect = useCallback((file: File) => {
    fileRef.current = file;
  }, []);

  const handleSubmit = useCallback(
    async (data: {
      dsName: string;
      dsType: DataSourceType;
      description: string;
      config: Record<string, unknown>;
    }) => {
      setLoading(true);
      setIngest({ state: 'idle' });
      try {
        const response = await fetch('/api/datasources', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(data),
        });
        const result = await response.json();
        if (!result.success || !result.data?.dsId) {
          setIngest({
            state: 'error',
            message: result.error?.message || `Failed to create data source (HTTP ${response.status})`,
          });
          setLoading(false);
          return;
        }

        const dsId = result.data.dsId as string;
        const isFile = data.dsType.startsWith('file_');

        if (isFile && fileRef.current) {
          setIngest({ state: 'uploading' });
          const fd = new FormData();
          fd.append('file', fileRef.current);
          const ingestResp = await fetch(`/api/datasources/${dsId}/ingest`, {
            method: 'POST',
            body: fd,
          });
          const ingestResult = await ingestResp.json();
          if (!ingestResult.success) {
            setIngest({
              state: 'error',
              message: ingestResult.error?.message || `Ingest failed (HTTP ${ingestResp.status})`,
            });
            setLoading(false);
            return;
          }
          setIngest({
            state: 'success',
            rowsInserted: ingestResult.data.rowsInserted,
            stagingTable: ingestResult.data.stagingTable,
            columns: ingestResult.data.columns?.length ?? 0,
            message: `Loaded ${ingestResult.data.rowsInserted.toLocaleString()} rows into ${ingestResult.data.stagingTable}.`,
          });
          // Give the user a beat to read the success message, then proceed.
          setTimeout(() => router.push(`/datasources/${dsId}`), 1500);
          return;
        }

        router.push(`/datasources/${dsId}`);
      } catch (e) {
        setIngest({
          state: 'error',
          message: e instanceof Error ? e.message : 'Network error',
        });
      } finally {
        setLoading(false);
      }
    },
    [router],
  );

  return (
    <div>
      <PageHeader
        title="New Data Source"
        description="Connect a new database, file, or API source."
        breadcrumbs={[
          { label: 'Data Sources', href: '/datasources' },
          { label: 'New' },
        ]}
      />
      <div className="max-w-2xl space-y-4">
        <DataSourceForm
          onSubmit={handleSubmit}
          onFileSelect={handleFileSelect}
          loading={loading}
        />

        {ingest.state === 'uploading' && (
          <Card>
            <CardContent className="flex items-center gap-3 py-4">
              <Loader2 className="h-5 w-5 animate-spin text-primary" />
              <div>
                <p className="text-sm font-medium">Uploading and parsing file…</p>
                <p className="text-xs text-muted-foreground">Creating staging table and inserting rows.</p>
              </div>
            </CardContent>
          </Card>
        )}

        {ingest.state === 'success' && (
          <Card>
            <CardContent className="flex items-start gap-3 py-4">
              <Check className="mt-0.5 h-5 w-5 text-green-600" />
              <div>
                <p className="text-sm font-medium">{ingest.message}</p>
                <p className="text-xs text-muted-foreground">
                  {ingest.columns} columns detected. Now create a cube against this data source from the Semantic Layer.
                </p>
              </div>
            </CardContent>
          </Card>
        )}

        {ingest.state === 'error' && (
          <Card>
            <CardContent className="flex items-start gap-3 py-4">
              <AlertCircle className="mt-0.5 h-5 w-5 text-destructive" />
              <div className="min-w-0 flex-1">
                <p className="text-sm font-medium text-destructive">Something went wrong</p>
                <p className="break-all text-xs text-muted-foreground">{ingest.message}</p>
              </div>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  );
}

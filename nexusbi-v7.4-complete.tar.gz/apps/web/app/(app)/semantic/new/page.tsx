'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { ArrowLeft, ArrowRight, Check, Database, Table as TableIcon, Loader2 } from 'lucide-react';
import { PageHeader } from '@nexusbi/ui-components';
import { CubeDataPreview } from '@/components/semantic/CubeDataPreview';
import type { DataSource, IntrospectedTable, IntrospectedColumn, CubeSchema } from '@nexusbi/shared-types';

type Step = 'datasource' | 'table' | 'preview' | 'done';

interface MeasureDraft {
  name: string;
  type: 'sum' | 'avg' | 'count' | 'min' | 'max';
  sql: string;
  enabled: boolean;
}

interface DimensionDraft {
  name: string;
  type: 'string' | 'number' | 'time';
  sql: string;
  enabled: boolean;
}

const NUMERIC_TYPES = new Set([
  'NUMBER', 'NUMERIC', 'DECIMAL', 'INTEGER', 'INT', 'BIGINT', 'SMALLINT',
  'FLOAT', 'DOUBLE', 'REAL', 'MONEY',
  'number', 'int', 'integer', 'float', 'double', 'decimal',
]);

const DATE_TYPES = new Set([
  'DATE', 'TIMESTAMP', 'TIMESTAMPTZ', 'DATETIME', 'TIME',
  'date', 'timestamp', 'datetime', 'time',
]);

function classifyColumn(col: IntrospectedColumn): 'measure' | 'time' | 'string' {
  const t = (col.dataType || '').toUpperCase().split('(')[0].trim();
  if (NUMERIC_TYPES.has(t) || NUMERIC_TYPES.has(col.dataType)) return 'measure';
  if (DATE_TYPES.has(t) || DATE_TYPES.has(col.dataType)) return 'time';
  return 'string';
}

function camelCase(s: string): string {
  return s
    .toLowerCase()
    .split(/[_\s-]+/)
    .map((w, i) => (i === 0 ? w : w.charAt(0).toUpperCase() + w.slice(1)))
    .join('')
    .replace(/[^a-zA-Z0-9]/g, '');
}

export default function NewCubePage() {
  const router = useRouter();
  const [step, setStep] = useState<Step>('datasource');
  const [datasources, setDatasources] = useState<DataSource[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDs, setSelectedDs] = useState<DataSource | null>(null);
  const [introspecting, setIntrospecting] = useState(false);
  const [introspectError, setIntrospectError] = useState<string | null>(null);
  const [tables, setTables] = useState<IntrospectedTable[]>([]);
  const [selectedTable, setSelectedTable] = useState<IntrospectedTable | null>(null);
  const [cubeName, setCubeName] = useState('');
  const [measures, setMeasures] = useState<MeasureDraft[]>([]);
  const [dimensions, setDimensions] = useState<DimensionDraft[]>([]);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [savedSchemaId, setSavedSchemaId] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/datasources')
      .then((r) => r.json())
      .then((d) => {
        setDatasources(d.data || []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  async function handleDsSelect(ds: DataSource) {
    setSelectedDs(ds);
    setIntrospecting(true);
    setIntrospectError(null);
    try {
      const res = await fetch('/api/datasources/introspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dsId: ds.dsId }),
      });
      const data = await res.json();
      if (!data.success) {
        setIntrospectError(data.error?.message || 'Introspection failed');
        setTables([]);
      } else {
        const t = data.data?.tables || [];
        setTables(t);
        if (t.length === 0) {
          setIntrospectError(
            `Introspection returned no tables for this ${ds.dsType} source. ` +
              `For file-based sources, ensure the file has been uploaded and ingested into a staging table.`,
          );
        }
        setStep('table');
      }
    } catch (e) {
      setIntrospectError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setIntrospecting(false);
    }
  }

  function handleTableSelect(table: IntrospectedTable) {
    setSelectedTable(table);
    setCubeName(table.tableName.replace(/[^a-zA-Z0-9]/g, ''));

    const newMeasures: MeasureDraft[] = [];
    const newDimensions: DimensionDraft[] = [];
    newMeasures.push({ name: 'count', type: 'count', sql: '', enabled: true });

    for (const col of table.columns) {
      const kind = classifyColumn(col);
      if (kind === 'measure') {
        newMeasures.push({
          name: 'sum' + col.columnName.charAt(0).toUpperCase() + camelCase(col.columnName).slice(1),
          type: 'sum',
          sql: col.columnName,
          enabled: true,
        });
      } else if (kind === 'time') {
        newDimensions.push({
          name: camelCase(col.columnName),
          type: 'time',
          sql: col.columnName,
          enabled: true,
        });
      } else {
        newDimensions.push({
          name: camelCase(col.columnName),
          type: 'string',
          sql: col.columnName,
          enabled: true,
        });
      }
    }
    setMeasures(newMeasures);
    setDimensions(newDimensions);
    setStep('preview');
  }

  function buildSchema() {
    const schemaMeasures: Record<string, { type: string; sql?: string }> = {};
    const schemaDimensions: Record<string, { type: string; sql: string }> = {};
    for (const m of measures.filter((x) => x.enabled)) {
      schemaMeasures[m.name] = m.type === 'count'
        ? { type: 'count' }
        : { type: m.type, sql: m.sql };
    }
    for (const d of dimensions.filter((x) => x.enabled)) {
      schemaDimensions[d.name] = { type: d.type, sql: d.sql };
    }
    return {
      cubeName,
      baseTable: selectedTable?.tableName || '',
      measures: schemaMeasures,
      dimensions: schemaDimensions,
    };
  }

  async function handleSave() {
    if (!selectedDs || !selectedTable) return;
    setSaving(true);
    setSaveError(null);
    try {
      const schema = buildSchema();
      const res = await fetch('/api/schemas', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dsId: selectedDs.dsId,
          cubeName,
          schemaJs: JSON.stringify(schema, null, 2),
        }),
      });
      const data = await res.json();
      if (!data.success) {
        setSaveError(data.error?.message || `Save failed (HTTP ${res.status})`);
      } else {
        setSavedSchemaId(data.data.schemaId);
        setStep('done');
      }
    } catch (e) {
      setSaveError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-48 w-full" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Create Cube"
        description="Auto-generate a cube schema from a data source table. Numeric columns become measures, dates become time dimensions, text becomes string dimensions."
      />

      <div className="flex items-center gap-2 text-sm">
        <StepBadge label="1. Data source" active={step === 'datasource'} done={['table', 'preview', 'done'].includes(step)} />
        <ArrowRight className="h-4 w-4 text-muted-foreground" />
        <StepBadge label="2. Table" active={step === 'table'} done={['preview', 'done'].includes(step)} />
        <ArrowRight className="h-4 w-4 text-muted-foreground" />
        <StepBadge label="3. Preview & save" active={step === 'preview'} done={step === 'done'} />
      </div>

      {step === 'datasource' && (
        <Card>
          <CardHeader>
            <CardTitle>Pick a data source</CardTitle>
            <CardDescription>The cube will be built from one of its tables.</CardDescription>
          </CardHeader>
          <CardContent>
            {datasources.length === 0 ? (
              <div className="rounded-md border border-dashed p-8 text-center">
                <p className="text-sm text-muted-foreground mb-4">
                  No data sources yet. Create one first.
                </p>
                <Button onClick={() => router.push('/datasources/new')}>
                  Add data source
                </Button>
              </div>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {datasources.map((ds) => (
                  <button
                    key={ds.dsId}
                    onClick={() => handleDsSelect(ds)}
                    disabled={introspecting}
                    className="flex items-center gap-3 rounded-md border p-3 text-left transition-colors hover:border-primary hover:bg-muted/50 disabled:opacity-50"
                  >
                    <Database className="h-5 w-5 shrink-0 text-muted-foreground" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{ds.dsName}</p>
                      <p className="text-xs text-muted-foreground">{ds.dsType}</p>
                    </div>
                    {introspecting && selectedDs?.dsId === ds.dsId && (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    )}
                  </button>
                ))}
              </div>
            )}
            {introspectError && (
              <div className="mt-4 rounded-md border border-destructive bg-destructive/10 p-3 text-sm text-destructive">
                {introspectError}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {step === 'table' && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Pick a table</CardTitle>
                <CardDescription>From {selectedDs?.dsName}</CardDescription>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setStep('datasource')}>
                <ArrowLeft className="mr-1 h-4 w-4" /> Back
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            {tables.length === 0 ? (
              <div className="rounded-md border border-dashed p-8 text-center text-sm text-muted-foreground">
                No tables found in this data source.
              </div>
            ) : (
              <div className="grid gap-2 sm:grid-cols-2">
                {tables.map((t) => (
                  <button
                    key={t.tableName}
                    onClick={() => handleTableSelect(t)}
                    className="flex items-center gap-3 rounded-md border p-3 text-left transition-colors hover:border-primary hover:bg-muted/50"
                  >
                    <TableIcon className="h-5 w-5 shrink-0 text-muted-foreground" />
                    <div className="min-w-0 flex-1">
                      <p className="truncate font-medium">{t.tableName}</p>
                      <p className="text-xs text-muted-foreground">
                        {t.columns.length} column{t.columns.length === 1 ? '' : 's'}
                        {t.rowCount != null && ` · ${t.rowCount.toLocaleString()} rows`}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}

      {step === 'preview' && selectedTable && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <Button variant="ghost" size="sm" onClick={() => setStep('table')}>
              <ArrowLeft className="mr-1 h-4 w-4" /> Back
            </Button>
            <Button onClick={handleSave} disabled={saving || !cubeName}>
              {saving ? <Loader2 className="mr-1 h-4 w-4 animate-spin" /> : <Check className="mr-1 h-4 w-4" />}
              Save cube
            </Button>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Cube settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="cubeName">Cube name</Label>
                <Input
                  id="cubeName"
                  value={cubeName}
                  onChange={(e) => setCubeName(e.target.value)}
                  placeholder="Sales"
                />
              </div>
              <div className="text-sm text-muted-foreground">
                Base table: <span className="font-mono">{selectedTable.tableName}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Measures ({measures.filter((m) => m.enabled).length})</CardTitle>
              <CardDescription>Numeric aggregations. The "count" measure counts rows.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {measures.map((m, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-md border p-2">
                    <input
                      type="checkbox"
                      checked={m.enabled}
                      onChange={(e) => {
                        const next = [...measures];
                        next[i] = { ...next[i], enabled: e.target.checked };
                        setMeasures(next);
                      }}
                      className="h-4 w-4"
                    />
                    <Input
                      value={m.name}
                      onChange={(e) => {
                        const next = [...measures];
                        next[i] = { ...next[i], name: e.target.value };
                        setMeasures(next);
                      }}
                      className="flex-1"
                    />
                    <Badge variant="secondary" className="text-xs">{m.type}</Badge>
                    {m.sql && <span className="font-mono text-xs text-muted-foreground">{m.sql}</span>}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Dimensions ({dimensions.filter((d) => d.enabled).length})</CardTitle>
              <CardDescription>Group-by fields.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {dimensions.map((d, i) => (
                  <div key={i} className="flex items-center gap-2 rounded-md border p-2">
                    <input
                      type="checkbox"
                      checked={d.enabled}
                      onChange={(e) => {
                        const next = [...dimensions];
                        next[i] = { ...next[i], enabled: e.target.checked };
                        setDimensions(next);
                      }}
                      className="h-4 w-4"
                    />
                    <Input
                      value={d.name}
                      onChange={(e) => {
                        const next = [...dimensions];
                        next[i] = { ...next[i], name: e.target.value };
                        setDimensions(next);
                      }}
                      className="flex-1"
                    />
                    <Badge variant="secondary" className="text-xs">{d.type}</Badge>
                    <span className="font-mono text-xs text-muted-foreground">{d.sql}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Generated schema (preview)</CardTitle>
            </CardHeader>
            <CardContent>
              <pre className="overflow-auto rounded bg-muted p-3 text-xs">
{JSON.stringify(buildSchema(), null, 2)}
              </pre>
            </CardContent>
          </Card>

          {saveError && (
            <div className="rounded-md border border-destructive bg-destructive/10 p-3 text-sm text-destructive">
              {saveError}
            </div>
          )}
        </div>
      )}

      {step === 'done' && savedSchemaId && (
        <div className="space-y-4">
          <Card>
            <CardContent className="py-8 text-center">
              <Check className="mx-auto mb-3 h-10 w-10 text-green-600" />
              <p className="text-lg font-medium">Cube created — preview the data below</p>
              <p className="mt-1 text-sm text-muted-foreground">
                If the base table didn't exist, the engine seeded 24 sample rows so you can see results immediately.
              </p>
              <div className="mt-4 flex justify-center gap-2">
                <Button variant="outline" onClick={() => router.push('/semantic')}>
                  Back to cubes
                </Button>
                <Button onClick={() => router.push('/dashboards')}>
                  Build a dashboard with this cube
                </Button>
              </div>
            </CardContent>
          </Card>
          <CubeDataPreview
            schema={{
              schemaId: savedSchemaId,
              dsId: selectedDs!.dsId,
              cubeName,
              schemaJs: JSON.stringify(buildSchema()),
              isActive: 1,
              version: 1,
              createdBy: '',
              createdAt: '',
              updatedAt: '',
            } as CubeSchema}
          />
        </div>
      )}
    </div>
  );
}

function StepBadge({ label, active, done }: { label: string; active: boolean; done: boolean }) {
  return (
    <span
      className={`rounded-full px-3 py-1 text-xs font-medium ${
        done
          ? 'bg-green-100 text-green-800'
          : active
          ? 'bg-primary text-primary-foreground'
          : 'bg-muted text-muted-foreground'
      }`}
    >
      {label}
    </span>
  );
}

# NexusBI v7

> **Enterprise Business Intelligence platform.** Multi-tenant. Approval workflows. 12 connectors. SQLite or Oracle backend. Built on Next.js 15 + React 19 + NextAuth v5.

```
┌───────────────────────────────────────────────────────────────────┐
│  Production-grade BI in a single Node.js process.                 │
│  Zero native compilation. Zero binary downloads.                  │
│  Installs cleanly behind any corporate proxy.                     │
└───────────────────────────────────────────────────────────────────┘
```

---

## Table of contents

1. [Quick start](#1-quick-start)
2. [System requirements](#2-system-requirements)
3. [What you get out of the box](#3-what-you-get-out-of-the-box)
4. [Architecture](#4-architecture)
5. [Installation procedures](#5-installation-procedures)
6. [Switching to Oracle](#6-switching-to-oracle)
7. [Configuration reference](#7-configuration-reference)
8. [Operations runbook](#8-operations-runbook)
9. [Troubleshooting field guide](#9-troubleshooting-field-guide)
10. [Security model](#10-security-model)
11. [Database schema reference](#11-database-schema-reference)
12. [API surface reference](#12-api-surface-reference)
13. [Connector reference](#13-connector-reference)
14. [User roles and permissions](#14-user-roles-and-permissions)
15. [Approval workflow](#15-approval-workflow)
16. [Diagnostic tools](#16-diagnostic-tools)
17. [Development workflow](#17-development-workflow)
18. [Production deployment](#18-production-deployment)
19. [Upgrade procedures](#19-upgrade-procedures)
20. [Limits and capacity](#20-limits-and-capacity)
21. [Pre-existing technical debt](#21-pre-existing-technical-debt)
22. [Glossary](#22-glossary)

---

## 1. Quick start

```bash
# Extract
tar xzf nexusbi-v7-complete.tar.gz
cd nexusbi-v7-complete

# Install (one command — no monorepo workspace dance)
npm run install:all          # ~60s, 358 packages, zero errors

# Run
npm run dev                  # http://localhost:3000

# Log in
#   admin / Admin@123!
```

That's it. On first boot the app generates its own `NEXTAUTH_SECRET`, creates `apps/web/data/nexusbi.db` (52 tables, 6 users, 61 permissions, sample dashboards), and serves on `http://localhost:3000`.

If anything fails at this step → jump to [Troubleshooting field guide](#9-troubleshooting-field-guide).

---

## 2. System requirements

### Hard requirements

| Component | Minimum | Notes |
|---|---|---|
| **Node.js** | **22.0.0** | `node:sqlite` is a Node built-in introduced in 22 (gated behind `--experimental-sqlite`); stable in 23+. The launcher script auto-adds the flag on Node 22. |
| **npm** | 10.x (bundled with Node 22) | `pnpm` and `yarn` both work too if preferred. |
| **Disk** | 600 MB | `node_modules` ≈ 450 MB; `.next` build output ≈ 100 MB; SQLite DB ≈ 1 MB at seed. |
| **RAM** | 512 MB free | Dev server peaks around 350 MB resident. |

### What you do **not** need

- No Oracle client libraries (only required if `DB_BACKEND=oracle`)
- No Python, no `node-gyp`, no C++ toolchain
- No Docker
- No `better-sqlite3` (uses Node's built-in `node:sqlite`)
- No Cube.js server, no Cubestore binary, no Puppeteer, no chrome-headless-shell
- No `tailwindcss-animate` plugin (removed; native Tailwind keyframes used instead)

### Verified environments

| OS | Node | Status |
|---|---|---|
| macOS 14+ (Apple Silicon & Intel) | 22.x | ✓ Verified end-to-end |
| Windows 11 (PowerShell + cmd.exe) | 22.x | ✓ Verified, including paths with spaces (`C:\Project - Codes\NexusBI`) |
| Ubuntu 22.04 / 24.04 | 22.x | ✓ Verified |
| Behind enterprise proxy (Citigroup artifactory) | 22.x | ✓ Verified — no native compilation, no binary downloads required |

### Verifying your Node version

```bash
node --version
# Required: v22.x.x or v23.x.x or newer
# If you see v21 or below → upgrade is mandatory
```

**Upgrade options (macOS):**
```bash
# Homebrew
brew install node@22 && brew link --overwrite node@22

# nvm
nvm install 22 && nvm use 22 && nvm alias default 22
```

**Upgrade options (Windows):**
- Download installer: https://nodejs.org/en/download (LTS or Current)
- Or via `nvm-windows`: `nvm install 22 && nvm use 22`

---

## 3. What you get out of the box

### Application capabilities

| Capability | Status | Notes |
|---|---|---|
| Multi-tenant data sources | ✓ | Oracle, MongoDB, Hive, Impala, file uploads, REST/GraphQL/OAuth/Webhook APIs |
| Semantic layer (cubes) | ✓ | In-app TypeScript engine; replaces Cube.js entirely |
| Drag-and-drop dashboards | ✓ | React Grid Layout + ECharts + AG Grid |
| Workbook editor (Tableau-style) | ✓ | Worksheets, calculated fields, parameters, hierarchies, sets, groups |
| Story builder | ✓ | Multi-point narrative dashboards |
| Maker–Checker approval workflow | ✓ | Single or dual checker, full audit trail, approval replay |
| Tableau import (.twb / .twbx) | ✓ | Up to 100 MB by default; configurable |
| Scheduled reports | ✓ | Cron-based; email/webhook delivery |
| Real-time alerts | ✓ | Threshold + comparison + anomaly |
| Data lineage visualization | ✓ | Source → Cube → Dashboard graph |
| Webhook ingestion | ✓ | Inbound webhook → staging table → cube |
| Embed SDK | ✓ | Token-based dashboard embedding for external apps |
| Audit logging | ✓ | Every privileged action; queryable through admin UI |
| RBAC with timed access | ✓ | Role-based + per-resource time-bound grants |
| API source polling | ✓ | Cron-driven REST/GraphQL ingestion with JQ-style mapping |
| Comments & mentions | ✓ | Per-widget threaded comments with @mention notifications |

### Platform stats

| Metric | Value |
|---|---|
| Source files | ~480 (TypeScript + TSX) |
| Lines of code | ~50,000 |
| API routes | 82 |
| Database tables | 52 |
| Permission codes | 61 |
| UI components (shadcn/ui) | 21 |
| Connector types | 12 |
| Compiled CSS (Tailwind) | ~60 KB |
| Cold dev-server boot | ~5 s on macOS / ~7 s on Windows |
| `npm install` from cold | ~60 s |

---

## 4. Architecture

### High-level

```
┌──────────────────────────────────────────────────────────────────────┐
│  apps/web/  (Next.js 15.5.15 · React 19 · NextAuth 5 beta.31)        │
│                                                                      │
│  ┌────────────────────────────────────────────────────────────────┐  │
│  │  app/                  ← App Router pages + API routes         │  │
│  │   ├── (auth)/login/    ← Public login page                     │  │
│  │   ├── (app)/           ← Authenticated pages (dashboards, …)   │  │
│  │   ├── api/             ← 82 route handlers                     │  │
│  │   ├── layout.tsx       ← Root + <Providers> + <SessionProvider>│  │
│  │   ├── providers.tsx    ← Client-only provider wrapper          │  │
│  │   └── globals.css      ← Tailwind directives + design tokens   │  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │  middleware.ts         ← Auth-gating for all non-public paths  │  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │  lib/db/               ← Backend-agnostic DB facade            │  │
│  │   ├── index.ts             selects adapter via DB_BACKEND env  │  │
│  │   ├── sqlite-adapter.ts    uses node:sqlite                    │  │
│  │   ├── oracle-adapter.ts    uses oracledb (optional)            │  │
│  │   └── types.ts             SQL dialect translator              │  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │  lib/connectors/       ← External-system query connectors      │  │
│  │   ├── oracle-connector.ts                                      │  │
│  │   ├── mongo-connector.ts                                       │  │
│  │   └── hive-connector.ts                                        │  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │  lib/query-engine.ts   ← In-app semantic layer (Cube.js repl.) │  │
│  │  lib/auth.ts           ← NextAuth Credentials provider config  │  │
│  │  lib/audit.ts          ← Audit-log wrapper for routes          │  │
│  ├────────────────────────────────────────────────────────────────┤  │
│  │  scripts/                                                      │  │
│  │   ├── run.js               Cross-platform Next launcher        │  │
│  │   └── diag-login.js        Standalone auth diagnostic          │  │
│  └────────────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────────┘
                              │
                              ▼
                ┌──────────────────────────┐
                │   apps/web/data/         │
                │     nexusbi.db           │   ← SQLite DB (default)
                │     .auth-secret         │   ← 0600, auto-generated
                └──────────────────────────┘
                       (or Oracle if DB_BACKEND=oracle)
```

### Request lifecycle

```
HTTP request
   │
   ▼
[Next.js middleware.ts]
   │  • Public paths (/login, /api/auth/*) → pass through
   │  • Else: getToken() validates session JWT
   │  • No token → 307 redirect to /login?callbackUrl=…
   │  • Token → inject x-user-id + x-tenant-id headers
   ▼
[Route handler in app/api/.../route.ts]
   │  • requirePermission(user, 'permission.code')
   │  • withConnection(async conn => …)
   ▼
[lib/db/index.ts facade]
   │  • Reads DB_BACKEND env (default: sqlite)
   │  • Lazily initializes the chosen pool
   ▼
[sqlite-adapter.ts OR oracle-adapter.ts]
   │  • Adapter applies translateOracleToSqlite() if needed
   │  • Executes query, normalizes column casing to UPPERCASE
   ▼
[Database (SQLite or Oracle)]
```

### Why Next.js + NextAuth v5

- **App Router only** (no `pages/`). All 82 API routes use `app/api/.../route.ts` form.
- **NextAuth 5 beta.31** gives JWT sessions out of the box; we use `Credentials` provider with a custom `authorize()` that bcrypt-compares against the user table.
- **Edge middleware** runs in a separate runtime than route handlers, which is why `NEXTAUTH_SECRET` must be in `process.env` *before* Next starts (handled by `scripts/run.js`).

### Why SQLite by default

- **Zero credentials** — no separate database server to provision.
- **Zero native compilation** — `node:sqlite` is a Node 22 built-in, not an npm package. No `node-gyp`, no Python, no C++ toolchain, no node-headers download (which is exactly what gets blocked by corporate proxies).
- **Adapter abstraction** — switching to Oracle is a one-env-var change. The codebase never references `node:sqlite` outside `lib/db/sqlite-adapter.ts`.

---

## 5. Installation procedures

### 5.1 Standard install (SQLite, recommended)

```bash
tar xzf nexusbi-v7-complete.tar.gz
cd nexusbi-v7-complete

npm run install:all          # cd apps/web && npm install
npm run dev                  # node scripts/run.js dev
```

Open `http://localhost:3000`, log in as `admin` / `Admin@123!`.

What happens on first boot:

```
[1] scripts/run.js bootstraps NEXTAUTH_SECRET
    → generates 48-byte base64 random
    → writes apps/web/data/.auth-secret with mode 0600
[2] Next.js compiles middleware bundle (sees the secret in process.env)
[3] Authenticated request hits lib/db/sqlite-adapter.ts
    → opens apps/web/data/nexusbi.db (creates the file)
    → applies sqlite-seed.sql (52 tables, seed data)
    → 6 users inserted, all with verified bcrypt hashes
[4] Authorize() validates admin/Admin@123!
    → bcrypt.compareSync returns true
    → JWT issued with 61 permissions, role PLATFORM_ADMIN
[5] Browser cookie set, /login → / redirect, app shell renders
```

### 5.2 Install behind a corporate proxy

If npm is configured to use your enterprise registry:

```bash
# Verify your registry is reachable
npm config get registry
npm ping

# Then standard install
npm run install:all
```

What can fail:

| Symptom | Cause | Resolution |
|---|---|---|
| `EACCES` or `ETIMEDOUT` on `npm install` | Registry unreachable | Configure `~/.npmrc` with `registry=https://your-artifactory/.../npm` and any `_authToken` your IT requires |
| `Cannot find module 'oracledb'` at runtime | Optional dep not mirrored | Either accept (only fails if `DB_BACKEND=oracle`) or contact IT to mirror `oracledb` 6.7.0 |
| `403 Forbidden` for `node-headers.tar.gz` | Some other dep tried `node-gyp` | Should not happen with this release — file an issue if it does |

### 5.3 Production install

```bash
# On the target machine
tar xzf nexusbi-v7-complete.tar.gz
cd nexusbi-v7-complete

# Install + build
npm run install:all
cd apps/web && npm run build      # ~2.5 min, produces .next/standalone

# Set production secret (do NOT use auto-generated in prod)
export NEXTAUTH_SECRET="$(openssl rand -base64 48)"
export NEXTAUTH_URL="https://your-domain.example.com"

# Start
npm run start                     # node scripts/run.js start
```

---

## 6. Switching to Oracle

### 6.1 Prerequisites

- An Oracle database (any 12c+, including XE, SE, EE, ATP, ADW)
- A user with these grants:
  ```sql
  GRANT CONNECT, RESOURCE TO your_user;
  GRANT CREATE TABLE, CREATE INDEX, CREATE VIEW TO your_user;
  GRANT UNLIMITED TABLESPACE TO your_user;
  ```
- The Oracle driver: `cd apps/web && npm install oracledb`

### 6.2 Configuration

Create `apps/web/.env.local`:

```bash
DB_BACKEND=oracle
ORACLE_HOST=oracle.example.com
ORACLE_PORT=1521
ORACLE_SERVICE=XEPDB1
ORACLE_USER=nexusbi
ORACLE_PASSWORD=YourStrongPassword
ORACLE_POOL_MIN=2
ORACLE_POOL_MAX=10
```

### 6.3 Schema installation

```bash
# Dry run — prints what would be executed without running
npm run install:schema:oracle:dry

# Live install
npm run install:schema:oracle
```

The script reads `oracle-seed.sql` + `oracle-seed-v7.sql` and executes statements one at a time, reporting success/skip per statement. Idempotent — re-running is safe.

### 6.4 Switching back to SQLite

```bash
# Remove or comment DB_BACKEND in .env.local
# Restart dev server
npm run dev
```

The SQLite DB at `apps/web/data/nexusbi.db` is untouched between switches.

---

## 7. Configuration reference

All env vars go in `apps/web/.env.local` (gitignored).

### 7.1 Database

| Variable | Default | Required | Description |
|---|---|---|---|
| `DB_BACKEND` | `sqlite` | No | `sqlite` or `oracle` |
| `SQLITE_DB_PATH` | `./data/nexusbi.db` | No | Override SQLite file location (relative to `apps/web/`) |
| `SQLITE_AUTO_SCHEMA` | `true` | No | Set `false` to skip schema install on boot |
| `ORACLE_HOST` | — | Iff Oracle | Hostname of Oracle server |
| `ORACLE_PORT` | `1521` | No | Oracle listener port |
| `ORACLE_SERVICE` | — | Iff Oracle | Service name (e.g. `XEPDB1`, `ORCL`) |
| `ORACLE_USER` | — | Iff Oracle | Database user |
| `ORACLE_PASSWORD` | — | Iff Oracle | Database password |
| `ORACLE_POOL_MIN` | `2` | No | Minimum pool size |
| `ORACLE_POOL_MAX` | `10` | No | Maximum pool size |

### 7.2 Authentication

| Variable | Default | Required | Description |
|---|---|---|---|
| `NEXTAUTH_SECRET` | auto-generated | Yes (in prod) | JWT signing key. In dev, auto-generated to `data/.auth-secret`. **Set explicitly in production.** |
| `AUTH_SECRET` | mirrors `NEXTAUTH_SECRET` | No | NextAuth v5 alias |
| `NEXTAUTH_URL` | `http://localhost:3000` | Yes (in prod) | Canonical origin for cookies and callbacks |

### 7.3 Encryption

| Variable | Default | Required | Description |
|---|---|---|---|
| `ENCRYPTION_KEY` | — | Iff using 3rd-party connectors | 32-byte hex key for encrypting stored credentials (Oracle/MongoDB passwords, OAuth tokens) |

Generate with: `openssl rand -hex 32`

### 7.4 Optional features

| Variable | Default | Description |
|---|---|---|
| `MINIO_ENDPOINT` | — | S3-compatible object store for file uploads (Tableau, CSV, Excel) |
| `MINIO_ACCESS_KEY` | — | |
| `MINIO_SECRET_KEY` | — | |
| `MINIO_BUCKET` | `nexusbi-files` | |
| `SMTP_HOST` | — | Email delivery for scheduled reports + alerts + mentions |
| `SMTP_PORT` | `587` | |
| `SMTP_USER` | — | |
| `SMTP_PASSWORD` | — | |
| `SMTP_FROM` | `nexusbi@example.com` | |

### 7.5 Limits

| Variable | Default | Description |
|---|---|---|
| `middlewareClientMaxBodySize` (in `next.config.ts`) | `100mb` | Maximum upload body size — already configured |

---

## 8. Operations runbook

### 8.1 Daily operations

| Task | Command |
|---|---|
| Start dev server | `npm run dev` |
| Stop dev server | `Ctrl+C` |
| Check who is logged in | `curl -s http://localhost:3000/api/auth/session` |
| Tail logs | Watch the terminal running `npm run dev` |
| Reset DB (lose all data) | `cd apps/web && npm run db:reset && npm run dev` |

### 8.2 User management

**Create a new user (SQL):**

```sql
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID, IS_ACTIVE)
VALUES ('USR_NEW001', 'newuser@example.com', 'newuser',
        '$2b$12$<bcrypt hash>', 'New User', 'TENANT_DEFAULT', 1);

INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY)
VALUES ('USR_NEW001', 'R_AUTHOR', 'TENANT_DEFAULT', 'USR_ADMIN');
```

To generate the bcrypt hash:
```bash
node -e "console.log(require('bcryptjs').hashSync('TheirPassword!', 12))"
```

**Reset a user's password:**

```sql
UPDATE NB_USERS
   SET PASSWORD_HASH = '$2b$12$<new bcrypt hash>',
       UPDATED_AT = CURRENT_TIMESTAMP
 WHERE USERNAME = 'username';
```

**Disable a user:**

```sql
UPDATE NB_USERS SET IS_ACTIVE = 0 WHERE USERNAME = 'username';
```

### 8.3 Backup & restore

**SQLite:**

```bash
# Backup (online — uses SQLite's backup API for crash-consistency)
sqlite3 apps/web/data/nexusbi.db ".backup '/path/to/backup-$(date +%Y%m%d).db'"

# Or simpler if app is stopped: just copy the file
cp apps/web/data/nexusbi.db /path/to/backup.db

# Restore
cp /path/to/backup.db apps/web/data/nexusbi.db
```

**Oracle:** use your enterprise backup tooling (RMAN, expdp, etc.).

### 8.4 Health checks

| Check | URL | Expected |
|---|---|---|
| App responding | `GET /login` | HTTP 200 |
| Auth working | `GET /api/auth/session` (anon) | HTTP 200 with `{}` (empty) |
| DB reachable | `GET /api/auth/csrf` | HTTP 200 with `{"csrfToken":"…"}` |
| Authenticated route | `GET /api/datasources` (authed) | HTTP 200 with `{"success":true,"data":[…]}` |

### 8.5 Log rotation

`npm run dev` writes to stdout. In production, pipe to a rotated log file:

```bash
npm run start 2>&1 | rotatelogs /var/log/nexusbi/app.%Y%m%d.log 86400
```

Or use a process manager:

```bash
pm2 start npm --name nexusbi -- start
pm2 logs nexusbi
```

---

## 9. Troubleshooting field guide

### 9.1 Cannot log in

**Step 1 — run the diagnostic:**

```bash
cd apps/web
npm run diag:login admin "Admin@123!"
```

Reads `data/nexusbi.db` directly, performs the same lookup `authorize()` does, and prints exactly which step fails:

```
[OK]   DB located: ./data/nexusbi.db
[OK]   bcryptjs loaded
[info] NB_* tables in database: 52
[OK]   User row loaded (USER_ID=USR_ADMIN, IS_ACTIVE=1)
[OK]   PASSWORD_HASH is a well-formed bcrypt string
[OK]   bcrypt.compare SUCCEEDED
[info] Roles assigned: 1 — PLATFORM_ADMIN
[info] Permissions resolved: 61
DIAGNOSIS: credentials are VALID at the database level.
```

If that says VALID but the browser still fails → it's a session/cookie issue. Check `NEXTAUTH_URL` matches the origin you're visiting and clear browser cookies for `localhost:3000`.

**Step 2 — common causes:**

| Symptom | Cause | Fix |
|---|---|---|
| `[FAIL] No row in NB_USERS matches "admin"` | DB never seeded | `cd apps/web && npm run db:reset && npm run dev` |
| `[FAIL] bcrypt.compare FAILED` | Stale hash from earlier release | Re-run `npm run db:reset` (new seed has correct hashes) |
| `[FAIL] PASSWORD_HASH is NOT a well-formed bcrypt string` | Corrupted seed | `db:reset` |
| `[FAIL] IS_ACTIVE is 0` | User was disabled | `UPDATE NB_USERS SET IS_ACTIVE = 1 WHERE USERNAME = 'admin'` |

### 9.2 `Runtime MissingSecret` in middleware

```
Must pass `secret` if not set to JWT getToken()
    at middleware.ts (27:31)
```

**Cause:** `NEXTAUTH_SECRET` was not in `process.env` when Next.js compiled the middleware bundle.

**Fix:** ensure you start with `npm run dev` (which goes through `scripts/run.js`), not `npx next dev` directly. The launcher bootstraps the secret before spawning Next.

### 9.3 `node:sqlite is not available`

```
Error: Cannot load node:sqlite.
Detected Node 21.1.0. node:sqlite requires Node 22 or newer.
```

**Cause:** Node version below 22.

**Fix:** Upgrade Node to 22+. See [Section 2 — verifying Node version](#verifying-your-node-version).

### 9.4 Hydration mismatch in console

```
A tree hydrated but some attributes of the server rendered HTML didn't match
the client properties:
  island_form_infra_autocomplete="username"
```

**Cause:** Enterprise browser (Island, 1Password, LastPass, Bitwarden) injected DOM attributes between SSR and hydration.

**Fix:** already mitigated — `<input>` has `suppressHydrationWarning`. The console message is harmless and does not affect functionality. If you want it gone in dev: Chrome → DevTools → Settings → Console → Hide network errors / hydration warnings.

### 9.5 UI looks unstyled (raw HTML, blue underlined links)

**Cause:** Tailwind CSS not compiling — usually missing `postcss.config.js` or `tailwindcss-animate` plugin reference.

**Fix:** This release ships with both fixed. If you see this after extracting:
```bash
ls apps/web/postcss.config.js          # must exist
grep tailwindcss-animate apps/web/tailwind.config.ts   # must NOT show require()
rm -rf apps/web/.next                  # clear build cache
npm run dev                            # restart
```

### 9.6 `Request body exceeded 10MB`

```
POST /api/tableau/import error: TypeError: Failed to parse body as FormData.
Request body exceeded 10MB for /api/tableau/import.
```

**Cause:** File upload exceeded the configured limit.

**Fix:** Already raised to 100 MB in `next.config.ts`. To go higher:
```ts
experimental: {
  middlewareClientMaxBodySize: '250mb',  // adjust as needed
}
```
Then `rm -rf apps/web/.next && npm run dev`.

For files >250 MB, use presigned-URL direct uploads to MinIO/S3 instead.

### 9.7 Route returns 500 with `no such column`

```
GET /api/<route> error: SQLite execute failed: no such column: <COL_NAME>
```

**Cause:** Pre-existing schema/route mismatch (most have been fixed in this release).

**Fix:** Compare the route's SQL to `sqlite-seed.sql` schema. Usually one of:
- Column was renamed (e.g. `OWNER_ID` → `CREATED_BY`)
- Column doesn't exist in the seed (add it via `ALTER TABLE`)
- Wrong table reference

For a guided fix, search the codebase:
```bash
grep -rn "<COL_NAME>" apps/web/app/api apps/web/lib
```

### 9.8 `useSession must be wrapped in a <SessionProvider>`

**Cause:** Some component outside `<Providers>` is calling `useSession()`.

**Fix:** Make sure the component imports `useSession` from `next-auth/react` AND is rendered inside the tree that's wrapped by `<Providers>` in `app/layout.tsx`. If you've added a new top-level layout, ensure it doesn't bypass the root layout.

### 9.9 `next dev` fails with `Cannot find module 'tailwindcss-animate'`

**Cause:** Earlier build cache from before the `tailwindcss-animate` plugin was removed.

**Fix:**
```bash
rm -rf apps/web/.next
npm run dev
```

### 9.10 Dev server doesn't pick up config changes

`next.config.ts`, `tailwind.config.ts`, and `postcss.config.js` changes require a full restart (HMR doesn't reload config files):

```bash
# Ctrl+C the dev server
rm -rf apps/web/.next       # always safe, never required by app
npm run dev
```

### 9.11 SQLite DB locked / corrupted

```bash
cd apps/web
npm run db:reset            # removes nexusbi.db, nexusbi.db-wal, nexusbi.db-shm
npm run dev                 # re-seeds on first boot
```

You'll lose any data created since seed; backup first if needed.

---

## 10. Security model

### 10.1 Authentication

- **NextAuth v5** with JWT sessions (no DB-side session storage required)
- **bcrypt** for password hashing, cost factor **12** (~250 ms per verification on modern CPUs)
- **HttpOnly + SameSite=Lax + Secure** cookies in production
- **CSRF protection** via NextAuth's built-in token (required on every login POST)
- **Session expiry**: 8 hours by default (configurable in `lib/auth.ts`)

### 10.2 Authorization

- **RBAC** with 61 permission codes grouped into 11 categories (datasource, schema, dashboard, lineage, report, tableau, performance, webhook, template, admin, …)
- **Role hierarchy**: PLATFORM_ADMIN > AUTHOR > CHECKER > VIEWER > EMBED_ONLY
- **Row-level data filtering** via `NB_DS_ACCESS.ROW_FILTER_SQL` (per-role SQL predicates appended to all queries against that data source)
- **Column-level masking** via `NB_DS_ACCESS.COLUMN_BLACKLIST` (JSON array of column names to redact in API responses)
- **Time-bound access** via `NB_TIMED_ACCESS` (expires-at gate on any resource — dashboard, data source, etc.)

### 10.3 Audit logging

Every privileged action goes through `withAudit()` in `lib/audit.ts` which writes to `NB_AUDIT_LOG`:
- `LOG_ID, USER_ID, TENANT_ID, ACTION, RESOURCE_TYPE, RESOURCE_ID, REQUEST_PAYLOAD, RESPONSE_STATUS, IP_ADDRESS, USER_AGENT, DURATION_MS, CREATED_AT`

Sensitive fields (passwords, tokens, payment info) are auto-redacted by `sanitizePayload()` before logging.

### 10.4 Secret storage

- **`NEXTAUTH_SECRET`**: file mode `0600`, owner-only readable. In production, use env var instead of file.
- **Connector credentials** (Oracle/MongoDB passwords, OAuth tokens): AES-256-GCM encrypted via `lib/encryption.ts` using `ENCRYPTION_KEY`. Stored in `NB_DATA_SOURCES.CONFIG_ENCRYPTED`.
- **Masked-display version** in `NB_DATA_SOURCES.CONFIG_MASKED` for UI listings (passwords replaced with `********`).
- **Database file**: `apps/web/data/nexusbi.db` — protect with filesystem ACL in production.

### 10.5 Network security

- **Security headers** on every `/api/*` response (`X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `X-XSS-Protection`, `Referrer-Policy: strict-origin-when-cross-origin`) — see `next.config.ts`
- **CORS**: not enabled by default (intended for same-origin embedding)
- **Rate limiting**: not built in. For production, deploy behind nginx/Cloudflare/Vercel's edge rate limiter.

### 10.6 Approval workflow security

- **Maker–Checker** enforced: a user with `dashboard.approve` cannot approve their own dashboards.
- **Dual-checker mode**: dashboards marked `DUAL_CHECKER_REQUIRED = 1` need two independent approvers.
- **Approval snapshots** (`NB_APPROVAL_SNAPSHOTS`) capture exact dashboard state at approval time → tamper-evident replay history.
- **Audit replay** at `/api/dashboards/[id]/replay/[snapshotId]` reconstructs the dashboard exactly as approved.

### 10.7 Threat model — what this app does NOT defend against

- **Browser extensions** that read DOM (NextAuth's HttpOnly cookies are still safe)
- **Compromised admin account** (no break-glass mechanism — keep admin credentials in a vault)
- **Compromised Node.js process** (full read/write to SQLite DB)
- **Network MITM in dev** (no HTTPS by default; use a reverse proxy in production)
- **SQL injection in user-supplied row-level filters** — admins editing `NB_DS_ACCESS.ROW_FILTER_SQL` have full SQL access; treat as privileged operation

---

## 11. Database schema reference

52 tables, namespaced `NB_*` (NexusBI). Generated from `sqlite-seed.sql`. The Oracle equivalent is in `oracle-seed.sql`.

### 11.1 Core identity

| Table | Purpose | Key columns |
|---|---|---|
| `NB_TENANTS` | Multi-tenant boundary | `TENANT_ID`, `TENANT_NAME` |
| `NB_USERS` | User accounts | `USER_ID`, `USERNAME`, `EMAIL`, `PASSWORD_HASH`, `DISPLAY_NAME`, `FULL_NAME`, `TENANT_ID`, `IS_ACTIVE` |
| `NB_ROLES` | Role definitions | `ROLE_ID`, `ROLE_NAME`, `IS_SYSTEM_ROLE` |
| `NB_PERMISSIONS` | All known permission codes | `PERM_ID`, `PERM_CODE`, `PERM_CATEGORY` |
| `NB_ROLE_PERMISSIONS` | Role → permission mapping | `ROLE_ID`, `PERM_ID` |
| `NB_USER_ROLES` | User → role assignment | `USER_ID`, `ROLE_ID`, `TENANT_ID` |

### 11.2 Data sources

| Table | Purpose |
|---|---|
| `NB_DATA_SOURCES` | Connector instances (Oracle, Mongo, Hive, …) |
| `NB_DS_ACCESS` | Per-role access policy (row filter, column blacklist) |
| `NB_API_SOURCES` | REST/GraphQL/OAuth API source definitions |
| `NB_FILE_UPLOADS` | Uploaded CSV/Excel/JSON/Parquet files |

### 11.3 Semantic layer

| Table | Purpose |
|---|---|
| `NB_CUBE_SCHEMAS` | Cube definitions (JSON with measures + dimensions) |
| `NB_COLUMN_TAGS` | Per-column metadata (sensitivity, descriptions) |
| `NB_HIERARCHIES` | Drill-down hierarchies for dimensions |
| `NB_DATA_SETS` | Static / computed groupings of dimension members |
| `NB_DATA_GROUPS` | Bucketing dimension members into named groups |
| `NB_PARAMETERS` | Workbook-level user-configurable variables |
| `NB_CALCULATED_FIELDS` | Workbook-level derived measures (incl. LOD expressions) |

### 11.4 Dashboards & workbooks

| Table | Purpose |
|---|---|
| `NB_DASHBOARDS` | Dashboard definitions |
| `NB_DASHBOARD_VERSIONS` | Version history (every save creates a row) |
| `NB_DASHBOARD_SHARES` | Sharing grants per dashboard |
| `NB_WORKBOOKS` | Tableau-style worksheet containers |
| `NB_WORKSHEETS` | Individual worksheets within workbooks |
| `NB_DASHBOARD_ACTIONS` | Click-through actions between widgets |
| `NB_STORIES` | Multi-point dashboard narratives |
| `NB_STORY_POINTS` | Individual narrative points |
| `NB_SHAPE_LIBRARY` | Custom SVG shapes for dashboards |

### 11.5 Approval workflow

| Table | Purpose |
|---|---|
| `NB_DASHBOARD_REVIEWS` | Review submissions (DRAFT → PENDING → APPROVED/REJECTED) |
| `NB_CHECKER_ASSIGNMENTS` | Single or dual checker assignments per review |
| `NB_APPROVAL_SNAPSHOTS` | Tamper-evident state snapshot at approval time |

### 11.6 Operations

| Table | Purpose |
|---|---|
| `NB_AUDIT_LOG` | Every privileged action |
| `NB_PLATFORM_CONFIG` | Tenant-scoped feature flags + settings |
| `NB_TIMED_ACCESS` | Time-bound resource grants |
| `NB_PERF_METRICS` | Per-query performance metrics |
| `NB_PREAGG_RECOMMENDATIONS` | Suggested cube pre-aggregations |
| `NB_PROFILE_CACHE` | Cached column-profile statistics |

### 11.7 Integrations & delivery

| Table | Purpose |
|---|---|
| `NB_TABLEAU_IMPORTS` | History of imported `.twb`/`.twbx` files |
| `NB_DATA_FLOWS` | Visual ETL flows |
| `NB_DATA_FLOW_RUNS` | ETL execution history |
| `NB_SCHEDULED_FLOWS` | Cron-driven ETL schedules |
| `NB_SCHEDULED_REPORTS` | Cron-driven report deliveries |
| `NB_ALERTS` | Threshold/anomaly alert definitions |
| `NB_ALERT_FIRINGS` | Alert event history |
| `NB_SUBSCRIPTIONS` | User subscriptions to dashboard updates |
| `NB_SUBSCRIPTION_DELIVERIES` | Delivery attempt log |
| `NB_WEBHOOK_ENDPOINTS` | Outbound webhook definitions |
| `NB_WEBHOOK_DELIVERY_LOG` | Outbound webhook attempts |
| `NB_NOTIFICATIONS` | In-app notification inbox |
| `NB_DASH_TEMPLATES` | Marketplace template definitions |
| `NB_TEMPLATE_INSTALLS` | Template installation history |
| `NB_DATA_EXTRACTS` | Materialized data snapshots |
| `NB_MOBILE_LAYOUTS` | Mobile-specific dashboard layouts |
| `NB_NL_FILTER_HISTORY` | Natural-language filter query history |
| `NB_WIDGET_COMMENTS` | Per-widget threaded discussions |

### 11.8 Schema conventions

- **Column casing**: SCREAMING_SNAKE_CASE everywhere (Oracle convention)
- **Primary keys**: TEXT (UUID-style), explicitly inserted by `generateId()`
- **Timestamps**: TEXT in ISO-8601 (SQLite has no native datetime type)
- **Booleans**: INTEGER 0/1 (`IS_ACTIVE`, `CAN_EDIT`, etc.)
- **JSON columns**: TEXT, application-side parsed
- **Tenant scoping**: every multi-tenant table has `TENANT_ID` with FK to `NB_TENANTS`

---

## 12. API surface reference

82 routes under `apps/web/app/api/`. All require authentication except `/api/auth/*` and `/api/internal/*` (internal service-to-service).

### 12.1 Authentication

| Route | Method | Purpose |
|---|---|---|
| `/api/auth/[...nextauth]` | GET / POST | NextAuth session management |
| `/api/auth/csrf` | GET | CSRF token for credential POST |
| `/api/auth/session` | GET | Current session (user + roles + permissions) |
| `/api/auth/providers` | GET | Configured auth providers |
| `/api/auth/callback/credentials` | POST | Credentials login |

### 12.2 Data sources

| Route | Method | Permission |
|---|---|---|
| `/api/datasources` | GET, POST | `datasource.view`, `datasource.create` |
| `/api/datasources/[id]` | GET, PUT, DELETE | `datasource.view`, `datasource.edit`, `datasource.delete` |
| `/api/datasources/[id]/test` | POST | `datasource.test` |
| `/api/datasources/[id]/access` | GET, PUT | `datasource.manage_acl` |
| `/api/datasources/introspect` | POST | `schema.create` |

### 12.3 Cubes (semantic layer)

| Route | Method | Purpose |
|---|---|---|
| `/api/schemas` | GET, POST | List + create cube schemas |
| `/api/schemas/[id]` | GET, PUT, DELETE | Single cube CRUD |
| `/api/cube/v1/meta` | GET | Cube metadata for UI builder |
| `/api/cube/v1/load` | POST | Execute a cube query |

### 12.4 Dashboards

| Route | Method | Purpose |
|---|---|---|
| `/api/dashboards` | GET, POST | List + create |
| `/api/dashboards/[id]` | GET, PUT, DELETE | Single CRUD |
| `/api/dashboards/[id]/share` | POST, DELETE | Sharing management |
| `/api/dashboards/[id]/embed` | POST | Generate embed token |
| `/api/dashboards/[id]/export` | GET | PDF/PNG export |
| `/api/dashboards/[id]/versions` | GET | Version history |
| `/api/dashboards/[id]/restore` | POST | Restore old version |
| `/api/dashboards/[id]/submit` | POST | Submit for review |
| `/api/dashboards/[id]/approve` | POST | Approve (CHECKER+) |
| `/api/dashboards/[id]/reject` | POST | Reject (CHECKER+) |
| `/api/dashboards/[id]/reviews` | GET | Review history |
| `/api/dashboards/[id]/replay/[snapshotId]` | GET | Approval replay |
| `/api/dashboards/pending-review` | GET | Reviewer queue |

### 12.5 Other

| Group | Routes |
|---|---|
| Workbooks | `/api/workbooks`, `/api/workbooks/[id]`, `/api/workbooks/[id]/lod-fields`, `/api/workbooks/[id]/hierarchies` |
| Stories | `/api/stories`, `/api/stories/[id]` |
| Alerts | `/api/alerts`, `/api/alerts/[id]` |
| Flows | `/api/flows`, `/api/flows/[id]` |
| Lineage | `/api/lineage` |
| Tableau import | `/api/tableau/import`, `/api/tableau/import/[id]/preview` |
| Templates | `/api/templates`, `/api/templates/[id]/install` |
| Webhooks | `/api/webhooks`, `/api/webhooks/[id]/test`, `/api/webhook/ingest/[sourceId]` |
| Files | `/api/files/upload`, `/api/files/[id]/ingest` |
| Admin | `/api/admin/users`, `/api/admin/roles`, `/api/admin/platform`, `/api/admin/audit`, `/api/admin/timed-access` |
| Notifications | `/api/notifications` (POST) |

### 12.6 Response format

All API responses follow this shape:

```json
{
  "success": true,
  "data": <route-specific>
}
```

or on error:

```json
{
  "success": false,
  "error": {
    "code": "RBAC_DENIED" | "VALIDATION_ERROR" | "NOT_FOUND" | "INTERNAL_ERROR",
    "message": "Human-readable description"
  }
}
```

---

## 13. Connector reference

### 13.1 Database connectors

| Connector | Driver | Status |
|---|---|---|
| Oracle | `oracledb` 6.7.0 | ✓ Production-grade, full SQL support |
| MongoDB | `mongodb` 6.12.0 | ✓ Translates to Mongo aggregation pipelines |
| Hive | `hive-driver` 0.16.0 | ✓ HiveServer2 over Thrift |
| Impala | `hive-driver` 0.16.0 | ✓ Same driver, configured with Impala port |

All three are in `optionalDependencies`. If your environment can't install one, the others still work. Attempting to query an unavailable connector returns a clear error.

### 13.2 File connectors

| Connector | Library | Notes |
|---|---|---|
| CSV | `papaparse` 5.4.1 | Streaming parser |
| Excel (.xlsx) | `exceljs` 4.4.0 | Full styling support; replaced `xlsx`/SheetJS due to unpatched ReDoS CVEs |
| JSON | (built-in) | Single object or array of objects |
| Parquet | (planned) | Stub; not yet wired to a Parquet reader |

### 13.3 API connectors

| Connector | Auth methods supported |
|---|---|
| REST | None / Basic / Bearer / API key (header or query) |
| GraphQL | Same as REST + introspection-based schema |
| OAuth REST | OAuth 2.0 client_credentials, authorization_code, refresh_token |
| Inbound Webhook | HMAC signature verification (configurable algorithm + secret) |

API sources poll on a cron schedule defined in `NB_API_SOURCES.POLL_CRON`. Response data is shaped via JQ-style expression in `JQ_EXPRESSION` and landed into a staging table named in `STAGING_TABLE`.

---

## 14. User roles and permissions

### 14.1 Built-in roles

| Role | Permissions |
|---|---|
| **PLATFORM_ADMIN** | All 61 permissions. Can manage users, roles, all data, all dashboards across all tenants. |
| **AUTHOR** | Create/edit/delete data sources, cubes, dashboards, workbooks, stories, alerts, flows. Cannot approve dashboards. Cannot manage users. |
| **CHECKER** | Read-only access to most resources + `dashboard.approve` + `dashboard.reject`. Cannot edit. |
| **VIEWER** | Read-only access to dashboards/stories/lineage they have explicit share grants on. |
| **EMBED_ONLY** | Token-based external embed access. No UI access. |

### 14.2 Permission categories

| Category | Example permissions |
|---|---|
| `datasource` | `datasource.view`, `.create`, `.edit`, `.delete`, `.test`, `.manage_acl` |
| `schema` | `schema.view`, `.create`, `.edit`, `.delete` |
| `dashboard` | `dashboard.view`, `.create`, `.edit`, `.delete`, `.submit`, `.approve`, `.reject`, `.share`, `.embed`, `.export`, `.replay` |
| `workbook` | `workbook.view`, `.create`, `.edit`, `.delete`, `.publish` |
| `story` | `story.view`, `.create`, `.edit` |
| `flow` | `flow.view`, `.create`, `.edit`, `.delete`, `.run`, `.schedule` |
| `alert` | `alert.view`, `.create`, `.edit` |
| `comment` | `comment.view`, `.create`, `.resolve` |
| `template` | `template.view`, `.install`, `.publish` |
| `tableau` | `tableau.import` |
| `lineage` | `lineage.view` |
| `report` | `report.schedule` |
| `webhook` | `webhook.manage` |
| `performance` | `perf.view`, `preagg.manage` |
| `subscription` | `subscription.manage` |
| `file` | `file.upload`, `file.manage` |
| `api_source` | `api_source.manage` |
| `hierarchy` | `hierarchy.manage` |
| `shape` | `shape.manage` |
| `admin` | `admin.users`, `admin.roles`, `admin.platform`, `audit.view` |
| `explorer` | `explorer.use` |

Total: **61 distinct permission codes**.

### 14.3 How permission checks work

Inside any route handler:

```ts
const denied = await requirePermission(session.user, 'dashboard.create');
if (denied) return denied;   // returns 403 response
```

Behind the scenes:
1. `session.user.permissions` is a string array populated at login from `NB_ROLE_PERMISSIONS` joined through `NB_USER_ROLES`
2. Check is `permissions.includes('dashboard.create')`
3. Plus: row-level + column-level + timed-access checks where applicable

---

## 15. Approval workflow

### 15.1 States

```
DRAFT ────► PENDING_REVIEW ────► APPROVED
                  │
                  └────────────► REJECTED
```

### 15.2 Lifecycle

1. **AUTHOR creates dashboard** → state `DRAFT`
2. **AUTHOR clicks Submit** → state `PENDING_REVIEW`, row inserted in `NB_DASHBOARD_REVIEWS`
3. **Checker(s) assigned** → row(s) in `NB_CHECKER_ASSIGNMENTS`
4. **Checker approves**:
   - Single-checker mode: state → `APPROVED` immediately
   - Dual-checker mode (`DUAL_CHECKER_REQUIRED = 1`): waits for second checker
5. **Snapshot created** → row in `NB_APPROVAL_SNAPSHOTS` capturing `LAYOUT_JSON`, `WIDGETS_JSON`, `FILTERS_JSON`, `CUBE_QUERIES_JSON`
6. **Audit replay available** at `/api/dashboards/[id]/replay/[snapshotId]`

### 15.3 Maker-cannot-approve-self enforcement

`requirePermission()` blocks self-approval explicitly: if `dashboard.OWNER_ID === user.id`, the `dashboard.approve` permission is treated as denied for that specific dashboard.

---

## 16. Diagnostic tools

### 16.1 `npm run diag:login [username] [password]`

Standalone Node script that bypasses Next.js entirely and reads the SQLite DB directly. Reports each step of the auth flow:

```
[OK]   DB located: ./data/nexusbi.db
[OK]   bcryptjs loaded
[info] NB_* tables in database: 52
[OK]   User row loaded
       USER_ID      = USR_ADMIN
       USERNAME     = admin
       EMAIL        = admin@nexusbi.local
       DISPLAY_NAME = Platform Administrator
       TENANT_ID    = TENANT_DEFAULT
       IS_ACTIVE    = 1
       PASSWORD_HASH length = 60
       PASSWORD_HASH prefix = $2b$12$
[OK]   PASSWORD_HASH is a well-formed bcrypt string
[OK]   bcrypt.compare SUCCEEDED
[info] Roles assigned: 1 — PLATFORM_ADMIN
[info] Permissions resolved: 61
DIAGNOSIS: credentials are VALID at the database level.
```

### 16.2 `npm run db:reset`

Removes `data/nexusbi.db`, `data/nexusbi.db-wal`, `data/nexusbi.db-shm`. Next dev server boot re-seeds.

### 16.3 Server log inspection

The dev server logs every route invocation:
```
GET /api/datasources 200 in 45ms
POST /api/auth/callback/credentials 302 in 1295ms
SQLite: schema installed from ./sqlite-seed.sql
```

Errors are prefixed with `⨯`. NextAuth errors are prefixed with `[auth][error]`.

### 16.4 Direct DB inspection

```bash
sqlite3 apps/web/data/nexusbi.db
sqlite> .tables
sqlite> SELECT USERNAME, IS_ACTIVE FROM NB_USERS;
sqlite> SELECT R.ROLE_NAME, COUNT(P.PERM_CODE)
   ...> FROM NB_ROLES R
   ...> JOIN NB_ROLE_PERMISSIONS RP ON RP.ROLE_ID = R.ROLE_ID
   ...> JOIN NB_PERMISSIONS P       ON P.PERM_ID   = RP.PERM_ID
   ...> GROUP BY R.ROLE_NAME;
sqlite> .quit
```

---

## 17. Development workflow

### 17.1 Editing code

- **Hot Module Reload** (HMR) is on by default. Edit any `.ts` / `.tsx` / `.css` and the browser refreshes.
- **Config files** (`next.config.ts`, `tailwind.config.ts`, `postcss.config.js`) require a full restart.
- **Schema changes** (`sqlite-seed.sql`) require `db:reset` + restart.

### 17.2 Type checking

```bash
cd apps/web
npm run type-check       # tsc --noEmit
```

There are ~200 inherited type errors documented in `KNOWN_ISSUES.md`. They don't block runtime but should be cleaned up over time.

### 17.3 Linting

```bash
npm run lint             # next lint
```

### 17.4 Adding a new route

1. Create `apps/web/app/api/<your-route>/route.ts`
2. Use this template:
   ```ts
   export const runtime = 'nodejs';
   import { NextRequest, NextResponse } from 'next/server';
   import { getServerSession } from '@/lib/auth-options';
   import { requirePermission } from '@/lib/rbac-middleware';
   import { withAudit } from '@/lib/audit';
   import { withConnection } from '@/lib/oracle-pool';

   export const GET = withAudit(
     () => ({ action: 'your.action', resourceType: 'your_resource' }),
     async (request, _context, user) => {
       const denied = await requirePermission(user, 'your.permission');
       if (denied) return denied;
       const data = await withConnection(async (conn) => {
         const result = await conn.execute(
           `SELECT … FROM NB_… WHERE TENANT_ID = :t`,
           { t: user.tenantId },
           { outFormat: 4002 },
         );
         return result.rows;
       });
       return NextResponse.json({ success: true, data });
     },
   );
   ```

### 17.5 Adding a new permission

1. Add row to `sqlite-seed.sql`:
   ```sql
   INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION)
   VALUES (lower(hex(randomblob(16))), 'your.permission', 'category', 'Description');
   ```
2. Grant to roles:
   ```sql
   INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID)
   SELECT 'R_PADMIN', PERM_ID FROM NB_PERMISSIONS WHERE PERM_CODE = 'your.permission';
   ```
3. `npm run db:reset && npm run dev`
4. Reference in routes via `requirePermission(user, 'your.permission')`

### 17.6 Adding a new table

1. Edit `sqlite-seed.sql`, add `CREATE TABLE IF NOT EXISTS NB_YOUR_TABLE (…)`
2. Mirror in `oracle-seed.sql` with Oracle types (use `VARCHAR2`, `NUMBER`, `TIMESTAMP`)
3. `npm run db:reset && npm run dev` (SQLite)
4. `npm run install:schema:oracle` (Oracle)

---

## 18. Production deployment

### 18.1 Build

```bash
cd apps/web
npm run build       # produces .next/standalone

ls .next/standalone
# server.js + node_modules + apps/web/server.js
```

### 18.2 Run

```bash
export NODE_ENV=production
export NEXTAUTH_SECRET="$(openssl rand -base64 48)"
export NEXTAUTH_URL="https://nexusbi.example.com"
export DB_BACKEND=oracle  # or stay on sqlite
# … all other env vars from Section 7

cd apps/web
npm run start       # node scripts/run.js start
```

### 18.3 Behind a reverse proxy (nginx)

```nginx
server {
  listen 443 ssl http2;
  server_name nexusbi.example.com;

  ssl_certificate     /etc/ssl/nexusbi.crt;
  ssl_certificate_key /etc/ssl/nexusbi.key;

  client_max_body_size 100M;          # match middlewareClientMaxBodySize
  proxy_request_buffering off;        # for streaming uploads

  location / {
    proxy_pass http://localhost:3000;
    proxy_set_header Host              $host;
    proxy_set_header X-Real-IP         $remote_addr;
    proxy_set_header X-Forwarded-For   $proxy_add_x_forwarded_for;
    proxy_set_header X-Forwarded-Proto $scheme;
    proxy_http_version 1.1;
    proxy_set_header Connection "";
  }
}
```

### 18.4 With PM2

```bash
npm install -g pm2
cd apps/web
pm2 start npm --name nexusbi -- run start
pm2 save
pm2 startup        # set up systemd service
```

### 18.5 With systemd

```ini
# /etc/systemd/system/nexusbi.service
[Unit]
Description=NexusBI v7
After=network.target

[Service]
Type=simple
User=nexusbi
WorkingDirectory=/opt/nexusbi/apps/web
ExecStart=/usr/bin/npm run start
Restart=on-failure
Environment="NODE_ENV=production"
EnvironmentFile=/etc/nexusbi/env

[Install]
WantedBy=multi-user.target
```

```bash
sudo systemctl enable --now nexusbi
sudo journalctl -u nexusbi -f
```

### 18.6 Production checklist

- [ ] `NEXTAUTH_SECRET` set explicitly (NOT auto-generated)
- [ ] `NEXTAUTH_URL` matches the public origin
- [ ] `ENCRYPTION_KEY` set (if using 3rd-party connectors)
- [ ] Database backups scheduled (daily SQLite copy or RMAN)
- [ ] HTTPS terminated at reverse proxy
- [ ] `client_max_body_size` matches `middlewareClientMaxBodySize`
- [ ] Process manager (PM2/systemd) configured to auto-restart
- [ ] Log rotation set up
- [ ] Firewall: only proxy can reach :3000; only ops team can SSH
- [ ] Filesystem permissions on `apps/web/data/` set to mode `700`
- [ ] Cron jobs (scheduled reports, alerts, ETL flows) tested in staging first
- [ ] Audit log export pipeline if you need long-term retention

---

## 19. Upgrade procedures

### 19.1 In-place upgrade from a previous v7 release

```bash
# Stop the running server
# Then:
tar xzf nexusbi-v7-complete-NEW.tar.gz \
   --exclude='apps/web/data' \
   --exclude='apps/web/node_modules' \
   --exclude='apps/web/.next' \
   -C /path/to/installation

cd /path/to/installation/apps/web

# Reinstall in case package.json changed
npm install

# Clear build cache (config files might have changed)
rm -rf .next

# Restart
npm run start
```

The seed file uses `INSERT OR REPLACE` for users and `INSERT OR IGNORE` for everything else, so upgrading replaces stale password hashes in-place but preserves all your tenant data.

If a release adds new tables: `CREATE TABLE IF NOT EXISTS` makes the seed safe to re-run; the new tables get created on next dev/start.

If a release adds new columns to existing tables: this requires a migration. Check the release notes (or `KNOWN_ISSUES.md`) for the specific `ALTER TABLE` statements.

### 19.2 Major Node version upgrade

```bash
# Check what's currently installed
node --version

# Install new Node (e.g. 22 → 24)
nvm install 24 && nvm use 24
# (or homebrew/installer equivalent)

cd apps/web
rm -rf node_modules package-lock.json   # full clean
npm install

# Verify
npm run dev
```

---

## 20. Limits and capacity

### 20.1 Per-request limits

| Resource | Limit | Configurable |
|---|---|---|
| Request body size (uploads) | 100 MB | Yes (`next.config.ts`) |
| Response body size | Streamed; no fixed cap | Up to client memory |
| URL length | 8 KB (Node default) | Adjustable via `--max-http-header-size` |
| JSON body parse size | 100 MB (matches body limit) | Yes |
| Session JWT lifetime | 8 hours | Yes (`lib/auth.ts`) |

### 20.2 SQLite practical limits

| Resource | Limit |
|---|---|
| Concurrent writers | 1 (SQLite serializes writes via `BEGIN EXCLUSIVE`) |
| Concurrent readers | Unlimited (with WAL mode, which is enabled) |
| DB file size | 281 TB theoretical, but plan for backup/replication beyond ~20 GB |
| Per-row size | 1 GB (BLOB), much smaller in practice |
| Realistic load | Up to ~50 concurrent dashboard users on a single laptop-class CPU |

For higher loads, switch to Oracle (see Section 6).

### 20.3 Oracle practical limits

Bound by your Oracle plan and hardware. The connection pool defaults (`ORACLE_POOL_MIN=2`, `ORACLE_POOL_MAX=10`) are tuned for development; raise for production:

```bash
ORACLE_POOL_MIN=10
ORACLE_POOL_MAX=100
```

---

## 21. Pre-existing technical debt

This release has applied many fixes during the v6→v7 transition (Cube.js removal, SQLite migration, schema/route alignment). What remains:

### 21.1 ~200 TypeScript errors in API routes

Suppressed via `next.config.ts`:
```ts
typescript: { ignoreBuildErrors: true }
```

The app installs, builds, and boots; individual routes with the worst errors have been fixed (datasources, dashboards, alerts, flows, audit, lineage, schemas, workbooks, stories, templates, webhooks, admin/users, admin/roles — all return 200). The remaining errors are largely cosmetic (implicit any, missing types) and don't affect runtime.

See `KNOWN_ISSUES.md` for categorized fixes.

### 21.2 `tableau-driver` is still optional / partial

Tableau import works for `.twb` (XML) files. `.twbx` (ZIP-packaged) files unpack via `adm-zip` but some embedded data extracts (.hyper files) are not yet rehydrated.

### 21.3 No automated test suite

There's no `jest` / `vitest` / `playwright` setup. End-to-end verification has been done manually via `curl` + the `diag-login.js` script. Adding tests is a recommended next step.

### 21.4 Some routes log `Route handler error: TypeError: r.<X>.toISOString is not a function`

These have been fixed in the routes most likely to be hit (flows, hierarchies, comment-notifier). If you find another, replace `r.<COL>.toISOString()` with `String(r.<COL>)` since SQLite returns timestamps as TEXT, not Date objects.

---

## 22. Glossary

| Term | Meaning |
|---|---|
| **Tenant** | Top-level isolation boundary. Every multi-tenant table has `TENANT_ID`. Replaces "Organization" from earlier versions. |
| **Cube** | A semantic-layer definition with measures (aggregations) + dimensions (group-bys) over a base table or query. Defined in JSON in `NB_CUBE_SCHEMAS.SCHEMA_JSON`. |
| **Maker** | A user who creates dashboards (typically AUTHOR role). |
| **Checker** | A user who reviews/approves dashboards (CHECKER role). |
| **Maker-Checker** | The compliance pattern where the maker cannot approve their own work. |
| **Snapshot** | An immutable record of a dashboard's exact state at approval time, stored in `NB_APPROVAL_SNAPSHOTS`. |
| **Replay** | Reconstructing a dashboard from a snapshot for audit purposes. |
| **LOD expression** | "Level of Detail" calculation borrowed from Tableau syntax: `{FIXED [Region]: SUM([Sales])}`. |
| **Adapter facade** | The `lib/db/index.ts` module that hides whether the backend is SQLite or Oracle. |
| **Translator** | The `translateOracleToSqlite()` function in `lib/db/types.ts` that rewrites Oracle SQL idioms (NVL, SYSTIMESTAMP, FETCH NEXT, etc.) into SQLite syntax at query time. |
| **HMR** | Hot Module Reload — Next.js's dev-time mechanism for updating modules without a full page reload. |
| **CSRF token** | Cross-Site Request Forgery token issued by `/api/auth/csrf`, required on every credentials POST. |
| **Edge runtime** | The lightweight V8 isolate Next.js uses to run middleware. Has fewer Node APIs than the full Node.js runtime used by route handlers. |

---

## Support

- **Documentation**: this file
- **User guide**: `docs/NexusBI-User-Guide.docx` (50-chapter end-user manual)
- **Browser demo**: `nexusbi-v7-app.html` (self-contained HTML preview)
- **Known issues**: `KNOWN_ISSUES.md`
- **Diagnostic tool**: `npm run diag:login`
- **Database reset**: `npm run db:reset`

---

**NexusBI v7** — Built for production. Designed for proxies. Tested behind firewalls.

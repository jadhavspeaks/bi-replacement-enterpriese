'use client';

import * as React from 'react';
import { SessionProvider } from 'next-auth/react';

/**
 * Top-level client providers.
 *
 * Wraps every page (including authenticated routes under (app)/ and public
 * routes under (auth)/) in a SessionProvider so that any client component
 * below can call useSession() without throwing.
 *
 * This is required in NextAuth v5: any component that uses useSession(),
 * signIn(), or signOut() from `next-auth/react` must have a SessionProvider
 * ancestor. In earlier NextAuth versions the provider was optional in many
 * scenarios, but v5 hoisted it to be strictly required.
 *
 * Keep this component minimal — only truly global client providers belong
 * here. Feature-specific providers (e.g. react-query client, theme
 * provider, toast provider) should be colocated with the features that
 * use them so the global bundle stays small.
 */
export function Providers({ children }: { children: React.ReactNode }): React.JSX.Element {
  return <SessionProvider>{children}</SessionProvider>;
}

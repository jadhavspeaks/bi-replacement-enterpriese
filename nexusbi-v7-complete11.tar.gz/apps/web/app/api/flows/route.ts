import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import type { DataFlow } from '@nexusbi/shared-types';
import { generateId } from '@nexusbi/shared-types';

const CreateSchema = z.object({
  flowName: z.string().min(1).max(300),
  description: z.string().optional(),
});

export const GET = withAudit(
  () => ({ action: 'flow.list', resourceType: 'flow' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'flow.view');
    const rows = await withConnection(async (conn) => {
      const r = await conn.execute<{
        FLOW_ID: string; FLOW_NAME: string; DESCRIPTION: string | null;
        OWNER_ID: string; OWNER_NAME: string; VERSION: number;
        CREATED_AT: Date; UPDATED_AT: Date;
      }>(
        `SELECT f.FLOW_ID, f.FLOW_NAME, f.DESCRIPTION, f.OWNER_ID, u.FULL_NAME AS OWNER_NAME,
                f.VERSION, f.CREATED_AT, f.UPDATED_AT
         FROM NB_DATA_FLOWS f LEFT JOIN NB_USERS u ON f.OWNER_ID = u.USER_ID
         WHERE f.TENANT_ID = :org ORDER BY f.UPDATED_AT DESC`,
        { org: user.tenantId }, { outFormat: 4002 },
      );
      return r.rows ?? [];
    });

    return NextResponse.json({
      flows: rows.map((r) => ({
        flowId: r.FLOW_ID, flowName: r.FLOW_NAME, description: r.DESCRIPTION,
        ownerId: r.OWNER_ID, ownerName: r.OWNER_NAME, version: r.VERSION,
        createdAt: String(r.CREATED_AT), updatedAt: String(r.UPDATED_AT),
      })),
    });
  },
);

export const POST = withAudit(
  () => ({ action: 'flow.create', resourceType: 'flow' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'flow.create');
    const body = CreateSchema.parse(await request.json());
    const flowId = generateId('FLOW');

    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_DATA_FLOWS (FLOW_ID, TENANT_ID, FLOW_NAME, DESCRIPTION, OWNER_ID,
                                    NODES_JSON, EDGES_JSON, VERSION)
         VALUES (:fid, :org, :name, :desc, :owner, '[]', '[]', 1)`,
        { fid: flowId, org: user.tenantId, name: body.flowName, desc: body.description ?? null, owner: user.userId },
      );
      await conn.commit();
    });

    return NextResponse.json({ flowId }, { status: 201 });
  },
);

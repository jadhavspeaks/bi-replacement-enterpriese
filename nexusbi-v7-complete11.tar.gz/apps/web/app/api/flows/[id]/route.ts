import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';

const UpdateSchema = z.object({
  flowName: z.string().optional(),
  description: z.string().optional(),
  nodes: z.array(z.any()).optional(),
  edges: z.array(z.any()).optional(),
});

async function loadFlow(flowId: string, tenantId: string) {
  return withConnection(async (conn) => {
    const r = await conn.execute<{
      FLOW_ID: string; FLOW_NAME: string; DESCRIPTION: string | null; OWNER_ID: string;
      NODES_JSON: string; EDGES_JSON: string; VERSION: number;
      CREATED_AT: Date; UPDATED_AT: Date;
    }>(
      `SELECT FLOW_ID, FLOW_NAME, DESCRIPTION, OWNER_ID, NODES_JSON, EDGES_JSON, VERSION,
              CREATED_AT, UPDATED_AT FROM NB_DATA_FLOWS WHERE FLOW_ID = :fid AND TENANT_ID = :org`,
      { fid: flowId, org: tenantId }, { outFormat: 4002 },
    );
    return r.rows?.[0] ?? null;
  });
}

export const GET = withAudit(
  (_, params) => ({ action: 'flow.get', resourceType: 'flow', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'flow.view');
    const row = await loadFlow(params.id, user.tenantId);
    if (!row) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    return NextResponse.json({
      flowId: row.FLOW_ID, flowName: row.FLOW_NAME, description: row.DESCRIPTION,
      ownerId: row.OWNER_ID,
      nodes: JSON.parse(row.NODES_JSON ?? '[]'),
      edges: JSON.parse(row.EDGES_JSON ?? '[]'),
      version: row.VERSION,
      createdAt: row.CREATED_AT ? String(row.CREATED_AT) : null, updatedAt: row.UPDATED_AT ? String(row.UPDATED_AT) : null,
    });
  },
);

export const PATCH = withAudit(
  (_, params) => ({ action: 'flow.update', resourceType: 'flow', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'flow.edit');
    const body = UpdateSchema.parse(await request.json());
    await withConnection(async (conn) => {
      const sets: string[] = [];
      const binds: Record<string, unknown> = { fid: params.id, org: user.tenantId };
      if (body.flowName !== undefined) { sets.push('FLOW_NAME = :name'); binds.name = body.flowName; }
      if (body.description !== undefined) { sets.push('DESCRIPTION = :desc'); binds.desc = body.description; }
      if (body.nodes !== undefined) { sets.push('NODES_JSON = :nodes'); binds.nodes = JSON.stringify(body.nodes); }
      if (body.edges !== undefined) { sets.push('EDGES_JSON = :edges'); binds.edges = JSON.stringify(body.edges); }
      sets.push('VERSION = VERSION + 1', 'UPDATED_AT = SYSTIMESTAMP');
      await conn.execute(
        `UPDATE NB_DATA_FLOWS SET ${sets.join(', ')} WHERE FLOW_ID = :fid AND TENANT_ID = :org`,
        binds,
      );
      await conn.commit();
    });
    return NextResponse.json({ ok: true });
  },
);

export const DELETE = withAudit(
  (_, params) => ({ action: 'flow.delete', resourceType: 'flow', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'flow.delete');
    await withConnection(async (conn) => {
      await conn.execute(
        `DELETE FROM NB_DATA_FLOWS WHERE FLOW_ID = :fid AND TENANT_ID = :org`,
        { fid: params.id, org: user.tenantId },
      );
      await conn.commit();
    });
    return NextResponse.json({ ok: true });
  },
);

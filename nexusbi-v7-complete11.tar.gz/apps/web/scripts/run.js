#!/usr/bin/env node
/**
 * Cross-platform launcher for the Next.js CLI.
 *
 * Earlier versions of this script spawned `next.cmd` through a shell, which
 * broke on Windows whenever the project path contained spaces, parentheses,
 * or ampersands (very common — "C:\Project - Codes\NexusBI" for example).
 * The current approach is to require Next's CLI entrypoint *inside this same
 * Node process*. There is no shell involved, so paths cannot be misparsed.
 *
 * It also handles the SQLite flag transition:
 *   - Node 22: needs --experimental-sqlite (added below to the current process)
 *   - Node 23+: node:sqlite is stable; flag would be rejected, so it's omitted
 *
 * Usage:
 *   node scripts/run.js dev
 *   node scripts/run.js build
 *   node scripts/run.js start
 *   node scripts/run.js dev -- --port 4000     (extra args forwarded to Next)
 */

'use strict';

const path = require('node:path');
const fs = require('node:fs');
const crypto = require('node:crypto');
const { spawn } = require('node:child_process');

const target = process.argv[2];
if (!target || !['dev', 'build', 'start', 'lint'].includes(target)) {
  console.error('Usage: node scripts/run.js <dev|build|start|lint> [...extra args]');
  process.exit(1);
}

// Forward any extra args to Next (after `--` or simply trailing).
const passthrough = process.argv.slice(3).filter((a) => a !== '--');

// -----------------------------------------------------------------------------
// NEXTAUTH_SECRET bootstrap.
//
// This MUST happen before spawning Next, because Next.js middleware runs on the
// Edge Runtime and its env vars are inlined from process.env at bundle compile
// time (not re-read at request time in dev). If NEXTAUTH_SECRET isn't present
// when Next starts, `getToken()` inside middleware throws "Runtime MissingSecret".
//
// lib/boot-secret.ts does the same thing but runs in the Node runtime only
// (from auth.ts's module graph), which is too late for the Edge bundle.
//
// Priority:
//   1. Any existing env var (NEXTAUTH_SECRET or AUTH_SECRET) — unchanged
//   2. Contents of data/.auth-secret if it exists
//   3. Freshly generated 48-byte base64 secret, persisted to data/.auth-secret (0600)
// -----------------------------------------------------------------------------
function ensureAuthSecret() {
  if (process.env.NEXTAUTH_SECRET || process.env.AUTH_SECRET) {
    const value = process.env.NEXTAUTH_SECRET || process.env.AUTH_SECRET;
    process.env.NEXTAUTH_SECRET = value;
    process.env.AUTH_SECRET = value;
    return 'env';
  }

  const appRoot = path.resolve(__dirname, '..');
  const dataDir = path.join(appRoot, 'data');
  const secretFile = path.join(dataDir, '.auth-secret');

  try {
    if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });
  } catch (err) {
    console.warn(`run.js: could not create ${dataDir}:`, err.message);
  }

  let secret;
  let source;
  if (fs.existsSync(secretFile)) {
    secret = fs.readFileSync(secretFile, 'utf-8').trim();
    source = 'file-existing';
  } else {
    secret = crypto.randomBytes(48).toString('base64');
    try {
      fs.writeFileSync(secretFile, secret, { mode: 0o600 });
      source = 'file-generated';
    } catch (err) {
      console.warn(`run.js: could not persist secret to ${secretFile}:`, err.message);
      source = 'memory-only';
    }
  }

  if (!secret || secret.length < 32) {
    // Corrupted file or short value — regenerate.
    secret = crypto.randomBytes(48).toString('base64');
    try {
      fs.writeFileSync(secretFile, secret, { mode: 0o600 });
      source = 'file-regenerated';
    } catch {
      source = 'memory-only';
    }
  }

  process.env.NEXTAUTH_SECRET = secret;
  process.env.AUTH_SECRET = secret;
  return source;
}

const secretSource = ensureAuthSecret();
if (secretSource === 'file-generated') {
  console.log('run.js: generated NEXTAUTH_SECRET and saved to apps/web/data/.auth-secret (0600).');
} else if (secretSource === 'file-regenerated') {
  console.log('run.js: regenerated NEXTAUTH_SECRET (previous value was corrupt).');
}
// Silent for 'env' and 'file-existing' — reduces noise on normal startup.

// Detect Node version. Node 22 still has node:sqlite gated behind a flag;
// 23+ ships it stable. Adding the flag on >=23 would make Node abort at startup
// because it doesn't recognise the option.
const nodeMajor = parseInt(process.versions.node.split('.')[0], 10);
const needsSqliteFlag = nodeMajor === 22;

// Where is the Next CLI?
let nextCliPath;
try {
  nextCliPath = require.resolve('next/dist/bin/next', { paths: [path.resolve(__dirname, '..')] });
} catch (err) {
  console.error('Could not locate Next.js CLI. Did you run `npm install`?');
  console.error('  resolve error:', (err && err.message) || err);
  process.exit(1);
}

// Strategy: re-spawn the *current Node binary* with the right flags + the Next
// CLI script path. We use the explicit args array (not a shell) so spaces and
// special characters in the project path are handled by Node, not by cmd.exe.
const nodeBin = process.execPath; // absolute path to current node, no quoting issues
const nodeArgs = ['--no-warnings'];
if (needsSqliteFlag) nodeArgs.push('--experimental-sqlite');
nodeArgs.push(nextCliPath, target, ...passthrough);

const child = spawn(nodeBin, nodeArgs, {
  stdio: 'inherit',
  // No shell, no windowsVerbatimArguments — Node passes argv as-is.
  shell: false,
  // Explicitly pass env so NEXTAUTH_SECRET we just bootstrapped is inherited.
  env: process.env,
});

child.on('exit', (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  else process.exit(code ?? 0);
});

child.on('error', (err) => {
  console.error('Failed to launch Next.js:', err.message);
  process.exit(1);
});

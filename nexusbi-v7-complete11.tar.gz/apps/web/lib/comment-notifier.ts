import type { WidgetComment } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';

/**
 * Parses @mentions from comment bodies and notifies the mentioned users.
 * Also notifies the parent commenter when replies are posted.
 */

const MENTION_RE = /@([a-zA-Z0-9_][a-zA-Z0-9_.-]{0,49})/g;

export function extractMentions(content: string): string[] {
  const mentions = new Set<string>();
  let m: RegExpExecArray | null;
  while ((m = MENTION_RE.exec(content)) !== null) mentions.add(m[1]);
  return Array.from(mentions);
}

export async function resolveUsernameToId(username: string): Promise<string | null> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ USER_ID: string }>(
      `SELECT USER_ID FROM NB_USERS WHERE LOWER(USERNAME) = LOWER(:u)`,
      { u: username }, { outFormat: 4002 },
    );
    return r.rows?.[0]?.USER_ID ?? null;
  });
}

export async function notifyMentioned(
  comment: WidgetComment, mentionedUsernames: string[],
): Promise<void> {
  for (const uname of mentionedUsernames) {
    const userId = await resolveUsernameToId(uname);
    if (!userId) continue;
    // Placeholder: creates NB_NOTIFICATIONS row + dispatches email via lib/mailer.ts
    console.log(`[notify] @${uname} (${userId}) mentioned in comment ${comment.commentId}`);
  }
}

export async function notifyParentCommenter(
  comment: WidgetComment, parentId: string,
): Promise<void> {
  const parentUserId = await withConnection(async (conn) => {
    const r = await conn.execute<{ USER_ID: string }>(
      `SELECT USER_ID FROM NB_WIDGET_COMMENTS WHERE COMMENT_ID = :id`,
      { id: parentId }, { outFormat: 4002 },
    );
    return r.rows?.[0]?.USER_ID ?? null;
  });
  if (!parentUserId || parentUserId === comment.userId) return;
  console.log(`[notify] parent commenter ${parentUserId} got reply in ${comment.commentId}`);
}

export async function buildCommentTree(
  dashId: string, widgetId: string,
): Promise<WidgetComment[]> {
  const rows = await withConnection(async (conn) => {
    const r = await conn.execute<{
      COMMENT_ID: string; PARENT_ID: string | null; USER_ID: string;
      USERNAME: string; FULL_NAME: string; CONTENT: string;
      MARK_CONTEXT: string | null; MENTIONED_USERS: string | null;
      RESOLVED: number; CREATED_AT: Date; UPDATED_AT: Date;
    }>(
      `SELECT c.COMMENT_ID, c.PARENT_ID, c.USER_ID, u.USERNAME, u.FULL_NAME,
              c.CONTENT, c.MARK_CONTEXT, c.MENTIONED_USERS, c.RESOLVED,
              c.CREATED_AT, c.UPDATED_AT
       FROM NB_WIDGET_COMMENTS c JOIN NB_USERS u ON c.USER_ID = u.USER_ID
       WHERE c.DASH_ID = :d AND c.WIDGET_ID = :w
       ORDER BY c.CREATED_AT ASC`,
      { d: dashId, w: widgetId }, { outFormat: 4002 },
    );
    return r.rows ?? [];
  });

  const byId = new Map<string, WidgetComment>();
  for (const r of rows) {
    byId.set(r.COMMENT_ID, {
      commentId: r.COMMENT_ID, dashId, widgetId,
      parentId: r.PARENT_ID, userId: r.USER_ID, userName: r.FULL_NAME ?? r.USERNAME,
      content: r.CONTENT,
      markContext: r.MARK_CONTEXT ? safeParse(r.MARK_CONTEXT) : null,
      mentionedUsers: r.MENTIONED_USERS ? safeParse(r.MENTIONED_USERS) : [],
      resolved: r.RESOLVED === 1,
      createdAt: String(r.CREATED_AT),
      updatedAt: String(r.UPDATED_AT),
      replies: [],
    });
  }
  const top: WidgetComment[] = [];
  for (const c of byId.values()) {
    if (c.parentId && byId.has(c.parentId)) {
      byId.get(c.parentId)!.replies!.push(c);
    } else {
      top.push(c);
    }
  }
  return top;
}

function safeParse<T>(s: string): T | null {
  try { return JSON.parse(s) as T; } catch { return null; }
}

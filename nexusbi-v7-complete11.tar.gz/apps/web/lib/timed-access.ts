import type { TimedAccessResourceType, TimedAccess, TimedAccessCreateInput } from '@nexusbi/shared-types';
import { withConnection, generateId } from '@/lib/oracle-pool';
import { writeAuditLog } from '@/lib/audit';
import type { SessionUser } from '@nexusbi/shared-types';

export async function checkTimedAccess(
  resourceType: TimedAccessResourceType,
  resourceId: string,
  userId: string,
  tenantId: string,
): Promise<boolean> {
  return withConnection(async (conn) => {
    // Check if there are any timed access records for this resource
    const result = await conn.execute<{
      ACCESS_COUNT: number;
    }>(
      `SELECT COUNT(*) AS ACCESS_COUNT
       FROM NB_TIMED_ACCESS
       WHERE RESOURCE_TYPE = :resourceType
         AND RESOURCE_ID = :resourceId
         AND TENANT_ID = :tenantId
         AND IS_ACTIVE = 1`,
      { resourceType, resourceId, tenantId },
      { outFormat: 4002 },
    );

    const count = result.rows?.[0]?.ACCESS_COUNT ?? 0;

    // If no timed access records exist, resource is not time-restricted
    if (count === 0) return true;

    // Check if user has valid (non-expired) timed access
    const accessResult = await conn.execute<{
      VALID_COUNT: number;
    }>(
      `SELECT COUNT(*) AS VALID_COUNT
       FROM NB_TIMED_ACCESS
       WHERE RESOURCE_TYPE = :resourceType
         AND RESOURCE_ID = :resourceId
         AND TENANT_ID = :tenantId
         AND IS_ACTIVE = 1
         AND EXPIRES_AT > SYSTIMESTAMP
         AND (USER_ID = :userId OR ROLE_ID IN (
           SELECT ROLE_ID FROM NB_USER_ROLES
           WHERE USER_ID = :userId AND TENANT_ID = :tenantId
         ))`,
      { resourceType, resourceId, tenantId, userId },
      { outFormat: 4002 },
    );

    const validCount = accessResult.rows?.[0]?.VALID_COUNT ?? 0;

    if (validCount === 0) {
      // Log the denied access
      await conn.execute(
        `INSERT INTO NB_AUDIT_LOG
           (LOG_ID, USER_ID, TENANT_ID, ACTION, RESOURCE_TYPE, RESOURCE_ID,
            REQUEST_PAYLOAD, RESPONSE_STATUS, CREATED_AT)
         VALUES
           (:logId, :userId, :tenantId, :action, :resourceType, :resourceId,
            :payload, :status, SYSTIMESTAMP)`,
        {
          logId: generateId(),
          userId,
          tenantId,
          action: 'timed_access.expire',
          resourceType,
          resourceId,
          payload: JSON.stringify({ reason: 'Timed access expired or not found' }),
          status: 403,
        },
      );
      await conn.commit();
    }

    return validCount > 0;
  });
}

export async function grantTimedAccess(
  input: TimedAccessCreateInput,
  grantedBy: string,
  tenantId: string,
): Promise<TimedAccess> {
  return withConnection(async (conn) => {
    const accessId = generateId();

    await conn.execute(
      `INSERT INTO NB_TIMED_ACCESS
         (ACCESS_ID, RESOURCE_TYPE, RESOURCE_ID, ROLE_ID, USER_ID,
          GRANTED_BY, GRANTED_AT, EXPIRES_AT, IS_ACTIVE, TENANT_ID)
       VALUES
         (:accessId, :resourceType, :resourceId, :roleId, :userId,
          :grantedBy, SYSTIMESTAMP, TO_TIMESTAMP(:expiresAt, 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"'),
          1, :tenantId)`,
      {
        accessId,
        resourceType: input.resourceType,
        resourceId: input.resourceId,
        roleId: input.roleId ?? null,
        userId: input.userId ?? null,
        grantedBy,
        expiresAt: input.expiresAt,
        tenantId,
      },
    );
    await conn.commit();

    const result = await conn.execute<Record<string, unknown>>(
      `SELECT * FROM NB_TIMED_ACCESS WHERE ACCESS_ID = :accessId`,
      { accessId },
      { outFormat: 4002 },
    );

    const row = result.rows![0];
    return mapTimedAccess(row);
  });
}

export async function renewTimedAccess(
  accessId: string,
  newExpiresAt: string,
  tenantId: string,
): Promise<TimedAccess | null> {
  return withConnection(async (conn) => {
    const updateResult = await conn.execute(
      `UPDATE NB_TIMED_ACCESS
       SET EXPIRES_AT = TO_TIMESTAMP(:expiresAt, 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"'),
           IS_ACTIVE = 1
       WHERE ACCESS_ID = :accessId
         AND TENANT_ID = :tenantId`,
      { accessId, expiresAt: newExpiresAt, tenantId },
    );

    if ((updateResult.rowsAffected ?? 0) === 0) return null;
    await conn.commit();

    const result = await conn.execute<Record<string, unknown>>(
      `SELECT * FROM NB_TIMED_ACCESS WHERE ACCESS_ID = :accessId`,
      { accessId },
      { outFormat: 4002 },
    );

    if (!result.rows || result.rows.length === 0) return null;
    return mapTimedAccess(result.rows[0]);
  });
}

export async function listTimedAccess(tenantId: string): Promise<TimedAccess[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<Record<string, unknown>>(
      `SELECT * FROM NB_TIMED_ACCESS
       WHERE TENANT_ID = :tenantId
       ORDER BY EXPIRES_AT DESC`,
      { tenantId },
      { outFormat: 4002 },
    );

    return (result.rows || []).map(mapTimedAccess);
  });
}

export async function deactivateExpiredAccess(tenantId: string): Promise<number> {
  return withConnection(async (conn) => {
    const result = await conn.execute(
      `UPDATE NB_TIMED_ACCESS
       SET IS_ACTIVE = 0
       WHERE TENANT_ID = :tenantId
         AND IS_ACTIVE = 1
         AND EXPIRES_AT <= SYSTIMESTAMP`,
      { tenantId },
    );
    await conn.commit();
    return result.rowsAffected ?? 0;
  });
}

function mapTimedAccess(row: Record<string, unknown>): TimedAccess {
  return {
    accessId: row.ACCESS_ID as string,
    resourceType: row.RESOURCE_TYPE as TimedAccessResourceType,
    resourceId: row.RESOURCE_ID as string,
    roleId: (row.ROLE_ID as string) ?? null,
    userId: (row.USER_ID as string) ?? null,
    grantedBy: row.GRANTED_BY as string,
    grantedAt: String(row.GRANTED_AT),
    expiresAt: String(row.EXPIRES_AT),
    isActive: (row.IS_ACTIVE as number) === 1,
    tenantId: row.TENANT_ID as string,
  };
}

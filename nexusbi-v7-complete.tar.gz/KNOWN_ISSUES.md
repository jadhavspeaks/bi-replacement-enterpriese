# Known Issues — v7.0.0 (Cube.js-free release)

The package installs cleanly and `next build` passes because `typescript.ignoreBuildErrors` is enabled in `apps/web/next.config.ts`. Underneath, **~200 pre-existing TypeScript errors** remain in individual API routes. These were inherited from v6/v7, exposed only once the monorepo workspace setup was fixed.

The app boots. Most UI pages work. Some API routes will fail at runtime until patched.

---

## Cube.js removal — migration notes

This release replaces Cube.js with an in-app query engine (`lib/query-engine.ts`). If you have existing cube schemas in your Oracle `NB_CUBE_SCHEMAS` table written in JavaScript `cube(...)` syntax, they will still be accepted (the legacy parser handles them), but **JSON format is strongly preferred**:

**Legacy JS format (still works, deprecated):**
```js
cube(`Orders`, {
  sql: `SELECT * FROM public.orders`,
  measures: {
    total_revenue: { sql: `${CUBE}.total_amount`, type: `sum` }
  },
  dimensions: {
    region: { sql: `${CUBE}.region`, type: `string` }
  }
});
```

**New JSON format (recommended):**
```json
{
  "cubeName": "Orders",
  "baseTable": "public.orders",
  "measures": {
    "total_revenue": { "sql": "total_amount", "type": "sum" }
  },
  "dimensions": {
    "region": { "sql": "region", "type": "string" }
  }
}
```

Migrate with:
```sql
UPDATE NB_CUBE_SCHEMAS
   SET SCHEMA_JSON = ... -- your JSON string here
 WHERE CUBE_NAME = 'Orders';
```

Fields supported:
- `measures.*.type`: `count`, `sum`, `avg`, `min`, `max`, `countDistinct`
- `dimensions.*.type`: `string`, `number`, `time`, `boolean`

---

## Category 1 — `requireAuthAndPermission` vs `requirePermission`

**Symptom** — `error TS2724: '"@/lib/rbac-middleware"' has no exported member named 'requireAuthAndPermission'`

**Fix** — Already partially fixed via an alias. For remaining files:
```ts
// Before
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
// After
import { requirePermission } from '@/lib/rbac-middleware';
```

Files affected (22).

---

## Category 2 — Next.js 15 `params` is now a Promise

**Symptom** — `error TS2339: Property 'id' does not exist on type 'Promise<Record<string, string>>'`

**Fix**:
```ts
// Before
export async function GET(_req, { params }: { params: { id: string } }) {
  const id = params.id;
}
// After
export async function GET(_req, { params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
}
```

Files affected (~60).

---

## Category 3 — `withAudit` signature mismatch

**Symptom** — `error TS2554: Expected 3 arguments, but got 2`

**Fix** — Add the `getUser` third argument:
```ts
export const POST = withAudit(
  (req, p) => ({ action: 'thing.create', resourceType: 'thing' }),
  async (request, _context, user) => { /* ... */ },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);
```

Files affected (~40).

---

## Category 4 — `SessionUser.userId` and `SessionUser.permissions`

**Already applied** in `apps/web/types/rbac.types.ts`. Make sure your auth provider populates them when creating the session:

```ts
// In apps/web/lib/auth-options.ts — session callback
session.user = {
  id: token.sub,
  userId: token.sub,
  email: token.email,
  username: token.username,
  displayName: token.displayName,
  tenantId: token.tenantId,
  roles: token.roles,
  permissions: token.permissions || [],
};
```

---

## Category 5 — Implicit `any` in callback parameters

**Already mitigated** globally by `noImplicitAny: false` in `tsconfig.json`. For cleanliness when time permits:

```ts
// Before
const rows = result.rows?.map((r) => ({ ... }));
// After
const rows = result.rows?.map((r: Record<string, unknown>) => ({ ... }));
```

Files affected (~85).

---

## How to systematically clean up

```bash
cd apps/web

# 1. Rename the middleware import
find app/api -name "*.ts" -exec sed -i \
  's/requireAuthAndPermission/requirePermission/g' {} \;

# 2. Remove ignoreBuildErrors once above categories are patched
sed -i '/ignoreBuildErrors/d; /ignoreDuringBuilds/d' next.config.ts

# 3. Turn strict back on
sed -i 's/"strict": false/"strict": true/' tsconfig.json

# 4. Run the compile and fix remaining errors interactively
npx tsc --noEmit
```

---

## Known runtime issues (not TypeScript)

1. **Dashboard PDF/PNG export** — returns HTML/CSV/JSON instead. Puppeteer was removed. If you need real PDF rendering, install `puppeteer-core` + set `PUPPETEER_EXECUTABLE_PATH`.

2. **Real-time presence on dashboards** — `CollaboratorPresence` shows only the current user. yjs/y-websocket stubbed out due to React 19 peer-dep conflicts.

3. **Monaco code editor in semantic-layer schema editing** — replaced with a plain `<textarea>`. For syntax highlighting, re-add `@monaco-editor/react`.

4. **Graphic Walker explorer** — replaced with a lightweight field-picker + table. For the full drag-and-drop visual explorer, reinstall `@kanaries/graphic-walker` once it has React 19 support.

5. **JMESPath for API source ingest** — replaced with a minimal built-in path resolver (supports `a.b.c` and `a.b[0].c`). For complex JMESPath queries, reinstall `jmespath` and swap the shim back.

6. **MongoDB + Hive at runtime** — The `mongodb` and `hive-driver` packages are listed in `optionalDependencies`. If your npm registry doesn't have them, install succeeds but queries against MongoDB/Hive/Impala data sources will throw at runtime until you `npm install mongodb hive-driver` in `apps/web`.

None of these block the app from starting, logging in, browsing dashboards, running Oracle queries, or using Tableau import.

-- NexusBI — SQLite Seed SQL (auto-generated)
-- Idempotent: CREATE TABLE IF NOT EXISTS throughout.

-- ========= v6 BASE SCHEMA =========
-- ============================================================================
-- NexusBI v6 — Oracle Seed SQL
-- 31 Tables · 38 Permissions · 6 Roles · 6 Dummy Users · Sample Data
-- Run with: sqlplus nexusbi/password@host:port/service @oracle-seed.sql
-- ============================================================================

-- ─── 1. ORGANIZATIONS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_TENANTS (
  TENANT_ID           TEXT PRIMARY KEY,
  TENANT_NAME         TEXT  NOT NULL,
  TENANT_SLUG         TEXT  NOT NULL UNIQUE,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 2. USERS ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_USERS (
  USER_ID          TEXT PRIMARY KEY,
  EMAIL            TEXT  NOT NULL UNIQUE,
  USERNAME         TEXT  NOT NULL UNIQUE,
  PASSWORD_HASH    TEXT  NOT NULL,
  DISPLAY_NAME     TEXT,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  IS_ACTIVE        INTEGER      DEFAULT 1,
  LAST_LOGIN_AT    TEXT,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 3. ROLES ───────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_ROLES (
  ROLE_ID          TEXT PRIMARY KEY,
  ROLE_NAME        TEXT  NOT NULL UNIQUE,
  ROLE_DESCRIPTION TEXT,
  IS_SYSTEM_ROLE   INTEGER      DEFAULT 0,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 4. PERMISSIONS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_PERMISSIONS (
  PERM_ID          TEXT PRIMARY KEY,
  PERM_CODE        TEXT  NOT NULL UNIQUE,
  PERM_CATEGORY    TEXT   NOT NULL,
  DESCRIPTION      TEXT
);

-- ─── 5. ROLE_PERMISSIONS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_ROLE_PERMISSIONS (
  ROLE_ID          TEXT   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  PERM_ID          TEXT   NOT NULL REFERENCES NB_PERMISSIONS(PERM_ID),
  GRANTED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  GRANTED_BY       TEXT,
  PRIMARY KEY (ROLE_ID, PERM_ID)
);

-- ─── 6. USER_ROLES ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_USER_ROLES (
  USER_ID          TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  ROLE_ID          TEXT   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  ASSIGNED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  ASSIGNED_BY      TEXT,
  PRIMARY KEY (USER_ID, ROLE_ID, TENANT_ID)
);

-- ─── 7. DATA_SOURCES ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DATA_SOURCES (
  DS_ID            TEXT PRIMARY KEY,
  DS_NAME          TEXT  NOT NULL,
  DS_TYPE          TEXT   NOT NULL,
  DESCRIPTION      TEXT,
  CONFIG_ENCRYPTED TEXT,
  STATUS           TEXT   DEFAULT 'INACTIVE',
  LAST_TESTED_AT   TEXT,
  LAST_TEST_RESULT TEXT,
  CUBE_DS_ID       TEXT,
  OWNER_ID         TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 8. DS_ACCESS ───────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DS_ACCESS (
  ACCESS_ID        TEXT PRIMARY KEY,
  DS_ID            TEXT   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  ROLE_ID          TEXT   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  CAN_QUERY        INTEGER      DEFAULT 1,
  CAN_EXPORT       INTEGER      DEFAULT 0,
  CAN_MANAGE       INTEGER      DEFAULT 0,
  ROW_FILTER_SQL   TEXT,
  EXPIRES_AT       TEXT,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 9. CUBE_SCHEMAS ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_CUBE_SCHEMAS (
  SCHEMA_ID        TEXT PRIMARY KEY,
  DS_ID            TEXT   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  CUBE_NAME        TEXT  NOT NULL,
  SCHEMA_JS        TEXT           NOT NULL,
  VERSION          NUMERIC         DEFAULT 1,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  CREATED_BY       TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 10. COLUMN_TAGS ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_COLUMN_TAGS (
  TAG_ID           TEXT PRIMARY KEY,
  SCHEMA_ID        TEXT   NOT NULL REFERENCES NB_CUBE_SCHEMAS(SCHEMA_ID),
  COLUMN_NAME      TEXT  NOT NULL,
  TAG_KEY          TEXT  NOT NULL,
  TAG_VALUE        TEXT,
  CREATED_BY       TEXT,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 11. FILE_UPLOADS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_FILE_UPLOADS (
  FILE_ID          TEXT PRIMARY KEY,
  FILE_NAME        TEXT  NOT NULL,
  ORIGINAL_NAME    TEXT  NOT NULL,
  MIME_TYPE        TEXT,
  FILE_SIZE        NUMERIC,
  MINIO_BUCKET     TEXT  NOT NULL,
  MINIO_KEY        TEXT  NOT NULL,
  UPLOAD_STATUS    TEXT   DEFAULT 'UPLOADED',
  INGEST_STATUS    TEXT,
  DUCKDB_TABLE     TEXT,
  UPLOADED_BY      TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 12. API_SOURCES ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_API_SOURCES (
  SOURCE_ID        TEXT PRIMARY KEY,
  SOURCE_NAME      TEXT  NOT NULL,
  API_TYPE         TEXT   NOT NULL,
  BASE_URL         TEXT NOT NULL,
  AUTH_CONFIG      TEXT,
  POLL_CRON        TEXT,
  JQ_EXPRESSION    TEXT,
  PAGINATION_TYPE  TEXT,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  LAST_POLL_AT     TEXT,
  LAST_POLL_STATUS TEXT,
  LAST_ROW_COUNT   NUMERIC,
  DUCKDB_TABLE     TEXT,
  OWNER_ID         TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 13. DASHBOARDS ─────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DASHBOARDS (
  DASH_ID              TEXT PRIMARY KEY,
  DASH_NAME            TEXT  NOT NULL,
  DESCRIPTION          TEXT,
  LAYOUT_JSON          TEXT,
  WIDGETS_JSON         TEXT,
  FILTERS_JSON         TEXT,
  OWNER_ID             TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID               TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  IS_PUBLIC            INTEGER      DEFAULT 0,
  IS_EMBEDDED          INTEGER      DEFAULT 0,
  EMBED_TOKEN          TEXT,
  VERSION              NUMERIC         DEFAULT 1,
  THUMBNAIL_URL        TEXT,
  TAGS                 TEXT,
  APPROVAL_STATUS      TEXT   DEFAULT 'DRAFT',
  APPROVED_BY          TEXT,
  APPROVED_AT          TEXT,
  REJECTED_BY          TEXT,
  REJECTED_AT          TEXT,
  REJECTION_REASON     TEXT,
  SOURCE               TEXT   DEFAULT 'MANUAL',
  DUAL_CHECKER_REQUIRED INTEGER     DEFAULT 0,
  CREATED_AT           TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT           TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 14. DASHBOARD_VERSIONS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DASHBOARD_VERSIONS (
  VERSION_ID       TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  VERSION          NUMERIC         NOT NULL,
  LAYOUT_JSON      TEXT,
  WIDGETS_JSON     TEXT,
  SAVED_BY         TEXT   REFERENCES NB_USERS(USER_ID),
  SAVED_AT         TEXT      DEFAULT CURRENT_TIMESTAMP,
  CHANGE_SUMMARY   TEXT
);

-- ─── 15. DASHBOARD_SHARES ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DASHBOARD_SHARES (
  SHARE_ID         TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  ROLE_ID          TEXT   REFERENCES NB_ROLES(ROLE_ID),
  USER_ID          TEXT   REFERENCES NB_USERS(USER_ID),
  CAN_EDIT         INTEGER      DEFAULT 0,
  CAN_SHARE        INTEGER      DEFAULT 0,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 16. DASHBOARD_REVIEWS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DASHBOARD_REVIEWS (
  REVIEW_ID        TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  DASH_VERSION     NUMERIC         NOT NULL,
  SUBMITTED_BY     TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  SUBMITTED_AT     TEXT      DEFAULT CURRENT_TIMESTAMP,
  REVIEWED_BY      TEXT   REFERENCES NB_USERS(USER_ID),
  REVIEWED_AT      TEXT,
  REVIEW_STATUS    TEXT   DEFAULT 'PENDING',
  REVIEW_COMMENTS  TEXT,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID)
);

-- ─── 17. CHECKER_ASSIGNMENTS ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_CHECKER_ASSIGNMENTS (
  ASSIGNMENT_ID    TEXT PRIMARY KEY,
  REVIEW_ID        TEXT   NOT NULL REFERENCES NB_DASHBOARD_REVIEWS(REVIEW_ID),
  CHECKER_SLOT     INTEGER      NOT NULL CHECK (CHECKER_SLOT IN (1, 2)),
  CHECKER_ID       TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  ASSIGNED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  DECISION         TEXT,
  DECIDED_AT       TEXT,
  COMMENTS         TEXT
);

-- ─── 18. APPROVAL_SNAPSHOTS ─────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_APPROVAL_SNAPSHOTS (
  SNAPSHOT_ID      TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  REVIEW_ID        TEXT   NOT NULL REFERENCES NB_DASHBOARD_REVIEWS(REVIEW_ID),
  VERSION          NUMERIC         NOT NULL,
  LAYOUT_JSON      TEXT,
  WIDGETS_JSON     TEXT,
  FILTERS_JSON     TEXT,
  SNAPPED_BY       TEXT   REFERENCES NB_USERS(USER_ID),
  SNAPPED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID)
);

-- ─── 19. PERF_METRICS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_PERF_METRICS (
  METRIC_ID        TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  WIDGET_ID        TEXT   NOT NULL,
  USER_ID          TEXT   REFERENCES NB_USERS(USER_ID),
  LOAD_MS          NUMERIC         NOT NULL,
  CUBE_QUERY_MS    NUMERIC,
  RENDER_MS        NUMERIC,
  RECORDED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID)
);
CREATE INDEX IF NOT EXISTS IDX_PERF_DASH_WIDGET ON NB_PERF_METRICS(DASH_ID, WIDGET_ID);

-- ─── 20. MOBILE_LAYOUTS ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_MOBILE_LAYOUTS (
  LAYOUT_ID        TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  LAYOUT_JSON      TEXT,
  WIDGETS_JSON     TEXT,
  LAST_EDITED_BY   TEXT   REFERENCES NB_USERS(USER_ID),
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CONSTRAINT UK_MOBILE_DASH UNIQUE (DASH_ID, TENANT_ID)
);

-- ─── 21. NL_FILTER_HISTORY ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_NL_FILTER_HISTORY (
  HISTORY_ID       TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  USER_ID          TEXT   REFERENCES NB_USERS(USER_ID),
  RAW_INPUT        TEXT NOT NULL,
  PARSED_FILTERS   TEXT,
  PARSE_SUCCESS    INTEGER      DEFAULT 0,
  PARSE_CONFIDENCE NUMERIC,
  APPLIED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID)
);

-- ─── 22. PREAGG_RECOMMENDATIONS ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_PREAGG_RECOMMENDATIONS (
  REC_ID           TEXT PRIMARY KEY,
  CUBE_NAME        TEXT  NOT NULL,
  DS_ID            TEXT   REFERENCES NB_DATA_SOURCES(DS_ID),
  REASON           TEXT,
  QUERY_COUNT      NUMERIC         DEFAULT 0,
  AVG_QUERY_MS     NUMERIC,
  PREAGG_DEF       TEXT,
  SMART_REFRESH_CRON TEXT,
  CONFIDENCE_SCORE NUMERIC,
  STATUS           TEXT   DEFAULT 'PENDING',
  APPLIED_AT       TEXT,
  APPLIED_BY       TEXT,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 23. WEBHOOK_ENDPOINTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_WEBHOOK_ENDPOINTS (
  ENDPOINT_ID      TEXT PRIMARY KEY,
  ENDPOINT_NAME    TEXT  NOT NULL,
  URL              TEXT NOT NULL,
  SECRET_HASH      TEXT  NOT NULL,
  TRIGGER_TYPE     TEXT   NOT NULL,
  TRIGGER_CONFIG   TEXT,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_BY       TEXT   REFERENCES NB_USERS(USER_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 24. WEBHOOK_DELIVERY_LOG ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_WEBHOOK_DELIVERY_LOG (
  DELIVERY_ID      TEXT PRIMARY KEY,
  ENDPOINT_ID      TEXT   NOT NULL REFERENCES NB_WEBHOOK_ENDPOINTS(ENDPOINT_ID),
  TRIGGER_EVENT    TEXT  NOT NULL,
  PAYLOAD          TEXT,
  STATUS           TEXT   DEFAULT 'PENDING',
  HTTP_STATUS      NUMERIC,
  RESPONSE_BODY    TEXT,
  ATTEMPT_COUNT    NUMERIC         DEFAULT 0,
  DELIVERED_AT     TEXT,
  NEXT_RETRY_AT    TEXT,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 25. DASH_TEMPLATES ─────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DASH_TEMPLATES (
  TEMPLATE_ID      TEXT PRIMARY KEY,
  TEMPLATE_NAME    TEXT  NOT NULL,
  DESCRIPTION      TEXT,
  CATEGORY         TEXT,
  TAGS             TEXT,
  LAYOUT_JSON      TEXT,
  WIDGETS_JSON     TEXT,
  REQUIRED_DS_TYPES TEXT,
  THUMBNAIL_URL    TEXT,
  IS_GLOBAL        INTEGER      DEFAULT 0,
  PUBLISHED_BY     TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  INSTALL_COUNT    NUMERIC         DEFAULT 0
);

-- ─── 26. TEMPLATE_INSTALLS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_TEMPLATE_INSTALLS (
  INSTALL_ID       TEXT PRIMARY KEY,
  TEMPLATE_ID      TEXT   NOT NULL REFERENCES NB_DASH_TEMPLATES(TEMPLATE_ID),
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  DS_MAPPING       TEXT,
  INSTALLED_BY     TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  INSTALLED_AT     TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 27. TIMED_ACCESS ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_TIMED_ACCESS (
  ACCESS_ID        TEXT PRIMARY KEY,
  RESOURCE_TYPE    TEXT   NOT NULL,
  RESOURCE_ID      TEXT   NOT NULL,
  ROLE_ID          TEXT   REFERENCES NB_ROLES(ROLE_ID),
  USER_ID          TEXT   REFERENCES NB_USERS(USER_ID),
  GRANTED_BY       TEXT   REFERENCES NB_USERS(USER_ID),
  EXPIRES_AT       TEXT      NOT NULL,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 28. TABLEAU_IMPORTS ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_TABLEAU_IMPORTS (
  IMPORT_ID        TEXT PRIMARY KEY,
  ORIGINAL_NAME    TEXT  NOT NULL,
  MINIO_KEY        TEXT,
  IMPORT_STATUS    TEXT   DEFAULT 'PROCESSING',
  DASH_ID          TEXT   REFERENCES NB_DASHBOARDS(DASH_ID),
  WIDGETS_CREATED  NUMERIC,
  WARNINGS         TEXT,
  UNMAPPED_ITEMS   TEXT,
  IMPORTED_BY      TEXT   REFERENCES NB_USERS(USER_ID),
  TENANT_ID           TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  COMPLETED_AT     TEXT
);

-- ─── 29. SCHEDULED_REPORTS ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_SCHEDULED_REPORTS (
  REPORT_ID        TEXT PRIMARY KEY,
  DASH_ID          TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  REPORT_NAME      TEXT  NOT NULL,
  CRON_EXPRESSION  TEXT  NOT NULL,
  DELIVERY_TYPE    TEXT   NOT NULL,
  DELIVERY_CONFIG  TEXT,
  IS_ACTIVE        INTEGER      DEFAULT 1,
  LAST_RUN_AT      TEXT,
  LAST_RUN_STATUS  TEXT,
  NEXT_RUN_AT      TEXT,
  CREATED_BY       TEXT   REFERENCES NB_USERS(USER_ID),
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ─── 30. AUDIT_LOG ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_AUDIT_LOG (
  LOG_ID           TEXT PRIMARY KEY,
  USER_ID          TEXT   NOT NULL,
  TENANT_ID           TEXT,
  ACTION           TEXT  NOT NULL,
  RESOURCE_TYPE    TEXT,
  RESOURCE_ID      TEXT,
  REQUEST_PAYLOAD  TEXT,
  RESPONSE_STATUS  NUMERIC,
  IP_ADDRESS       TEXT,
  DURATION_MS      NUMERIC,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_AUDIT_ORG_DATE ON NB_AUDIT_LOG(TENANT_ID, CREATED_AT DESC);
CREATE INDEX IF NOT EXISTS IDX_AUDIT_USER     ON NB_AUDIT_LOG(USER_ID, CREATED_AT DESC);

-- ─── 31. PLATFORM_CONFIG ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_PLATFORM_CONFIG (
  CONFIG_KEY       TEXT  PRIMARY KEY,
  CONFIG_VALUE     TEXT           NOT NULL,
  CONFIG_TYPE      TEXT   DEFAULT 'STRING',
  DESCRIPTION      TEXT,
  IS_SECRET        INTEGER      DEFAULT 0,
  UPDATED_BY       TEXT,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP
);


-- ════════════════════════════════════════════════════════════════════
-- SEED: 38 Permissions
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.view',       'datasource',  'View data sources');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.create',     'datasource',  'Create data sources');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.edit',       'datasource',  'Edit data sources');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.delete',     'datasource',  'Delete data sources');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.test',       'datasource',  'Test data source connections');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'datasource.manage_acl', 'datasource',  'Manage data source access controls');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'schema.view',           'schema',      'View cube schemas');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'schema.edit',           'schema',      'Edit cube schemas');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'schema.create',         'schema',      'Create cube schemas');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'schema.delete',         'schema',      'Delete cube schemas');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'explorer.use',          'explorer',    'Use the data explorer');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.view',        'dashboard',   'View dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.create',      'dashboard',   'Create dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.edit',        'dashboard',   'Edit dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.delete',      'dashboard',   'Delete dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.submit',      'dashboard',   'Submit dashboards for review');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.approve',     'dashboard',   'Approve pending dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.reject',      'dashboard',   'Reject pending dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.share',       'dashboard',   'Share dashboards with roles/users');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.embed',       'dashboard',   'Generate embed tokens');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.export',      'dashboard',   'Export dashboards to PDF/image');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'dashboard.replay',      'dashboard',   'View approval replay history');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'lineage.view',          'lineage',     'View data lineage graph');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'report.schedule',       'report',      'Create and manage scheduled reports');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'tableau.import',        'tableau',     'Import Tableau workbooks');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'perf.view',             'performance', 'View performance scorecards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'preagg.manage',         'performance', 'Manage pre-aggregation recommendations');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'webhook.manage',        'webhook',     'Manage outbound webhook endpoints');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'template.view',         'template',    'Browse template marketplace');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'template.install',      'template',    'Install templates as dashboards');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'template.publish',      'template',    'Publish dashboards as templates');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'admin.roles',           'admin',       'Manage roles and permissions');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'admin.users',           'admin',       'Manage user accounts');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'admin.platform',        'admin',       'Manage platform configuration');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'audit.view',            'admin',       'View audit log');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'file.upload',           'file',        'Upload files');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'file.manage',           'file',        'Manage uploaded files');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'api_source.manage',     'api_source',  'Manage API data sources');

-- ════════════════════════════════════════════════════════════════════
-- SEED: 6 Roles
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_PADMIN',  'PLATFORM_ADMIN',  'Full platform administration',  1);
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_DSADMIN', 'DS_ADMIN',        'Data source administration',    1);
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_AUTHOR',  'AUTHOR',          'Dashboard creation and editing',1);
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_CHECKER', 'CHECKER',         'Dashboard approval workflow',   1);
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_VIEWER',  'VIEWER',          'Dashboard viewing only',        1);
INSERT OR IGNORE INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_EMBED',   'EMBED_ONLY',      'Embedded dashboard access',     1);

-- ════════════════════════════════════════════════════════════════════
-- SEED: Role → Permission Map
-- ════════════════════════════════════════════════════════════════════

-- PLATFORM_ADMIN → ALL 38 permissions
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS;

-- DS_ADMIN → 18 permissions
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_DSADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('datasource.view','datasource.create','datasource.edit','datasource.delete','datasource.test','datasource.manage_acl',
                      'schema.view','schema.edit','schema.create','schema.delete',
                      'explorer.use','lineage.view','file.upload','file.manage','api_source.manage',
                      'perf.view','preagg.manage','tableau.import');

-- AUTHOR → 19 permissions
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('datasource.view','schema.view','explorer.use','lineage.view',
                      'dashboard.view','dashboard.create','dashboard.edit','dashboard.delete','dashboard.submit',
                      'dashboard.share','dashboard.embed','dashboard.export','dashboard.replay',
                      'report.schedule','template.view','template.install','template.publish',
                      'perf.view','file.upload');

-- CHECKER → 6 permissions
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_CHECKER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('dashboard.view','dashboard.approve','dashboard.reject','dashboard.replay','lineage.view','perf.view');

-- VIEWER → 4 permissions
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('dashboard.view','template.view','explorer.use','lineage.view');

-- EMBED_ONLY → 1 permission
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_EMBED', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE = 'dashboard.view';


-- ════════════════════════════════════════════════════════════════════
-- SEED: Default Organization
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_TENANTS (TENANT_ID, TENANT_NAME, TENANT_SLUG) VALUES ('TENANT_DEFAULT', 'Default Tenant', 'default');


-- ════════════════════════════════════════════════════════════════════
-- SEED: 6 Dummy Users (for testing)
--
-- admin:       Admin@123!   hash = $2b$12$J.XKzQGvrL7SLDAOt9MRe.hV3EPH8OnRAfUNSAkovVwLdGjpQBv9G
-- others:      Test@123!    hash = $2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6
-- Hashes regenerated 2026-04-20 with bcryptjs@2.4.3, cost factor 12. Verified.
-- Use INSERT OR REPLACE so re-running this seed on an existing DB overwrites stale hashes.
-- ════════════════════════════════════════════════════════════════════

-- 1. admin (PLATFORM_ADMIN) — password: Admin@123!
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_ADMIN', 'admin@nexusbi.local', 'admin',
          '$2b$12$J.XKzQGvrL7SLDAOt9MRe.hV3EPH8OnRAfUNSAkovVwLdGjpQBv9G',
          'Platform Administrator', 'TENANT_DEFAULT');

-- 2. author1 (AUTHOR) — password: Test@123!
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_AUTHOR1', 'sarah.chen@acme.local', 'author1',
          '$2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6',
          'Sarah Chen', 'TENANT_DEFAULT');

-- 3. checker1 (CHECKER) — password: Test@123!
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_CHECKER1', 'michael.kim@acme.local', 'checker1',
          '$2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6',
          'Michael Kim', 'TENANT_DEFAULT');

-- 4. checker2 (CHECKER) — password: Test@123! (needed for dual-checker testing)
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_CHECKER2', 'emma.wilson@acme.local', 'checker2',
          '$2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6',
          'Emma Wilson', 'TENANT_DEFAULT');

-- 5. viewer1 (VIEWER) — password: Test@123!
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_VIEWER1', 'david.lee@acme.local', 'viewer1',
          '$2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6',
          'David Lee', 'TENANT_DEFAULT');

-- 6. embed_user (EMBED_ONLY) — password: Test@123!
INSERT OR REPLACE INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID)
  VALUES ('USR_EMBED', 'embed@nexusbi.local', 'embed_user',
          '$2b$12$Lr5LHY2nnu..ci4YbpstEu/qbWEFCRyCGrFBVxEGUQMCaKnJEM0B6',
          'Embed Service Account', 'TENANT_DEFAULT');


-- ════════════════════════════════════════════════════════════════════
-- SEED: User → Role Assignments
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_ADMIN',    'R_PADMIN',  'TENANT_DEFAULT', 'SYSTEM');
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_AUTHOR1',  'R_AUTHOR',  'TENANT_DEFAULT', 'SYSTEM');
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_CHECKER1', 'R_CHECKER', 'TENANT_DEFAULT', 'SYSTEM');
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_CHECKER2', 'R_CHECKER', 'TENANT_DEFAULT', 'SYSTEM');
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_VIEWER1',  'R_VIEWER',  'TENANT_DEFAULT', 'SYSTEM');
INSERT OR IGNORE INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_BY) VALUES ('USR_EMBED',    'R_EMBED',   'TENANT_DEFAULT', 'SYSTEM');


-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Dashboards (3 dashboards in different states)
-- ════════════════════════════════════════════════════════════════════

-- Dashboard 1: APPROVED (visible to VIEWER)
INSERT OR IGNORE INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, TENANT_ID, VERSION, TAGS, APPROVAL_STATUS, APPROVED_BY, APPROVED_AT, SOURCE)
  VALUES ('DASH_REVENUE', 'Q4 Revenue Overview',
          'Quarterly revenue performance across all regions with product breakdown.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"Total Revenue","staticValue":"$4.28M","subtitle":"↑ 14.2% vs Q3","x":0,"y":0,"w":3,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"Orders","staticValue":"12,847","subtitle":"↑ 8.1%","x":3,"y":0,"w":3,"h":3},{"widgetId":"w3","widgetType":"kpi","title":"AOV","staticValue":"$333","subtitle":"↓ 2.1%","x":6,"y":0,"w":3,"h":3},{"widgetId":"w4","widgetType":"chart","title":"Revenue by Region","echartsOption":{"xAxis":{"type":"category","data":["APAC","EMEA","Americas","ANZ"]},"yAxis":{"type":"value"},"series":[{"data":[1420000,980000,1560000,320000],"type":"bar","itemStyle":{"color":"#1e40af"}}],"grid":{"left":60,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":8,"h":6},{"widgetId":"w5","widgetType":"table","title":"Top Products","columns":["Product","Revenue","Growth"],"rows":[["Enterprise Plan","$1.2M","+18%"],["Pro Plan","$847K","+12%"],["Team Plan","$562K","+5%"],["Starter","$231K","-3%"]],"x":8,"y":3,"w":4,"h":6}]',
          'USR_AUTHOR1', 'TENANT_DEFAULT', 3, 'revenue,quarterly,q4', 'APPROVED', 'USR_CHECKER1', CURRENT_TIMESTAMP, 'MANUAL');

INSERT OR IGNORE INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (lower(hex(randomblob(16))), 'DASH_REVENUE', 3, 'USR_AUTHOR1', 'Q4 final numbers updated');

-- Dashboard 2: DRAFT (only visible to AUTHOR and above)
INSERT OR IGNORE INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, TENANT_ID, VERSION, TAGS, APPROVAL_STATUS, SOURCE)
  VALUES ('DASH_CHURN', 'Customer Churn Analysis',
          'Monthly churn rates, cohort retention curves, and at-risk account identification.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"Monthly Churn Rate","staticValue":"2.4%","subtitle":"↓ 0.3pp","x":0,"y":0,"w":4,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"At-Risk Accounts","staticValue":"47","subtitle":"Need attention","x":4,"y":0,"w":4,"h":3},{"widgetId":"w3","widgetType":"chart","title":"Churn Trend","echartsOption":{"xAxis":{"type":"category","data":["Jan","Feb","Mar","Apr","May","Jun"]},"yAxis":{"type":"value","axisLabel":{"formatter":"{value}%"}},"series":[{"data":[3.2,2.9,2.7,2.8,2.5,2.4],"type":"line","smooth":true,"itemStyle":{"color":"#c2410c"}}],"grid":{"left":50,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":12,"h":6}]',
          'USR_AUTHOR1', 'TENANT_DEFAULT', 1, 'churn,retention', 'DRAFT', 'MANUAL');

INSERT OR IGNORE INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (lower(hex(randomblob(16))), 'DASH_CHURN', 1, 'USR_AUTHOR1', 'Initial creation');

-- Dashboard 3: PENDING_REVIEW with dual-checker (testing approval workflow)
INSERT OR IGNORE INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, TENANT_ID, VERSION, TAGS, APPROVAL_STATUS, SOURCE, DUAL_CHECKER_REQUIRED)
  VALUES ('DASH_APAC', 'APAC Sales Performance',
          'Regional sales metrics for Asia-Pacific with country-level breakdown.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"APAC Revenue","staticValue":"$1.42M","subtitle":"↑ 22.7%","x":0,"y":0,"w":4,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"New Customers","staticValue":"284","subtitle":"↑ 18%","x":4,"y":0,"w":4,"h":3},{"widgetId":"w3","widgetType":"chart","title":"Revenue by Country","echartsOption":{"xAxis":{"type":"category","data":["Japan","Australia","India","Singapore","Korea"]},"yAxis":{"type":"value"},"series":[{"data":[480000,320000,280000,190000,150000],"type":"bar","itemStyle":{"color":"#047857"}}],"grid":{"left":60,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":12,"h":6}]',
          'USR_AUTHOR1', 'TENANT_DEFAULT', 2, 'apac,sales,regional', 'PENDING_REVIEW', 'MANUAL', 1);

INSERT OR IGNORE INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (lower(hex(randomblob(16))), 'DASH_APAC', 2, 'USR_AUTHOR1', 'Added country breakdown chart');

-- Review record for the pending dashboard
INSERT OR IGNORE INTO NB_DASHBOARD_REVIEWS (REVIEW_ID, DASH_ID, DASH_VERSION, SUBMITTED_BY, REVIEW_STATUS, TENANT_ID)
  VALUES ('REV_APAC_01', 'DASH_APAC', 2, 'USR_AUTHOR1', 'PENDING', 'TENANT_DEFAULT');


-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Platform Config
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('app.name', 'NexusBI', 'STRING', 'Application display name', 0);
INSERT OR IGNORE INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('app.version', '6.0.0', 'STRING', 'Application version', 0);
INSERT OR IGNORE INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('approval.dual_checker_default', 'false', 'BOOLEAN', 'Default dual-checker requirement for new dashboards', 0);


-- ════════════════════════════════════════════════════════════════════
-- WORKBOOK SYSTEM (Tableau replacement: workbooks, worksheets,
-- calculated fields, parameters, stories, dashboard actions)
-- ════════════════════════════════════════════════════════════════════

-- 32. WORKBOOKS — Author's personal workspace (Tableau .twbx equivalent)
CREATE TABLE IF NOT EXISTS NB_WORKBOOKS (
  WORKBOOK_ID       TEXT PRIMARY KEY,
  WORKBOOK_NAME     TEXT  NOT NULL,
  DESCRIPTION       TEXT,
  OWNER_ID          TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  TENANT_ID            TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  DS_ID             TEXT   REFERENCES NB_DATA_SOURCES(DS_ID),
  TAGS              TEXT,
  IS_PUBLISHED      INTEGER      DEFAULT 0,
  PUBLISHED_DASH_ID TEXT   REFERENCES NB_DASHBOARDS(DASH_ID),
  THUMBNAIL_URL     TEXT,
  VERSION           NUMERIC         DEFAULT 1,
  CREATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_WB_OWNER ON NB_WORKBOOKS(OWNER_ID, TENANT_ID);

-- 33. WORKSHEETS — Single analysis view inside a workbook (one chart/table)
CREATE TABLE IF NOT EXISTS NB_WORKSHEETS (
  WORKSHEET_ID    TEXT PRIMARY KEY,
  WORKBOOK_ID     TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  WORKSHEET_NAME  TEXT  NOT NULL,
  SORT_ORDER      NUMERIC         DEFAULT 0,
  CHART_TYPE      TEXT   NOT NULL,
  SHELVES_JSON    TEXT           NOT NULL,
  CUBE_QUERY_JSON TEXT,
  CUBE_NAME       TEXT,
  SORT_SPECS_JSON TEXT,
  MARK_TYPE       TEXT,
  COLOR_PALETTE   TEXT,
  AXIS_CONFIG     TEXT,
  TOOLTIP_CONFIG  TEXT,
  REF_LINES_JSON  TEXT,
  ANNOTATIONS_JSON TEXT,
  CREATED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_WS_WORKBOOK ON NB_WORKSHEETS(WORKBOOK_ID, SORT_ORDER);

-- 34. CALCULATED FIELDS — Custom dimensions/measures defined per workbook
CREATE TABLE IF NOT EXISTS NB_CALCULATED_FIELDS (
  FIELD_ID         TEXT PRIMARY KEY,
  WORKBOOK_ID      TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  FIELD_NAME       TEXT  NOT NULL,
  EXPRESSION       TEXT           NOT NULL,
  FIELD_TYPE       TEXT   NOT NULL CHECK (FIELD_TYPE IN ('dimension', 'measure')),
  DATA_TYPE        TEXT   NOT NULL CHECK (DATA_TYPE IN ('string', 'NUMERIC', 'date', 'boolean')),
  DESCRIPTION      TEXT,
  IS_VALID         INTEGER      DEFAULT 1,
  VALIDATION_ERROR TEXT,
  LOD_TYPE         TEXT,
  LOD_DIMENSIONS   TEXT,
  LOD_AGGREGATION  TEXT,
  LOD_FILTER       TEXT,
  CREATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT       TEXT      DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT UK_CF_WB_NAME UNIQUE (WORKBOOK_ID, FIELD_NAME)
);

-- 35. PARAMETERS — User-configurable variables (Tableau parameters)
CREATE TABLE IF NOT EXISTS NB_PARAMETERS (
  PARAMETER_ID      TEXT PRIMARY KEY,
  WORKBOOK_ID       TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  PARAMETER_NAME    TEXT  NOT NULL,
  DISPLAY_NAME      TEXT  NOT NULL,
  DATA_TYPE         TEXT   NOT NULL CHECK (DATA_TYPE IN ('string','integer','float','date','boolean')),
  CURRENT_VALUE     TEXT NOT NULL,
  DEFAULT_VALUE     TEXT NOT NULL,
  ALLOWABLE_TYPE    TEXT   NOT NULL CHECK (ALLOWABLE_TYPE IN ('all','list','range')),
  ALLOWABLE_VALUES  TEXT,
  RANGE_MIN         TEXT,
  RANGE_MAX         TEXT,
  RANGE_STEP        TEXT,
  CREATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT UK_PARAM_WB_NAME UNIQUE (WORKBOOK_ID, PARAMETER_NAME)
);

-- 36. STORIES — Multi-dashboard narrative sequences (Tableau Story)
CREATE TABLE IF NOT EXISTS NB_STORIES (
  STORY_ID      TEXT PRIMARY KEY,
  STORY_NAME    TEXT  NOT NULL,
  DESCRIPTION   TEXT,
  OWNER_ID      TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  TENANT_ID        TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  IS_PUBLISHED  INTEGER      DEFAULT 0,
  VERSION       NUMERIC         DEFAULT 1,
  CREATED_AT    TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT    TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- 37. STORY POINTS — Individual frames within a story
CREATE TABLE IF NOT EXISTS NB_STORY_POINTS (
  POINT_ID         TEXT PRIMARY KEY,
  STORY_ID         TEXT   NOT NULL REFERENCES NB_STORIES(STORY_ID) ON DELETE CASCADE,
  SORT_ORDER       NUMERIC         NOT NULL,
  POINT_TYPE       TEXT   NOT NULL CHECK (POINT_TYPE IN ('dashboard','worksheet','text','image')),
  TITLE            TEXT  NOT NULL,
  NARRATIVE        TEXT,
  DASH_ID          TEXT   REFERENCES NB_DASHBOARDS(DASH_ID),
  WORKSHEET_ID     TEXT   REFERENCES NB_WORKSHEETS(WORKSHEET_ID),
  CONTENT_JSON     TEXT,
  FILTER_OVERRIDES TEXT
);
CREATE INDEX IF NOT EXISTS IDX_SP_STORY ON NB_STORY_POINTS(STORY_ID, SORT_ORDER);

-- 38. DASHBOARD ACTIONS — Inter-widget filter/highlight/URL actions
CREATE TABLE IF NOT EXISTS NB_DASHBOARD_ACTIONS (
  ACTION_ID         TEXT PRIMARY KEY,
  DASH_ID           TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  ACTION_NAME       TEXT  NOT NULL,
  ACTION_TYPE       TEXT   NOT NULL CHECK (ACTION_TYPE IN ('filter','highlight','url','parameter')),
  TRIGGER_TYPE      TEXT   NOT NULL CHECK (TRIGGER_TYPE IN ('select','hover','menu')),
  SOURCE_WIDGET_ID  TEXT   NOT NULL,
  TARGET_WIDGETS    TEXT           NOT NULL,
  SOURCE_FIELD      TEXT,
  TARGET_FIELD      TEXT,
  URL_TEMPLATE      TEXT,
  PARAMETER_NAME    TEXT,
  IS_ENABLED        INTEGER      DEFAULT 1,
  CREATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- 39. DATA EXTRACTS — Scheduled snapshots into Oracle staging
CREATE TABLE IF NOT EXISTS NB_DATA_EXTRACTS (
  EXTRACT_ID         TEXT PRIMARY KEY,
  DS_ID              TEXT   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  EXTRACT_NAME       TEXT  NOT NULL,
  QUERY_EXPRESSION   TEXT           NOT NULL,
  REFRESH_SCHEDULE   TEXT,
  LAST_REFRESHED_AT  TEXT,
  ROW_COUNT          NUMERIC         DEFAULT 0,
  STAGING_TABLE      TEXT  NOT NULL,
  IS_INCREMENTAL     INTEGER      DEFAULT 0,
  INCREMENTAL_COLUMN TEXT,
  TENANT_ID             TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CREATED_AT         TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- 40. DATA SETS — Static or computed groups of dimension members
CREATE TABLE IF NOT EXISTS NB_DATA_SETS (
  SET_ID          TEXT PRIMARY KEY,
  WORKBOOK_ID     TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  SET_NAME        TEXT  NOT NULL,
  SET_TYPE        TEXT   NOT NULL CHECK (SET_TYPE IN ('static','computed')),
  BASE_DIMENSION  TEXT  NOT NULL,
  STATIC_MEMBERS  TEXT,
  CONDITION_JSON  TEXT,
  TOP_N_JSON      TEXT,
  CREATED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- 41. DATA GROUPS — Bucketing dimension members into named groups
CREATE TABLE IF NOT EXISTS NB_DATA_GROUPS (
  GROUP_ID        TEXT PRIMARY KEY,
  WORKBOOK_ID     TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  GROUP_NAME      TEXT  NOT NULL,
  BASE_DIMENSION  TEXT  NOT NULL,
  GROUP_MEMBERS   TEXT           NOT NULL,
  INCLUDE_OTHER   INTEGER      DEFAULT 1,
  OTHER_LABEL     TEXT  DEFAULT 'Other',
  CREATED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP
);

-- ════════════════════════════════════════════════════════════════════
-- WORKBOOK PERMISSIONS — Add to NB_PERMISSIONS
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'workbook.view',     'workbook', 'View own workbooks');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'workbook.create',   'workbook', 'Create new workbooks');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'workbook.edit',     'workbook', 'Edit workbooks');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'workbook.delete',   'workbook', 'Delete workbooks');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'workbook.publish',  'workbook', 'Publish workbook to dashboard');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'story.view',        'story',    'View stories');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'story.create',      'story',    'Create stories');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'story.edit',        'story',    'Edit stories');

-- Grant workbook + story perms to PLATFORM_ADMIN
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('workbook.view','workbook.create','workbook.edit','workbook.delete','workbook.publish','story.view','story.create','story.edit');

-- Grant workbook + story perms to AUTHOR (the Maker role)
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('workbook.view','workbook.create','workbook.edit','workbook.delete','workbook.publish','story.view','story.create','story.edit');

-- Grant story.view to VIEWER
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS WHERE PERM_CODE = 'story.view';

-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Workbook (so AUTHOR has something to start with)
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_WORKBOOKS (WORKBOOK_ID, WORKBOOK_NAME, DESCRIPTION, OWNER_ID, TENANT_ID, TAGS, VERSION)
  VALUES ('WB_REVENUE', 'Revenue Analysis Workbook',
          'Personal workspace for exploring quarterly revenue across regions and products.',
          'USR_AUTHOR1', 'TENANT_DEFAULT', 'revenue,exploratory', 1);

INSERT OR IGNORE INTO NB_WORKSHEETS (WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME)
  VALUES ('WS_REGION', 'WB_REVENUE', 'Revenue by Region', 0, 'bar',
          '{"columns":["region"],"rows":["total_revenue"],"color":"region","size":null,"label":null,"detail":[],"tooltip":[],"filters":[],"pages":[]}',
          'Orders');

INSERT OR IGNORE INTO NB_WORKSHEETS (WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME)
  VALUES ('WS_TREND', 'WB_REVENUE', 'Revenue Trend', 1, 'line',
          '{"columns":["order_date.month"],"rows":["total_revenue"],"color":null,"size":null,"label":null,"detail":[],"tooltip":[],"filters":[],"pages":[]}',
          'Orders');

INSERT OR IGNORE INTO NB_CALCULATED_FIELDS (FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID)
  VALUES (lower(hex(randomblob(16))), 'WB_REVENUE', 'profit_margin', '(total_revenue - total_cost) / NULLIF(total_revenue, 0)', 'measure', 'NUMERIC',
          'Profit margin as a percentage of revenue', 1);

INSERT OR IGNORE INTO NB_CALCULATED_FIELDS (FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID)
  VALUES (lower(hex(randomblob(16))), 'WB_REVENUE', 'revenue_bucket', 'CASE WHEN total_revenue > 1000000 THEN ''High'' WHEN total_revenue > 100000 THEN ''Mid'' ELSE ''Low'' END', 'dimension', 'string',
          'Bucket revenue into High/Mid/Low tiers', 1);

INSERT OR IGNORE INTO NB_PARAMETERS (PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE, CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, ALLOWABLE_VALUES)
  VALUES (lower(hex(randomblob(16))), 'WB_REVENUE', 'target_region', 'Target Region', 'string', 'APAC', 'APAC', 'list',
          '["APAC","EMEA","Americas","ANZ","LATAM"]');

INSERT OR IGNORE INTO NB_PARAMETERS (PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE, CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, RANGE_MIN, RANGE_MAX, RANGE_STEP)
  VALUES (lower(hex(randomblob(16))), 'WB_REVENUE', 'min_revenue', 'Minimum Revenue', 'integer', '100000', '100000', 'range',
          '0', '10000000', '50000');

-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Story
-- ════════════════════════════════════════════════════════════════════
INSERT OR IGNORE INTO NB_STORIES (STORY_ID, STORY_NAME, DESCRIPTION, OWNER_ID, TENANT_ID, IS_PUBLISHED, VERSION)
  VALUES ('STORY_Q4', 'Q4 Performance Story',
          'Walkthrough of Q4 results across regions, products, and trends.',
          'USR_AUTHOR1', 'TENANT_DEFAULT', 1, 1);

INSERT OR IGNORE INTO NB_STORY_POINTS (POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE, DASH_ID)
  VALUES (lower(hex(randomblob(16))), 'STORY_Q4', 0, 'dashboard', 'Q4 Revenue Overview',
          'We exceeded Q3 revenue by 14.2%, driven primarily by APAC and Americas.', 'DASH_REVENUE');

INSERT OR IGNORE INTO NB_STORY_POINTS (POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE)
  VALUES (lower(hex(randomblob(16))), 'STORY_Q4', 1, 'text', 'Key Takeaways',
          'Three things stood out this quarter: (1) APAC growth of 22.7%, (2) AOV decline of 2.1% needs attention, (3) Enterprise Plan continues to be our top revenue driver at $1.2M.');

-- ════════════════════════════════════════════════════════════════════
-- SEED: Dashboard Shares (so VIEWER role sees ONLY shared dashboards)
-- ════════════════════════════════════════════════════════════════════
-- Share Q4 Revenue dashboard with viewer1 specifically
INSERT OR IGNORE INTO NB_DASHBOARD_SHARES (SHARE_ID, DASH_ID, USER_ID, CAN_EDIT, CAN_SHARE, TENANT_ID)
  VALUES (lower(hex(randomblob(16))), 'DASH_REVENUE', 'USR_VIEWER1', 0, 0, 'TENANT_DEFAULT');

-- Share Q4 Revenue dashboard with the entire VIEWER role
INSERT OR IGNORE INTO NB_DASHBOARD_SHARES (SHARE_ID, DASH_ID, ROLE_ID, CAN_EDIT, CAN_SHARE, TENANT_ID)
  VALUES (lower(hex(randomblob(16))), 'DASH_REVENUE', 'R_VIEWER', 0, 0, 'TENANT_DEFAULT');


-- ========= v7 EXTENSIONS =========
-- ════════════════════════════════════════════════════════════════════
-- NexusBI v7 Extensions: Tier 1 + Tier 2 + Tier 3 + Collaboration
-- Adds: hierarchies, shape library, data flows, profile cache,
--       comments, subscriptions, alerts
-- Run AFTER oracle-seed.sql
-- ════════════════════════════════════════════════════════════════════

-- ── TIER 1: HIERARCHIES ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_HIERARCHIES (
  HIER_ID       TEXT PRIMARY KEY,
  WORKBOOK_ID   TEXT   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  HIER_NAME     TEXT  NOT NULL,
  LEVELS_JSON   TEXT           NOT NULL,
  CREATED_AT    TEXT      DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT UK_HIER_WB_NAME UNIQUE (WORKBOOK_ID, HIER_NAME)
);
CREATE INDEX IF NOT EXISTS IDX_HIER_WB ON NB_HIERARCHIES(WORKBOOK_ID);

-- LOD expressions live as a column on NB_CALCULATED_FIELDS
-- LOD_* columns were previously added via ALTER TABLE here, but they are now folded
-- directly into the NB_CALCULATED_FIELDS CREATE TABLE above so this seed is safe
-- to re-run on an existing database (SQLite ALTER TABLE ADD COLUMN lacks IF NOT EXISTS).

-- ── TIER 2: SHAPE LIBRARY ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_SHAPE_LIBRARY (
  SHAPE_ID        TEXT PRIMARY KEY,
  TENANT_ID          TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  SHAPE_NAME      TEXT  NOT NULL,
  SHAPE_CATEGORY  TEXT,
  SVG_CONTENT     TEXT           NOT NULL,
  VIEW_BOX        TEXT  DEFAULT '0 0 24 24',
  IS_SYSTEM       INTEGER      DEFAULT 0,
  CREATED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT UK_SHAPE_TENANT_NAME UNIQUE (TENANT_ID, SHAPE_NAME)
);
CREATE INDEX IF NOT EXISTS IDX_SHAPE_ORG ON NB_SHAPE_LIBRARY(TENANT_ID, SHAPE_CATEGORY);

-- ── TIER 3: DATA FLOWS ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_DATA_FLOWS (
  FLOW_ID       TEXT PRIMARY KEY,
  TENANT_ID        TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  FLOW_NAME     TEXT  NOT NULL,
  DESCRIPTION   TEXT,
  OWNER_ID      TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  NODES_JSON    TEXT           NOT NULL,
  EDGES_JSON    TEXT           NOT NULL,
  VERSION       NUMERIC         DEFAULT 1,
  CREATED_AT    TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT    TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_DF_OWNER ON NB_DATA_FLOWS(OWNER_ID, TENANT_ID);

CREATE TABLE IF NOT EXISTS NB_DATA_FLOW_RUNS (
  RUN_ID              TEXT PRIMARY KEY,
  FLOW_ID             TEXT   NOT NULL REFERENCES NB_DATA_FLOWS(FLOW_ID) ON DELETE CASCADE,
  STATUS              TEXT   NOT NULL CHECK (STATUS IN ('queued','running','success','failed','cancelled')),
  STARTED_AT          TEXT      DEFAULT CURRENT_TIMESTAMP,
  FINISHED_AT         TEXT,
  TRIGGERED_BY        TEXT  NOT NULL,
  NODE_RESULTS_JSON   TEXT,
  ERROR_MESSAGE       TEXT,
  TOTAL_ROWS          NUMERIC         DEFAULT 0,
  DURATION_MS         NUMERIC         DEFAULT 0
);
CREATE INDEX IF NOT EXISTS IDX_DFR_FLOW ON NB_DATA_FLOW_RUNS(FLOW_ID, STARTED_AT DESC);

CREATE TABLE IF NOT EXISTS NB_SCHEDULED_FLOWS (
  SCHEDULE_ID             TEXT PRIMARY KEY,
  FLOW_ID                 TEXT   NOT NULL REFERENCES NB_DATA_FLOWS(FLOW_ID) ON DELETE CASCADE,
  CRON_EXPRESSION         TEXT  NOT NULL,
  NOTIFY_ON_FAILURE       TEXT   DEFAULT 'none' CHECK (NOTIFY_ON_FAILURE IN ('none','email','webhook','both')),
  NOTIFY_EMAILS_JSON      TEXT,
  WEBHOOK_URL             TEXT,
  MAX_RUNTIME_MINUTES     NUMERIC         DEFAULT 60,
  INCREMENTAL_COLUMN      TEXT,
  INCREMENTAL_WATERMARK   TEXT,
  IS_ENABLED              INTEGER      DEFAULT 1,
  LAST_RUN_AT             TEXT,
  LAST_RUN_STATUS         TEXT,
  CREATED_AT              TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_SCHED_ENABLED ON NB_SCHEDULED_FLOWS(IS_ENABLED, CRON_EXPRESSION);

CREATE TABLE IF NOT EXISTS NB_PROFILE_CACHE (
  CACHE_ID          TEXT PRIMARY KEY,
  TABLE_NAME        TEXT  NOT NULL,
  COLUMN_NAME       TEXT  NOT NULL,
  TENANT_ID            TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  PROFILE_JSON      TEXT           NOT NULL,
  CACHED_AT         TEXT      DEFAULT CURRENT_TIMESTAMP,
  EXPIRES_AT        TEXT      DEFAULT (datetime(CURRENT_TIMESTAMP, '+1 hour')),
  CONSTRAINT UK_PROFILE_CACHE UNIQUE (TENANT_ID, TABLE_NAME, COLUMN_NAME)
);
CREATE INDEX IF NOT EXISTS IDX_PROFILE_EXPIRES ON NB_PROFILE_CACHE(EXPIRES_AT);

-- ── COLLABORATION: WIDGET COMMENTS ──────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_WIDGET_COMMENTS (
  COMMENT_ID        TEXT PRIMARY KEY,
  DASH_ID           TEXT   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  WIDGET_ID         TEXT  NOT NULL,
  PARENT_ID         TEXT   REFERENCES NB_WIDGET_COMMENTS(COMMENT_ID),
  USER_ID           TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  CONTENT           TEXT           NOT NULL,
  MARK_CONTEXT      TEXT,
  MENTIONED_USERS   TEXT,
  RESOLVED          INTEGER      DEFAULT 0,
  CREATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT        TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_WC_DASH ON NB_WIDGET_COMMENTS(DASH_ID, WIDGET_ID, CREATED_AT DESC);
CREATE INDEX IF NOT EXISTS IDX_WC_PARENT ON NB_WIDGET_COMMENTS(PARENT_ID);

-- ── COLLABORATION: SUBSCRIPTIONS ────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_SUBSCRIPTIONS (
  SUBSCRIPTION_ID      TEXT PRIMARY KEY,
  SUBSCRIPTION_TYPE    TEXT   NOT NULL CHECK (SUBSCRIPTION_TYPE IN ('dashboard','widget','story')),
  TARGET_ID            TEXT  NOT NULL,
  OWNER_ID             TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  TENANT_ID               TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  SUB_NAME             TEXT  NOT NULL,
  CRON_EXPRESSION      TEXT  NOT NULL,
  TIMEZONE             TEXT  DEFAULT 'UTC',
  DELIVERY_CHANNELS    TEXT           NOT NULL,
  RECIPIENTS           TEXT           NOT NULL,
  RENDER_FORMAT        TEXT   DEFAULT 'png' CHECK (RENDER_FORMAT IN ('png','pdf','csv','xlsx','html')),
  FILTER_OVERRIDES     TEXT,
  EMAIL_SUBJECT        TEXT,
  EMAIL_BODY           TEXT,
  IS_ENABLED           INTEGER      DEFAULT 1,
  LAST_DELIVERED_AT    TEXT,
  LAST_STATUS          TEXT,
  CREATED_AT           TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT           TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_SUB_OWNER ON NB_SUBSCRIPTIONS(OWNER_ID, TENANT_ID);
CREATE INDEX IF NOT EXISTS IDX_SUB_ENABLED ON NB_SUBSCRIPTIONS(IS_ENABLED, CRON_EXPRESSION);

CREATE TABLE IF NOT EXISTS NB_SUBSCRIPTION_DELIVERIES (
  DELIVERY_ID       TEXT PRIMARY KEY,
  SUBSCRIPTION_ID   TEXT   NOT NULL REFERENCES NB_SUBSCRIPTIONS(SUBSCRIPTION_ID) ON DELETE CASCADE,
  STATUS            TEXT   NOT NULL CHECK (STATUS IN ('success','failed')),
  DELIVERED_AT      TEXT      DEFAULT CURRENT_TIMESTAMP,
  DURATION_MS       NUMERIC         DEFAULT 0,
  ERROR_MESSAGE     TEXT,
  RECIPIENT_COUNT   NUMERIC         DEFAULT 0,
  FILE_SIZE         NUMERIC
);
CREATE INDEX IF NOT EXISTS IDX_SD_SUB ON NB_SUBSCRIPTION_DELIVERIES(SUBSCRIPTION_ID, DELIVERED_AT DESC);

-- ── COLLABORATION: SMART ALERTS ─────────────────────────────────────
CREATE TABLE IF NOT EXISTS NB_ALERTS (
  ALERT_ID                  TEXT PRIMARY KEY,
  DASH_ID                   TEXT   REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  WIDGET_ID                 TEXT,
  CUBE_NAME                 TEXT  NOT NULL,
  ALERT_NAME                TEXT  NOT NULL,
  DESCRIPTION               TEXT,
  OWNER_ID                  TEXT   NOT NULL REFERENCES NB_USERS(USER_ID),
  TENANT_ID                    TEXT   NOT NULL REFERENCES NB_TENANTS(TENANT_ID),
  CONDITION_JSON            TEXT           NOT NULL,
  CHECK_FREQUENCY           TEXT  NOT NULL,
  NOTIFICATION_CHANNELS     TEXT           NOT NULL,
  RECIPIENTS                TEXT           NOT NULL,
  COOLDOWN_MINUTES          NUMERIC         DEFAULT 60,
  LAST_TRIGGERED_AT         TEXT,
  LAST_CHECKED_AT           TEXT,
  LAST_VALUE                NUMERIC,
  IS_ENABLED                INTEGER      DEFAULT 1,
  CREATED_AT                TEXT      DEFAULT CURRENT_TIMESTAMP,
  UPDATED_AT                TEXT      DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX IF NOT EXISTS IDX_ALERT_OWNER ON NB_ALERTS(OWNER_ID, TENANT_ID);
CREATE INDEX IF NOT EXISTS IDX_ALERT_ENABLED ON NB_ALERTS(IS_ENABLED, CHECK_FREQUENCY);

CREATE TABLE IF NOT EXISTS NB_ALERT_FIRINGS (
  FIRING_ID         TEXT PRIMARY KEY,
  ALERT_ID          TEXT   NOT NULL REFERENCES NB_ALERTS(ALERT_ID) ON DELETE CASCADE,
  FIRED_AT          TEXT      DEFAULT CURRENT_TIMESTAMP,
  TRIGGER_VALUE     NUMERIC,
  PREVIOUS_VALUE    NUMERIC,
  CONDITION_MET     TEXT,
  DELIVERY_STATUS   TEXT   DEFAULT 'pending' CHECK (DELIVERY_STATUS IN ('pending','delivered','failed')),
  NOTIFIED_CHANNELS TEXT,
  ERROR_MESSAGE     TEXT
);
CREATE INDEX IF NOT EXISTS IDX_AF_ALERT ON NB_ALERT_FIRINGS(ALERT_ID, FIRED_AT DESC);

-- ── PERMISSIONS ─────────────────────────────────────────────────────
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.view',          'flow',         'View data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.create',        'flow',         'Create data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.edit',          'flow',         'Edit data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.delete',        'flow',         'Delete data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.run',           'flow',         'Run data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'flow.schedule',      'flow',         'Schedule data flows');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'comment.view',       'comment',      'View widget comments');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'comment.create',     'comment',      'Post widget comments');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'comment.resolve',    'comment',      'Resolve comment threads');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'subscription.manage','subscription', 'Create and manage subscriptions');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'alert.view',         'alert',        'View alerts');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'alert.create',       'alert',        'Create smart alerts');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'alert.edit',         'alert',        'Edit alerts');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'shape.manage',       'shape',        'Upload and manage custom shapes');
INSERT OR IGNORE INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (lower(hex(randomblob(16))), 'hierarchy.manage',   'hierarchy',    'Manage drill-down hierarchies');

-- Grant all new perms to PLATFORM_ADMIN
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN (
    'flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule',
    'comment.view','comment.create','comment.resolve',
    'subscription.manage',
    'alert.view','alert.create','alert.edit',
    'shape.manage','hierarchy.manage'
  );

-- AUTHOR: flow full, comment full, subscription manage, alert full, shape manage, hierarchy manage
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN (
    'flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule',
    'comment.view','comment.create','comment.resolve',
    'subscription.manage',
    'alert.view','alert.create','alert.edit',
    'shape.manage','hierarchy.manage'
  );

-- CHECKER: view flows + comments
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_CHECKER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('flow.view','comment.view','comment.create','comment.resolve','alert.view');

-- VIEWER: comments and alerts only
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('comment.view','comment.create','alert.view','subscription.manage');

-- DS_ADMIN: flows (for ETL)
INSERT OR IGNORE INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_DSADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule');

-- ── SAMPLE DATA ─────────────────────────────────────────────────────

-- Sample hierarchy for the Revenue workbook
INSERT OR IGNORE INTO NB_HIERARCHIES (HIER_ID, WORKBOOK_ID, HIER_NAME, LEVELS_JSON)
  VALUES (lower(hex(randomblob(16))), 'WB_REVENUE', 'Geography', '["region","country","city"]');

-- System shapes
INSERT OR IGNORE INTO NB_SHAPE_LIBRARY (SHAPE_ID, TENANT_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (lower(hex(randomblob(16))), 'TENANT_DEFAULT', 'circle', 'basic', '<circle cx="12" cy="12" r="10" fill="currentColor"/>', 1);
INSERT OR IGNORE INTO NB_SHAPE_LIBRARY (SHAPE_ID, TENANT_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (lower(hex(randomblob(16))), 'TENANT_DEFAULT', 'square', 'basic', '<rect x="2" y="2" width="20" height="20" fill="currentColor"/>', 1);
INSERT OR IGNORE INTO NB_SHAPE_LIBRARY (SHAPE_ID, TENANT_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (lower(hex(randomblob(16))), 'TENANT_DEFAULT', 'triangle', 'basic', '<polygon points="12,2 22,22 2,22" fill="currentColor"/>', 1);
INSERT OR IGNORE INTO NB_SHAPE_LIBRARY (SHAPE_ID, TENANT_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (lower(hex(randomblob(16))), 'TENANT_DEFAULT', 'diamond', 'basic', '<polygon points="12,2 22,12 12,22 2,12" fill="currentColor"/>', 1);
INSERT OR IGNORE INTO NB_SHAPE_LIBRARY (SHAPE_ID, TENANT_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (lower(hex(randomblob(16))), 'TENANT_DEFAULT', 'star', 'basic', '<polygon points="12,2 15,9 22,9 16,14 19,22 12,17 5,22 8,14 2,9 9,9" fill="currentColor"/>', 1);

-- Sample data flow (CSV clean + pivot pipeline)
INSERT OR IGNORE INTO NB_DATA_FLOWS (FLOW_ID, TENANT_ID, FLOW_NAME, DESCRIPTION, OWNER_ID, NODES_JSON, EDGES_JSON, VERSION)
  VALUES ('FLOW_SALES_PREP', 'TENANT_DEFAULT', 'Sales Data Prep',
    'Clean uploaded sales CSV, split region column, and output to Oracle for dashboarding.',
    'USR_A1',
    '[
      {"id":"n1","type":"input_file","position":{"x":50,"y":100},"config":{"fileId":"FILE_SAMPLE","sourceType":"csv"},"label":"Sales CSV"},
      {"id":"n2","type":"clean_nulls","position":{"x":280,"y":100},"config":{"columns":["amount"],"action":"remove"},"label":"Clean Nulls"},
      {"id":"n3","type":"filter","position":{"x":510,"y":100},"config":{"condition":"amount > 100"},"label":"Filter"},
      {"id":"n4","type":"aggregate","position":{"x":740,"y":100},"config":{"groupBy":["region"],"aggs":[{"fn":"sum","col":"amount","alias":"total"}]},"label":"Aggregate"},
      {"id":"n5","type":"output_oracle","position":{"x":970,"y":100},"config":{"targetTable":"NB_STG_SALES_PREPPED"},"label":"Output"}
    ]',
    '[
      {"id":"e1","source":"n1","target":"n2"},
      {"id":"e2","source":"n2","target":"n3"},
      {"id":"e3","source":"n3","target":"n4"},
      {"id":"e4","source":"n4","target":"n5"}
    ]',
    1);

-- Sample comment thread
INSERT OR IGNORE INTO NB_WIDGET_COMMENTS (COMMENT_ID, DASH_ID, WIDGET_ID, USER_ID, CONTENT, MENTIONED_USERS)
  VALUES ('CMT_1', 'DASH_REVENUE', 'w4', 'USR_C1', 'Why is LATAM so low this quarter?', '[]');
INSERT OR IGNORE INTO NB_WIDGET_COMMENTS (COMMENT_ID, DASH_ID, WIDGET_ID, PARENT_ID, USER_ID, CONTENT)
  VALUES ('CMT_2', 'DASH_REVENUE', 'w4', 'CMT_1', 'USR_A1', 'Currency devaluation + two large deals pushed to Q1. Expecting recovery.');

-- Sample subscription
INSERT OR IGNORE INTO NB_SUBSCRIPTIONS (SUBSCRIPTION_ID, SUBSCRIPTION_TYPE, TARGET_ID, OWNER_ID, TENANT_ID, SUB_NAME,
  CRON_EXPRESSION, DELIVERY_CHANNELS, RECIPIENTS, RENDER_FORMAT, EMAIL_SUBJECT)
  VALUES ('SUB_Q4_WEEKLY', 'dashboard', 'DASH_REVENUE', 'USR_A1', 'TENANT_DEFAULT',
    'Q4 Revenue — Weekly Monday 9am',
    '0 9 * * MON', '["email"]', '["sarah.chen@acme.local","david.lee@acme.local"]',
    'pdf', 'Q4 Revenue Weekly Update');

-- Sample alert
INSERT OR IGNORE INTO NB_ALERTS (ALERT_ID, DASH_ID, WIDGET_ID, CUBE_NAME, ALERT_NAME, DESCRIPTION, OWNER_ID, TENANT_ID,
  CONDITION_JSON, CHECK_FREQUENCY, NOTIFICATION_CHANNELS, RECIPIENTS, COOLDOWN_MINUTES)
  VALUES ('ALERT_REV_DROP', 'DASH_REVENUE', 'w1', 'Orders',
    'Revenue Drop Warning',
    'Fires when total revenue drops below $3.5M on the Q4 dashboard.',
    'USR_A1', 'TENANT_DEFAULT',
    '{"measure":"total_revenue","operator":"lt","threshold":3500000}',
    '0 */4 * * *',
    '["email","webhook"]',
    '["sarah.chen@acme.local"]',
    60);

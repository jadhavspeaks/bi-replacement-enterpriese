#!/usr/bin/env node
/**
 * NexusBI — Oracle schema installer
 *
 * Uses YOUR EXISTING Oracle user. Does NOT create a new Oracle user.
 * Does NOT require sqlplus. Uses node-oracledb (already a project dep).
 *
 * Usage:
 *   node scripts/install-schema.js
 *
 * Reads credentials from environment:
 *   ORACLE_USER=your_existing_user
 *   ORACLE_PASSWORD=your_password
 *   ORACLE_CONNECT_STRING=host:1521/SERVICE
 *
 * Or pass explicitly:
 *   ORACLE_USER=scott ORACLE_PASSWORD=tiger ORACLE_CONNECT_STRING=db:1521/ORCL node scripts/install-schema.js
 *
 * Flags:
 *   --only-v7       Apply only the v7 extensions (assumes v6 already installed)
 *   --only-v6       Apply only the v6 base schema
 *   --drop-first    Drop all NB_* tables first (destructive!)
 *   --dry-run       Print the DDL without executing it
 */

'use strict';

const fs = require('fs');
const path = require('path');

function req(mod) {
  // Try local first, then from apps/web/node_modules (where oracledb lives).
  try { return require(mod); }
  catch {}
  try { return require(path.resolve(__dirname, '..', 'apps', 'web', 'node_modules', mod)); }
  catch (e) {
    console.error(`\n✗ Missing dependency "${mod}". Run: cd apps/web && npm install ${mod}\n`);
    process.exit(1);
  }
}

const oracledb = req('oracledb');
oracledb.autoCommit = false;

const ARGS = process.argv.slice(2);
const flags = {
  onlyV6: ARGS.includes('--only-v6'),
  onlyV7: ARGS.includes('--only-v7'),
  dropFirst: ARGS.includes('--drop-first'),
  dryRun: ARGS.includes('--dry-run'),
};

const USER = process.env.ORACLE_USER;
const PASSWORD = process.env.ORACLE_PASSWORD;
const CONNECT = process.env.ORACLE_CONNECT_STRING || process.env.ORACLE_CONNECTION_STRING;

if (!USER || !PASSWORD || !CONNECT) {
  console.error(`
╔════════════════════════════════════════════════════════════════╗
║  NexusBI schema installer                                      ║
╠════════════════════════════════════════════════════════════════╣
║  Set these environment variables (use your own Oracle user):  ║
║                                                                ║
║    ORACLE_USER=<your_existing_oracle_user>                    ║
║    ORACLE_PASSWORD=<your_password>                            ║
║    ORACLE_CONNECT_STRING=<host>:<port>/<service_name>         ║
║                                                                ║
║  Then run: node scripts/install-schema.js                     ║
╚════════════════════════════════════════════════════════════════╝
`);
  process.exit(1);
}

const ROOT = path.resolve(__dirname, '..');
const V6_FILE = path.join(ROOT, 'oracle-seed.sql');
const V7_FILE = path.join(ROOT, 'oracle-seed-v7.sql');

function readSql(file) {
  if (!fs.existsSync(file)) {
    console.error(`✗ SQL file not found: ${file}`);
    process.exit(1);
  }
  return fs.readFileSync(file, 'utf8');
}

/**
 * Splits an Oracle SQL script into individual executable statements.
 * Handles:
 *   - Statement terminators: ; for DML/DDL, / on its own line for PL/SQL blocks
 *   - Line comments (--) and block comments (/ * ... * /)
 *   - CLOB literals with embedded semicolons (preserved inside quotes)
 */
function splitStatements(sql) {
  const stmts = [];
  let buf = '';
  let inSingle = false, inDouble = false, inBlockComment = false;
  let i = 0;
  const lines = sql.split(/\r?\n/);

  for (const rawLine of lines) {
    let line = rawLine;

    // Remove line comments only when not inside strings
    if (!inSingle && !inDouble && !inBlockComment) {
      const lc = line.indexOf('--');
      if (lc >= 0) {
        // Ensure -- is not inside a string on this line
        let beforeLc = line.slice(0, lc);
        const quotes = (beforeLc.match(/'/g) || []).length;
        if (quotes % 2 === 0) line = line.slice(0, lc);
      }
    }

    // Line-alone slash terminator (PL/SQL)
    if (line.trim() === '/' && buf.trim().length > 0 && !inBlockComment) {
      stmts.push(buf.trim());
      buf = '';
      continue;
    }

    // Walk char-by-char to handle semicolons inside strings correctly
    let j = 0;
    while (j < line.length) {
      const c = line[j];
      const nx = line[j + 1];

      if (inBlockComment) {
        if (c === '*' && nx === '/') { inBlockComment = false; j += 2; continue; }
        j++; continue;
      }
      if (!inSingle && !inDouble && c === '/' && nx === '*') {
        inBlockComment = true; j += 2; continue;
      }
      if (!inDouble && c === "'") { inSingle = !inSingle; buf += c; j++; continue; }
      if (!inSingle && c === '"') { inDouble = !inDouble; buf += c; j++; continue; }

      if (!inSingle && !inDouble && c === ';') {
        if (buf.trim().length > 0) { stmts.push(buf.trim()); buf = ''; }
        j++; continue;
      }

      buf += c;
      j++;
    }
    buf += '\n';
  }

  const tail = buf.trim();
  if (tail.length > 0) stmts.push(tail);
  return stmts;
}

async function executeScript(conn, sql, label) {
  const statements = splitStatements(sql);
  console.log(`\n▸ ${label} — ${statements.length} statements`);
  let ok = 0, skipped = 0, failed = 0;

  for (let i = 0; i < statements.length; i++) {
    const stmt = statements[i];
    if (!stmt || /^\s*(COMMIT|SET\s|SHOW\s|ALTER\s+SESSION)/i.test(stmt)) {
      if (/^\s*COMMIT/i.test(stmt)) {
        if (!flags.dryRun) await conn.commit();
      }
      continue;
    }
    if (flags.dryRun) { console.log(`  [DRY] ${stmt.slice(0, 80).replace(/\n/g, ' ')}...`); continue; }
    try {
      await conn.execute(stmt);
      ok++;
      process.stdout.write('.');
    } catch (err) {
      const msg = err.message || String(err);
      // Common idempotent errors — treat as "already exists"
      if (/ORA-00955|ORA-01430|ORA-02260|ORA-02275|ORA-00001|ORA-01408/i.test(msg)) {
        skipped++;
        process.stdout.write('~');
      } else {
        failed++;
        console.error(`\n✗ Statement ${i + 1} failed:\n  ${stmt.slice(0, 200)}\n  → ${msg}`);
      }
    }
  }
  if (!flags.dryRun) await conn.commit();
  console.log(`\n  ✓ ${ok} ok · ~ ${skipped} skipped (already exist) · ✗ ${failed} failed`);
  return { ok, skipped, failed };
}

async function dropAllNbTables(conn) {
  console.log('\n▸ Dropping all NB_* objects (destructive)...');
  const q = `
    SELECT 'DROP ' || OBJECT_TYPE || ' "' || OBJECT_NAME || '"' ||
           CASE WHEN OBJECT_TYPE = 'TABLE' THEN ' CASCADE CONSTRAINTS PURGE' ELSE '' END AS CMD
    FROM USER_OBJECTS
    WHERE OBJECT_NAME LIKE 'NB\\_%' ESCAPE '\\'
      AND OBJECT_TYPE IN ('TABLE','VIEW','SEQUENCE','TRIGGER','PROCEDURE','FUNCTION','PACKAGE','TYPE')
    ORDER BY CASE OBJECT_TYPE WHEN 'TRIGGER' THEN 1 WHEN 'VIEW' THEN 2 WHEN 'TABLE' THEN 3 ELSE 4 END
  `;
  const result = await conn.execute(q, {}, { outFormat: oracledb.OUT_FORMAT_OBJECT });
  const cmds = (result.rows || []).map((r) => r.CMD);
  for (const cmd of cmds) {
    try { await conn.execute(cmd); process.stdout.write('.'); }
    catch (err) { process.stdout.write('!'); }
  }
  await conn.commit();
  console.log(`\n  ✓ Dropped ${cmds.length} objects`);
}

async function main() {
  console.log(`
NexusBI Oracle schema installer
═══════════════════════════════
User:     ${USER}
Target:   ${CONNECT}
Mode:     ${flags.dryRun ? 'DRY RUN' : flags.onlyV7 ? 'v7 only' : flags.onlyV6 ? 'v6 only' : 'v6 + v7'}
${flags.dropFirst ? 'Drop:     yes (DESTRUCTIVE)' : ''}
`);

  let conn;
  try {
    conn = await oracledb.getConnection({
      user: USER,
      password: PASSWORD,
      connectString: CONNECT,
    });
    console.log('✓ Connected to Oracle');

    if (flags.dropFirst && !flags.dryRun) {
      await dropAllNbTables(conn);
    }

    let totalOk = 0, totalSkipped = 0, totalFailed = 0;

    if (!flags.onlyV7) {
      const sql = readSql(V6_FILE);
      const { ok, skipped, failed } = await executeScript(conn, sql, 'v6 base schema (oracle-seed.sql)');
      totalOk += ok; totalSkipped += skipped; totalFailed += failed;
    }
    if (!flags.onlyV6) {
      const sql = readSql(V7_FILE);
      const { ok, skipped, failed } = await executeScript(conn, sql, 'v7 extensions (oracle-seed-v7.sql)');
      totalOk += ok; totalSkipped += skipped; totalFailed += failed;
    }

    console.log(`
═══════════════════════════════
Summary: ${totalOk} ok · ${totalSkipped} skipped · ${totalFailed} failed
${totalFailed > 0 ? '⚠ Some statements failed — review errors above' : '✓ Installation complete'}
`);
    await conn.close();
    process.exit(totalFailed > 0 ? 1 : 0);
  } catch (err) {
    console.error(`\n✗ ${err.message || err}\n`);
    if (conn) { try { await conn.close(); } catch {} }
    process.exit(1);
  }
}

main();

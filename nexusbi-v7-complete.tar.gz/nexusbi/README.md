# NexusBI v7

Enterprise BI platform with full Tableau parity — built on Cube.js, Oracle, Next.js 15, and React 19.

**v7 adds:** LOD expressions · drill-down hierarchies · forecasting · k-means clustering · Show Me panel · 12 table calcs · maps · density plots · sparklines · visual data flow editor (30 node types) · column profiling · smart join recommender · threaded widget comments with @mentions · scheduled subscriptions · smart alerts (12 operators).

---

## Contents

- `oracle-seed.sql` — base schema (41 tables, 46 permissions, 6 roles, sample data)
- `oracle-seed-v7.sql` — v7 extensions (14 tables, 15 permissions, sample data)
- `scripts/install-schema.js` — schema installer (uses **your existing Oracle user**, no sqlplus)
- `scripts/generate-secrets.js` — generate NextAuth / Cube.js / encryption secrets
- `.env.example` — environment variable template
- `apps/web/` — Next.js 15 app (UI, API routes, libraries)
- `apps/cube/` — Cube.js semantic layer
- `packages/shared-types/` — TypeScript types shared across apps
- `nexusbi-v7-app.html` — self-contained demo SPA (open in any browser)
- `docs/NexusBI-User-Guide.docx` — complete user guide (every feature, step-by-step)

---

## Installation (uses YOUR existing Oracle user)

NexusBI does **not** create a new Oracle database user. It uses whatever credentials
you provide to connect to your existing schema and creates `NB_*` tables inside it.

### Prerequisites

On the target Oracle user, your DBA must grant:

```sql
GRANT CREATE SESSION,  CREATE TABLE,  CREATE SEQUENCE,
      CREATE TRIGGER,  CREATE VIEW,   CREATE PROCEDURE
   TO <your_existing_user>;
ALTER USER <your_existing_user> QUOTA 500M ON <tablespace>;
```

### Install steps

```bash
# 1. Extract the package
tar -xzf nexusbi-v7-complete.tar.gz
cd nexusbi/

# 2. Copy .env.example → .env.local and fill in YOUR Oracle credentials
cp .env.example .env.local
# Edit .env.local — set ORACLE_USER / ORACLE_PASSWORD / ORACLE_HOST / ORACLE_SERVICE

# 3. Install deps
npm install

# 4. Install the schema (no sqlplus required — uses node-oracledb from deps)
ORACLE_USER=<your_user> ORACLE_PASSWORD=<pw> ORACLE_CONNECT_STRING=host:1521/SERVICE \
  node scripts/install-schema.js

# Optional flags:
#   --only-v6     apply only base schema
#   --only-v7     apply only v7 extensions (v6 must already exist)
#   --drop-first  drop all NB_* objects first (DESTRUCTIVE)
#   --dry-run     print DDL without executing

# 5. Generate secrets for NextAuth / Cube.js / encryption
node scripts/generate-secrets.js

# 6. Start everything
npm run dev       # or `npm run build && npm start` for production
```

Visit **http://localhost:3000**. Log in with one of the seeded test accounts:

| Username    | Password      | Role            |
|-------------|---------------|-----------------|
| `admin`     | `Admin@123!`  | PLATFORM_ADMIN  |
| `author1`   | `Test@123!`   | AUTHOR          |
| `checker1`  | `Test@123!`   | CHECKER         |
| `viewer1`   | `Test@123!`   | VIEWER          |
| `embed_user`| `Test@123!`   | EMBED_ONLY      |

---

## 27 supported data connectors

**Databases** — Postgres · MySQL · MariaDB · MS SQL Server · Oracle · SQLite · Redshift · Snowflake · BigQuery · Databricks · Athena · ClickHouse · MongoDB

**Hadoop ecosystem** — **Hive · Impala** · SparkSQL (all with Kerberos/PLAIN/NOSASL auth)

**Query engines** — Presto · Trino

**APIs** — REST · GraphQL · OAuth REST · Webhooks

**Files** — CSV · Excel · Parquet · JSON

**Embedded** — DuckDB

---

## Tableau workbook import (`.twbx`)

Uploading a Tableau workbook is a first-class feature:

1. Sign in as an AUTHOR or PLATFORM_ADMIN.
2. Go to **Workbooks → Import Tableau Workbook**.
3. Drag-and-drop a `.twbx` file (max 100 MB).
4. NexusBI extracts the embedded `.twb` XML and parses:
   - Data source references (connection class + tables)
   - Worksheets (viz type → NexusBI chart type via 19-mapping table)
   - Filters (equality / range / set)
   - Calculated fields (Tableau syntax → cube-calc)
   - Dashboard zone layouts (converted to widget positions)
5. Preview the mapping before committing (see what became a KPI, bar, line, etc.).
6. Click **Create Workbook** — a new NexusBI workbook is created with sheets, fields, and a dashboard.

Source: `apps/web/lib/tableau-import.ts` · DB tables: `NB_TABLEAU_IMPORTS`, `NB_TABLEAU_WORKSHEET_MAP`.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  apps/web (Next.js 15 · App Router · React 19 · NextAuth v5) │
│  ├── app/(auth)/login                                        │
│  ├── app/(app)/* ─ 28 pages                                  │
│  ├── app/api/*   ─ 72+ routes, Zod-validated, audit-wrapped  │
│  └── lib/*       ─ 40+ libraries (LOD, flow executor, etc.)  │
└───────┬──────────────────────────────────────────────────────┘
        │ internal HTTPS (JWT)
┌───────▼──────────────────────────────────────────────────────┐
│  apps/cube (Cube.js semantic layer, dynamic driver loading)  │
└───────┬──────────────────────────────────────────────────────┘
        │ native drivers (Postgres, Hive, Impala, Oracle, ...)
┌───────▼──────────────────────────────────────────────────────┐
│  Oracle (metadata) + external warehouses (query data)        │
└──────────────────────────────────────────────────────────────┘
```

---

## Troubleshooting

**`ORA-00955: name is already used`** when installing the schema — expected on re-runs; the installer treats these as "already exists" and continues.

**`ORA-01950: no privileges on tablespace`** — your Oracle user has no quota. Ask your DBA to run `ALTER USER <user> QUOTA 500M ON <tablespace>`.

**Hive/Impala connector fails with `SASL authentication failed`** — set `authMechanism: 'KERBEROS'` and provide `kerberosPrincipal` + `kerberosKeytab`, OR set `authMechanism: 'PLAIN'` and provide `username`/`password`.

**Tableau import fails with `No .twb file found`** — the uploaded file isn't a valid `.twbx` (it must be a ZIP archive containing a `.twb` XML). Save from Tableau Desktop as "Packaged Workbook".

---

## License

Internal / Commercial.

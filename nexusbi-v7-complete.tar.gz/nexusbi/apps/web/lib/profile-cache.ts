import type { ColumnProfile, HistogramBin } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';

/**
 * Column profiling: one query per column per hour (cached in NB_PROFILE_CACHE).
 * Stats: count, unique, nulls, min/max, mean, median, stddev, top values, histogram.
 */

export async function profileColumn(
  tableName: string, columnName: string, orgId: string,
): Promise<ColumnProfile> {
  const cached = await getCached(tableName, columnName, orgId);
  if (cached) return cached;

  const col = columnName.toUpperCase();
  const table = tableName.toUpperCase();

  const dataType = await withConnection(async (conn) => {
    const r = await conn.execute<{ DATA_TYPE: string }>(
      `SELECT DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = :t AND COLUMN_NAME = :c`,
      { t: table, c: col }, { outFormat: 4002 },
    );
    return r.rows?.[0]?.DATA_TYPE ?? 'VARCHAR2';
  });

  const isNumeric = /NUMBER|FLOAT|INTEGER|DECIMAL/.test(dataType);
  const isDate = /DATE|TIMESTAMP/.test(dataType);

  const basic = await withConnection(async (conn) => {
    const sql = `
      SELECT COUNT(*) AS TOTAL,
             COUNT(DISTINCT "${col}") AS UNIQ,
             SUM(CASE WHEN "${col}" IS NULL THEN 1 ELSE 0 END) AS NULLS,
             ${isNumeric ? `MIN("${col}") AS MINV, MAX("${col}") AS MAXV, AVG("${col}") AS MEANV, MEDIAN("${col}") AS MEDV, STDDEV("${col}") AS STDV` :
               isDate ? `TO_CHAR(MIN("${col}"), 'YYYY-MM-DD"T"HH24:MI:SS') AS MINV, TO_CHAR(MAX("${col}"), 'YYYY-MM-DD"T"HH24:MI:SS') AS MAXV, NULL AS MEANV, NULL AS MEDV, NULL AS STDV` :
               `MIN("${col}") AS MINV, MAX("${col}") AS MAXV, NULL AS MEANV, NULL AS MEDV, NULL AS STDV`}
      FROM ${table}
    `;
    const r = await conn.execute<{
      TOTAL: number; UNIQ: number; NULLS: number;
      MINV: unknown; MAXV: unknown; MEANV: number | null; MEDV: number | null; STDV: number | null;
    }>(sql, {}, { outFormat: 4002 });
    return r.rows?.[0];
  });

  let histogram: HistogramBin[] | undefined;
  if (isNumeric && basic && basic.MINV != null && basic.MAXV != null) {
    const bins = 20;
    histogram = await withConnection(async (conn) => {
      const r = await conn.execute<{ BN: number; LO: number; HI: number; CNT: number }>(
        `WITH bucketed AS (
           SELECT WIDTH_BUCKET("${col}", :mn, :mx, :bins) AS BN FROM ${table} WHERE "${col}" IS NOT NULL
         )
         SELECT BN, :mn + ((BN - 1) * (:mx - :mn) / :bins) AS LO,
                :mn + (BN * (:mx - :mn) / :bins) AS HI, COUNT(*) AS CNT
         FROM bucketed WHERE BN BETWEEN 1 AND :bins
         GROUP BY BN ORDER BY BN`,
        { mn: basic.MINV, mx: basic.MAXV, bins },
        { outFormat: 4002 },
      );
      return (r.rows ?? []).map((x) => ({ lower: x.LO, upper: x.HI, count: x.CNT }));
    });
  }

  let topValues: Array<{ value: unknown; count: number }> | undefined;
  if (!isNumeric || (basic?.UNIQ ?? 0) < 100) {
    topValues = await withConnection(async (conn) => {
      const r = await conn.execute<{ VAL: unknown; CNT: number }>(
        `SELECT "${col}" AS VAL, COUNT(*) AS CNT FROM ${table}
         WHERE "${col}" IS NOT NULL GROUP BY "${col}" ORDER BY CNT DESC FETCH FIRST 20 ROWS ONLY`,
        {}, { outFormat: 4002 },
      );
      return (r.rows ?? []).map((x) => ({ value: x.VAL, count: x.CNT }));
    });
  }

  const profile: ColumnProfile = {
    columnName: col,
    dataType,
    totalRows: basic?.TOTAL ?? 0,
    uniqueCount: basic?.UNIQ ?? 0,
    nullCount: basic?.NULLS ?? 0,
    nullPercent: basic && basic.TOTAL > 0 ? (basic.NULLS / basic.TOTAL) * 100 : 0,
    minValue: basic?.MINV ?? null,
    maxValue: basic?.MAXV ?? null,
    meanValue: basic?.MEANV ?? undefined,
    medianValue: basic?.MEDV ?? undefined,
    stdDev: basic?.STDV ?? undefined,
    histogram, topValues,
    outlierCount: histogram ? computeOutlierCount(histogram, basic?.MEANV ?? 0, basic?.STDV ?? 0) : undefined,
    cachedAt: new Date().toISOString(),
  };

  await persistCache(tableName, columnName, orgId, profile);
  return profile;
}

function computeOutlierCount(histogram: HistogramBin[], mean: number, stdDev: number): number {
  if (stdDev === 0) return 0;
  const lower = mean - 3 * stdDev;
  const upper = mean + 3 * stdDev;
  return histogram.reduce((acc, bin) => {
    const binCenter = (bin.lower + bin.upper) / 2;
    return binCenter < lower || binCenter > upper ? acc + bin.count : acc;
  }, 0);
}

async function getCached(tableName: string, columnName: string, orgId: string): Promise<ColumnProfile | null> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ PROFILE_JSON: string; EXPIRES_AT: Date }>(
      `SELECT PROFILE_JSON, EXPIRES_AT FROM NB_PROFILE_CACHE
       WHERE ORG_ID = :orgId AND TABLE_NAME = :t AND COLUMN_NAME = :c AND EXPIRES_AT > SYSTIMESTAMP`,
      { orgId, t: tableName, c: columnName }, { outFormat: 4002 },
    );
    if (!r.rows?.[0]) return null;
    try { return JSON.parse(r.rows[0].PROFILE_JSON); } catch { return null; }
  });
}

async function persistCache(
  tableName: string, columnName: string, orgId: string, profile: ColumnProfile,
): Promise<void> {
  await withConnection(async (conn) => {
    await conn.execute(
      `MERGE INTO NB_PROFILE_CACHE p
       USING (SELECT :orgId AS ORG_ID, :t AS TABLE_NAME, :c AS COLUMN_NAME FROM dual) s
       ON (p.ORG_ID = s.ORG_ID AND p.TABLE_NAME = s.TABLE_NAME AND p.COLUMN_NAME = s.COLUMN_NAME)
       WHEN MATCHED THEN UPDATE SET PROFILE_JSON = :json, CACHED_AT = SYSTIMESTAMP,
         EXPIRES_AT = SYSTIMESTAMP + INTERVAL '1' HOUR
       WHEN NOT MATCHED THEN INSERT (CACHE_ID, ORG_ID, TABLE_NAME, COLUMN_NAME, PROFILE_JSON)
         VALUES (SYS_GUID(), :orgId, :t, :c, :json)`,
      { orgId, t: tableName, c: columnName, json: JSON.stringify(profile) },
    );
    await conn.commit();
  });
}

import type { DensityConfig, DensityResult, DensityBin } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';

/**
 * Density / contour plot binning. Server-side via Oracle WIDTH_BUCKET to
 * avoid sending millions of raw points to the browser.
 */

export async function computeDensity(
  sourceTable: string,
  config: DensityConfig,
  orgId: string,
): Promise<DensityResult> {
  const xField = config.xField.toUpperCase();
  const yField = config.yField.toUpperCase();

  const rangeRes = await withConnection(async (conn) => {
    const r = await conn.execute<{ X_MIN: number; X_MAX: number; Y_MIN: number; Y_MAX: number }>(
      `SELECT MIN("${xField}") AS X_MIN, MAX("${xField}") AS X_MAX,
              MIN("${yField}") AS Y_MIN, MAX("${yField}") AS Y_MAX
       FROM ${sourceTable}`,
      {},
      { outFormat: 4002 },
    );
    return r.rows?.[0] ?? { X_MIN: 0, X_MAX: 1, Y_MIN: 0, Y_MAX: 1 };
  });

  const xMin = rangeRes.X_MIN ?? 0;
  const xMax = rangeRes.X_MAX ?? 1;
  const yMin = rangeRes.Y_MIN ?? 0;
  const yMax = rangeRes.Y_MAX ?? 1;

  const binsX = config.binsX;
  const binsY = config.binsY;

  const binsResult = await withConnection(async (conn) => {
    const r = await conn.execute<{ XB: number; YB: number; CNT: number }>(
      `SELECT WIDTH_BUCKET("${xField}", :xmin, :xmax, :binsX) AS XB,
              WIDTH_BUCKET("${yField}", :ymin, :ymax, :binsY) AS YB,
              COUNT(*) AS CNT
       FROM ${sourceTable}
       GROUP BY WIDTH_BUCKET("${xField}", :xmin, :xmax, :binsX),
                WIDTH_BUCKET("${yField}", :ymin, :ymax, :binsY)`,
      { xmin: xMin, xmax: xMax, ymin: yMin, ymax: yMax, binsX, binsY },
      { outFormat: 4002 },
    );
    return r.rows ?? [];
  });

  const xStep = (xMax - xMin) / binsX;
  const yStep = (yMax - yMin) / binsY;

  const bins: DensityBin[] = [];
  let maxDensity = 0;
  for (const row of binsResult) {
    const xb = row.XB;
    const yb = row.YB;
    if (xb < 1 || xb > binsX || yb < 1 || yb > binsY) continue;
    const cnt = row.CNT;
    bins.push({
      xBin: xb,
      yBin: yb,
      xLow: xMin + (xb - 1) * xStep,
      xHigh: xMin + xb * xStep,
      yLow: yMin + (yb - 1) * yStep,
      yHigh: yMin + yb * yStep,
      density: cnt,
    });
    if (cnt > maxDensity) maxDensity = cnt;
  }

  return {
    bins,
    xRange: [xMin, xMax],
    yRange: [yMin, yMax],
    maxDensity,
  };
}

export function densityToColorGrid(
  result: DensityResult,
  colorPalette: 'viridis' | 'inferno' | 'blues' | 'oranges' = 'viridis',
): Array<{ x: number; y: number; color: string; density: number }> {
  const palettes: Record<string, string[]> = {
    viridis: ['#440154', '#3b528b', '#21918c', '#5ec962', '#fde725'],
    inferno: ['#000004', '#56106e', '#bb3754', '#f98e09', '#fcffa4'],
    blues: ['#f7fbff', '#c6dbef', '#6baed6', '#2171b5', '#08306b'],
    oranges: ['#fff5eb', '#fdd0a2', '#fd8d3c', '#d94801', '#7f2704'],
  };
  const colors = palettes[colorPalette] ?? palettes.viridis;

  return result.bins.map((b) => {
    const t = result.maxDensity === 0 ? 0 : b.density / result.maxDensity;
    const idx = Math.min(colors.length - 1, Math.floor(t * (colors.length - 1)));
    return {
      x: (b.xLow + b.xHigh) / 2,
      y: (b.yLow + b.yHigh) / 2,
      color: colors[idx],
      density: b.density,
    };
  });
}

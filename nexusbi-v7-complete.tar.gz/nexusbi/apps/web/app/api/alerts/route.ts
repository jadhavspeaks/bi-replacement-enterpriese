import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { generateId } from '@nexusbi/shared-types';

const ConditionSchema = z.object({
  measure: z.string(),
  operator: z.enum(['gt','gte','lt','lte','eq','neq','crossed_above','crossed_below','pct_change_gt','pct_change_lt','stddev_above','stddev_below','in_range','out_of_range']),
  threshold: z.number(),
  thresholdUpper: z.number().optional(),
  comparisonWindow: z.object({ value: z.number(), unit: z.enum(['minute','hour','day','week','month']) }).optional(),
  filters: z.array(z.any()).optional(),
});

const CreateSchema = z.object({
  dashId: z.string().optional(),
  widgetId: z.string().optional(),
  cubeName: z.string().min(1),
  alertName: z.string().min(1).max(300),
  description: z.string().optional(),
  condition: ConditionSchema,
  checkFrequency: z.string().min(1),
  notificationChannels: z.array(z.enum(['email','webhook','slack','teams'])),
  recipients: z.array(z.string()),
  cooldownMinutes: z.number().int().min(0).max(10080).optional(),
});

export const GET = withAudit(
  () => ({ action: 'alert.list', resourceType: 'alert' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'alert.view');
    const rows = await withConnection(async (conn) => {
      const r = await conn.execute<{
        ALERT_ID: string; ALERT_NAME: string; DESCRIPTION: string | null;
        CONDITION_JSON: string; CHECK_FREQUENCY: string;
        NOTIFICATION_CHANNELS: string; IS_ENABLED: number;
        LAST_TRIGGERED_AT: Date | null; LAST_VALUE: number | null;
      }>(
        `SELECT ALERT_ID, ALERT_NAME, DESCRIPTION, CONDITION_JSON, CHECK_FREQUENCY,
                NOTIFICATION_CHANNELS, IS_ENABLED, LAST_TRIGGERED_AT, LAST_VALUE
         FROM NB_ALERTS WHERE ORG_ID = :org ORDER BY CREATED_AT DESC`,
        { org: user.orgId }, { outFormat: 4002 },
      );
      return r.rows ?? [];
    });
    return NextResponse.json({
      alerts: rows.map((r) => ({
        alertId: r.ALERT_ID, alertName: r.ALERT_NAME, description: r.DESCRIPTION,
        condition: JSON.parse(r.CONDITION_JSON),
        checkFrequency: r.CHECK_FREQUENCY,
        notificationChannels: JSON.parse(r.NOTIFICATION_CHANNELS),
        isEnabled: r.IS_ENABLED === 1,
        lastTriggeredAt: r.LAST_TRIGGERED_AT?.toISOString() ?? null,
        lastValue: r.LAST_VALUE,
      })),
    });
  },
);

export const POST = withAudit(
  () => ({ action: 'alert.create', resourceType: 'alert' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'alert.create');
    const body = CreateSchema.parse(await request.json());
    const alertId = generateId('ALERT');
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_ALERTS (ALERT_ID, DASH_ID, WIDGET_ID, CUBE_NAME, ALERT_NAME, DESCRIPTION,
          OWNER_ID, ORG_ID, CONDITION_JSON, CHECK_FREQUENCY, NOTIFICATION_CHANNELS,
          RECIPIENTS, COOLDOWN_MINUTES, IS_ENABLED)
         VALUES (:id, :d, :w, :cube, :n, :desc, :o, :org, :cj, :cf, :nc, :r, :cd, 1)`,
        {
          id: alertId, d: body.dashId ?? null, w: body.widgetId ?? null, cube: body.cubeName,
          n: body.alertName, desc: body.description ?? null, o: user.userId, org: user.orgId,
          cj: JSON.stringify(body.condition), cf: body.checkFrequency,
          nc: JSON.stringify(body.notificationChannels), r: JSON.stringify(body.recipients),
          cd: body.cooldownMinutes ?? 60,
        },
      );
      await conn.commit();
    });
    return NextResponse.json({ alertId }, { status: 201 });
  },
);

import { NextRequest, NextResponse } from 'next/server';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { executeFlow } from '@/lib/flow-executor';

export const POST = withAudit(
  (_, params) => ({ action: 'flow.run', resourceType: 'flow', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'flow.run');
    const flow = await withConnection(async (conn) => {
      const r = await conn.execute<{
        FLOW_ID: string; FLOW_NAME: string; NODES_JSON: string; EDGES_JSON: string;
      }>(
        `SELECT FLOW_ID, FLOW_NAME, NODES_JSON, EDGES_JSON FROM NB_DATA_FLOWS
         WHERE FLOW_ID = :fid AND ORG_ID = :org`,
        { fid: params.id, org: user.orgId }, { outFormat: 4002 },
      );
      return r.rows?.[0];
    });
    if (!flow) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const run = await executeFlow({
      flowId: flow.FLOW_ID, flowName: flow.FLOW_NAME, orgId: user.orgId,
      description: null, ownerId: user.userId,
      nodes: JSON.parse(flow.NODES_JSON ?? '[]'),
      edges: JSON.parse(flow.EDGES_JSON ?? '[]'),
      version: 1, createdAt: '', updatedAt: '',
    }, user.username, user.orgId);

    return NextResponse.json(run, { status: 202 });
  },
);

import type { ColumnSchemaEntry } from './file-ingest.types';

// ── Flow Graph ──

export type FlowNodeType =
  | 'input_source' | 'input_file' | 'input_api' | 'input_extract'
  | 'clean_nulls' | 'clean_duplicates' | 'rename_columns' | 'change_type' | 'trim_whitespace'
  | 'filter' | 'sort' | 'limit' | 'sample'
  | 'pivot' | 'unpivot'
  | 'join' | 'union' | 'cross_join'
  | 'aggregate' | 'derive_column' | 'split_column' | 'concatenate'
  | 'date_part' | 'date_trunc' | 'date_diff'
  | 'output_oracle' | 'output_cube' | 'output_export' | 'output_csv';

export interface FlowNode {
  id: string;
  type: FlowNodeType;
  position: { x: number; y: number };
  config: Record<string, unknown>;
  label?: string;
  outputSchema?: ColumnSchemaEntry[];
  rowCount?: number;
  status?: FlowNodeStatus;
  errorMessage?: string;
}

export type FlowNodeStatus = 'pending' | 'running' | 'success' | 'failed' | 'skipped';

export interface FlowEdge {
  id: string;
  source: string;
  target: string;
  sourceHandle?: string;
  targetHandle?: 'left' | 'right' | 'default';
}

export interface DataFlow {
  flowId: string;
  orgId: string;
  flowName: string;
  description: string | null;
  ownerId: string;
  nodes: FlowNode[];
  edges: FlowEdge[];
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface DataFlowCreateInput {
  flowName: string;
  description?: string;
}

export interface DataFlowUpdateInput {
  flowName?: string;
  description?: string;
  nodes?: FlowNode[];
  edges?: FlowEdge[];
}

// ── Flow Runs ──

export type FlowRunStatus = 'queued' | 'running' | 'success' | 'failed' | 'cancelled';

export interface FlowRun {
  runId: string;
  flowId: string;
  status: FlowRunStatus;
  startedAt: string;
  finishedAt: string | null;
  triggeredBy: string;
  nodeResults: FlowNodeResult[];
  errorMessage: string | null;
  totalRowsProcessed: number;
  durationMs: number;
}

export interface FlowNodeResult {
  nodeId: string;
  status: FlowNodeStatus;
  stagingTable: string | null;
  rowCount: number;
  durationMs: number;
  errorMessage: string | null;
}

// ── Scheduled Runs ──

export interface ScheduledFlow {
  scheduleId: string;
  flowId: string;
  cronExpression: string;
  notifyOnFailure: 'none' | 'email' | 'webhook' | 'both';
  notifyEmails: string[];
  webhookUrl: string | null;
  maxRuntimeMinutes: number;
  incrementalColumn: string | null;
  incrementalWatermark: string | null;
  isEnabled: boolean;
  lastRunAt: string | null;
  lastRunStatus: FlowRunStatus | null;
}

// ── Node Executor Interface ──

export interface FlowNodeExecutor {
  nodeType: FlowNodeType;
  validate(node: FlowNode, inputSchemas: ColumnSchemaEntry[][]): NodeValidationResult;
  buildSQL(node: FlowNode, inputTables: string[]): string;
  outputSchema(node: FlowNode, inputSchemas: ColumnSchemaEntry[][]): ColumnSchemaEntry[];
}

export interface NodeValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
}

// ── Column Profile ──

export interface ColumnProfile {
  columnName: string;
  dataType: string;
  totalRows: number;
  uniqueCount: number;
  nullCount: number;
  nullPercent: number;
  minValue: unknown;
  maxValue: unknown;
  meanValue?: number;
  medianValue?: number;
  stdDev?: number;
  histogram?: HistogramBin[];
  topValues?: Array<{ value: unknown; count: number }>;
  outlierCount?: number;
  cachedAt: string;
}

export interface HistogramBin {
  lower: number;
  upper: number;
  count: number;
}

// ── Smart Join Recommender ──

export interface JoinSuggestion {
  leftColumn: string;
  rightColumn: string;
  nameScore: number;
  valueOverlap: number;
  totalScore: number;
  joinType: 'inner' | 'left' | 'right' | 'outer';
  leftRows: number;
  rightRows: number;
  estimatedMatchRate: number;
}

export interface JoinRecommendRequest {
  leftTable: string;
  rightTable: string;
  sampleSize?: number;
}

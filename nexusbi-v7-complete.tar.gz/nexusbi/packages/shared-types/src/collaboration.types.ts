// ── Inline Widget Comments ──

export interface WidgetComment {
  commentId: string;
  dashId: string;
  widgetId: string;
  parentId: string | null;
  userId: string;
  userName: string;
  content: string;
  markContext: Record<string, unknown> | null;
  mentionedUsers: string[];
  resolved: boolean;
  createdAt: string;
  updatedAt: string;
  replies?: WidgetComment[];
}

export interface CommentCreateInput {
  dashId: string;
  widgetId: string;
  parentId?: string;
  content: string;
  markContext?: Record<string, unknown>;
}

export interface CommentUpdateInput {
  content?: string;
  resolved?: boolean;
}

// ── Subscriptions (scheduled delivery) ──

export type SubscriptionType = 'dashboard' | 'widget' | 'story';
export type DeliveryFormat = 'png' | 'pdf' | 'csv' | 'xlsx' | 'html';
export type DeliveryChannel = 'email' | 'webhook' | 'slack' | 'teams';

export interface Subscription {
  subscriptionId: string;
  subscriptionType: SubscriptionType;
  targetId: string;
  ownerId: string;
  orgId: string;
  name: string;
  cronExpression: string;
  timezone: string;
  deliveryChannels: DeliveryChannel[];
  recipients: string[];
  renderFormat: DeliveryFormat;
  filterOverrides: Record<string, unknown> | null;
  emailSubject: string | null;
  emailBody: string | null;
  isEnabled: boolean;
  lastDeliveredAt: string | null;
  lastStatus: 'success' | 'failed' | null;
  createdAt: string;
  updatedAt: string;
}

export interface SubscriptionCreateInput {
  subscriptionType: SubscriptionType;
  targetId: string;
  name: string;
  cronExpression: string;
  timezone?: string;
  deliveryChannels: DeliveryChannel[];
  recipients: string[];
  renderFormat: DeliveryFormat;
  filterOverrides?: Record<string, unknown>;
  emailSubject?: string;
  emailBody?: string;
}

export interface SubscriptionDelivery {
  deliveryId: string;
  subscriptionId: string;
  status: 'success' | 'failed';
  deliveredAt: string;
  durationMs: number;
  errorMessage: string | null;
  recipientCount: number;
  fileSize: number | null;
}

// ── Smart Alerts ──

export type AlertOperator =
  | 'gt' | 'gte' | 'lt' | 'lte' | 'eq' | 'neq'
  | 'crossed_above' | 'crossed_below'
  | 'pct_change_gt' | 'pct_change_lt'
  | 'stddev_above' | 'stddev_below'
  | 'in_range' | 'out_of_range';

export interface AlertCondition {
  measure: string;
  operator: AlertOperator;
  threshold: number;
  thresholdUpper?: number;
  comparisonWindow?: {
    value: number;
    unit: 'minute' | 'hour' | 'day' | 'week' | 'month';
  };
  filters?: Array<{ dimension: string; operator: string; values: unknown[] }>;
}

export interface Alert {
  alertId: string;
  dashId: string | null;
  widgetId: string | null;
  cubeName: string;
  alertName: string;
  description: string | null;
  ownerId: string;
  orgId: string;
  condition: AlertCondition;
  checkFrequency: string;
  notificationChannels: DeliveryChannel[];
  recipients: string[];
  cooldownMinutes: number;
  lastTriggeredAt: string | null;
  lastCheckedAt: string | null;
  lastValue: number | null;
  isEnabled: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface AlertCreateInput {
  dashId?: string;
  widgetId?: string;
  cubeName: string;
  alertName: string;
  description?: string;
  condition: AlertCondition;
  checkFrequency: string;
  notificationChannels: DeliveryChannel[];
  recipients: string[];
  cooldownMinutes?: number;
}

export interface AlertFiring {
  firingId: string;
  alertId: string;
  firedAt: string;
  triggerValue: number;
  previousValue: number | null;
  conditionMet: string;
  deliveryStatus: 'pending' | 'delivered' | 'failed';
  notifiedChannels: DeliveryChannel[];
  errorMessage: string | null;
}

export interface AlertEvaluationResult {
  alertId: string;
  checkedAt: string;
  conditionMet: boolean;
  currentValue: number;
  previousValue: number | null;
  triggerReason: string | null;
  shouldFire: boolean;
  inCooldown: boolean;
}

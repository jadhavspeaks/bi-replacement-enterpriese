-- ════════════════════════════════════════════════════════════════════
-- NexusBI v7 Extensions: Tier 1 + Tier 2 + Tier 3 + Collaboration
-- Adds: hierarchies, shape library, data flows, profile cache,
--       comments, subscriptions, alerts
-- Run AFTER oracle-seed.sql
-- ════════════════════════════════════════════════════════════════════

-- ── TIER 1: HIERARCHIES ─────────────────────────────────────────────
CREATE TABLE NB_HIERARCHIES (
  HIER_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID   VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  HIER_NAME     VARCHAR2(200)  NOT NULL,
  LEVELS_JSON   CLOB           NOT NULL,
  CREATED_AT    TIMESTAMP      DEFAULT SYSTIMESTAMP,
  CONSTRAINT UK_HIER_WB_NAME UNIQUE (WORKBOOK_ID, HIER_NAME)
);
CREATE INDEX IDX_HIER_WB ON NB_HIERARCHIES(WORKBOOK_ID);

-- LOD expressions live as a column on NB_CALCULATED_FIELDS
ALTER TABLE NB_CALCULATED_FIELDS ADD (
  LOD_TYPE        VARCHAR2(20),
  LOD_DIMENSIONS  CLOB,
  LOD_AGGREGATION VARCHAR2(20),
  LOD_FILTER      CLOB
);

-- ── TIER 2: SHAPE LIBRARY ───────────────────────────────────────────
CREATE TABLE NB_SHAPE_LIBRARY (
  SHAPE_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ORG_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  SHAPE_NAME      VARCHAR2(200)  NOT NULL,
  SHAPE_CATEGORY  VARCHAR2(100),
  SVG_CONTENT     CLOB           NOT NULL,
  VIEW_BOX        VARCHAR2(100)  DEFAULT '0 0 24 24',
  IS_SYSTEM       NUMBER(1)      DEFAULT 0,
  CREATED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  CONSTRAINT UK_SHAPE_ORG_NAME UNIQUE (ORG_ID, SHAPE_NAME)
);
CREATE INDEX IDX_SHAPE_ORG ON NB_SHAPE_LIBRARY(ORG_ID, SHAPE_CATEGORY);

-- ── TIER 3: DATA FLOWS ──────────────────────────────────────────────
CREATE TABLE NB_DATA_FLOWS (
  FLOW_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ORG_ID        VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  FLOW_NAME     VARCHAR2(300)  NOT NULL,
  DESCRIPTION   CLOB,
  OWNER_ID      VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  NODES_JSON    CLOB           NOT NULL,
  EDGES_JSON    CLOB           NOT NULL,
  VERSION       NUMBER         DEFAULT 1,
  CREATED_AT    TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT    TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_DF_OWNER ON NB_DATA_FLOWS(OWNER_ID, ORG_ID);

CREATE TABLE NB_DATA_FLOW_RUNS (
  RUN_ID              VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  FLOW_ID             VARCHAR2(36)   NOT NULL REFERENCES NB_DATA_FLOWS(FLOW_ID) ON DELETE CASCADE,
  STATUS              VARCHAR2(20)   NOT NULL CHECK (STATUS IN ('queued','running','success','failed','cancelled')),
  STARTED_AT          TIMESTAMP      DEFAULT SYSTIMESTAMP,
  FINISHED_AT         TIMESTAMP,
  TRIGGERED_BY        VARCHAR2(100)  NOT NULL,
  NODE_RESULTS_JSON   CLOB,
  ERROR_MESSAGE       CLOB,
  TOTAL_ROWS          NUMBER         DEFAULT 0,
  DURATION_MS         NUMBER         DEFAULT 0
);
CREATE INDEX IDX_DFR_FLOW ON NB_DATA_FLOW_RUNS(FLOW_ID, STARTED_AT DESC);

CREATE TABLE NB_SCHEDULED_FLOWS (
  SCHEDULE_ID             VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  FLOW_ID                 VARCHAR2(36)   NOT NULL REFERENCES NB_DATA_FLOWS(FLOW_ID) ON DELETE CASCADE,
  CRON_EXPRESSION         VARCHAR2(100)  NOT NULL,
  NOTIFY_ON_FAILURE       VARCHAR2(20)   DEFAULT 'none' CHECK (NOTIFY_ON_FAILURE IN ('none','email','webhook','both')),
  NOTIFY_EMAILS_JSON      CLOB,
  WEBHOOK_URL             VARCHAR2(2000),
  MAX_RUNTIME_MINUTES     NUMBER         DEFAULT 60,
  INCREMENTAL_COLUMN      VARCHAR2(200),
  INCREMENTAL_WATERMARK   VARCHAR2(200),
  IS_ENABLED              NUMBER(1)      DEFAULT 1,
  LAST_RUN_AT             TIMESTAMP,
  LAST_RUN_STATUS         VARCHAR2(20),
  CREATED_AT              TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_SCHED_ENABLED ON NB_SCHEDULED_FLOWS(IS_ENABLED, CRON_EXPRESSION);

CREATE TABLE NB_PROFILE_CACHE (
  CACHE_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  TABLE_NAME        VARCHAR2(128)  NOT NULL,
  COLUMN_NAME       VARCHAR2(128)  NOT NULL,
  ORG_ID            VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  PROFILE_JSON      CLOB           NOT NULL,
  CACHED_AT         TIMESTAMP      DEFAULT SYSTIMESTAMP,
  EXPIRES_AT        TIMESTAMP      DEFAULT (SYSTIMESTAMP + INTERVAL '1' HOUR),
  CONSTRAINT UK_PROFILE_CACHE UNIQUE (ORG_ID, TABLE_NAME, COLUMN_NAME)
);
CREATE INDEX IDX_PROFILE_EXPIRES ON NB_PROFILE_CACHE(EXPIRES_AT);

-- ── COLLABORATION: WIDGET COMMENTS ──────────────────────────────────
CREATE TABLE NB_WIDGET_COMMENTS (
  COMMENT_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  WIDGET_ID         VARCHAR2(100)  NOT NULL,
  PARENT_ID         VARCHAR2(36)   REFERENCES NB_WIDGET_COMMENTS(COMMENT_ID),
  USER_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  CONTENT           CLOB           NOT NULL,
  MARK_CONTEXT      CLOB,
  MENTIONED_USERS   CLOB,
  RESOLVED          NUMBER(1)      DEFAULT 0,
  CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_WC_DASH ON NB_WIDGET_COMMENTS(DASH_ID, WIDGET_ID, CREATED_AT DESC);
CREATE INDEX IDX_WC_PARENT ON NB_WIDGET_COMMENTS(PARENT_ID);

-- ── COLLABORATION: SUBSCRIPTIONS ────────────────────────────────────
CREATE TABLE NB_SUBSCRIPTIONS (
  SUBSCRIPTION_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  SUBSCRIPTION_TYPE    VARCHAR2(20)   NOT NULL CHECK (SUBSCRIPTION_TYPE IN ('dashboard','widget','story')),
  TARGET_ID            VARCHAR2(100)  NOT NULL,
  OWNER_ID             VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ORG_ID               VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  SUB_NAME             VARCHAR2(300)  NOT NULL,
  CRON_EXPRESSION      VARCHAR2(100)  NOT NULL,
  TIMEZONE             VARCHAR2(100)  DEFAULT 'UTC',
  DELIVERY_CHANNELS    CLOB           NOT NULL,
  RECIPIENTS           CLOB           NOT NULL,
  RENDER_FORMAT        VARCHAR2(20)   DEFAULT 'png' CHECK (RENDER_FORMAT IN ('png','pdf','csv','xlsx','html')),
  FILTER_OVERRIDES     CLOB,
  EMAIL_SUBJECT        VARCHAR2(500),
  EMAIL_BODY           CLOB,
  IS_ENABLED           NUMBER(1)      DEFAULT 1,
  LAST_DELIVERED_AT    TIMESTAMP,
  LAST_STATUS          VARCHAR2(20),
  CREATED_AT           TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT           TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_SUB_OWNER ON NB_SUBSCRIPTIONS(OWNER_ID, ORG_ID);
CREATE INDEX IDX_SUB_ENABLED ON NB_SUBSCRIPTIONS(IS_ENABLED, CRON_EXPRESSION);

CREATE TABLE NB_SUBSCRIPTION_DELIVERIES (
  DELIVERY_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  SUBSCRIPTION_ID   VARCHAR2(36)   NOT NULL REFERENCES NB_SUBSCRIPTIONS(SUBSCRIPTION_ID) ON DELETE CASCADE,
  STATUS            VARCHAR2(20)   NOT NULL CHECK (STATUS IN ('success','failed')),
  DELIVERED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  DURATION_MS       NUMBER         DEFAULT 0,
  ERROR_MESSAGE     CLOB,
  RECIPIENT_COUNT   NUMBER         DEFAULT 0,
  FILE_SIZE         NUMBER
);
CREATE INDEX IDX_SD_SUB ON NB_SUBSCRIPTION_DELIVERIES(SUBSCRIPTION_ID, DELIVERED_AT DESC);

-- ── COLLABORATION: SMART ALERTS ─────────────────────────────────────
CREATE TABLE NB_ALERTS (
  ALERT_ID                  VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID                   VARCHAR2(36)   REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  WIDGET_ID                 VARCHAR2(100),
  CUBE_NAME                 VARCHAR2(200)  NOT NULL,
  ALERT_NAME                VARCHAR2(300)  NOT NULL,
  DESCRIPTION               CLOB,
  OWNER_ID                  VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ORG_ID                    VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CONDITION_JSON            CLOB           NOT NULL,
  CHECK_FREQUENCY           VARCHAR2(100)  NOT NULL,
  NOTIFICATION_CHANNELS     CLOB           NOT NULL,
  RECIPIENTS                CLOB           NOT NULL,
  COOLDOWN_MINUTES          NUMBER         DEFAULT 60,
  LAST_TRIGGERED_AT         TIMESTAMP,
  LAST_CHECKED_AT           TIMESTAMP,
  LAST_VALUE                NUMBER,
  IS_ENABLED                NUMBER(1)      DEFAULT 1,
  CREATED_AT                TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT                TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_ALERT_OWNER ON NB_ALERTS(OWNER_ID, ORG_ID);
CREATE INDEX IDX_ALERT_ENABLED ON NB_ALERTS(IS_ENABLED, CHECK_FREQUENCY);

CREATE TABLE NB_ALERT_FIRINGS (
  FIRING_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ALERT_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_ALERTS(ALERT_ID) ON DELETE CASCADE,
  FIRED_AT          TIMESTAMP      DEFAULT SYSTIMESTAMP,
  TRIGGER_VALUE     NUMBER,
  PREVIOUS_VALUE    NUMBER,
  CONDITION_MET     VARCHAR2(1000),
  DELIVERY_STATUS   VARCHAR2(20)   DEFAULT 'pending' CHECK (DELIVERY_STATUS IN ('pending','delivered','failed')),
  NOTIFIED_CHANNELS CLOB,
  ERROR_MESSAGE     CLOB
);
CREATE INDEX IDX_AF_ALERT ON NB_ALERT_FIRINGS(ALERT_ID, FIRED_AT DESC);

-- ── PERMISSIONS ─────────────────────────────────────────────────────
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.view',          'flow',         'View data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.create',        'flow',         'Create data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.edit',          'flow',         'Edit data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.delete',        'flow',         'Delete data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.run',           'flow',         'Run data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'flow.schedule',      'flow',         'Schedule data flows');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'comment.view',       'comment',      'View widget comments');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'comment.create',     'comment',      'Post widget comments');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'comment.resolve',    'comment',      'Resolve comment threads');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'subscription.manage','subscription', 'Create and manage subscriptions');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'alert.view',         'alert',        'View alerts');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'alert.create',       'alert',        'Create smart alerts');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'alert.edit',         'alert',        'Edit alerts');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'shape.manage',       'shape',        'Upload and manage custom shapes');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'hierarchy.manage',   'hierarchy',    'Manage drill-down hierarchies');

-- Grant all new perms to PLATFORM_ADMIN
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN (
    'flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule',
    'comment.view','comment.create','comment.resolve',
    'subscription.manage',
    'alert.view','alert.create','alert.edit',
    'shape.manage','hierarchy.manage'
  );

-- AUTHOR: flow full, comment full, subscription manage, alert full, shape manage, hierarchy manage
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN (
    'flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule',
    'comment.view','comment.create','comment.resolve',
    'subscription.manage',
    'alert.view','alert.create','alert.edit',
    'shape.manage','hierarchy.manage'
  );

-- CHECKER: view flows + comments
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_CHECKER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('flow.view','comment.view','comment.create','comment.resolve','alert.view');

-- VIEWER: comments and alerts only
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('comment.view','comment.create','alert.view','subscription.manage');

-- DS_ADMIN: flows (for ETL)
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_DSADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('flow.view','flow.create','flow.edit','flow.delete','flow.run','flow.schedule');

-- ── SAMPLE DATA ─────────────────────────────────────────────────────

-- Sample hierarchy for the Revenue workbook
INSERT INTO NB_HIERARCHIES (HIER_ID, WORKBOOK_ID, HIER_NAME, LEVELS_JSON)
  VALUES (SYS_GUID(), 'WB_REVENUE', 'Geography', '["region","country","city"]');

-- System shapes
INSERT INTO NB_SHAPE_LIBRARY (SHAPE_ID, ORG_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (SYS_GUID(), 'ORG_DEFAULT', 'circle', 'basic', '<circle cx="12" cy="12" r="10" fill="currentColor"/>', 1);
INSERT INTO NB_SHAPE_LIBRARY (SHAPE_ID, ORG_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (SYS_GUID(), 'ORG_DEFAULT', 'square', 'basic', '<rect x="2" y="2" width="20" height="20" fill="currentColor"/>', 1);
INSERT INTO NB_SHAPE_LIBRARY (SHAPE_ID, ORG_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (SYS_GUID(), 'ORG_DEFAULT', 'triangle', 'basic', '<polygon points="12,2 22,22 2,22" fill="currentColor"/>', 1);
INSERT INTO NB_SHAPE_LIBRARY (SHAPE_ID, ORG_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (SYS_GUID(), 'ORG_DEFAULT', 'diamond', 'basic', '<polygon points="12,2 22,12 12,22 2,12" fill="currentColor"/>', 1);
INSERT INTO NB_SHAPE_LIBRARY (SHAPE_ID, ORG_ID, SHAPE_NAME, SHAPE_CATEGORY, SVG_CONTENT, IS_SYSTEM)
  VALUES (SYS_GUID(), 'ORG_DEFAULT', 'star', 'basic', '<polygon points="12,2 15,9 22,9 16,14 19,22 12,17 5,22 8,14 2,9 9,9" fill="currentColor"/>', 1);

-- Sample data flow (CSV clean + pivot pipeline)
INSERT INTO NB_DATA_FLOWS (FLOW_ID, ORG_ID, FLOW_NAME, DESCRIPTION, OWNER_ID, NODES_JSON, EDGES_JSON, VERSION)
  VALUES ('FLOW_SALES_PREP', 'ORG_DEFAULT', 'Sales Data Prep',
    'Clean uploaded sales CSV, split region column, and output to Oracle for dashboarding.',
    'USR_A1',
    '[
      {"id":"n1","type":"input_file","position":{"x":50,"y":100},"config":{"fileId":"FILE_SAMPLE","sourceType":"csv"},"label":"Sales CSV"},
      {"id":"n2","type":"clean_nulls","position":{"x":280,"y":100},"config":{"columns":["amount"],"action":"remove"},"label":"Clean Nulls"},
      {"id":"n3","type":"filter","position":{"x":510,"y":100},"config":{"condition":"amount > 100"},"label":"Filter"},
      {"id":"n4","type":"aggregate","position":{"x":740,"y":100},"config":{"groupBy":["region"],"aggs":[{"fn":"sum","col":"amount","alias":"total"}]},"label":"Aggregate"},
      {"id":"n5","type":"output_oracle","position":{"x":970,"y":100},"config":{"targetTable":"NB_STG_SALES_PREPPED"},"label":"Output"}
    ]',
    '[
      {"id":"e1","source":"n1","target":"n2"},
      {"id":"e2","source":"n2","target":"n3"},
      {"id":"e3","source":"n3","target":"n4"},
      {"id":"e4","source":"n4","target":"n5"}
    ]',
    1);

-- Sample comment thread
INSERT INTO NB_WIDGET_COMMENTS (COMMENT_ID, DASH_ID, WIDGET_ID, USER_ID, CONTENT, MENTIONED_USERS)
  VALUES ('CMT_1', 'DASH_REVENUE', 'w4', 'USR_C1', 'Why is LATAM so low this quarter?', '[]');
INSERT INTO NB_WIDGET_COMMENTS (COMMENT_ID, DASH_ID, WIDGET_ID, PARENT_ID, USER_ID, CONTENT)
  VALUES ('CMT_2', 'DASH_REVENUE', 'w4', 'CMT_1', 'USR_A1', 'Currency devaluation + two large deals pushed to Q1. Expecting recovery.');

-- Sample subscription
INSERT INTO NB_SUBSCRIPTIONS (SUBSCRIPTION_ID, SUBSCRIPTION_TYPE, TARGET_ID, OWNER_ID, ORG_ID, SUB_NAME,
  CRON_EXPRESSION, DELIVERY_CHANNELS, RECIPIENTS, RENDER_FORMAT, EMAIL_SUBJECT)
  VALUES ('SUB_Q4_WEEKLY', 'dashboard', 'DASH_REVENUE', 'USR_A1', 'ORG_DEFAULT',
    'Q4 Revenue — Weekly Monday 9am',
    '0 9 * * MON', '["email"]', '["sarah.chen@acme.local","david.lee@acme.local"]',
    'pdf', 'Q4 Revenue Weekly Update');

-- Sample alert
INSERT INTO NB_ALERTS (ALERT_ID, DASH_ID, WIDGET_ID, CUBE_NAME, ALERT_NAME, DESCRIPTION, OWNER_ID, ORG_ID,
  CONDITION_JSON, CHECK_FREQUENCY, NOTIFICATION_CHANNELS, RECIPIENTS, COOLDOWN_MINUTES)
  VALUES ('ALERT_REV_DROP', 'DASH_REVENUE', 'w1', 'Orders',
    'Revenue Drop Warning',
    'Fires when total revenue drops below $3.5M on the Q4 dashboard.',
    'USR_A1', 'ORG_DEFAULT',
    '{"measure":"total_revenue","operator":"lt","threshold":3500000}',
    '0 */4 * * *',
    '["email","webhook"]',
    '["sarah.chen@acme.local"]',
    60);

COMMIT;

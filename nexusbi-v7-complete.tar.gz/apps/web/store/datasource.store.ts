import { create } from 'zustand';
import type { DataSource } from '@nexusbi/shared-types';

interface DataSourceState {
  dataSources: DataSource[];
  loading: boolean;
  error: string | null;
  selectedDsId: string | null;
  fetchDataSources: () => Promise<void>;
  setSelectedDsId: (dsId: string | null) => void;
  getDataSourceById: (dsId: string) => DataSource | undefined;
  invalidate: () => void;
}

export const useDataSourceStore = create<DataSourceState>((set, get) => ({
  dataSources: [],
  loading: false,
  error: null,
  selectedDsId: null,

  fetchDataSources: async () => {
    set({ loading: true, error: null });
    try {
      const response = await fetch('/api/datasources');
      if (!response.ok) {
        throw new Error(`Failed to fetch datasources: ${response.status}`);
      }

      const data = await response.json();
      if (!data.success) {
        throw new Error(data.error?.message || 'Failed to fetch datasources');
      }

      set({ dataSources: data.data || [], loading: false });
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : 'Unknown error',
        loading: false,
      });
    }
  },

  setSelectedDsId: (dsId) => set({ selectedDsId: dsId }),

  getDataSourceById: (dsId) => {
    return get().dataSources.find((ds) => ds.dsId === dsId);
  },

  invalidate: () => {
    set({ dataSources: [], loading: false, error: null });
    get().fetchDataSources();
  },
}));

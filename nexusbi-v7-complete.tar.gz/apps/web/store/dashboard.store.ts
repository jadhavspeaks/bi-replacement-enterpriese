import { create } from 'zustand';
import type {
  Dashboard,
  WidgetConfig,
  LayoutConfig,
  DashboardFiltersState,
  CubeFilter,
} from '@nexusbi/shared-types';

interface HistoryEntry {
  widgets: WidgetConfig[];
  layout: LayoutConfig;
}

interface DashboardBuilderState {
  dashboard: Dashboard | null;
  widgets: WidgetConfig[];
  layout: LayoutConfig;
  filters: DashboardFiltersState;
  selectedWidgetId: string | null;
  isDirty: boolean;
  isSaving: boolean;
  editMode: 'desktop' | 'mobile';
  history: HistoryEntry[];
  historyIndex: number;

  setDashboard: (dashboard: Dashboard) => void;
  setWidgets: (widgets: WidgetConfig[]) => void;
  setLayout: (layout: LayoutConfig) => void;
  setFilters: (filters: DashboardFiltersState) => void;
  selectWidget: (widgetId: string | null) => void;
  setEditMode: (mode: 'desktop' | 'mobile') => void;

  addWidget: (widget: WidgetConfig) => void;
  updateWidget: (widgetId: string, updates: Partial<WidgetConfig>) => void;
  removeWidget: (widgetId: string) => void;
  duplicateWidget: (widgetId: string) => void;
  moveWidget: (widgetId: string, position: { x: number; y: number; w: number; h: number }) => void;

  addGlobalFilter: (filter: CubeFilter) => void;
  removeGlobalFilter: (index: number) => void;
  clearGlobalFilters: () => void;

  undo: () => void;
  redo: () => void;
  canUndo: () => boolean;
  canRedo: () => boolean;

  save: () => Promise<boolean>;
  reset: () => void;
}

const DEFAULT_LAYOUT: LayoutConfig = {
  cols: 12,
  rowHeight: 40,
  margin: [10, 10],
  containerPadding: [10, 10],
  compactType: 'vertical',
};

const MAX_HISTORY = 50;

function pushHistory(state: DashboardBuilderState): Partial<DashboardBuilderState> {
  const entry: HistoryEntry = {
    widgets: JSON.parse(JSON.stringify(state.widgets)),
    layout: JSON.parse(JSON.stringify(state.layout)),
  };

  const newHistory = state.history.slice(0, state.historyIndex + 1);
  newHistory.push(entry);

  if (newHistory.length > MAX_HISTORY) {
    newHistory.shift();
  }

  return {
    history: newHistory,
    historyIndex: newHistory.length - 1,
    isDirty: true,
  };
}

export const useDashboardStore = create<DashboardBuilderState>((set, get) => ({
  dashboard: null,
  widgets: [],
  layout: DEFAULT_LAYOUT,
  filters: { globalFilters: [], widgetFilters: {} },
  selectedWidgetId: null,
  isDirty: false,
  isSaving: false,
  editMode: 'desktop',
  history: [],
  historyIndex: -1,

  setDashboard: (dashboard) => {
    const widgets = dashboard.widgetsJson || [];
    const layout = dashboard.layoutJson || DEFAULT_LAYOUT;
    const filters = dashboard.filtersJson || { globalFilters: [], widgetFilters: {} };

    set({
      dashboard,
      widgets,
      layout,
      filters,
      isDirty: false,
      selectedWidgetId: null,
      history: [{ widgets: JSON.parse(JSON.stringify(widgets)), layout: JSON.parse(JSON.stringify(layout)) }],
      historyIndex: 0,
    });
  },

  setWidgets: (widgets) => set((s) => ({ widgets, ...pushHistory(s) })),
  setLayout: (layout) => set((s) => ({ layout, ...pushHistory(s) })),
  setFilters: (filters) => set({ filters, isDirty: true }),
  selectWidget: (widgetId) => set({ selectedWidgetId: widgetId }),
  setEditMode: (mode) => set({ editMode: mode }),

  addWidget: (widget) => set((s) => {
    const widgets = [...s.widgets, widget];
    return { widgets, selectedWidgetId: widget.widgetId, ...pushHistory({ ...s, widgets }) };
  }),

  updateWidget: (widgetId, updates) => set((s) => {
    const widgets = s.widgets.map((w) =>
      w.widgetId === widgetId ? { ...w, ...updates } : w,
    );
    return { widgets, ...pushHistory({ ...s, widgets }) };
  }),

  removeWidget: (widgetId) => set((s) => {
    const widgets = s.widgets.filter((w) => w.widgetId !== widgetId);
    const selectedWidgetId = s.selectedWidgetId === widgetId ? null : s.selectedWidgetId;
    return { widgets, selectedWidgetId, ...pushHistory({ ...s, widgets }) };
  }),

  duplicateWidget: (widgetId) => set((s) => {
    const source = s.widgets.find((w) => w.widgetId === widgetId);
    if (!source) return s;

    const newWidget: WidgetConfig = {
      ...JSON.parse(JSON.stringify(source)),
      widgetId: crypto.randomUUID(),
      title: `${source.title} (copy)`,
      position: {
        ...source.position,
        y: source.position.y + source.position.h,
      },
    };

    const widgets = [...s.widgets, newWidget];
    return { widgets, selectedWidgetId: newWidget.widgetId, ...pushHistory({ ...s, widgets }) };
  }),

  moveWidget: (widgetId, position) => set((s) => {
    const widgets = s.widgets.map((w) =>
      w.widgetId === widgetId ? { ...w, position: { ...w.position, ...position } } : w,
    );
    return { widgets, isDirty: true };
  }),

  addGlobalFilter: (filter) => set((s) => ({
    filters: {
      ...s.filters,
      globalFilters: [...s.filters.globalFilters, filter],
    },
    isDirty: true,
  })),

  removeGlobalFilter: (index) => set((s) => ({
    filters: {
      ...s.filters,
      globalFilters: s.filters.globalFilters.filter((_, i) => i !== index),
    },
    isDirty: true,
  })),

  clearGlobalFilters: () => set((s) => ({
    filters: { ...s.filters, globalFilters: [] },
    isDirty: true,
  })),

  undo: () => set((s) => {
    if (s.historyIndex <= 0) return s;
    const newIndex = s.historyIndex - 1;
    const entry = s.history[newIndex];
    return {
      widgets: JSON.parse(JSON.stringify(entry.widgets)),
      layout: JSON.parse(JSON.stringify(entry.layout)),
      historyIndex: newIndex,
      isDirty: true,
    };
  }),

  redo: () => set((s) => {
    if (s.historyIndex >= s.history.length - 1) return s;
    const newIndex = s.historyIndex + 1;
    const entry = s.history[newIndex];
    return {
      widgets: JSON.parse(JSON.stringify(entry.widgets)),
      layout: JSON.parse(JSON.stringify(entry.layout)),
      historyIndex: newIndex,
      isDirty: true,
    };
  }),

  canUndo: () => get().historyIndex > 0,
  canRedo: () => get().historyIndex < get().history.length - 1,

  save: async () => {
    const { dashboard, widgets, layout, filters } = get();
    if (!dashboard) return false;

    set({ isSaving: true });
    try {
      const response = await fetch(`/api/dashboards/${dashboard.dashId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          layoutJson: layout,
          widgetsJson: widgets,
          filtersJson: filters,
        }),
      });

      if (!response.ok) {
        set({ isSaving: false });
        return false;
      }

      const data = await response.json();
      if (data.success) {
        set({ isDirty: false, isSaving: false });
        return true;
      }

      set({ isSaving: false });
      return false;
    } catch {
      set({ isSaving: false });
      return false;
    }
  },

  reset: () => set({
    dashboard: null,
    widgets: [],
    layout: DEFAULT_LAYOUT,
    filters: { globalFilters: [], widgetFilters: {} },
    selectedWidgetId: null,
    isDirty: false,
    isSaving: false,
    editMode: 'desktop',
    history: [],
    historyIndex: -1,
  }),
}));

import { create } from 'zustand';
import type { CubeMeta, CubeMetaMember } from '@/lib/cube-client';

interface ExplorerState {
  selectedDsId: string | null;
  selectedCubeName: string | null;
  cubes: CubeMeta[];
  cubesLoading: boolean;
  cubesError: string | null;
  setSelectedDsId: (dsId: string | null) => void;
  setSelectedCubeName: (cubeName: string | null) => void;
  fetchCubes: (dsId?: string) => Promise<void>;
  getSelectedCube: () => CubeMeta | undefined;
  getMeasures: () => CubeMetaMember[];
  getDimensions: () => CubeMetaMember[];
  clear: () => void;
}

export const useExplorerStore = create<ExplorerState>((set, get) => ({
  selectedDsId: null,
  selectedCubeName: null,
  cubes: [],
  cubesLoading: false,
  cubesError: null,

  setSelectedDsId: (dsId) => {
    set({ selectedDsId: dsId, selectedCubeName: null, cubes: [] });
    if (dsId) {
      get().fetchCubes(dsId);
    }
  },

  setSelectedCubeName: (cubeName) => set({ selectedCubeName: cubeName }),

  fetchCubes: async (dsId) => {
    set({ cubesLoading: true, cubesError: null });
    try {
      const params = new URLSearchParams();
      if (dsId) params.set('dataSource', dsId);

      const response = await fetch(`/api/cube/v1/meta?${params.toString()}`);
      if (!response.ok) {
        throw new Error(`Failed to fetch cube metadata: ${response.status}`);
      }

      const data = await response.json();
      const cubes = data.cubes || [];

      set({
        cubes,
        cubesLoading: false,
        selectedCubeName: cubes.length > 0 ? cubes[0].name : null,
      });
    } catch (error) {
      set({
        cubesError: error instanceof Error ? error.message : 'Unknown error',
        cubesLoading: false,
      });
    }
  },

  getSelectedCube: () => {
    const { cubes, selectedCubeName } = get();
    return cubes.find((c) => c.name === selectedCubeName);
  },

  getMeasures: () => {
    const cube = get().getSelectedCube();
    return cube?.measures || [];
  },

  getDimensions: () => {
    const cube = get().getSelectedCube();
    return cube?.dimensions || [];
  },

  clear: () => set({
    selectedDsId: null,
    selectedCubeName: null,
    cubes: [],
    cubesLoading: false,
    cubesError: null,
  }),
}));

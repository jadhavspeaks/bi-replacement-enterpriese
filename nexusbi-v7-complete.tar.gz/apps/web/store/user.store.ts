import { create } from 'zustand';
import type { SessionUser, PermissionCode } from '@nexusbi/shared-types';

interface UserState {
  user: SessionUser | null;
  permissions: Set<string>;
  loading: boolean;
  setUser: (user: SessionUser | null) => void;
  setPermissions: (permissions: PermissionCode[]) => void;
  fetchPermissions: () => Promise<void>;
  clear: () => void;
}

export const useUserStore = create<UserState>((set, get) => ({
  user: null,
  permissions: new Set<string>(),
  loading: false,

  setUser: (user) => set({ user }),

  setPermissions: (permissions) => set({ permissions: new Set(permissions) }),

  fetchPermissions: async () => {
    const { user } = get();
    if (!user) return;

    set({ loading: true });
    try {
      const response = await fetch('/api/admin/roles');
      if (!response.ok) {
        set({ loading: false });
        return;
      }

      const data = await response.json();
      if (!data.success) {
        set({ loading: false });
        return;
      }

      // Resolve permissions from user's roles
      const userRoles = new Set(user.roles);
      const allPermissions = new Set<string>();

      for (const role of data.data || []) {
        if (userRoles.has(role.roleName)) {
          for (const perm of role.permissions || []) {
            allPermissions.add(perm.permCode);
          }
        }
      }

      set({ permissions: allPermissions, loading: false });
    } catch {
      set({ loading: false });
    }
  },

  clear: () => set({ user: null, permissions: new Set(), loading: false }),
}));

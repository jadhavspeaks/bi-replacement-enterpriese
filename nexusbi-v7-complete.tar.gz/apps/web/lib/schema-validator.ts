/**
 * Lightweight schema validator.
 * Replaces the former @nexusbi/cube-schema package which was tightly coupled
 * to Cube.js. Schemas in NexusBI v7+ are stored as JSON (not JavaScript source)
 * so sanitization is simple: parse it and check the shape.
 */

export interface SchemaValidationResult {
  valid: boolean;
  errors: Array<{ line: number | null; message: string; severity: 'error' | 'warning' }>;
  warnings: Array<{ line: number | null; message: string; severity: 'error' | 'warning' }>;
  cubeName: string | null;
  measuresCount: number;
  dimensionsCount: number;
}

const VALID_MEASURE_TYPES = ['count', 'sum', 'avg', 'min', 'max', 'countDistinct'];
const VALID_DIMENSION_TYPES = ['string', 'number', 'time', 'boolean'];

/**
 * "Sanitize" a schema source. For JSON schemas this is a no-op beyond trimming;
 * for legacy JS schemas it strips `require()` calls and process references.
 */
export function sanitizeSchemaJs(source: string): string {
  if (!source) return '';
  return source
    .replace(/require\s*\(/g, '/* require removed */ (')
    .replace(/process\.\w+/g, '/* process ref removed */')
    .replace(/eval\s*\(/g, '/* eval removed */ (')
    .trim();
}

/**
 * Validate a schema source. Accepts either JSON or a Cube.js-style `cube(...)`
 * definition. For JSON we do a full shape check; for JS we extract the cube
 * name and count members heuristically.
 */
export function validateCubeSchema(source: string): SchemaValidationResult {
  const errors: SchemaValidationResult['errors'] = [];
  const warnings: SchemaValidationResult['warnings'] = [];
  let cubeName: string | null = null;
  let measuresCount = 0;
  let dimensionsCount = 0;

  const trimmed = (source || '').trim();
  if (!trimmed) {
    errors.push({ line: 1, message: 'Schema is empty', severity: 'error' });
    return { valid: false, errors, warnings, cubeName, measuresCount, dimensionsCount };
  }

  // Try parsing as JSON first.
  if (trimmed.startsWith('{')) {
    try {
      const parsed = JSON.parse(trimmed);

      if (!parsed.cubeName && !parsed.name) {
        errors.push({ line: null, message: 'Missing "cubeName" (or "name") field', severity: 'error' });
      } else {
        cubeName = parsed.cubeName || parsed.name;
      }

      if (!parsed.baseTable && !parsed.sql) {
        errors.push({ line: null, message: 'Missing "baseTable" (or "sql") field', severity: 'error' });
      }

      const measures = parsed.measures || {};
      const dimensions = parsed.dimensions || {};

      measuresCount = Object.keys(measures).length;
      dimensionsCount = Object.keys(dimensions).length;

      for (const [name, def] of Object.entries<{ sql?: string; type?: string }>(measures)) {
        if (!def.type) errors.push({ line: null, message: `Measure "${name}" missing "type"`, severity: 'error' });
        else if (!VALID_MEASURE_TYPES.includes(def.type)) {
          errors.push({ line: null, message: `Measure "${name}" has invalid type "${def.type}" (must be one of: ${VALID_MEASURE_TYPES.join(', ')})`, severity: 'error' });
        }
        if (!def.sql && def.type !== 'count') {
          warnings.push({ line: null, message: `Measure "${name}" has no "sql" expression`, severity: 'warning' });
        }
      }

      for (const [name, def] of Object.entries<{ sql?: string; type?: string }>(dimensions)) {
        if (!def.type) errors.push({ line: null, message: `Dimension "${name}" missing "type"`, severity: 'error' });
        else if (!VALID_DIMENSION_TYPES.includes(def.type)) {
          errors.push({ line: null, message: `Dimension "${name}" has invalid type "${def.type}" (must be one of: ${VALID_DIMENSION_TYPES.join(', ')})`, severity: 'error' });
        }
        if (!def.sql) {
          errors.push({ line: null, message: `Dimension "${name}" missing "sql" expression`, severity: 'error' });
        }
      }

      return {
        valid: errors.length === 0,
        errors,
        warnings,
        cubeName,
        measuresCount,
        dimensionsCount,
      };
    } catch (e) {
      errors.push({
        line: null,
        message: `JSON parse error: ${e instanceof Error ? e.message : 'invalid JSON'}`,
        severity: 'error',
      });
      return { valid: false, errors, warnings, cubeName, measuresCount, dimensionsCount };
    }
  }

  // Legacy JS-style schema — extract basic info heuristically.
  const cubeMatch = trimmed.match(/cube\s*\(\s*['"`]([^'"`]+)['"`]/);
  if (cubeMatch) cubeName = cubeMatch[1];
  else {
    errors.push({ line: null, message: 'Could not find cube() declaration', severity: 'error' });
  }

  const measuresBlock = trimmed.match(/measures\s*:\s*\{([^}]*)\}/s);
  if (measuresBlock) {
    measuresCount = (measuresBlock[1].match(/\w+\s*:\s*\{/g) || []).length;
  }

  const dimensionsBlock = trimmed.match(/dimensions\s*:\s*\{([^}]*)\}/s);
  if (dimensionsBlock) {
    dimensionsCount = (dimensionsBlock[1].match(/\w+\s*:\s*\{/g) || []).length;
  }

  warnings.push({
    line: null,
    message: 'Legacy JS-style schema detected. Consider migrating to JSON format for stricter validation.',
    severity: 'warning',
  });

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    cubeName,
    measuresCount,
    dimensionsCount,
  };
}

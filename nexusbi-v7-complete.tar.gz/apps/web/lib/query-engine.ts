/**
 * NexusBI — Query Engine
 *
 * Replaces the former Cube.js semantic layer with a lightweight in-app engine.
 * Reads cube-style schema definitions from NB_CUBE_SCHEMAS (Oracle), compiles
 * a query into the appropriate dialect, dispatches to the native driver for
 * each data source type, and normalizes the result.
 *
 * Supports the 12 approved data source types. Oracle runs directly; other
 * sources can either query live or go through the staged-to-Oracle tables
 * created by file-ingest, api-source-ingest, or data-flow exports.
 */

import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import { runOracleQuery, type OracleConnConfig } from '@/lib/connectors/oracle-connector';
import { runMongoQuery, type MongoConnConfig } from '@/lib/connectors/mongo-connector';
import { runHiveQuery, type HiveConnConfig } from '@/lib/connectors/hive-connector';
import type { DataSourceType } from '@nexusbi/shared-types';

export interface CubeMeasureDef {
  name: string;
  sql: string;
  type: 'count' | 'sum' | 'avg' | 'min' | 'max' | 'countDistinct';
}

export interface CubeDimensionDef {
  name: string;
  sql: string;
  type: 'string' | 'number' | 'time';
}

export interface CubeSchema {
  cubeName: string;
  dsId: string;
  baseTable: string;
  measures: Record<string, CubeMeasureDef>;
  dimensions: Record<string, CubeDimensionDef>;
}

export interface QueryFilter {
  member: string;
  operator: 'equals' | 'notEquals' | 'gt' | 'gte' | 'lt' | 'lte' | 'contains' | 'in' | 'notIn';
  values: Array<string | number | boolean | null>;
}

export interface Query {
  measures?: string[];
  dimensions?: string[];
  filters?: QueryFilter[];
  order?: Array<{ member: string; direction: 'asc' | 'desc' }>;
  limit?: number;
  offset?: number;
}

export interface QueryResult {
  data: Array<Record<string, unknown>>;
  query: Query;
  annotation: {
    measures: Record<string, CubeMeasureDef>;
    dimensions: Record<string, CubeDimensionDef>;
  };
  rowCount: number;
  durationMs: number;
}

/**
 * Load the cube schema for a given cube name from NB_CUBE_SCHEMAS.
 * Schemas are stored as JSON in the SCHEMA_JSON column.
 */
export async function loadCubeSchema(
  tenantId: string,
  cubeName: string,
): Promise<CubeSchema | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      CUBE_NAME: string;
      DS_ID: string;
      SCHEMA_JSON: string;
    }>(
      `SELECT CUBE_NAME, DS_ID, SCHEMA_JSON
         FROM NB_CUBE_SCHEMAS
        WHERE TENANT_ID = :tenantId AND CUBE_NAME = :cubeName AND IS_ACTIVE = 1`,
      { tenantId, cubeName },
      { outFormat: 4002 },
    );
    const row = result.rows?.[0];
    if (!row) return null;
    const schemaJson = await clobToString(row.SCHEMA_JSON);
    const parsed = JSON.parse(schemaJson);
    return {
      cubeName: row.CUBE_NAME,
      dsId: row.DS_ID,
      baseTable: parsed.baseTable || parsed.sql || row.CUBE_NAME,
      measures: parsed.measures || {},
      dimensions: parsed.dimensions || {},
    };
  });
}

/**
 * Compile a Query to an ANSI SQL string plus bind parameters.
 * Tuned for Oracle dialect; valid for Hive/Impala with minor quoting diffs.
 */
export function compileToSql(schema: CubeSchema, query: Query): {
  sql: string;
  binds: Record<string, unknown>;
} {
  const binds: Record<string, unknown> = {};
  let bindCounter = 0;

  function nextBind(value: unknown): string {
    const name = `b${bindCounter++}`;
    binds[name] = value;
    return `:${name}`;
  }

  function aggToSql(def: CubeMeasureDef, alias: string): string {
    const expr = def.sql.replace(/\$\{CUBE\}\./g, '');
    switch (def.type) {
      case 'sum': return `SUM(${expr}) AS "${alias}"`;
      case 'avg': return `AVG(${expr}) AS "${alias}"`;
      case 'min': return `MIN(${expr}) AS "${alias}"`;
      case 'max': return `MAX(${expr}) AS "${alias}"`;
      case 'count': return `COUNT(*) AS "${alias}"`;
      case 'countDistinct': return `COUNT(DISTINCT ${expr}) AS "${alias}"`;
      default: return `${expr} AS "${alias}"`;
    }
  }

  function dimToSql(def: CubeDimensionDef, alias: string): string {
    const expr = def.sql.replace(/\$\{CUBE\}\./g, '');
    return `${expr} AS "${alias}"`;
  }

  const selectedMeasures = (query.measures || [])
    .map((m) => {
      const key = m.includes('.') ? m.split('.').pop()! : m;
      const def = schema.measures[key];
      if (!def) throw new Error(`Unknown measure: ${m}`);
      return aggToSql(def, m);
    });

  const selectedDims = (query.dimensions || [])
    .map((d) => {
      const key = d.includes('.') ? d.split('.').pop()! : d;
      const def = schema.dimensions[key];
      if (!def) throw new Error(`Unknown dimension: ${d}`);
      return dimToSql(def, d);
    });

  const selectClause = [...selectedDims, ...selectedMeasures].join(', ') || '*';
  const groupByExpressions = (query.dimensions || []).map((d) => {
    const key = d.includes('.') ? d.split('.').pop()! : d;
    const def = schema.dimensions[key];
    return def.sql.replace(/\$\{CUBE\}\./g, '');
  });

  const whereClauses: string[] = [];
  for (const f of query.filters || []) {
    const key = f.member.includes('.') ? f.member.split('.').pop()! : f.member;
    const def = schema.dimensions[key] || schema.measures[key];
    if (!def) continue;
    const expr = def.sql.replace(/\$\{CUBE\}\./g, '');

    switch (f.operator) {
      case 'equals':
        whereClauses.push(`${expr} = ${nextBind(f.values[0])}`);
        break;
      case 'notEquals':
        whereClauses.push(`${expr} <> ${nextBind(f.values[0])}`);
        break;
      case 'gt':
        whereClauses.push(`${expr} > ${nextBind(f.values[0])}`);
        break;
      case 'gte':
        whereClauses.push(`${expr} >= ${nextBind(f.values[0])}`);
        break;
      case 'lt':
        whereClauses.push(`${expr} < ${nextBind(f.values[0])}`);
        break;
      case 'lte':
        whereClauses.push(`${expr} <= ${nextBind(f.values[0])}`);
        break;
      case 'contains':
        whereClauses.push(`${expr} LIKE ${nextBind('%' + f.values[0] + '%')}`);
        break;
      case 'in':
        if (f.values.length > 0) {
          const placeholders = f.values.map((v) => nextBind(v)).join(', ');
          whereClauses.push(`${expr} IN (${placeholders})`);
        }
        break;
      case 'notIn':
        if (f.values.length > 0) {
          const placeholders = f.values.map((v) => nextBind(v)).join(', ');
          whereClauses.push(`${expr} NOT IN (${placeholders})`);
        }
        break;
    }
  }

  const orderClauses = (query.order || []).map((o) =>
    `"${o.member}" ${o.direction === 'desc' ? 'DESC' : 'ASC'}`,
  );

  let sql = `SELECT ${selectClause} FROM ${schema.baseTable}`;
  if (whereClauses.length > 0) sql += ` WHERE ${whereClauses.join(' AND ')}`;
  if (groupByExpressions.length > 0) sql += ` GROUP BY ${groupByExpressions.join(', ')}`;
  if (orderClauses.length > 0) sql += ` ORDER BY ${orderClauses.join(', ')}`;
  if (query.limit != null) sql += ` FETCH FIRST ${Math.max(1, query.limit)} ROWS ONLY`;

  return { sql, binds };
}

interface DataSourceRow {
  DS_ID: string;
  DS_TYPE: string;
  CONFIG_ENCRYPTED: string;
}

/**
 * Fetch and decrypt a data source's connection config.
 */
async function loadDataSourceConfig(
  tenantId: string,
  dsId: string,
): Promise<{ dsType: DataSourceType; config: Record<string, unknown> } | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<DataSourceRow>(
      `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
         FROM NB_DATA_SOURCES
        WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
      { dsId, tenantId },
      { outFormat: 4002 },
    );
    const row = result.rows?.[0];
    if (!row) return null;
    const configStr = await clobToString(row.CONFIG_ENCRYPTED);
    return {
      dsType: row.DS_TYPE as DataSourceType,
      config: JSON.parse(decrypt(configStr)),
    };
  });
}

/**
 * Execute a query against the appropriate data source.
 */
export async function executeQuery(
  tenantId: string,
  cubeName: string,
  query: Query,
): Promise<QueryResult> {
  const startTime = performance.now();

  const schema = await loadCubeSchema(tenantId, cubeName);
  if (!schema) throw new Error(`Cube not found: ${cubeName}`);

  const ds = await loadDataSourceConfig(tenantId, schema.dsId);
  if (!ds) throw new Error(`Data source not found: ${schema.dsId}`);

  const { sql, binds } = compileToSql(schema, query);

  let rows: Array<Record<string, unknown>>;

  switch (ds.dsType) {
    case 'oracle':
    case 'file_csv':
    case 'file_excel':
    case 'file_json':
    case 'file_parquet':
    case 'api_rest':
    case 'api_graphql':
    case 'api_oauth_rest':
    case 'api_webhook': {
      // All file/API data is staged into Oracle NB_STG_* tables,
      // so query it directly via oracledb.
      const cfg = ds.dsType === 'oracle'
        ? (ds.config as unknown as OracleConnConfig)
        : ({
          host: process.env.ORACLE_HOST!,
          port: parseInt(process.env.ORACLE_PORT || '1521', 10),
          serviceName: process.env.ORACLE_SERVICE!,
          user: process.env.ORACLE_USER!,
          password: process.env.ORACLE_PASSWORD!,
        });
      rows = await runOracleQuery(cfg, sql, binds);
      break;
    }
    case 'mongodb': {
      // For MongoDB, translate the SQL-style query to an aggregation pipeline.
      // This is a simplified translation; complex queries should be staged first.
      const pipeline = translateToMongoAggregation(schema, query);
      const collection = schema.baseTable;
      rows = await runMongoQuery(ds.config as unknown as MongoConnConfig, collection, pipeline);
      break;
    }
    case 'hive':
    case 'impala': {
      // Hive/Impala understand ANSI SQL that our compiler produces.
      // Interpolate binds inline (Hive Thrift doesn't support named binds).
      const inlinedSql = inlineOracleBinds(sql, binds);
      rows = await runHiveQuery(ds.config as unknown as HiveConnConfig, inlinedSql);
      break;
    }
    default:
      throw new Error(`Unsupported data source type for query: ${ds.dsType}`);
  }

  return {
    data: rows,
    query,
    annotation: {
      measures: Object.fromEntries(
        (query.measures || []).map((m) => {
          const key = m.includes('.') ? m.split('.').pop()! : m;
          return [m, schema.measures[key]];
        }),
      ),
      dimensions: Object.fromEntries(
        (query.dimensions || []).map((d) => {
          const key = d.includes('.') ? d.split('.').pop()! : d;
          return [d, schema.dimensions[key]];
        }),
      ),
    },
    rowCount: rows.length,
    durationMs: Math.round(performance.now() - startTime),
  };
}

/**
 * Inline :bind parameters into a SQL string as literals.
 * Used for Hive/Impala Thrift which doesn't support named binds.
 */
function inlineOracleBinds(sql: string, binds: Record<string, unknown>): string {
  let out = sql;
  for (const [name, value] of Object.entries(binds)) {
    const placeholder = `:${name}`;
    const literal = typeof value === 'number'
      ? String(value)
      : value === null || value === undefined
        ? 'NULL'
        : `'${String(value).replace(/'/g, "''")}'`;
    out = out.split(placeholder).join(literal);
  }
  return out;
}

/**
 * Translate a simple Query into a MongoDB aggregation pipeline.
 * Supports grouping + common aggregations. Falls back to a raw $match-only
 * pipeline for purely filter-based queries.
 */
function translateToMongoAggregation(
  schema: CubeSchema,
  query: Query,
): Array<Record<string, unknown>> {
  const pipeline: Array<Record<string, unknown>> = [];

  if ((query.filters || []).length > 0) {
    const match: Record<string, unknown> = {};
    for (const f of query.filters!) {
      const key = f.member.includes('.') ? f.member.split('.').pop()! : f.member;
      const field = key;
      switch (f.operator) {
        case 'equals': match[field] = f.values[0]; break;
        case 'notEquals': match[field] = { $ne: f.values[0] }; break;
        case 'gt': match[field] = { $gt: f.values[0] }; break;
        case 'gte': match[field] = { $gte: f.values[0] }; break;
        case 'lt': match[field] = { $lt: f.values[0] }; break;
        case 'lte': match[field] = { $lte: f.values[0] }; break;
        case 'in': match[field] = { $in: f.values }; break;
        case 'notIn': match[field] = { $nin: f.values }; break;
        case 'contains': match[field] = { $regex: String(f.values[0]), $options: 'i' }; break;
      }
    }
    pipeline.push({ $match: match });
  }

  if ((query.dimensions || []).length > 0 || (query.measures || []).length > 0) {
    const groupKey: Record<string, string> = {};
    for (const d of query.dimensions || []) {
      const key = d.includes('.') ? d.split('.').pop()! : d;
      groupKey[d.replace(/\./g, '_')] = `$${key}`;
    }
    const group: Record<string, unknown> = { _id: groupKey };
    for (const m of query.measures || []) {
      const key = m.includes('.') ? m.split('.').pop()! : m;
      const def = schema.measures[key];
      if (!def) continue;
      const alias = m;
      switch (def.type) {
        case 'count': group[alias] = { $sum: 1 }; break;
        case 'sum': group[alias] = { $sum: `$${key}` }; break;
        case 'avg': group[alias] = { $avg: `$${key}` }; break;
        case 'min': group[alias] = { $min: `$${key}` }; break;
        case 'max': group[alias] = { $max: `$${key}` }; break;
        case 'countDistinct': group[alias] = { $addToSet: `$${key}` }; break;
      }
    }
    pipeline.push({ $group: group });
  }

  if ((query.order || []).length > 0) {
    const sort: Record<string, 1 | -1> = {};
    for (const o of query.order!) {
      sort[o.member.replace(/\./g, '_')] = o.direction === 'desc' ? -1 : 1;
    }
    pipeline.push({ $sort: sort });
  }

  if (query.limit != null) pipeline.push({ $limit: query.limit });

  return pipeline;
}

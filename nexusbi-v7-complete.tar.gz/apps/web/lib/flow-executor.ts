import type {
  DataFlow, FlowNode, FlowEdge, FlowRun, FlowRunStatus, FlowNodeResult, FlowNodeStatus,
} from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';
import { buildNodeSQL, validateNode } from '@/lib/flow-node-executors';
import { generateId } from '@nexusbi/shared-types';

/**
 * Executes a data flow graph as a DAG:
 *   1. Topological sort of nodes
 *   2. For each node: CREATE TABLE AS SELECT <nodeSQL> into NB_FLOW_<flow>_<node>
 *   3. Track per-node status, row count, duration in NB_DATA_FLOW_RUNS
 *   4. On failure: mark downstream nodes as 'skipped', persist error
 */

function topologicalSort(nodes: FlowNode[], edges: FlowEdge[]): string[] | null {
  const graph = new Map<string, string[]>();
  const inDegree = new Map<string, number>();
  for (const n of nodes) { graph.set(n.id, []); inDegree.set(n.id, 0); }
  for (const e of edges) {
    graph.get(e.source)?.push(e.target);
    inDegree.set(e.target, (inDegree.get(e.target) ?? 0) + 1);
  }
  const queue: string[] = [];
  for (const [id, deg] of inDegree) if (deg === 0) queue.push(id);
  const sorted: string[] = [];
  while (queue.length) {
    const n = queue.shift()!;
    sorted.push(n);
    for (const next of graph.get(n) ?? []) {
      inDegree.set(next, (inDegree.get(next) ?? 1) - 1);
      if (inDegree.get(next) === 0) queue.push(next);
    }
  }
  return sorted.length === nodes.length ? sorted : null;
}

function stagingTableName(flowId: string, nodeId: string): string {
  const suffix = `${flowId}_${nodeId}`.toUpperCase().replace(/[^A-Z0-9_]/g, '_').slice(0, 60);
  return `NB_FLOW_${suffix}`;
}

function inputsFor(nodeId: string, edges: FlowEdge[]): string[] {
  return edges.filter((e) => e.target === nodeId).map((e) => e.source);
}

export async function executeFlow(
  flow: DataFlow,
  triggeredBy: string,
  tenantId: string,
): Promise<FlowRun> {
  const runId = generateId('RUN');
  const startedAt = new Date().toISOString();
  const sortedNodeIds = topologicalSort(flow.nodes, flow.edges);

  if (!sortedNodeIds) {
    const errMsg = 'Flow graph contains cycles and cannot be executed';
    await persistRun({
      runId, flowId: flow.flowId, status: 'failed',
      startedAt, finishedAt: new Date().toISOString(),
      triggeredBy, nodeResults: [], errorMessage: errMsg,
      totalRowsProcessed: 0, durationMs: 0,
    });
    return {
      runId, flowId: flow.flowId, status: 'failed',
      startedAt, finishedAt: new Date().toISOString(),
      triggeredBy, nodeResults: [], errorMessage: errMsg,
      totalRowsProcessed: 0, durationMs: 0,
    };
  }

  const nodeById = new Map(flow.nodes.map((n) => [n.id, n]));
  const nodeStagingTable = new Map<string, string>();
  const nodeResults: FlowNodeResult[] = [];
  const failedUpstream = new Set<string>();
  let totalRows = 0;
  const runStart = Date.now();

  await persistRun({
    runId, flowId: flow.flowId, status: 'running',
    startedAt, finishedAt: null, triggeredBy,
    nodeResults: [], errorMessage: null,
    totalRowsProcessed: 0, durationMs: 0,
  });

  for (const nodeId of sortedNodeIds) {
    const node = nodeById.get(nodeId)!;
    const upstreamIds = inputsFor(nodeId, flow.edges);
    const anyUpstreamFailed = upstreamIds.some((u) => failedUpstream.has(u));

    if (anyUpstreamFailed) {
      nodeResults.push({
        nodeId, status: 'skipped', stagingTable: null,
        rowCount: 0, durationMs: 0,
        errorMessage: 'Upstream node failed',
      });
      failedUpstream.add(nodeId);
      continue;
    }

    const validation = validateNode(node, []);
    if (!validation.valid) {
      nodeResults.push({
        nodeId, status: 'failed', stagingTable: null,
        rowCount: 0, durationMs: 0,
        errorMessage: `Validation failed: ${validation.errors.join('; ')}`,
      });
      failedUpstream.add(nodeId);
      continue;
    }

    const stagingTable = stagingTableName(flow.flowId, nodeId);
    const inputTables = upstreamIds.map((u) => nodeStagingTable.get(u)!).filter(Boolean);
    const nodeStart = Date.now();

    try {
      const innerSQL = buildNodeSQL(node, inputTables);
      const ctas = `CREATE TABLE ${stagingTable} AS ${innerSQL}`;

      await withConnection(async (conn) => {
        try { await conn.execute(`DROP TABLE ${stagingTable} CASCADE CONSTRAINTS PURGE`); } catch {}
        await conn.execute(ctas);
        await conn.commit();
      });

      const rowCount = await withConnection(async (conn) => {
        const r = await conn.execute<{ CNT: number }>(
          `SELECT COUNT(*) AS CNT FROM ${stagingTable}`,
          {}, { outFormat: 4002 },
        );
        return r.rows?.[0]?.CNT ?? 0;
      });

      nodeStagingTable.set(nodeId, stagingTable);
      totalRows += rowCount;
      nodeResults.push({
        nodeId, status: 'success', stagingTable,
        rowCount, durationMs: Date.now() - nodeStart,
        errorMessage: null,
      });
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : String(err);
      nodeResults.push({
        nodeId, status: 'failed', stagingTable: null,
        rowCount: 0, durationMs: Date.now() - nodeStart,
        errorMessage,
      });
      failedUpstream.add(nodeId);
    }
  }

  const finalStatus: FlowRunStatus =
    nodeResults.every((r) => r.status === 'success') ? 'success' :
    nodeResults.some((r) => r.status === 'success') && nodeResults.some((r) => r.status === 'failed') ? 'failed' :
    'failed';

  const finishedAt = new Date().toISOString();
  const durationMs = Date.now() - runStart;
  const failedNode = nodeResults.find((r) => r.status === 'failed');

  const run: FlowRun = {
    runId, flowId: flow.flowId, status: finalStatus,
    startedAt, finishedAt, triggeredBy, nodeResults,
    errorMessage: failedNode?.errorMessage ?? null,
    totalRowsProcessed: totalRows, durationMs,
  };

  await persistRun(run);
  return run;
}

async function persistRun(run: FlowRun & { finishedAt: string | null }): Promise<void> {
  await withConnection(async (conn) => {
    await conn.execute(
      `MERGE INTO NB_DATA_FLOW_RUNS r
       USING (SELECT :runId AS RUN_ID FROM dual) s ON (r.RUN_ID = s.RUN_ID)
       WHEN MATCHED THEN UPDATE SET
         STATUS = :status, FINISHED_AT = :finishedAt,
         NODE_RESULTS_JSON = :nodeResults,
         ERROR_MESSAGE = :errMsg, TOTAL_ROWS = :totalRows, DURATION_MS = :durMs
       WHEN NOT MATCHED THEN INSERT
         (RUN_ID, FLOW_ID, STATUS, STARTED_AT, FINISHED_AT, TRIGGERED_BY,
          NODE_RESULTS_JSON, ERROR_MESSAGE, TOTAL_ROWS, DURATION_MS)
         VALUES (:runId, :flowId, :status, :startedAt, :finishedAt, :triggeredBy,
          :nodeResults, :errMsg, :totalRows, :durMs)`,
      {
        runId: run.runId, flowId: run.flowId, status: run.status,
        startedAt: run.startedAt, finishedAt: run.finishedAt,
        triggeredBy: run.triggeredBy,
        nodeResults: JSON.stringify(run.nodeResults),
        errMsg: run.errorMessage, totalRows: run.totalRowsProcessed,
        durMs: run.durationMs,
      },
    );
    await conn.commit();
  });
}

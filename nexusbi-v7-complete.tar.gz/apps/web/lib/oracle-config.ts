import { withConnection, clobToString } from '@/lib/oracle-pool';
import { cacheGet, cacheSet, cacheDel } from '@/lib/cache';

const CONFIG_CACHE_TTL = 60;
const CONFIG_CACHE_PREFIX = 'config:';

export interface PlatformConfig {
  key: string;
  value: string;
  configType: string;
  description: string | null;
  isSecret: boolean;
}

export async function getConfigValue(key: string): Promise<string | null> {
  const cacheKey = `${CONFIG_CACHE_PREFIX}${key}`;
  const cached = await cacheGet(cacheKey);
  if (cached !== null) {
    return cached === '__NULL__' ? null : cached;
  }

  const value = await withConnection(async (conn) => {
    const result = await conn.execute<{ CONFIG_VALUE: string }>(
      `SELECT CONFIG_VALUE FROM NB_PLATFORM_CONFIG WHERE CONFIG_KEY = :key`,
      { key },
      { outFormat: 4002 },
    );
    if (!result.rows || result.rows.length === 0) return null;
    return await clobToString(result.rows[0].CONFIG_VALUE);
  });

  if (value !== null) {
    await cacheSet(cacheKey, value, CONFIG_CACHE_TTL);
  } else {
    await cacheSet(cacheKey, '__NULL__', CONFIG_CACHE_TTL);
  }

  return value;
}

export async function getConfigValueTyped<T>(key: string): Promise<T | null> {
  const value = await getConfigValue(key);
  if (value === null) return null;
  try {
    return JSON.parse(value) as T;
  } catch {
    return value as unknown as T;
  }
}

export async function setConfigValue(
  key: string,
  value: string,
  modifiedBy: string,
  options?: { configType?: string; description?: string; isSecret?: boolean },
): Promise<void> {
  await withConnection(async (conn) => {
    const existing = await conn.execute(
      `SELECT CONFIG_KEY FROM NB_PLATFORM_CONFIG WHERE CONFIG_KEY = :key`,
      { key },
    );

    if (existing.rows && existing.rows.length > 0) {
      await conn.execute(
        `UPDATE NB_PLATFORM_CONFIG
         SET CONFIG_VALUE = :value,
             CONFIG_TYPE = NVL(:configType, CONFIG_TYPE),
             DESCRIPTION = NVL(:description, DESCRIPTION),
             IS_SECRET = NVL(:isSecret, IS_SECRET),
             UPDATED_BY = :modifiedBy,
             UPDATED_AT = SYSTIMESTAMP
         WHERE CONFIG_KEY = :key`,
        {
          key, value,
          configType: options?.configType ?? null,
          description: options?.description ?? null,
          isSecret: options?.isSecret !== undefined ? (options.isSecret ? 1 : 0) : null,
          modifiedBy,
        },
      );
    } else {
      await conn.execute(
        `INSERT INTO NB_PLATFORM_CONFIG
           (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET, UPDATED_BY, UPDATED_AT)
         VALUES
           (:key, :value, :configType, :description, :isSecret, :modifiedBy, SYSTIMESTAMP)`,
        {
          key, value,
          configType: options?.configType ?? 'STRING',
          description: options?.description ?? null,
          isSecret: options?.isSecret ? 1 : 0,
          modifiedBy,
        },
      );
    }

    await conn.commit();
  });

  await cacheDel(`${CONFIG_CACHE_PREFIX}${key}`);
}

export async function getAllConfigs(includeSecrets: boolean = false): Promise<PlatformConfig[]> {
  return withConnection(async (conn) => {
    const secretFilter = includeSecrets ? '' : `WHERE IS_SECRET = 0`;
    const result = await conn.execute<{
      CONFIG_KEY: string; CONFIG_VALUE: string; CONFIG_TYPE: string;
      DESCRIPTION: string | null; IS_SECRET: number;
    }>(
      `SELECT CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET
       FROM NB_PLATFORM_CONFIG ${secretFilter} ORDER BY CONFIG_KEY`,
      {},
      { outFormat: 4002 },
    );

    if (!result.rows) return [];

    const configs: PlatformConfig[] = [];
    for (const row of result.rows) {
      configs.push({
        key: row.CONFIG_KEY,
        value: row.IS_SECRET === 1 ? '********' : await clobToString(row.CONFIG_VALUE),
        configType: row.CONFIG_TYPE,
        description: row.DESCRIPTION,
        isSecret: row.IS_SECRET === 1,
      });
    }
    return configs;
  });
}

export async function deleteConfig(key: string): Promise<boolean> {
  const deleted = await withConnection(async (conn) => {
    const result = await conn.execute(
      `DELETE FROM NB_PLATFORM_CONFIG WHERE CONFIG_KEY = :key`,
      { key },
    );
    await conn.commit();
    return (result.rowsAffected ?? 0) > 0;
  });

  await cacheDel(`${CONFIG_CACHE_PREFIX}${key}`);
  return deleted;
}

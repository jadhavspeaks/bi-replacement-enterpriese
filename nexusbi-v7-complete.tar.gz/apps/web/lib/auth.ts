// MUST be the very first import — ensures NEXTAUTH_SECRET is set before NextAuth reads it.
import '@/lib/boot-secret';

import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import bcrypt from 'bcryptjs';
import { getOrInitPool, clobToString } from '@/lib/oracle-pool';
import type { SessionUser } from '@nexusbi/shared-types';

export const {
  handlers,
  auth,
  signIn,
  signOut,
} = NextAuth({
  providers: [
    Credentials({
      name: 'credentials',
      credentials: {
        username: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          return null;
        }

        const username = credentials.username as string;
        const password = credentials.password as string;

        const pool = await getOrInitPool();
        let conn;

        try {
          conn = await pool.getConnection();

          const result = await conn.execute<{
            USER_ID: string;
            EMAIL: string;
            USERNAME: string;
            PASSWORD_HASH: string;
            DISPLAY_NAME: string | null;
            TENANT_ID: string;
            IS_ACTIVE: number;
          }>(
            `SELECT USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, TENANT_ID, IS_ACTIVE
             FROM NB_USERS
             WHERE USERNAME = :username`,
            { username },
            { outFormat: 4002 /* oracledb.OUT_FORMAT_OBJECT */ },
          );

          const rows = result.rows;
          if (!rows || rows.length === 0) {
            return null;
          }

          const user = rows[0];

          if (user.IS_ACTIVE !== 1) {
            return null;
          }

          const passwordHash = typeof user.PASSWORD_HASH === 'string'
            ? user.PASSWORD_HASH
            : await clobToString(user.PASSWORD_HASH);

          const isValid = await bcrypt.compare(password, passwordHash);
          if (!isValid) {
            return null;
          }

          // Load roles from NB_USER_ROLES.
          // Note: the seed schema for NB_USER_ROLES has columns
          // (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_AT, ASSIGNED_BY) and no EXPIRES_AT.
          // An earlier revision gated roles with an EXPIRES_AT check that caused the
          // whole authorize() to throw on SQLite ("no such column: UR.EXPIRES_AT"),
          // which NextAuth surfaces as CredentialsSignin.
          const rolesResult = await conn.execute<{
            ROLE_NAME: string;
          }>(
            `SELECT R.ROLE_NAME
             FROM NB_USER_ROLES UR
             JOIN NB_ROLES R ON R.ROLE_ID = UR.ROLE_ID
             WHERE UR.USER_ID = :userId`,
            { userId: user.USER_ID },
            { outFormat: 4002 },
          );

          const roles = (rolesResult.rows || []).map((r) => r.ROLE_NAME);

          // Load permissions granted via those roles.
          // The seed schema uses column names PERM_ID / PERM_CODE (not PERMISSION_ID /
          // PERMISSION_CODE). An earlier revision used the longer names and caused the
          // whole authorize() to throw -> return null -> CredentialsSignin.
          let permissions: string[] = [];
          if (roles.length > 0) {
            const permsResult = await conn.execute<{ PERM_CODE: string }>(
              `SELECT DISTINCT P.PERM_CODE
                 FROM NB_ROLE_PERMISSIONS RP
                 JOIN NB_ROLES       R ON R.ROLE_ID = RP.ROLE_ID
                 JOIN NB_PERMISSIONS P ON P.PERM_ID = RP.PERM_ID
                WHERE R.ROLE_NAME IN (${roles.map((_, i) => `:r${i}`).join(', ')})`,
              Object.fromEntries(roles.map((r, i) => [`r${i}`, r])),
              { outFormat: 4002 },
            );
            permissions = (permsResult.rows || []).map((p) => p.PERM_CODE);
          }

          // Update last login
          await conn.execute(
            `UPDATE NB_USERS SET LAST_LOGIN_AT = SYSTIMESTAMP WHERE USER_ID = :userId`,
            { userId: user.USER_ID },
          );
          await conn.commit();

          return {
            id: user.USER_ID,
            userId: user.USER_ID,
            email: user.EMAIL,
            username: user.USERNAME,
            displayName: user.DISPLAY_NAME || user.USERNAME,
            tenantId: user.TENANT_ID,
            roles,
            permissions,
          };
        } catch (error) {
          console.error('Auth error:', error);
          return null;
        } finally {
          if (conn) {
            try {
              await conn.close();
            } catch {
              // ignore close errors
            }
          }
        }
      },
    }),
  ],
  session: {
    strategy: 'jwt',
    maxAge: 8 * 60 * 60, // 8 hours
  },
  pages: {
    signIn: '/login',
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const u = user as SessionUser;
        token.id = u.id;
        token.userId = u.userId || u.id;
        token.email = u.email;
        token.username = u.username;
        token.displayName = u.displayName;
        token.tenantId = u.tenantId;
        token.roles = u.roles;
        token.permissions = u.permissions || [];
      }
      return token;
    },
    async session({ session, token }) {
      session.user = {
        id: token.id as string,
        userId: (token.userId as string) || (token.id as string),
        email: token.email as string,
        username: token.username as string,
        displayName: token.displayName as string,
        tenantId: token.tenantId as string,
        roles: token.roles as string[],
        permissions: (token.permissions as string[]) || [],
      };
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
  trustHost: true,
});

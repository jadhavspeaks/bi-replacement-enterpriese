import type { LODExpression, LODType, LODAggregation, ParsedLOD } from '@nexusbi/shared-types';

/**
 * Parses Tableau-style LOD expressions.
 * Grammar:
 *   LOD := '{' TYPE DIMS ':' AGG '(' FIELD ')' FILTER? '}'
 *   TYPE := 'FIXED' | 'INCLUDE' | 'EXCLUDE'
 *   DIMS := '[' NAME ']' (',' '[' NAME ']')*
 *   AGG  := 'SUM' | 'AVG' | 'COUNT' | 'COUNTD' | 'MIN' | 'MAX' | 'MEDIAN'
 *   FIELD := '[' NAME ']' | NAME
 *   FILTER := 'WHERE' EXPR
 *
 * Examples:
 *   {FIXED [region]: SUM([sales])}
 *   {FIXED [region], [category]: AVG([profit])}
 *   {INCLUDE [product]: SUM([quantity])}
 *   {EXCLUDE [order_date]: COUNTD([customer_id])}
 */

const AGGREGATIONS: LODAggregation[] = ['SUM', 'AVG', 'COUNT', 'COUNTD', 'MIN', 'MAX', 'MEDIAN'];
const LOD_TYPES: LODType[] = ['fixed', 'include', 'exclude'];

export function parseLOD(raw: string, alias: string): ParsedLOD {
  const errors: string[] = [];
  const trimmed = raw.trim();

  if (!trimmed.startsWith('{') || !trimmed.endsWith('}')) {
    return {
      expr: {} as LODExpression,
      raw,
      errors: ['LOD expression must be wrapped in { }'],
    };
  }

  const inner = trimmed.slice(1, -1).trim();

  // Split on the first colon (must handle brackets)
  const colonIdx = findTopLevelColon(inner);
  if (colonIdx === -1) {
    return { expr: {} as LODExpression, raw, errors: ['Missing ":" separator between dimensions and aggregation'] };
  }

  const dimsSection = inner.slice(0, colonIdx).trim();
  const aggSection = inner.slice(colonIdx + 1).trim();

  // Parse type and dimensions
  const typeMatch = dimsSection.match(/^(FIXED|INCLUDE|EXCLUDE)\b/i);
  if (!typeMatch) {
    return { expr: {} as LODExpression, raw, errors: ['LOD must start with FIXED, INCLUDE, or EXCLUDE'] };
  }
  const type = typeMatch[1].toLowerCase() as LODType;
  if (!LOD_TYPES.includes(type)) {
    errors.push(`Unknown LOD type: ${typeMatch[1]}`);
  }

  const afterType = dimsSection.slice(typeMatch[0].length).trim();
  const dimensions = parseDimensions(afterType);
  if (dimensions.length === 0 && type !== 'exclude') {
    errors.push('LOD requires at least one dimension');
  }

  // Parse aggregation: AGG(field) [WHERE filter]
  const filterMatch = aggSection.match(/\bWHERE\s+(.+)$/i);
  const aggPart = filterMatch ? aggSection.slice(0, aggSection.length - filterMatch[0].length).trim() : aggSection;
  const filter = filterMatch ? filterMatch[1].trim() : undefined;

  const aggMatch = aggPart.match(/^(\w+)\s*\(\s*(.+?)\s*\)\s*$/);
  if (!aggMatch) {
    errors.push('Aggregation must be of form FN(field)');
    return { expr: { type, dimensions, aggregation: 'SUM', measureField: '', alias, filter }, raw, errors };
  }

  const aggName = aggMatch[1].toUpperCase() as LODAggregation;
  if (!AGGREGATIONS.includes(aggName)) {
    errors.push(`Unknown aggregation: ${aggName}. Valid: ${AGGREGATIONS.join(', ')}`);
  }

  const fieldRaw = aggMatch[2].trim();
  const measureField = fieldRaw.startsWith('[') && fieldRaw.endsWith(']')
    ? fieldRaw.slice(1, -1)
    : fieldRaw;

  if (!measureField) {
    errors.push('Aggregation field cannot be empty');
  }

  return {
    expr: {
      type,
      dimensions,
      aggregation: aggName,
      measureField,
      alias,
      filter,
    },
    raw,
    errors,
  };
}

function findTopLevelColon(s: string): number {
  let depth = 0;
  for (let i = 0; i < s.length; i++) {
    if (s[i] === '[' || s[i] === '(') depth++;
    else if (s[i] === ']' || s[i] === ')') depth--;
    else if (s[i] === ':' && depth === 0) return i;
  }
  return -1;
}

function parseDimensions(s: string): string[] {
  if (!s.trim()) return [];
  const dims: string[] = [];
  const re = /\[([^\]]+)\]|([a-zA-Z_][a-zA-Z0-9_.]*)/g;
  let m: RegExpExecArray | null;
  while ((m = re.exec(s)) !== null) {
    dims.push((m[1] ?? m[2]).trim());
  }
  return dims;
}

export function formatLOD(expr: LODExpression): string {
  const typeUpper = expr.type.toUpperCase();
  const dims = expr.dimensions.map((d) => `[${d}]`).join(', ');
  const agg = `${expr.aggregation}([${expr.measureField}])`;
  const filter = expr.filter ? ` WHERE ${expr.filter}` : '';
  return `{${typeUpper} ${dims}: ${agg}${filter}}`;
}

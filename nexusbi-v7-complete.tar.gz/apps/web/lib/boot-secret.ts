/**
 * Ensures NEXTAUTH_SECRET is available before NextAuth initializes.
 *
 * Priority:
 *   1. If NEXTAUTH_SECRET (or AUTH_SECRET) env var is set → use it.
 *   2. Otherwise, read/create ./data/.auth-secret (gitignored, 0600 perms).
 *
 * This eliminates the previous `npm run generate:secrets` step. Users who
 * deploy to production and want a stable secret across replicas can still set
 * the env var explicitly; everyone else gets a transparent auto-generated
 * secret persisted alongside the SQLite database.
 */

import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';

let ensured = false;

export function ensureAuthSecret(): void {
  if (ensured) return;
  ensured = true;

  if (process.env.NEXTAUTH_SECRET || process.env.AUTH_SECRET) {
    // Mirror whichever is set to both names so all code paths find it.
    const value = (process.env.NEXTAUTH_SECRET || process.env.AUTH_SECRET)!;
    process.env.NEXTAUTH_SECRET = value;
    process.env.AUTH_SECRET = value;
    return;
  }

  const dataDir = path.resolve(process.cwd(), 'data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  const secretFile = path.join(dataDir, '.auth-secret');

  let secret: string;
  if (fs.existsSync(secretFile)) {
    secret = fs.readFileSync(secretFile, 'utf-8').trim();
  } else {
    secret = crypto.randomBytes(48).toString('base64');
    fs.writeFileSync(secretFile, secret, { mode: 0o600 });
    console.log(`Generated NEXTAUTH_SECRET → ${secretFile} (0600). Back this file up or set NEXTAUTH_SECRET in your env to rotate it.`);
  }

  process.env.NEXTAUTH_SECRET = secret;
  process.env.AUTH_SECRET = secret;
}

// Run on module import so callers don't have to remember.
ensureAuthSecret();

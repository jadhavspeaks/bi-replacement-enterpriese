import { SignJWT } from 'jose';
import type {
  WebhookEndpoint,
  WebhookPayload,
  WebhookDeliveryLog,
  WebhookDeliveryStatus,
} from '@nexusbi/shared-types';
import { withConnection, clobToString, parseJsonClob, generateId } from '@/lib/oracle-pool';

const MAX_RETRIES = 3;
const RETRY_BASE_MS = 5000;
const WEBHOOK_TIMEOUT_MS = 15000;

async function signPayload(payload: WebhookPayload, secret: string): Promise<string> {
  const secretBytes = new TextEncoder().encode(secret);
  return new SignJWT(payload as unknown as Record<string, unknown>)
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setExpirationTime('5m')
    .sign(secretBytes);
}

export async function deliverWebhook(
  endpoint: WebhookEndpoint,
  event: string,
  data: Record<string, unknown>,
  tenantId: string,
): Promise<WebhookDeliveryLog> {
  const payload: WebhookPayload = {
    event,
    dashId: (data.dashId as string) ?? undefined,
    triggeredAt: new Date().toISOString(),
    data,
    tenantId,
  };

  const deliveryId = generateId();
  let httpStatus: number | null = null;
  let responseBody: string | null = null;
  let status: WebhookDeliveryStatus = 'PENDING';
  let attemptCount = 0;

  // Create initial delivery log entry
  await withConnection(async (conn) => {
    await conn.execute(
      `INSERT INTO NB_WEBHOOK_DELIVERY_LOG
         (DELIVERY_ID, ENDPOINT_ID, TRIGGER_EVENT, PAYLOAD,
          HTTP_STATUS, RESPONSE_BODY, ATTEMPT_COUNT,
          DELIVERED_AT, NEXT_RETRY_AT, STATUS)
       VALUES
         (:deliveryId, :endpointId, :triggerEvent, :payload,
          NULL, NULL, 0,
          NULL, NULL, 'PENDING')`,
      {
        deliveryId,
        endpointId: endpoint.endpointId,
        triggerEvent: event,
        payload: JSON.stringify(payload),
      },
    );
    await conn.commit();
  });

  // Attempt delivery with retries
  for (let attempt = 0; attempt <= MAX_RETRIES; attempt++) {
    attemptCount = attempt + 1;

    try {
      const signedToken = await signPayload(payload, endpoint.secretHash);

      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), WEBHOOK_TIMEOUT_MS);

      const response = await fetch(endpoint.url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-NexusBI-Signature': signedToken,
          'X-NexusBI-Event': event,
          'X-NexusBI-Delivery': deliveryId,
        },
        body: JSON.stringify(payload),
        signal: controller.signal,
      });

      clearTimeout(timeoutId);
      httpStatus = response.status;

      try {
        responseBody = await response.text();
        if (responseBody.length > 4000) {
          responseBody = responseBody.substring(0, 4000) + '...[truncated]';
        }
      } catch {
        responseBody = null;
      }

      if (response.ok) {
        status = 'SUCCESS';
        break;
      }

      // Non-retryable status codes
      if (httpStatus >= 400 && httpStatus < 500 && httpStatus !== 429) {
        status = 'FAILED';
        break;
      }

      // Retryable — continue loop
      if (attempt < MAX_RETRIES) {
        status = 'RETRYING';
        const delay = RETRY_BASE_MS * Math.pow(2, attempt);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        status = 'FAILED';
      }
    } catch (error) {
      const errMsg = error instanceof Error ? error.message : 'Unknown error';
      responseBody = errMsg;

      if (attempt < MAX_RETRIES) {
        status = 'RETRYING';
        const delay = RETRY_BASE_MS * Math.pow(2, attempt);
        await new Promise((resolve) => setTimeout(resolve, delay));
      } else {
        status = 'FAILED';
      }
    }
  }

  // Update delivery log
  const nextRetryAt = status === 'RETRYING'
    ? new Date(Date.now() + RETRY_BASE_MS * Math.pow(2, attemptCount)).toISOString()
    : null;

  await withConnection(async (conn) => {
    await conn.execute(
      `UPDATE NB_WEBHOOK_DELIVERY_LOG
       SET HTTP_STATUS = :httpStatus,
           RESPONSE_BODY = :responseBody,
           ATTEMPT_COUNT = :attemptCount,
           DELIVERED_AT = SYSTIMESTAMP,
           NEXT_RETRY_AT = :nextRetryAt,
           STATUS = :status
       WHERE DELIVERY_ID = :deliveryId`,
      {
        deliveryId,
        httpStatus,
        responseBody,
        attemptCount,
        nextRetryAt,
        status,
      },
    );
    await conn.commit();
  });

  return {
    deliveryId,
    endpointId: endpoint.endpointId,
    triggerEvent: event,
    payload,
    httpStatus,
    responseBody,
    attemptCount,
    deliveredAt: new Date().toISOString(),
    nextRetryAt,
    status,
  };
}

export async function getEndpointsByTrigger(
  triggerType: string,
  tenantId: string,
): Promise<WebhookEndpoint[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      ENDPOINT_ID: string;
      ENDPOINT_NAME: string;
      URL: string;
      SECRET_HASH: string;
      TRIGGER_TYPE: string;
      TRIGGER_CONFIG: string;
      IS_ACTIVE: number;
      TENANT_ID: string;
      CREATED_BY: string;
      CREATED_AT: string;
    }>(
      `SELECT ENDPOINT_ID, ENDPOINT_NAME, URL, SECRET_HASH,
              TRIGGER_TYPE, TRIGGER_CONFIG, IS_ACTIVE,
              TENANT_ID, CREATED_BY, CREATED_AT
       FROM NB_WEBHOOK_ENDPOINTS
       WHERE TRIGGER_TYPE = :triggerType
         AND TENANT_ID = :tenantId
         AND IS_ACTIVE = 1`,
      { triggerType, tenantId },
      { outFormat: 4002 },
    );

    const endpoints: WebhookEndpoint[] = [];
    for (const row of result.rows || []) {
      const triggerConfigStr = await clobToString(row.TRIGGER_CONFIG);
      endpoints.push({
        endpointId: row.ENDPOINT_ID,
        endpointName: row.ENDPOINT_NAME,
        url: row.URL,
        secretHash: row.SECRET_HASH,
        triggerType: row.TRIGGER_TYPE as WebhookEndpoint['triggerType'],
        triggerConfig: parseJsonClob(triggerConfigStr),
        isActive: row.IS_ACTIVE === 1,
        tenantId: row.TENANT_ID,
        createdBy: row.CREATED_BY,
        createdAt: String(row.CREATED_AT),
      });
    }

    return endpoints;
  });
}

export async function fireApprovalWebhooks(
  dashId: string,
  dashName: string,
  approvedBy: string,
  tenantId: string,
): Promise<void> {
  const endpoints = await getEndpointsByTrigger('approval', tenantId);
  for (const ep of endpoints) {
    try {
      await deliverWebhook(ep, 'dashboard.approved', {
        dashId,
        dashName,
        approvedBy,
      }, tenantId);
    } catch (error) {
      console.error(`Webhook delivery failed for endpoint ${ep.endpointId}:`, error);
    }
  }
}

export async function getDeliveryLog(
  endpointId: string,
  tenantId: string,
  limit: number = 50,
): Promise<WebhookDeliveryLog[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      DELIVERY_ID: string;
      ENDPOINT_ID: string;
      TRIGGER_EVENT: string;
      PAYLOAD: string;
      HTTP_STATUS: number | null;
      RESPONSE_BODY: string;
      ATTEMPT_COUNT: number;
      DELIVERED_AT: string | null;
      NEXT_RETRY_AT: string | null;
      STATUS: string;
    }>(
      `SELECT DL.DELIVERY_ID, DL.ENDPOINT_ID, DL.TRIGGER_EVENT,
              DL.PAYLOAD, DL.HTTP_STATUS, DL.RESPONSE_BODY,
              DL.ATTEMPT_COUNT, DL.DELIVERED_AT, DL.NEXT_RETRY_AT, DL.STATUS
       FROM NB_WEBHOOK_DELIVERY_LOG DL
       JOIN NB_WEBHOOK_ENDPOINTS E ON E.ENDPOINT_ID = DL.ENDPOINT_ID
       WHERE DL.ENDPOINT_ID = :endpointId
         AND E.TENANT_ID = :tenantId
       ORDER BY DL.DELIVERED_AT DESC NULLS LAST
       FETCH FIRST :limit ROWS ONLY`,
      { endpointId, tenantId, limit },
      { outFormat: 4002 },
    );

    const logs: WebhookDeliveryLog[] = [];
    for (const row of result.rows || []) {
      const payloadStr = await clobToString(row.PAYLOAD);
      const responseStr = await clobToString(row.RESPONSE_BODY);
      logs.push({
        deliveryId: row.DELIVERY_ID,
        endpointId: row.ENDPOINT_ID,
        triggerEvent: row.TRIGGER_EVENT,
        payload: parseJsonClob(payloadStr),
        httpStatus: row.HTTP_STATUS,
        responseBody: responseStr || null,
        attemptCount: row.ATTEMPT_COUNT,
        deliveredAt: row.DELIVERED_AT ? String(row.DELIVERED_AT) : null,
        nextRetryAt: row.NEXT_RETRY_AT ? String(row.NEXT_RETRY_AT) : null,
        status: row.STATUS as WebhookDeliveryStatus,
      });
    }

    return logs;
  });
}

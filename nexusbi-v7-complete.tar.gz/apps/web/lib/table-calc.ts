import type { TableCalc, TableCalcResult } from '@nexusbi/shared-types';

/**
 * Post-aggregation table calculations applied client-side to result rows.
 * No external deps - pure JS implementations of the Tableau calc suite.
 */

type Row = Record<string, unknown>;

function num(v: unknown): number {
  if (v === null || v === undefined) return 0;
  if (typeof v === 'number') return v;
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function partitionRows(rows: Row[], partitionBy: string[] | undefined): Row[][] {
  if (!partitionBy || partitionBy.length === 0) return [rows];
  const groups = new Map<string, Row[]>();
  for (const row of rows) {
    const key = partitionBy.map((p) => String(row[p] ?? '')).join('||');
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(row);
  }
  return Array.from(groups.values());
}

function sortPartition(rows: Row[], orderBy: string[] | undefined): Row[] {
  if (!orderBy || orderBy.length === 0) return rows;
  return [...rows].sort((a, b) => {
    for (const col of orderBy) {
      const av = a[col], bv = b[col];
      if (typeof av === 'number' && typeof bv === 'number') {
        if (av < bv) return -1;
        if (av > bv) return 1;
      } else {
        const as = String(av ?? ''), bs = String(bv ?? '');
        if (as < bs) return -1;
        if (as > bs) return 1;
      }
    }
    return 0;
  });
}

function applyRunningTotal(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    let acc = 0;
    for (const row of ordered) {
      acc += num(row[calc.targetMeasure]);
      row[calc.alias] = acc;
    }
  }
}

function applyPctOfTotal(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const total = part.reduce((s, r) => s + num(r[calc.targetMeasure]), 0);
    for (const row of part) {
      row[calc.alias] = total === 0 ? 0 : (num(row[calc.targetMeasure]) / total) * 100;
    }
  }
}

function applyDifference(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    for (let i = 0; i < ordered.length; i++) {
      if (i === 0) { ordered[i][calc.alias] = null; continue; }
      ordered[i][calc.alias] = num(ordered[i][calc.targetMeasure]) - num(ordered[i - 1][calc.targetMeasure]);
    }
  }
}

function applyPctDifference(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    for (let i = 0; i < ordered.length; i++) {
      if (i === 0) { ordered[i][calc.alias] = null; continue; }
      const prev = num(ordered[i - 1][calc.targetMeasure]);
      const curr = num(ordered[i][calc.targetMeasure]);
      ordered[i][calc.alias] = prev === 0 ? null : ((curr - prev) / prev) * 100;
    }
  }
}

function applyRank(rows: Row[], calc: TableCalc, dense: boolean): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const sorted = [...part].sort((a, b) => num(b[calc.targetMeasure]) - num(a[calc.targetMeasure]));
    let rank = 0, lastVal = Number.POSITIVE_INFINITY, gap = 1;
    for (const row of sorted) {
      const v = num(row[calc.targetMeasure]);
      if (v !== lastVal) { rank = dense ? rank + 1 : rank + gap; gap = 1; lastVal = v; } else { gap++; }
      row[calc.alias] = rank;
    }
  }
}

function applyMovingAvg(rows: Row[], calc: TableCalc): void {
  const window = calc.window ?? 3;
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    for (let i = 0; i < ordered.length; i++) {
      const start = Math.max(0, i - window + 1);
      let sum = 0, count = 0;
      for (let j = start; j <= i; j++) { sum += num(ordered[j][calc.targetMeasure]); count++; }
      ordered[i][calc.alias] = count === 0 ? 0 : sum / count;
    }
  }
}

function applyPercentile(rows: Row[], calc: TableCalc): void {
  const p = (calc.percentileValue ?? 50) / 100;
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const values = part.map((r) => num(r[calc.targetMeasure])).sort((a, b) => a - b);
    const idx = Math.max(0, Math.min(values.length - 1, Math.floor(p * values.length)));
    const pctileValue = values[idx];
    for (const row of part) row[calc.alias] = pctileValue;
  }
}

function applyZScore(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const values = part.map((r) => num(r[calc.targetMeasure]));
    const mean = values.reduce((a, b) => a + b, 0) / (values.length || 1);
    const variance = values.reduce((s, v) => s + (v - mean) ** 2, 0) / (values.length || 1);
    const std = Math.sqrt(variance);
    for (const row of part) {
      row[calc.alias] = std === 0 ? 0 : (num(row[calc.targetMeasure]) - mean) / std;
    }
  }
}

function applyNtile(rows: Row[], calc: TableCalc): void {
  const buckets = calc.ntileBuckets ?? 4;
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const sorted = [...part].sort((a, b) => num(b[calc.targetMeasure]) - num(a[calc.targetMeasure]));
    for (let i = 0; i < sorted.length; i++) {
      sorted[i][calc.alias] = Math.floor((i / sorted.length) * buckets) + 1;
    }
  }
}

function applyFirstDiff(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    if (ordered.length === 0) continue;
    const base = num(ordered[0][calc.targetMeasure]);
    for (const row of ordered) {
      row[calc.alias] = num(row[calc.targetMeasure]) - base;
    }
  }
}

function applyCompoundGrowth(rows: Row[], calc: TableCalc): void {
  const partitions = partitionRows(rows, calc.partitionBy);
  for (const part of partitions) {
    const ordered = sortPartition(part, calc.orderBy);
    if (ordered.length === 0) continue;
    const start = num(ordered[0][calc.targetMeasure]);
    if (start === 0) { for (const row of ordered) row[calc.alias] = null; continue; }
    for (let i = 0; i < ordered.length; i++) {
      const curr = num(ordered[i][calc.targetMeasure]);
      if (i === 0) { ordered[i][calc.alias] = 0; continue; }
      ordered[i][calc.alias] = (Math.pow(curr / start, 1 / i) - 1) * 100;
    }
  }
}

export function applyTableCalcs(rows: Row[], calcs: TableCalc[]): TableCalcResult {
  const working = rows.map((r) => ({ ...r }));
  const computed: string[] = [];

  for (const calc of calcs) {
    switch (calc.type) {
      case 'running_total':    applyRunningTotal(working, calc); break;
      case 'pct_of_total':     applyPctOfTotal(working, calc); break;
      case 'difference':       applyDifference(working, calc); break;
      case 'pct_difference':   applyPctDifference(working, calc); break;
      case 'rank':             applyRank(working, calc, false); break;
      case 'dense_rank':       applyRank(working, calc, true); break;
      case 'moving_avg':       applyMovingAvg(working, calc); break;
      case 'percentile':       applyPercentile(working, calc); break;
      case 'z_score':          applyZScore(working, calc); break;
      case 'ntile':            applyNtile(working, calc); break;
      case 'first_diff':       applyFirstDiff(working, calc); break;
      case 'compound_growth':  applyCompoundGrowth(working, calc); break;
    }
    computed.push(calc.alias);
  }

  return { rows: working, computedColumns: computed };
}

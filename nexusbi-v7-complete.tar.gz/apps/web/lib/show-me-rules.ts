import type { ShowMeContext, ShowMeRecommendation, FieldSchemaMeta } from '@nexusbi/shared-types';

interface ChartRule {
  chartType: string;
  label: string;
  requires: {
    minDimensions?: number;
    maxDimensions?: number;
    minMeasures?: number;
    maxMeasures?: number;
    requiresTemporal?: boolean;
    requiresGeographic?: boolean;
    lowCardinalityDim?: boolean;
  };
  score: (ctx: ShowMeContext) => number;
  reason: (ctx: ShowMeContext) => string;
}

function countFields(names: string[], schemas: FieldSchemaMeta[], fieldClass: FieldSchemaMeta['fieldClass']): number {
  return names.filter((n) => schemas.find((s) => s.name === n)?.fieldClass === fieldClass).length;
}

function hasTemporal(names: string[], schemas: FieldSchemaMeta[]): boolean {
  return names.some((n) => schemas.find((s) => s.name === n)?.dataType === 'date');
}

function hasGeo(names: string[], schemas: FieldSchemaMeta[]): boolean {
  return names.some((n) => schemas.find((s) => s.name === n)?.dataType === 'geo');
}

function totalDimensions(ctx: ShowMeContext): number {
  return [...ctx.shelves.columns, ...ctx.shelves.rows]
    .filter((n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'dimension').length;
}

function totalMeasures(ctx: ShowMeContext): number {
  return [...ctx.shelves.columns, ...ctx.shelves.rows]
    .filter((n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'measure').length;
}

const RULES: ChartRule[] = [
  {
    chartType: 'bar',
    label: 'Bar',
    requires: { minDimensions: 1, maxDimensions: 2, minMeasures: 1 },
    score: (ctx) => {
      const d = totalDimensions(ctx); const m = totalMeasures(ctx);
      if (d === 1 && m === 1) return 0.95;
      if (d === 2 && m === 1) return 0.85;
      return d >= 1 && m >= 1 ? 0.6 : 0;
    },
    reason: () => 'Ideal for comparing a measure across categories',
  },
  {
    chartType: 'stacked_bar',
    label: 'Stacked Bar',
    requires: { minDimensions: 2, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) >= 2 && totalMeasures(ctx) === 1 ? 0.8 : 0.3,
    reason: () => 'Shows composition within categories',
  },
  {
    chartType: 'grouped_bar',
    label: 'Grouped Bar',
    requires: { minDimensions: 2, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) === 2 && totalMeasures(ctx) >= 1 ? 0.8 : 0.3,
    reason: () => 'Compares measures across two dimensions',
  },
  {
    chartType: 'line',
    label: 'Line',
    requires: { minDimensions: 1, minMeasures: 1, requiresTemporal: true },
    score: (ctx) => {
      const temporal = hasTemporal(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas);
      if (temporal && totalMeasures(ctx) >= 1) return 0.95;
      if (totalMeasures(ctx) >= 1 && totalDimensions(ctx) === 1) return 0.5;
      return 0.1;
    },
    reason: (ctx) => hasTemporal(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas)
      ? 'Perfect for time-series data' : 'Line charts work best with temporal dimensions',
  },
  {
    chartType: 'area',
    label: 'Area',
    requires: { minDimensions: 1, minMeasures: 1, requiresTemporal: true },
    score: (ctx) => hasTemporal(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas) ? 0.85 : 0.2,
    reason: () => 'Emphasises volume over time',
  },
  {
    chartType: 'stacked_area',
    label: 'Stacked Area',
    requires: { minDimensions: 2, minMeasures: 1, requiresTemporal: true },
    score: (ctx) => {
      const temporal = hasTemporal(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas);
      return temporal && totalDimensions(ctx) >= 2 ? 0.8 : 0.2;
    },
    reason: () => 'Shows how parts contribute to a whole over time',
  },
  {
    chartType: 'pie',
    label: 'Pie',
    requires: { minDimensions: 1, maxDimensions: 1, minMeasures: 1, lowCardinalityDim: true },
    score: (ctx) => {
      if (totalDimensions(ctx) !== 1 || totalMeasures(ctx) !== 1) return 0.2;
      const dim = [...ctx.shelves.columns, ...ctx.shelves.rows].find(
        (n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'dimension');
      const schema = ctx.schemas.find((s) => s.name === dim);
      if (schema?.cardinality && schema.cardinality <= 8) return 0.9;
      if (schema?.cardinality && schema.cardinality <= 15) return 0.5;
      return 0.2;
    },
    reason: (ctx) => {
      const dim = [...ctx.shelves.columns, ...ctx.shelves.rows].find(
        (n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'dimension');
      const card = ctx.schemas.find((s) => s.name === dim)?.cardinality;
      if (card && card > 15) return `Too many categories (${card}) — pie charts work best with ≤8`;
      return 'Good for showing proportions';
    },
  },
  {
    chartType: 'donut',
    label: 'Donut',
    requires: { minDimensions: 1, maxDimensions: 1, minMeasures: 1, lowCardinalityDim: true },
    score: (ctx) => {
      if (totalDimensions(ctx) !== 1 || totalMeasures(ctx) !== 1) return 0.2;
      const dim = [...ctx.shelves.columns, ...ctx.shelves.rows].find(
        (n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'dimension');
      const schema = ctx.schemas.find((s) => s.name === dim);
      if (schema?.cardinality && schema.cardinality <= 8) return 0.85;
      return 0.3;
    },
    reason: () => 'Like pie but with central space for a KPI',
  },
  {
    chartType: 'scatter',
    label: 'Scatter',
    requires: { minMeasures: 2 },
    score: (ctx) => totalMeasures(ctx) === 2 ? 0.9 : totalMeasures(ctx) >= 2 ? 0.7 : 0.1,
    reason: () => 'Explores correlation between two measures',
  },
  {
    chartType: 'bubble',
    label: 'Bubble',
    requires: { minMeasures: 3 },
    score: (ctx) => totalMeasures(ctx) >= 3 ? 0.85 : 0.2,
    reason: () => 'Three measures: x, y, and size',
  },
  {
    chartType: 'heatmap',
    label: 'Heatmap',
    requires: { minDimensions: 2, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) === 2 && totalMeasures(ctx) === 1 ? 0.85 : 0.3,
    reason: () => 'Dense 2D matrix of values',
  },
  {
    chartType: 'treemap',
    label: 'Treemap',
    requires: { minDimensions: 1, maxDimensions: 2, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) >= 1 && totalMeasures(ctx) === 1 ? 0.7 : 0.2,
    reason: () => 'Hierarchical sized rectangles',
  },
  {
    chartType: 'histogram',
    label: 'Histogram',
    requires: { minMeasures: 1, maxDimensions: 0 },
    score: (ctx) => totalMeasures(ctx) === 1 && totalDimensions(ctx) === 0 ? 0.9 : 0.2,
    reason: () => 'Distribution of a single measure',
  },
  {
    chartType: 'box_plot',
    label: 'Box Plot',
    requires: { minDimensions: 1, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) >= 1 && totalMeasures(ctx) >= 1 ? 0.7 : 0.2,
    reason: () => 'Shows quartile distribution per category',
  },
  {
    chartType: 'funnel',
    label: 'Funnel',
    requires: { minDimensions: 1, maxDimensions: 1, minMeasures: 1 },
    score: (ctx) => {
      const dim = [...ctx.shelves.columns, ...ctx.shelves.rows].find(
        (n) => ctx.schemas.find((s) => s.name === n)?.fieldClass === 'dimension');
      const card = ctx.schemas.find((s) => s.name === dim)?.cardinality;
      return totalDimensions(ctx) === 1 && totalMeasures(ctx) === 1 && card && card <= 10 ? 0.75 : 0.25;
    },
    reason: () => 'Shows progression through stages',
  },
  {
    chartType: 'gauge',
    label: 'Gauge',
    requires: { maxDimensions: 0, minMeasures: 1, maxMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) === 0 && totalMeasures(ctx) === 1 ? 0.6 : 0.1,
    reason: () => 'Single value against a target',
  },
  {
    chartType: 'waterfall',
    label: 'Waterfall',
    requires: { minDimensions: 1, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) === 1 && totalMeasures(ctx) === 1 ? 0.65 : 0.2,
    reason: () => 'Cumulative additive changes',
  },
  {
    chartType: 'table',
    label: 'Table',
    requires: {},
    score: () => 0.5,
    reason: () => 'Universal fallback — always works',
  },
  {
    chartType: 'pivot',
    label: 'Pivot Table',
    requires: { minDimensions: 2, minMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) >= 2 ? 0.6 : 0.3,
    reason: () => 'Cross-tab with row/column dimensions',
  },
  {
    chartType: 'kpi',
    label: 'KPI Card',
    requires: { maxDimensions: 0, minMeasures: 1, maxMeasures: 1 },
    score: (ctx) => totalDimensions(ctx) === 0 && totalMeasures(ctx) === 1 ? 0.85 : 0.1,
    reason: () => 'Headline number with trend',
  },
  {
    chartType: 'map_choropleth',
    label: 'Map (Choropleth)',
    requires: { minDimensions: 1, minMeasures: 1, requiresGeographic: true },
    score: (ctx) => {
      const geo = hasGeo(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas);
      return geo && totalMeasures(ctx) >= 1 ? 0.95 : 0.1;
    },
    reason: (ctx) => hasGeo(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas)
      ? 'Geographic shading by measure' : 'Requires a geographic dimension',
  },
  {
    chartType: 'map_point',
    label: 'Map (Points)',
    requires: { requiresGeographic: true },
    score: (ctx) => hasGeo(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas) ? 0.85 : 0.1,
    reason: () => 'Latitude/longitude markers',
  },
  {
    chartType: 'map_heatmap',
    label: 'Map (Heatmap)',
    requires: { requiresGeographic: true },
    score: (ctx) => hasGeo(ctx.shelves.columns.concat(ctx.shelves.rows), ctx.schemas) ? 0.75 : 0.1,
    reason: () => 'Density over geography',
  },
  {
    chartType: 'text',
    label: 'Text Card',
    requires: {},
    score: () => 0.2,
    reason: () => 'Static text or markdown',
  },
];

export function recommend(context: ShowMeContext): ShowMeRecommendation[] {
  const results = RULES.map((rule) => {
    const score = rule.score(context);
    return {
      chartType: rule.chartType,
      score,
      compatible: score >= 0.4,
      reason: rule.reason(context),
    };
  });
  return results.sort((a, b) => b.score - a.score);
}

export function autoMapShelves(
  chartType: string,
  dimensions: string[],
  measures: string[],
): Record<string, string[]> {
  const shelves: Record<string, string[]> = { columns: [], rows: [] };
  switch (chartType) {
    case 'bar':
    case 'stacked_bar':
      shelves.columns = dimensions.slice(0, 1);
      shelves.rows = measures.slice(0, 1);
      break;
    case 'line':
    case 'area':
      shelves.columns = dimensions.slice(0, 1);
      shelves.rows = measures.slice(0, 2);
      break;
    case 'scatter':
    case 'bubble':
      shelves.columns = measures.slice(0, 1);
      shelves.rows = measures.slice(1, 2);
      break;
    case 'pie':
    case 'donut':
      shelves.columns = [];
      shelves.rows = measures.slice(0, 1);
      break;
    case 'kpi':
      shelves.rows = measures.slice(0, 1);
      break;
    case 'table':
    case 'pivot':
      shelves.columns = dimensions;
      shelves.rows = measures;
      break;
    default:
      shelves.columns = dimensions.slice(0, 1);
      shelves.rows = measures.slice(0, 1);
  }
  return shelves;
}

import type { PermissionCode } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';
import { cacheGet, cacheSet, cacheDel, invalidateCache, CACHE_KEYS, CACHE_TTL } from '@/lib/cache';

export interface ResolvedPermissions {
  userId: string;
  tenantId: string;
  permissions: Set<string>;
  roles: string[];
}

export async function resolvePermissions(
  userId: string,
  tenantId: string,
  roleNames: string[],
): Promise<ResolvedPermissions> {
  const cacheKey = CACHE_KEYS.permissions(userId, tenantId);

  const cached = await cacheGet(cacheKey);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as { permissions: string[]; roles: string[] };
      return { userId, tenantId, permissions: new Set(parsed.permissions), roles: parsed.roles };
    } catch {
      // invalid cache
    }
  }

  const permissions = await withConnection(async (conn) => {
    const result = await conn.execute<{ PERM_CODE: string }>(
      `SELECT DISTINCT P.PERM_CODE
       FROM NB_USER_ROLES UR
       JOIN NB_ROLE_PERMISSIONS RP ON RP.ROLE_ID = UR.ROLE_ID
       JOIN NB_PERMISSIONS P ON P.PERM_ID = RP.PERM_ID
       WHERE UR.USER_ID = :userId AND UR.TENANT_ID = :tenantId`,
      { userId, tenantId },
      { outFormat: 4002 },
    );
    return (result.rows || []).map((r) => r.PERM_CODE);
  });

  const resolved: ResolvedPermissions = { userId, tenantId, permissions: new Set(permissions), roles: roleNames };

  await cacheSet(cacheKey, JSON.stringify({ permissions, roles: roleNames }), CACHE_TTL.permissions);
  return resolved;
}

export function hasPermission(resolved: ResolvedPermissions, permission: PermissionCode): boolean {
  return resolved.permissions.has(permission);
}

export async function checkPermission(
  userId: string, tenantId: string, roleNames: string[], permission: PermissionCode,
): Promise<boolean> {
  const resolved = await resolvePermissions(userId, tenantId, roleNames);
  return hasPermission(resolved, permission);
}

export async function invalidatePermissionCache(userId: string, tenantId: string): Promise<void> {
  await cacheDel(CACHE_KEYS.permissions(userId, tenantId));
}

export async function invalidateAllPermissionCaches(tenantId: string): Promise<void> {
  await invalidateCache(`perms:*:${tenantId}`);
}

export async function getUserPermissionsList(
  userId: string, tenantId: string, roleNames: string[],
): Promise<PermissionCode[]> {
  const resolved = await resolvePermissions(userId, tenantId, roleNames);
  return Array.from(resolved.permissions) as PermissionCode[];
}

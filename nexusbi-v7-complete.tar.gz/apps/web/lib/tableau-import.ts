import AdmZip from 'adm-zip';
import { XMLParser } from 'fast-xml-parser';
import type {
  TableauParseResult,
  TableauWorksheetMap,
  TableauDataSourceRef,
  TableauFilterMap,
  TableauCalculatedField,
} from '@nexusbi/shared-types';
import type { WidgetConfig, WidgetPosition, ChartType } from '@nexusbi/shared-types';
import { downloadFile, BUCKETS } from '@/lib/storage';

const xmlParser = new XMLParser({
  ignoreAttributes: false,
  attributeNamePrefix: '@_',
  textNodeName: '#text',
  isArray: (name) => {
    const arrayTags = [
      'worksheet', 'datasource', 'column', 'filter', 'calculated-field',
      'zone', 'pane', 'rows', 'cols', 'mark',
    ];
    return arrayTags.includes(name);
  },
});

function extractTwbFromTwbx(buffer: Buffer): string {
  const zip = new AdmZip(buffer);
  const entries = zip.getEntries();

  const twbEntry = entries.find((e) => e.entryName.endsWith('.twb'));
  if (!twbEntry) {
    throw new Error('No .twb file found inside .twbx archive');
  }

  return twbEntry.getData().toString('utf-8');
}

function mapTableauChartType(vizType: string): ChartType {
  const mapping: Record<string, ChartType> = {
    'bar': 'bar',
    'stackedbar': 'bar',
    'line': 'line',
    'area': 'area',
    'pie': 'pie',
    'scatter': 'scatter',
    'treemap': 'treemap',
    'heatmap': 'heatmap',
    'map': 'scatter',
    'gantt': 'bar',
    'bubble': 'scatter',
    'histogram': 'bar',
    'box-and-whisker': 'boxplot',
    'waterfall': 'waterfall',
    'funnel': 'funnel',
    'dual-axis': 'line',
    'combo': 'bar',
    'text': 'bar',
  };

  return mapping[vizType.toLowerCase()] || 'bar';
}

function extractDataSources(workbook: Record<string, unknown>): TableauDataSourceRef[] {
  const sources: TableauDataSourceRef[] = [];

  try {
    const datasources = getNestedArray(workbook, 'workbook.datasources.datasource');
    for (const ds of datasources) {
      const name = ds['@_name'] || ds['@_caption'] || 'Unknown';
      const connection = ds.connection || {};
      const connectionType = connection['@_class'] || 'unknown';

      const tables: string[] = [];
      const relations = getNestedArray(ds, 'connection.relation');
      for (const rel of relations) {
        if (rel['@_table']) tables.push(rel['@_table']);
        if (rel['@_name']) tables.push(rel['@_name']);
      }

      sources.push({
        name: String(name),
        connectionType: String(connectionType),
        server: connection['@_server'] ? String(connection['@_server']) : undefined,
        database: connection['@_dbname'] ? String(connection['@_dbname']) : undefined,
        tables,
      });
    }
  } catch {
    // Graceful fallback
  }

  return sources;
}

function extractWorksheets(workbook: Record<string, unknown>): TableauWorksheetMap[] {
  const worksheets: TableauWorksheetMap[] = [];

  try {
    const wsNodes = getNestedArray(workbook, 'workbook.worksheets.worksheet');

    for (const ws of wsNodes) {
      const worksheetName = ws['@_name'] || 'Unnamed';
      const dimensions: string[] = [];
      const measures: string[] = [];
      const filters: TableauFilterMap[] = [];
      const calculatedFields: TableauCalculatedField[] = [];

      // Extract rows/cols (dimensions and measures)
      const table = ws.table || {};
      const rows = table.rows ? String(table.rows).split('][').map((s: string) => s.replace(/[\[\]]/g, '')) : [];
      const cols = table.cols ? String(table.cols).split('][').map((s: string) => s.replace(/[\[\]]/g, '')) : [];

      for (const field of [...rows, ...cols]) {
        if (!field) continue;
        if (field.startsWith('Measure')) {
          measures.push(field);
        } else {
          dimensions.push(field);
        }
      }

      // Detect chart type from marks
      const panes = getNestedArray(ws, 'table.pane');
      let vizType = 'bar';
      for (const pane of panes) {
        const marks = getNestedArray(pane, 'mark');
        for (const mark of marks) {
          if (mark['@_class']) {
            vizType = String(mark['@_class']);
            break;
          }
        }
      }

      // Extract filters
      const filterNodes = getNestedArray(ws, 'table.view.filter');
      for (const f of filterNodes) {
        filters.push({
          fieldName: f['@_column'] || f['@_field'] || 'unknown',
          filterType: f['@_class'] || 'categorical',
          values: f.groupfilter?.groupmember
            ? [].concat(f.groupfilter.groupmember).map((m: Record<string, string>) => m['@_member'] || '')
            : undefined,
        });
      }

      const chartType = mapTableauChartType(vizType);
      const widgetType = measures.length === 1 && dimensions.length === 0 ? 'kpi'
        : vizType === 'text' ? 'table'
        : 'chart';

      worksheets.push({
        worksheetName: String(worksheetName),
        widgetType,
        chartType: widgetType === 'chart' ? chartType : undefined,
        dimensions,
        measures,
        filters,
        calculatedFields,
      });
    }
  } catch {
    // Graceful fallback
  }

  return worksheets;
}

function extractDashboardLayout(workbook: Record<string, unknown>): TableauParseResult['dashboardLayout'] | undefined {
  try {
    const dashboards = getNestedArray(workbook, 'workbook.dashboards.dashboard');
    if (dashboards.length === 0) return undefined;

    const dash = dashboards[0];
    const size = dash.size || {};
    const width = parseInt(size['@_maxwidth'] || size['@_width'] || '1200', 10);
    const height = parseInt(size['@_maxheight'] || size['@_height'] || '800', 10);

    const zones: Array<{ worksheetName: string; x: number; y: number; w: number; h: number }> = [];
    const zoneNodes = getNestedArray(dash, 'zones.zone');

    for (const zone of zoneNodes) {
      if (zone['@_name']) {
        zones.push({
          worksheetName: String(zone['@_name']),
          x: parseInt(zone['@_x'] || '0', 10),
          y: parseInt(zone['@_y'] || '0', 10),
          w: parseInt(zone['@_w'] || zone['@_maxwidth'] || '400', 10),
          h: parseInt(zone['@_h'] || zone['@_maxheight'] || '300', 10),
        });
      }
    }

    return { width, height, zones };
  } catch {
    return undefined;
  }
}

function getNestedArray(obj: Record<string, unknown>, path: string): Array<Record<string, unknown>> {
  const parts = path.split('.');
  let current: unknown = obj;

  for (const part of parts) {
    if (current === null || current === undefined || typeof current !== 'object') return [];
    current = (current as Record<string, unknown>)[part];
  }

  if (Array.isArray(current)) return current as Array<Record<string, unknown>>;
  if (current && typeof current === 'object') return [current as Record<string, unknown>];
  return [];
}

export function parseTwb(twbXml: string): TableauParseResult {
  const parsed = xmlParser.parse(twbXml);

  return {
    worksheets: extractWorksheets(parsed),
    dataSources: extractDataSources(parsed),
    parameters: [],
    dashboardLayout: extractDashboardLayout(parsed),
  };
}

export async function importTwbx(minioPath: string): Promise<TableauParseResult> {
  const [bucket, ...objectParts] = minioPath.split('/');
  const objectName = objectParts.join('/');
  const buffer = await downloadFile(bucket, objectName);
  const twbXml = extractTwbFromTwbx(buffer);
  return parseTwb(twbXml);
}

export function convertWorksheetsToWidgets(
  worksheets: TableauWorksheetMap[],
  layout?: TableauParseResult['dashboardLayout'],
): WidgetConfig[] {
  const widgets: WidgetConfig[] = [];
  const gridCols = 12;

  for (let i = 0; i < worksheets.length; i++) {
    const ws = worksheets[i];

    let position: WidgetPosition;
    if (layout && layout.zones[i]) {
      const zone = layout.zones.find((z) => z.worksheetName === ws.worksheetName) || layout.zones[i];
      position = {
        x: Math.round((zone.x / layout.width) * gridCols),
        y: Math.round((zone.y / layout.height) * 20),
        w: Math.max(2, Math.round((zone.w / layout.width) * gridCols)),
        h: Math.max(2, Math.round((zone.h / layout.height) * 10)),
      };
    } else {
      const col = i % 2;
      const row = Math.floor(i / 2);
      position = { x: col * 6, y: row * 4, w: 6, h: 4 };
    }

    const widget: WidgetConfig = {
      widgetId: `imported_${i}`,
      widgetType: ws.widgetType as WidgetConfig['widgetType'],
      title: ws.worksheetName,
      position,
    };

    if (ws.widgetType === 'chart' && ws.chartType) {
      widget.chartConfig = {
        chartType: ws.chartType as ChartType,
        showLegend: true,
        showDataLabels: false,
      };
    }

    widgets.push(widget);
  }

  return widgets;
}

import type { LODExpression, CompiledLOD, LODContext } from '@nexusbi/shared-types';

/**
 * Compiles LOD expressions to Oracle SQL.
 *
 * FIXED:    computes at the specified dims regardless of viz dims.
 *           SQL: CTE with GROUP BY the fixed dims, LEFT JOIN to main query.
 *
 * INCLUDE:  adds the specified dims to the viz dims for this calc only.
 *           SQL: GROUP BY (viz_dims UNION include_dims), aggregate, then
 *           aggregate back up to viz_dim level.
 *
 * EXCLUDE:  removes the specified dims from the viz dims for this calc.
 *           SQL: GROUP BY (viz_dims - exclude_dims), aggregate, then
 *           join back on the remaining dims.
 */

function qualifyCol(cube: string, col: string): string {
  return `"${cube.toUpperCase()}"."${col.toUpperCase()}"`;
}

function sqlAgg(agg: string, col: string): string {
  const qualified = `"${col.toUpperCase()}"`;
  switch (agg) {
    case 'SUM':    return `SUM(${qualified})`;
    case 'AVG':    return `AVG(${qualified})`;
    case 'COUNT':  return `COUNT(${qualified})`;
    case 'COUNTD': return `COUNT(DISTINCT ${qualified})`;
    case 'MIN':    return `MIN(${qualified})`;
    case 'MAX':    return `MAX(${qualified})`;
    case 'MEDIAN': return `MEDIAN(${qualified})`;
    default:       return `SUM(${qualified})`;
  }
}

export function compileLOD(expr: LODExpression, context: LODContext): CompiledLOD {
  const { vizDimensions, cubeName } = context;
  const aliasCol = `"${expr.alias.toUpperCase()}"`;
  const cube = cubeName.toUpperCase();
  const sourceTable = cube;

  switch (expr.type) {
    case 'fixed': {
      const fixedDims = expr.dimensions.map((d) => d.toUpperCase());
      const groupCols = fixedDims.map((d) => `"${d}"`).join(', ');
      const filterClause = expr.filter ? ` WHERE ${expr.filter}` : '';

      const cteSql = `
        WITH ${expr.alias}_cte AS (
          SELECT ${groupCols}, ${sqlAgg(expr.aggregation, expr.measureField)} AS ${aliasCol}
          FROM ${sourceTable}${filterClause}
          GROUP BY ${groupCols}
        )
      `.trim();

      return {
        sql: cteSql,
        cubeQuery: null,
        joinKeys: fixedDims,
        requiresRawSQL: true,
      };
    }

    case 'include': {
      const includeDims = expr.dimensions.map((d) => d.toUpperCase());
      const vizDims = vizDimensions.map((d) => d.toUpperCase());
      const allDims = Array.from(new Set([...vizDims, ...includeDims]));
      const innerGroup = allDims.map((d) => `"${d}"`).join(', ');
      const outerGroup = vizDims.map((d) => `"${d}"`).join(', ');
      const filterClause = expr.filter ? ` WHERE ${expr.filter}` : '';

      const cteSql = `
        WITH ${expr.alias}_inner AS (
          SELECT ${innerGroup}, ${sqlAgg(expr.aggregation, expr.measureField)} AS inner_val
          FROM ${sourceTable}${filterClause}
          GROUP BY ${innerGroup}
        ),
        ${expr.alias}_cte AS (
          SELECT ${outerGroup}, ${rollupAgg(expr.aggregation)}(inner_val) AS ${aliasCol}
          FROM ${expr.alias}_inner
          GROUP BY ${outerGroup}
        )
      `.trim();

      return {
        sql: cteSql,
        cubeQuery: null,
        joinKeys: vizDims,
        requiresRawSQL: true,
      };
    }

    case 'exclude': {
      const excludeDims = new Set(expr.dimensions.map((d) => d.toUpperCase()));
      const vizDims = vizDimensions.map((d) => d.toUpperCase());
      const remainingDims = vizDims.filter((d) => !excludeDims.has(d));
      if (remainingDims.length === 0) {
        const filterClause = expr.filter ? ` WHERE ${expr.filter}` : '';
        return {
          sql: `WITH ${expr.alias}_cte AS (SELECT ${sqlAgg(expr.aggregation, expr.measureField)} AS ${aliasCol} FROM ${sourceTable}${filterClause})`,
          cubeQuery: null,
          joinKeys: [],
          requiresRawSQL: true,
        };
      }

      const groupCols = remainingDims.map((d) => `"${d}"`).join(', ');
      const filterClause = expr.filter ? ` WHERE ${expr.filter}` : '';

      const cteSql = `
        WITH ${expr.alias}_cte AS (
          SELECT ${groupCols}, ${sqlAgg(expr.aggregation, expr.measureField)} AS ${aliasCol}
          FROM ${sourceTable}${filterClause}
          GROUP BY ${groupCols}
        )
      `.trim();

      return {
        sql: cteSql,
        cubeQuery: null,
        joinKeys: remainingDims,
        requiresRawSQL: true,
      };
    }

    default:
      throw new Error(`Unsupported LOD type: ${(expr as LODExpression).type}`);
  }
}

function rollupAgg(originalAgg: string): string {
  if (originalAgg === 'COUNT' || originalAgg === 'COUNTD') return 'SUM';
  return originalAgg;
}

export function buildLODQuery(
  baseQuery: string,
  lods: Array<{ compiled: CompiledLOD; alias: string }>,
  vizDimensions: string[],
): string {
  if (lods.length === 0) return baseQuery;

  const ctes = lods.map((l) => l.compiled.sql.replace(/^\s*WITH\s+/i, '').trim());
  const cteCombined = `WITH ${ctes.join(',\n')}`;

  const lodJoins = lods
    .map((l) => {
      if (l.compiled.joinKeys.length === 0) {
        return `CROSS JOIN ${l.alias}_cte`;
      }
      const joinConds = l.compiled.joinKeys.map((k) => `base."${k}" = ${l.alias}_cte."${k}"`).join(' AND ');
      return `LEFT JOIN ${l.alias}_cte ON ${joinConds}`;
    })
    .join('\n');

  const lodSelects = lods.map((l) => `${l.alias}_cte."${l.alias.toUpperCase()}" AS "${l.alias}"`).join(', ');

  return `${cteCombined}\nSELECT base.*, ${lodSelects}\nFROM (${baseQuery}) base\n${lodJoins}`;
}

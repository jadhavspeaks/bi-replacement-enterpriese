import nodemailer from 'nodemailer';
import type { DeliveryType, DeliveryConfig, EmailDeliveryConfig, SlackDeliveryConfig, TeamsDeliveryConfig } from '@nexusbi/shared-types';
import { getConfigValue } from '@/lib/oracle-config';

interface SmtpConfig {
  host: string;
  port: number;
  secure: boolean;
  user: string;
  pass: string;
  from: string;
}

async function getSmtpConfig(): Promise<SmtpConfig | null> {
  const configStr = await getConfigValue('smtp.config');
  if (!configStr) return null;
  try {
    return JSON.parse(configStr) as SmtpConfig;
  } catch {
    return null;
  }
}

async function sendEmail(config: EmailDeliveryConfig, subject: string, html: string, attachments?: Array<{ filename: string; content: Buffer; contentType: string }>): Promise<void> {
  const smtp = await getSmtpConfig();
  if (!smtp) {
    throw new Error('SMTP not configured. Set smtp.config in NB_PLATFORM_CONFIG.');
  }

  const transporter = nodemailer.createTransport({
    host: smtp.host,
    port: smtp.port,
    secure: smtp.secure,
    auth: {
      user: smtp.user,
      pass: smtp.pass,
    },
  });

  await transporter.sendMail({
    from: smtp.from,
    to: config.recipients.join(', '),
    cc: config.cc?.join(', '),
    bcc: config.bcc?.join(', '),
    subject: config.subject || subject,
    html,
    attachments: attachments?.map((a) => ({
      filename: a.filename,
      content: a.content,
      contentType: a.contentType,
    })),
  });
}

async function sendSlack(config: SlackDeliveryConfig, text: string, imageUrl?: string): Promise<void> {
  const blocks: Array<Record<string, unknown>> = [
    {
      type: 'section',
      text: {
        type: 'mrkdwn',
        text,
      },
    },
  ];

  if (config.mentionUsers && config.mentionUsers.length > 0) {
    const mentions = config.mentionUsers.map((u) => `<@${u}>`).join(' ');
    blocks.unshift({
      type: 'section',
      text: { type: 'mrkdwn', text: mentions },
    });
  }

  if (imageUrl && config.includeScreenshot) {
    blocks.push({
      type: 'image',
      image_url: imageUrl,
      alt_text: 'Dashboard screenshot',
    });
  }

  const response = await fetch(config.webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      channel: config.channel,
      blocks,
    }),
  });

  if (!response.ok) {
    throw new Error(`Slack notification failed: ${response.status} ${response.statusText}`);
  }
}

async function sendTeams(config: TeamsDeliveryConfig, title: string, text: string, imageUrl?: string): Promise<void> {
  const sections: Array<Record<string, unknown>> = [
    {
      activityTitle: title,
      text,
    },
  ];

  if (imageUrl && config.includeScreenshot) {
    sections.push({
      images: [
        {
          image: imageUrl,
          title: 'Dashboard screenshot',
        },
      ],
    });
  }

  const card = {
    '@type': 'MessageCard',
    '@context': 'http://schema.org/extensions',
    themeColor: '2563eb',
    summary: title,
    sections,
  };

  if (config.mentionUsers && config.mentionUsers.length > 0) {
    card.summary = `${title} — cc: ${config.mentionUsers.join(', ')}`;
  }

  const response = await fetch(config.webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(card),
  });

  if (!response.ok) {
    throw new Error(`Teams notification failed: ${response.status} ${response.statusText}`);
  }
}

export interface NotificationPayload {
  deliveryType: DeliveryType;
  deliveryConfig: DeliveryConfig;
  subject: string;
  body: string;
  htmlBody?: string;
  imageUrl?: string;
  attachments?: Array<{ filename: string; content: Buffer; contentType: string }>;
}

export async function sendNotification(payload: NotificationPayload): Promise<void> {
  switch (payload.deliveryType) {
    case 'email': {
      const emailConfig = payload.deliveryConfig as EmailDeliveryConfig;
      await sendEmail(
        emailConfig,
        payload.subject,
        payload.htmlBody || `<p>${payload.body}</p>`,
        payload.attachments,
      );
      break;
    }
    case 'slack': {
      const slackConfig = payload.deliveryConfig as SlackDeliveryConfig;
      await sendSlack(slackConfig, payload.body, payload.imageUrl);
      break;
    }
    case 'teams': {
      const teamsConfig = payload.deliveryConfig as TeamsDeliveryConfig;
      await sendTeams(teamsConfig, payload.subject, payload.body, payload.imageUrl);
      break;
    }
    default:
      throw new Error(`Unsupported delivery type: ${payload.deliveryType}`);
  }
}

export function buildDashboardReportHtml(
  dashName: string,
  reportName: string,
  generatedAt: string,
  screenshotUrl?: string,
): string {
  return `
    <!DOCTYPE html>
    <html>
    <head><meta charset="utf-8"></head>
    <body style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
      <div style="background: #1e3a8a; color: white; padding: 20px; text-align: center;">
        <h1 style="margin: 0;">NexusBI</h1>
      </div>
      <div style="padding: 20px;">
        <h2>${reportName}</h2>
        <p>Dashboard: <strong>${dashName}</strong></p>
        <p>Generated: ${generatedAt}</p>
        ${screenshotUrl ? `<img src="${screenshotUrl}" alt="Dashboard" style="max-width: 100%; border: 1px solid #e5e7eb;" />` : ''}
        <hr style="border: none; border-top: 1px solid #e5e7eb; margin: 20px 0;" />
        <p style="color: #6b7280; font-size: 12px;">This is an automated report from NexusBI.</p>
      </div>
    </body>
    </html>
  `;
}

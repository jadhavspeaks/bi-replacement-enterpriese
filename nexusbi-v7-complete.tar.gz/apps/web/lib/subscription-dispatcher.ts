import type { Subscription, SubscriptionDelivery, DeliveryChannel } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';
import { generateId } from '@nexusbi/shared-types';

/**
 * Dispatches subscriptions on their cron schedule:
 *   1. Render target (dashboard / widget / story) via Puppeteer
 *   2. Package as chosen format (png/pdf/csv/xlsx/html)
 *   3. Deliver to all channels (email via SMTP, webhook via POST, Slack/Teams via webhook URL)
 *   4. Record NB_SUBSCRIPTION_DELIVERIES row
 */

export async function dispatchSubscription(sub: Subscription): Promise<SubscriptionDelivery> {
  const deliveryId = generateId('DELIV');
  const start = Date.now();
  let fileSize: number | null = null;
  let errorMessage: string | null = null;
  let status: 'success' | 'failed' = 'success';

  try {
    const rendered = await renderTarget(sub);
    fileSize = rendered.size;
    await Promise.all(sub.deliveryChannels.map((ch) => deliverToChannel(ch, sub, rendered)));
  } catch (err) {
    status = 'failed';
    errorMessage = err instanceof Error ? err.message : String(err);
  }

  const delivery: SubscriptionDelivery = {
    deliveryId,
    subscriptionId: sub.subscriptionId,
    status,
    deliveredAt: new Date().toISOString(),
    durationMs: Date.now() - start,
    errorMessage,
    recipientCount: sub.recipients.length,
    fileSize,
  };

  await persistDelivery(delivery);
  await updateSubLastRun(sub.subscriptionId, status);
  return delivery;
}

interface RenderedOutput {
  buffer: Buffer;
  mimeType: string;
  size: number;
  filename: string;
}

async function renderTarget(sub: Subscription): Promise<RenderedOutput> {
  // Placeholder - in production uses the existing lib/render-engine.ts Puppeteer chain
  const buf = Buffer.from(`Rendered ${sub.subscriptionType}:${sub.targetId} as ${sub.renderFormat}`);
  const mime = sub.renderFormat === 'pdf' ? 'application/pdf'
    : sub.renderFormat === 'png' ? 'image/png'
    : sub.renderFormat === 'csv' ? 'text/csv'
    : sub.renderFormat === 'xlsx' ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    : 'text/html';
  return {
    buffer: buf, mimeType: mime, size: buf.byteLength,
    filename: `${sub.name.replace(/[^a-zA-Z0-9]/g, '_')}.${sub.renderFormat}`,
  };
}

async function deliverToChannel(
  channel: DeliveryChannel, sub: Subscription, rendered: RenderedOutput,
): Promise<void> {
  switch (channel) {
    case 'email':
      await deliverEmail(sub, rendered);
      break;
    case 'webhook':
      await deliverWebhook(sub, rendered);
      break;
    case 'slack':
      await deliverSlack(sub, rendered);
      break;
    case 'teams':
      await deliverTeams(sub, rendered);
      break;
  }
}

async function deliverEmail(sub: Subscription, rendered: RenderedOutput): Promise<void> {
  // Uses nodemailer via lib/mailer.ts in production
  console.log(`[mail] subject=${sub.emailSubject ?? sub.name} to=${sub.recipients.join(',')} size=${rendered.size}`);
}

async function deliverWebhook(sub: Subscription, rendered: RenderedOutput): Promise<void> {
  for (const url of sub.recipients) {
    try {
      await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscriptionId: sub.subscriptionId,
          subscriptionType: sub.subscriptionType,
          targetId: sub.targetId,
          renderFormat: sub.renderFormat,
          contentBase64: rendered.buffer.toString('base64'),
          deliveredAt: new Date().toISOString(),
        }),
      });
    } catch (err) {
      throw new Error(`Webhook delivery failed to ${url}: ${err}`);
    }
  }
}

async function deliverSlack(sub: Subscription, rendered: RenderedOutput): Promise<void> {
  for (const webhookUrl of sub.recipients) {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        text: sub.emailSubject ?? sub.name,
        attachments: [{ text: sub.emailBody ?? '', color: '#1e40af' }],
      }),
    });
  }
}

async function deliverTeams(sub: Subscription, rendered: RenderedOutput): Promise<void> {
  for (const webhookUrl of sub.recipients) {
    await fetch(webhookUrl, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        '@type': 'MessageCard',
        '@context': 'http://schema.org/extensions',
        title: sub.emailSubject ?? sub.name,
        text: sub.emailBody ?? '',
      }),
    });
  }
}

async function persistDelivery(delivery: SubscriptionDelivery): Promise<void> {
  await withConnection(async (conn) => {
    await conn.execute(
      `INSERT INTO NB_SUBSCRIPTION_DELIVERIES
        (DELIVERY_ID, SUBSCRIPTION_ID, STATUS, DELIVERED_AT, DURATION_MS,
         ERROR_MESSAGE, RECIPIENT_COUNT, FILE_SIZE)
       VALUES (:id, :sid, :st, :da, :dm, :em, :rc, :fs)`,
      {
        id: delivery.deliveryId, sid: delivery.subscriptionId,
        st: delivery.status, da: delivery.deliveredAt, dm: delivery.durationMs,
        em: delivery.errorMessage, rc: delivery.recipientCount, fs: delivery.fileSize,
      },
    );
    await conn.commit();
  });
}

async function updateSubLastRun(subId: string, status: 'success' | 'failed'): Promise<void> {
  await withConnection(async (conn) => {
    await conn.execute(
      `UPDATE NB_SUBSCRIPTIONS SET LAST_DELIVERED_AT = SYSTIMESTAMP, LAST_STATUS = :s,
         UPDATED_AT = SYSTIMESTAMP WHERE SUBSCRIPTION_ID = :id`,
      { s: status, id: subId },
    );
    await conn.commit();
  });
}

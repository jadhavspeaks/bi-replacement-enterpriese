import type { ActiveSetState, SetAction, SetActionBehavior } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';

/** Applies a set action to an active set state. Pure function. */
export function applySetAction(
  current: ActiveSetState, action: SetAction, clickedValues: unknown[],
): ActiveSetState {
  const behavior = action.behavior;
  const memberSet = new Set(current.members.map((m) => JSON.stringify(m)));
  const clickedSet = new Set(clickedValues.map((v) => JSON.stringify(v)));

  let newMembers: unknown[];
  switch (behavior) {
    case 'add_to_set':
      newMembers = Array.from(new Set([...current.members, ...clickedValues].map((m) => JSON.stringify(m))))
        .map((s) => JSON.parse(s));
      break;
    case 'remove_from_set':
      newMembers = current.members.filter((m) => !clickedSet.has(JSON.stringify(m)));
      break;
    case 'replace_set':
      newMembers = clickedValues;
      break;
    default:
      newMembers = current.members;
  }

  return {
    ...current,
    members: newMembers,
    lastUpdated: new Date().toISOString(),
  };
}

export async function persistWorkbookSet(
  workbookId: string, setId: string, state: ActiveSetState,
): Promise<void> {
  if (state.scope !== 'workbook') return;
  await withConnection(async (conn) => {
    await conn.execute(
      `UPDATE NB_DATA_SETS SET STATIC_MEMBERS = :mem, UPDATED_AT = SYSTIMESTAMP
       WHERE SET_ID = :id AND WORKBOOK_ID = :wb`,
      { mem: JSON.stringify(state.members), id: setId, wb: workbookId },
    );
    await conn.commit();
  });
}

/**
 * Shared types for the DB adapter layer. Both SQLite and Oracle adapters
 * conform to these signatures so the rest of the codebase stays unchanged.
 *
 * The codebase was originally written against Oracle (oracledb) with SQL
 * using :bindName placeholders and Oracle-specific features. The SQLite
 * adapter translates this dialect on the fly at query time.
 */

export interface DbExecuteOptions {
  /** Preserved for Oracle-adapter compatibility; ignored by SQLite. */
  outFormat?: number;
}

export interface DbExecuteResult<T = Record<string, unknown>> {
  rows?: T[];
  rowsAffected?: number;
  lastRowId?: number | string;
}

export interface DbConnection {
  execute<T = Record<string, unknown>>(
    sql: string,
    binds?: Record<string, unknown> | unknown[],
    options?: DbExecuteOptions,
  ): Promise<DbExecuteResult<T>>;
  commit(): Promise<void>;
  rollback(): Promise<void>;
  close(): Promise<void>;
}

export interface DbPool {
  getConnection(): Promise<DbConnection>;
  close(): Promise<void>;
}

export type DbBackend = 'sqlite' | 'oracle';

/**
 * Translate Oracle SQL dialect to SQLite dialect.
 * Handles the subset of Oracle-isms actually used by this codebase.
 * This is a token-aware translator — it respects quoted string literals.
 */
export function translateOracleToSqlite(sql: string): string {
  // Strip trailing semicolons on single statements (SQLite doesn't mind, but
  // many of our call sites include them for legibility).
  let out = sql;

  // Preserve string literals during translation.
  const literals: string[] = [];
  out = out.replace(/'([^']|'')*'/g, (m) => {
    literals.push(m);
    return `__LIT_${literals.length - 1}__`;
  });

  // SYSTIMESTAMP / SYSDATE → CURRENT_TIMESTAMP
  out = out.replace(/\bSYSTIMESTAMP\b/gi, 'CURRENT_TIMESTAMP');
  out = out.replace(/\bSYSDATE\b/gi, 'CURRENT_TIMESTAMP');

  // FROM DUAL → (no-op; SQLite allows bare SELECT)
  out = out.replace(/\bFROM\s+DUAL\b/gi, '');

  // FETCH FIRST n ROWS ONLY  →  LIMIT n
  out = out.replace(/\bFETCH\s+FIRST\s+(\d+)\s+ROWS?\s+ONLY\b/gi, 'LIMIT $1');
  out = out.replace(/\bFETCH\s+NEXT\s+(\d+)\s+ROWS?\s+ONLY\b/gi, 'LIMIT $1');

  // ROWNUM <= n  →  translated to LIMIT n when used as outer filter
  // For simple cases only; complex uses should be rewritten manually.
  out = out.replace(/\bWHERE\s+ROWNUM\s*<=?\s*(\d+)\b/gi, 'LIMIT $1');
  out = out.replace(/\bAND\s+ROWNUM\s*<=?\s*(\d+)\b/gi, 'LIMIT $1');

  // NVL(a, b)  →  COALESCE(a, b)
  out = out.replace(/\bNVL\s*\(/gi, 'COALESCE(');

  // NUMBER(p,s) / NUMBER(p) / NUMBER  →  NUMERIC in column definitions
  out = out.replace(/\bNUMBER\s*\(\s*\d+\s*,\s*\d+\s*\)/gi, 'NUMERIC');
  out = out.replace(/\bNUMBER\s*\(\s*\d+\s*\)/gi, 'INTEGER');
  out = out.replace(/\bNUMBER\b(?!\()/gi, 'NUMERIC');

  // VARCHAR2(n) / VARCHAR2  →  TEXT
  out = out.replace(/\bVARCHAR2\s*\(\s*\d+(\s*(CHAR|BYTE))?\s*\)/gi, 'TEXT');
  out = out.replace(/\bVARCHAR2\b/gi, 'TEXT');

  // NVARCHAR2, NCHAR → TEXT
  out = out.replace(/\bNVARCHAR2\s*\(\s*\d+\s*\)/gi, 'TEXT');
  out = out.replace(/\bNCHAR\s*\(\s*\d+\s*\)/gi, 'TEXT');

  // CLOB, NCLOB, BLOB  →  TEXT / BLOB
  out = out.replace(/\bNCLOB\b/gi, 'TEXT');
  out = out.replace(/\bCLOB\b/gi, 'TEXT');
  // BLOB already valid in SQLite, keep as-is.

  // TIMESTAMP(n) / TIMESTAMP WITH (LOCAL) TIME ZONE → TEXT
  out = out.replace(/\bTIMESTAMP\s*\(\s*\d+\s*\)\s+WITH\s+(LOCAL\s+)?TIME\s+ZONE\b/gi, 'TEXT');
  out = out.replace(/\bTIMESTAMP\s*\(\s*\d+\s*\)/gi, 'TEXT');
  out = out.replace(/\bTIMESTAMP\s+WITH\s+(LOCAL\s+)?TIME\s+ZONE\b/gi, 'TEXT');
  out = out.replace(/\bTIMESTAMP\b/gi, 'TEXT');

  // DATE columns → TEXT (SQLite stores dates as ISO strings)
  // BUT only in DDL, not in expressions like DATE '2024-01-01' → leave literal.
  // Applied only when preceded by column-name-like token in CREATE TABLE.
  // Conservative: leave DATE alone; SQLite accepts "DATE" as a type affinity.

  // Identity columns: "GENERATED ... AS IDENTITY" → "PRIMARY KEY AUTOINCREMENT"
  out = out.replace(
    /\bGENERATED\s+(ALWAYS|BY\s+DEFAULT)(\s+ON\s+NULL)?\s+AS\s+IDENTITY(\s*\([^)]*\))?/gi,
    'AUTOINCREMENT',
  );

  // DEFAULT SYS_GUID() → handled at application level via generateId().
  // Strip DEFAULT SYS_GUID() — callers will bind the id explicitly.
  out = out.replace(/DEFAULT\s+SYS_GUID\s*\(\s*\)/gi, '');

  // CONSTRAINT ... ENABLE/DISABLE/VALIDATE → strip Oracle-only clauses
  out = out.replace(/\s+ENABLE\b/gi, '');
  out = out.replace(/\s+DISABLE\b/gi, '');
  out = out.replace(/\s+VALIDATE\b/gi, '');
  out = out.replace(/\s+NOVALIDATE\b/gi, '');

  // USING INDEX tablespace clauses → strip
  out = out.replace(/\bUSING\s+INDEX\s+TABLESPACE\s+\w+/gi, '');
  out = out.replace(/\bTABLESPACE\s+\w+/gi, '');

  // CHECK (col IN (...)) stays as-is (valid in SQLite).

  // ON DELETE CASCADE / SET NULL → valid in SQLite, keep.

  // CREATE OR REPLACE VIEW → SQLite doesn't support OR REPLACE on views
  out = out.replace(/\bCREATE\s+OR\s+REPLACE\s+VIEW\b/gi, 'CREATE VIEW IF NOT EXISTS');

  // CREATE OR REPLACE TRIGGER → drop+create (Oracle triggers not supported in v7 seed)
  // Our seed uses triggers only for audit; skipped by the seeder for SQLite.

  // Restore string literals.
  out = out.replace(/__LIT_(\d+)__/g, (_, i) => literals[parseInt(i, 10)]);

  return out;
}

/**
 * Convert :name binds to @name binds for better-sqlite3.
 * Also normalizes the bind object key names (better-sqlite3 accepts both
 * "name" and ":name" as keys; we pass without the colon).
 */

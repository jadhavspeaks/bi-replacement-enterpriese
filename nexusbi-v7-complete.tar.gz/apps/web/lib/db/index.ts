/**
 * Unified DB facade. Matches the surface of the original lib/oracle-pool.ts
 * so the 92 files that import from it keep working unchanged.
 *
 * Backend is selected by DB_BACKEND env var:
 *   DB_BACKEND=sqlite  (default — works out of the box, no credentials needed)
 *   DB_BACKEND=oracle  (reactivates oracledb when you have Oracle access again)
 */

import crypto from 'node:crypto';
import type { DbConnection, DbPool, DbBackend } from './types';
import { createSqlitePool } from './sqlite-adapter';
import { createOraclePool } from './oracle-adapter';

let currentPool: DbPool | null = null;
let initPromise: Promise<DbPool> | null = null;

function getBackend(): DbBackend {
  const raw = (process.env.DB_BACKEND || 'sqlite').toLowerCase();
  if (raw === 'oracle') return 'oracle';
  if (raw === 'sqlite') return 'sqlite';
  console.warn(`Unknown DB_BACKEND value "${raw}", falling back to sqlite.`);
  return 'sqlite';
}

export async function getOrInitPool(): Promise<DbPool> {
  if (currentPool) return currentPool;
  if (!initPromise) {
    initPromise = (async () => {
      const backend = getBackend();
      currentPool = backend === 'oracle' ? await createOraclePool() : await createSqlitePool();
      return currentPool;
    })().catch((err) => {
      initPromise = null;
      throw err;
    });
  }
  return initPromise;
}

/**
 * Back-compat alias for the old oracle-pool API. Throws if not initialized
 * yet — prefer getOrInitPool() in new code.
 */
export function getOraclePool(): DbPool {
  if (!currentPool) {
    throw new Error('Database pool not initialized. Call getOrInitPool() first.');
  }
  return currentPool;
}

export async function initOraclePool(): Promise<DbPool> {
  return getOrInitPool();
}

/**
 * Execute a function within a connection, auto-closing on exit.
 * No transaction semantics — use withTransaction for that.
 */
export async function withConnection<T>(
  fn: (conn: DbConnection) => Promise<T>,
): Promise<T> {
  const pool = await getOrInitPool();
  const conn = await pool.getConnection();
  try {
    return await fn(conn);
  } finally {
    try { await conn.close(); } catch { /* ignore */ }
  }
}

/**
 * Execute a function within a transaction. Commits on success, rolls back
 * on throw. The callback should NOT call commit() or rollback() itself.
 */
export async function withTransaction<T>(
  fn: (conn: DbConnection) => Promise<T>,
): Promise<T> {
  const pool = await getOrInitPool();
  const conn = await pool.getConnection();
  try {
    // For SQLite, explicitly BEGIN; for Oracle, autoCommit is off by default.
    try { await conn.execute('BEGIN', {}); } catch { /* Oracle already in tx */ }
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    try { await conn.rollback(); } catch { /* ignore */ }
    throw err;
  } finally {
    try { await conn.close(); } catch { /* ignore */ }
  }
}

/**
 * Read a CLOB or text value as a string. With SQLite everything is already a
 * string; with Oracle we transparently resolve the LOB handle.
 */
export async function clobToString(clob: unknown): Promise<string> {
  if (typeof clob === 'string') return clob;
  if (clob === null || clob === undefined) return '';
  if (typeof clob === 'object' && clob !== null && 'getData' in clob) {
    const data = await (clob as { getData: () => Promise<string | Buffer> }).getData();
    if (typeof data === 'string') return data;
    if (Buffer.isBuffer(data)) return data.toString('utf-8');
  }
  return String(clob);
}

export function parseJsonClob<T = unknown>(clobStr: string | null): T | null {
  if (!clobStr || clobStr.trim() === '') return null;
  try {
    return JSON.parse(clobStr) as T;
  } catch {
    return null;
  }
}

/**
 * Generate a short UUID v4. Used everywhere primary keys are needed.
 * Same signature as the original oracle-pool.ts helper.
 */
export function generateId(): string {
  return crypto.randomUUID();
}

/**
 * Brand for SQL that has been reviewed to include tenant scoping.
 * Kept for API compatibility; not enforced beyond a runtime check.
 */
export type OrgScopedQuery = string & { readonly __brand: unique symbol };

export function createOrgScopedQuery(sql: string): OrgScopedQuery {
  const upper = sql.toUpperCase();
  if (
    !sql.includes(':tenantId') &&
    !upper.includes('NB_PLATFORM_CONFIG') &&
    !upper.includes('NB_ROLES') &&
    !upper.includes('NB_PERMISSIONS')
  ) {
    throw new Error(
      `OrgScopedQuery requires :tenantId bind variable. SQL: ${sql.substring(0, 100)}`,
    );
  }
  return sql as OrgScopedQuery;
}

export type { DbConnection, DbPool, DbBackend } from './types';

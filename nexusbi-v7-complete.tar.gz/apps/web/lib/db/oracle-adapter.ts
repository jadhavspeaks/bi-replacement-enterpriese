/**
 * Oracle adapter — wraps the original oracledb pool behind the shared
 * DbPool / DbConnection surface. This lets the rest of the app stay unchanged
 * when you flip DB_BACKEND back to oracle.
 *
 * Kept feature-complete: CLOB fetching, named binds, OUT_FORMAT_OBJECT, and
 * connection-pool mechanics all still work.
 */

import type { DbConnection, DbExecuteOptions, DbExecuteResult, DbPool } from './types';

type Oracledb = typeof import('oracledb');
type OracleDbPool = import('oracledb').Pool;
type OracleConnection = import('oracledb').Connection;

let oracledb: Oracledb | null = null;
let oraclePool: OracleDbPool | null = null;
let poolInitPromise: Promise<OracleDbPool> | null = null;

async function getOracle(): Promise<Oracledb> {
  if (oracledb) return oracledb;
  try {
    oracledb = (await import('oracledb')).default as unknown as Oracledb;
    return oracledb;
  } catch {
    throw new Error(
      'oracledb is not installed. Run: cd apps/web && npm install oracledb',
    );
  }
}

function buildConnectString(): string {
  const host = process.env.ORACLE_HOST;
  const port = process.env.ORACLE_PORT || '1521';
  const service = process.env.ORACLE_SERVICE;

  if (!host || !service) {
    throw new Error(
      'Oracle connection requires ORACLE_HOST and ORACLE_SERVICE environment variables.',
    );
  }
  return `${host}:${port}/${service}`;
}

async function initPool(): Promise<OracleDbPool> {
  if (oraclePool) return oraclePool;

  const ora = await getOracle();

  const user = process.env.ORACLE_USER;
  const password = process.env.ORACLE_PASSWORD;
  if (!user || !password) {
    throw new Error(
      'Oracle connection requires ORACLE_USER and ORACLE_PASSWORD environment variables.',
    );
  }

  ora.outFormat = ora.OUT_FORMAT_OBJECT;
  ora.autoCommit = false;
  ora.fetchAsString = [ora.CLOB];

  oraclePool = await ora.createPool({
    user,
    password,
    connectString: buildConnectString(),
    poolMin: 4,
    poolMax: 20,
    poolIncrement: 2,
    poolTimeout: 60,
    queueTimeout: 30000,
    enableStatistics: false,
  });

  console.log(`Oracle pool initialized: ${user}@${buildConnectString()}`);
  return oraclePool;
}

async function getOrInitOraclePool(): Promise<OracleDbPool> {
  if (oraclePool) return oraclePool;
  if (!poolInitPromise) {
    poolInitPromise = initPool().catch((err) => {
      poolInitPromise = null;
      throw err;
    });
  }
  return poolInitPromise;
}

function wrapConnection(conn: OracleConnection): DbConnection {
  return {
    async execute<T = Record<string, unknown>>(
      sql: string,
      binds: Record<string, unknown> | unknown[] = {},
      options: DbExecuteOptions = {},
    ): Promise<DbExecuteResult<T>> {
      const result = await conn.execute(sql, binds, {
        outFormat: options.outFormat ?? 4002, // OUT_FORMAT_OBJECT
      });
      return {
        rows: result.rows as T[] | undefined,
        rowsAffected: result.rowsAffected,
      };
    },
    async commit(): Promise<void> {
      await conn.commit();
    },
    async rollback(): Promise<void> {
      await conn.rollback();
    },
    async close(): Promise<void> {
      try { await conn.close(); } catch { /* ignore */ }
    },
  };
}

export async function createOraclePool(): Promise<DbPool> {
  await getOrInitOraclePool();
  return {
    async getConnection(): Promise<DbConnection> {
      const p = await getOrInitOraclePool();
      const conn = await p.getConnection();
      return wrapConnection(conn);
    },
    async close(): Promise<void> {
      if (oraclePool) {
        await oraclePool.close(0);
        oraclePool = null;
        poolInitPromise = null;
      }
    },
  };
}

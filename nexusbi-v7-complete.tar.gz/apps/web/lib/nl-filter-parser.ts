import type { CubeFilter, FilterOperator } from '@nexusbi/shared-types';
import type { NLFilterParseResult } from '@nexusbi/shared-types';

interface Token {
  type: 'word' | 'number' | 'date' | 'comparison' | 'conjunction' | 'unknown';
  value: string;
  normalized: string;
}

interface DateRange {
  start: string;
  end: string;
}

const COMPARISON_PATTERNS: Array<{ pattern: RegExp; operator: FilterOperator }> = [
  { pattern: /^(?:greater\s+than|above|more\s+than|over|>|gt)\s*/i, operator: 'gt' },
  { pattern: /^(?:greater\s+than\s+or\s+equal|at\s+least|>=|gte)\s*/i, operator: 'gte' },
  { pattern: /^(?:less\s+than|below|under|<|lt)\s*/i, operator: 'lt' },
  { pattern: /^(?:less\s+than\s+or\s+equal|at\s+most|<=|lte)\s*/i, operator: 'lte' },
  { pattern: /^(?:equals?|is|=|==)\s*/i, operator: 'equals' },
  { pattern: /^(?:not|isn'?t|!=|<>)\s*/i, operator: 'notEquals' },
  { pattern: /^(?:contains?|includes?|like)\s*/i, operator: 'contains' },
  { pattern: /^(?:not\s+contain|excludes?|not\s+like)\s*/i, operator: 'notContains' },
];

const QUARTER_MAP: Record<string, { startMonth: number; endMonth: number }> = {
  Q1: { startMonth: 1, endMonth: 3 },
  Q2: { startMonth: 4, endMonth: 6 },
  Q3: { startMonth: 7, endMonth: 9 },
  Q4: { startMonth: 10, endMonth: 12 },
};

const REGION_ALIASES: Record<string, string[]> = {
  APAC: ['Asia Pacific', 'APAC', 'Asia', 'Pacific'],
  EMEA: ['Europe Middle East Africa', 'EMEA', 'Europe'],
  AMER: ['Americas', 'AMER', 'North America', 'South America', 'NA', 'LATAM'],
  NAM: ['North America', 'NAM', 'US', 'USA', 'Canada'],
};

const NUMBER_SUFFIXES: Record<string, number> = {
  k: 1_000,
  K: 1_000,
  m: 1_000_000,
  M: 1_000_000,
  b: 1_000_000_000,
  B: 1_000_000_000,
};

function parseNumberWithSuffix(str: string): number | null {
  const match = str.match(/^(\d+(?:\.\d+)?)\s*([kKmMbB])?$/);
  if (!match) return null;
  const base = parseFloat(match[1]);
  const suffix = match[2];
  if (suffix && suffix in NUMBER_SUFFIXES) {
    return base * NUMBER_SUFFIXES[suffix];
  }
  return base;
}

function parseDateExpression(text: string): DateRange | null {
  const now = new Date();
  const year = now.getFullYear();

  // Quarter patterns: "Q3 2024", "Q1"
  const quarterMatch = text.match(/\b(Q[1-4])\s*(\d{4})?\b/i);
  if (quarterMatch) {
    const quarter = quarterMatch[1].toUpperCase();
    const qYear = quarterMatch[2] ? parseInt(quarterMatch[2]) : year;
    const q = QUARTER_MAP[quarter];
    if (q) {
      const start = `${qYear}-${String(q.startMonth).padStart(2, '0')}-01`;
      const endMonth = q.endMonth;
      const lastDay = new Date(qYear, endMonth, 0).getDate();
      const end = `${qYear}-${String(endMonth).padStart(2, '0')}-${lastDay}`;
      return { start, end };
    }
  }

  // "last N days"
  const lastDaysMatch = text.match(/\blast\s+(\d+)\s+days?\b/i);
  if (lastDaysMatch) {
    const days = parseInt(lastDaysMatch[1]);
    const end = new Date(now);
    const start = new Date(now);
    start.setDate(start.getDate() - days);
    return {
      start: start.toISOString().split('T')[0],
      end: end.toISOString().split('T')[0],
    };
  }

  // "last N months"
  const lastMonthsMatch = text.match(/\blast\s+(\d+)\s+months?\b/i);
  if (lastMonthsMatch) {
    const months = parseInt(lastMonthsMatch[1]);
    const end = new Date(now);
    const start = new Date(now);
    start.setMonth(start.getMonth() - months);
    return {
      start: start.toISOString().split('T')[0],
      end: end.toISOString().split('T')[0],
    };
  }

  // "this year", "this month"
  if (/\bthis\s+year\b/i.test(text)) {
    return { start: `${year}-01-01`, end: `${year}-12-31` };
  }
  if (/\bthis\s+month\b/i.test(text)) {
    const month = String(now.getMonth() + 1).padStart(2, '0');
    const lastDay = new Date(year, now.getMonth() + 1, 0).getDate();
    return { start: `${year}-${month}-01`, end: `${year}-${month}-${lastDay}` };
  }

  // "last year"
  if (/\blast\s+year\b/i.test(text)) {
    return { start: `${year - 1}-01-01`, end: `${year - 1}-12-31` };
  }

  // "YYYY" standalone year
  const yearMatch = text.match(/\b(20\d{2})\b/);
  if (yearMatch && !quarterMatch) {
    const y = parseInt(yearMatch[1]);
    return { start: `${y}-01-01`, end: `${y}-12-31` };
  }

  return null;
}

function findComparisonAndValue(
  text: string,
): { operator: FilterOperator; value: string } | null {
  for (const { pattern, operator } of COMPARISON_PATTERNS) {
    const match = text.match(pattern);
    if (match) {
      const rest = text.slice(match[0].length).trim();
      const numMatch = rest.match(/^(\d+(?:\.\d+)?[kKmMbB]?)/);
      if (numMatch) {
        const num = parseNumberWithSuffix(numMatch[1]);
        if (num !== null) {
          return { operator, value: String(num) };
        }
      }
    }
  }

  // Standalone number with implicit "gte"
  const standaloneNum = text.match(/\b(\d+(?:\.\d+)?[kKmMbB]?)\b/);
  if (standaloneNum) {
    const num = parseNumberWithSuffix(standaloneNum[1]);
    if (num !== null) {
      return { operator: 'gte', value: String(num) };
    }
  }

  return null;
}

function findRegions(text: string): string[] {
  const found: string[] = [];
  for (const [canonical, aliases] of Object.entries(REGION_ALIASES)) {
    for (const alias of aliases) {
      if (text.toUpperCase().includes(alias.toUpperCase())) {
        found.push(canonical);
        break;
      }
    }
  }
  return found;
}

function matchDimensionOrMeasure(
  word: string,
  available: string[],
): string | null {
  const lower = word.toLowerCase();

  // Exact match
  for (const m of available) {
    const memberName = m.split('.').pop()?.toLowerCase();
    if (memberName === lower) return m;
  }

  // Partial match
  for (const m of available) {
    const memberName = m.split('.').pop()?.toLowerCase() || '';
    if (memberName.includes(lower) || lower.includes(memberName)) {
      return m;
    }
  }

  return null;
}

export function parseNLFilter(
  text: string,
  options?: {
    cubeName?: string;
    availableDimensions?: string[];
    availableMeasures?: string[];
  },
): NLFilterParseResult {
  const filters: CubeFilter[] = [];
  const unmatched: string[] = [];
  let confidence = 0;
  let matchedSegments = 0;
  const totalSegments = text.split(/\s+/).length;

  const availableDimensions = options?.availableDimensions || [];
  const availableMeasures = options?.availableMeasures || [];
  const cubeName = options?.cubeName || '';

  // 1. Extract date filters
  const dateRange = parseDateExpression(text);
  if (dateRange) {
    // Try to find a time dimension
    const timeDim = availableDimensions.find((d) => {
      const lower = d.toLowerCase();
      return lower.includes('date') || lower.includes('time') || lower.includes('created') || lower.includes('ordered');
    });

    if (timeDim) {
      filters.push({
        member: timeDim,
        operator: 'inDateRange',
        values: [dateRange.start, dateRange.end],
      });
      matchedSegments += 2;
    } else if (cubeName) {
      filters.push({
        member: `${cubeName}.createdAt`,
        operator: 'inDateRange',
        values: [dateRange.start, dateRange.end],
      });
      matchedSegments += 2;
    }
  }

  // 2. Extract region filters
  const regions = findRegions(text);
  if (regions.length > 0) {
    const regionDim = availableDimensions.find((d) => {
      const lower = d.toLowerCase();
      return lower.includes('region') || lower.includes('geography') || lower.includes('territory');
    });

    if (regionDim) {
      filters.push({
        member: regionDim,
        operator: regions.length === 1 ? 'equals' : 'equals',
        values: regions,
      });
      matchedSegments += regions.length;
    }
  }

  // 3. Extract comparison filters (e.g., "revenue above 1M")
  const comparison = findComparisonAndValue(text);
  if (comparison) {
    // Try to identify which measure this applies to
    const words = text.toLowerCase().split(/\s+/);
    let matchedMeasure: string | null = null;

    for (const word of words) {
      const match = matchDimensionOrMeasure(word, availableMeasures);
      if (match) {
        matchedMeasure = match;
        break;
      }
    }

    if (matchedMeasure) {
      filters.push({
        member: matchedMeasure,
        operator: comparison.operator,
        values: [comparison.value],
      });
      matchedSegments += 2;
    } else if (availableMeasures.length > 0) {
      // Default to first measure
      filters.push({
        member: availableMeasures[0],
        operator: comparison.operator,
        values: [comparison.value],
      });
      matchedSegments += 1;
    }
  }

  // 4. Try to match remaining words to dimensions
  const words = text.split(/\s+/);
  const stopWords = new Set([
    'show', 'me', 'the', 'and', 'or', 'for', 'in', 'of', 'with',
    'above', 'below', 'over', 'under', 'greater', 'less', 'than',
    'is', 'are', 'was', 'were', 'a', 'an', 'to', 'from', 'by',
    'last', 'this', 'next', 'days', 'months', 'year', 'years',
    'q1', 'q2', 'q3', 'q4', 'revenue', 'sales', 'profit', 'cost',
  ]);

  for (const word of words) {
    const lower = word.toLowerCase().replace(/[^a-z0-9]/g, '');
    if (stopWords.has(lower) || lower.length < 2) continue;

    // Already matched via other logic
    if (regions.some((r) => r.toLowerCase() === lower)) continue;

    const dimMatch = matchDimensionOrMeasure(lower, availableDimensions);
    if (dimMatch) {
      // Value match — check if this word could be a dimension value
      const existingFilter = filters.find((f) => f.member === dimMatch);
      if (!existingFilter) {
        matchedSegments++;
      }
    } else {
      if (!stopWords.has(lower)) {
        unmatched.push(word);
      }
    }
  }

  // Calculate confidence
  if (filters.length > 0) {
    confidence = Math.min(
      100,
      Math.round((matchedSegments / Math.max(totalSegments, 1)) * 100),
    );
  }

  return {
    filters,
    confidence,
    unmatched,
  };
}

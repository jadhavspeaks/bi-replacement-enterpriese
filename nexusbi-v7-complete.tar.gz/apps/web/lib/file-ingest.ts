import Papa from 'papaparse';
import ExcelJS from 'exceljs';
import { downloadFile, BUCKETS } from '@/lib/storage';
import { withConnection, withTransaction } from '@/lib/oracle-pool';
import type { ColumnSchemaEntry, IngestResult, IngestOptions } from '@nexusbi/shared-types';

function inferOracleType(sampleValues: string[]): string {
  const nonEmpty = sampleValues.filter((v) => v !== '' && v !== null && v !== undefined);
  if (nonEmpty.length === 0) return 'VARCHAR2(4000)';
  if (nonEmpty.every((v) => /^-?\d+$/.test(String(v)))) return 'NUMBER(19)';
  if (nonEmpty.every((v) => /^-?\d+\.?\d*$/.test(String(v)))) return 'NUMBER(38,10)';
  if (nonEmpty.every((v) => /^(true|false|0|1|yes|no)$/i.test(String(v)))) return 'NUMBER(1)';
  if (nonEmpty.every((v) => /^\d{4}-\d{2}-\d{2}/.test(String(v)))) return 'TIMESTAMP';
  const maxLen = Math.max(...nonEmpty.map((v) => String(v).length), 1);
  if (maxLen <= 200) return 'VARCHAR2(500)';
  if (maxLen <= 2000) return 'VARCHAR2(4000)';
  return 'CLOB';
}

function sanitizeTableName(name: string): string {
  return ('NB_STG_' + name)
    .replace(/\.[^.]+$/, '')
    .replace(/[^a-zA-Z0-9_]/g, '_')
    .replace(/^(\d)/, '_$1')
    .toUpperCase()
    .substring(0, 128);
}

function sanitizeColumnName(name: string): string {
  return name
    .replace(/[^a-zA-Z0-9_]/g, '_')
    .replace(/^(\d)/, '_$1')
    .toUpperCase()
    .substring(0, 128);
}

async function parseCsvBuffer(
  buffer: Buffer,
  options?: IngestOptions,
): Promise<{ headers: string[]; rows: string[][] }> {
  const text = buffer.toString('utf-8');
  const result = Papa.parse<string[]>(text, { header: false, skipEmptyLines: true });
  const allRows = result.data;
  const skipRows = options?.skipRows || 0;
  const startIdx = skipRows;
  const headers = allRows[startIdx].map(sanitizeColumnName);
  const dataStart = startIdx + 1;
  const maxRows = options?.maxRows;
  const rows = maxRows ? allRows.slice(dataStart, dataStart + maxRows) : allRows.slice(dataStart);
  return { headers, rows };
}

async function parseExcelBuffer(
  buffer: Buffer,
  sheetName?: string,
): Promise<{ headers: string[]; rows: string[][] }> {
  const workbook = new ExcelJS.Workbook();
  await workbook.xlsx.load(buffer as unknown as ArrayBuffer);

  const sheet = sheetName ? workbook.getWorksheet(sheetName) : workbook.worksheets[0];
  if (!sheet) throw new Error(`Sheet ${sheetName || '(first)'} not found`);

  const headers: string[] = [];
  const rows: string[][] = [];

  sheet.eachRow({ includeEmpty: false }, (row, rowNumber) => {
    // row.values is 1-indexed; slice(1) drops the leading undefined
    const values = (row.values as unknown[]).slice(1).map((v) => {
      if (v === null || v === undefined) return '';
      if (typeof v === 'object' && v !== null && 'text' in (v as Record<string, unknown>)) {
        return String((v as { text: unknown }).text ?? '');
      }
      if (typeof v === 'object' && v !== null && 'result' in (v as Record<string, unknown>)) {
        return String((v as { result: unknown }).result ?? '');
      }
      return String(v);
    });
    if (rowNumber === 1) {
      headers.push(...values.map(sanitizeColumnName));
    } else {
      rows.push(values);
    }
  });

  return { headers, rows };
}

function buildSchema(headers: string[], rows: string[][]): ColumnSchemaEntry[] {
  const sampleSize = Math.min(rows.length, 100);
  const schema: ColumnSchemaEntry[] = [];
  for (let i = 0; i < headers.length; i++) {
    const sampleValues = rows.slice(0, sampleSize).map((row) => row[i] || '');
    const oracleType = inferOracleType(sampleValues);
    const hasNull = sampleValues.some((v) => v === '' || v === null || v === undefined);
    schema.push({ name: headers[i], type: oracleType, nullable: hasNull, sampleValues: sampleValues.slice(0, 5) });
  }
  return schema;
}

function castValue(val: string, oracleType: string): unknown {
  if (val === '' || val === null || val === undefined) return null;
  if (oracleType.startsWith('NUMBER(19')) return parseInt(val, 10) || null;
  if (oracleType.startsWith('NUMBER(38')) return parseFloat(val) || null;
  if (oracleType === 'NUMBER(1)') return /^(true|1|yes)$/i.test(val) ? 1 : 0;
  return val;
}

export async function ingestFile(
  fileId: string,
  minioPath: string,
  fileType: string,
  tenantId: string,
  options?: IngestOptions,
): Promise<IngestResult> {
  const startTime = performance.now();

  await withConnection(async (conn) => {
    await conn.execute(
      `UPDATE NB_FILE_UPLOADS SET INGEST_STATUS = 'INGESTING' WHERE FILE_ID = :fileId AND TENANT_ID = :tenantId`,
      { fileId, tenantId },
    );
    await conn.commit();
  });

  try {
    const [bucket, ...objectParts] = minioPath.split('/');
    const objectName = objectParts.join('/');
    const buffer = await downloadFile(bucket, objectName);

    let headers: string[];
    let rows: string[][];

    switch (fileType) {
      case 'csv': {
        const parsed = await parseCsvBuffer(buffer, options);
        headers = parsed.headers;
        rows = parsed.rows;
        break;
      }
      case 'excel': {
        const parsed = await parseExcelBuffer(buffer);
        headers = parsed.headers;
        rows = parsed.rows;
        break;
      }
      case 'json': {
        const jsonData = JSON.parse(buffer.toString('utf-8'));
        const arr = Array.isArray(jsonData) ? jsonData : [jsonData];
        if (arr.length === 0) { headers = []; rows = []; }
        else {
          headers = Object.keys(arr[0]).map(sanitizeColumnName);
          rows = arr.map((item) => headers.map((h) => String(item[h] ?? '')));
        }
        break;
      }
      default:
        throw new Error(`Unsupported file type: ${fileType}`);
    }

    if (options?.columnMapping) {
      headers = headers.map((h) => sanitizeColumnName(options.columnMapping![h] || h));
    }

    const columnSchema = buildSchema(headers, rows);
    const tableName = options?.stagingTableName
      ? sanitizeTableName(options.stagingTableName)
      : sanitizeTableName(fileId);

    await withTransaction(async (conn) => {
      if (options?.ifExists === 'replace') {
        try { await conn.execute(`DROP TABLE ${tableName} PURGE`); } catch { /* table may not exist */ }
      }

      const createCols = columnSchema.map((col) => `"${col.name}" ${col.type}`).join(', ');
      await conn.execute(`CREATE TABLE ${tableName} (${createCols})`);

      const batchSize = 500;
      for (let i = 0; i < rows.length; i += batchSize) {
        const batch = rows.slice(i, i + batchSize);
        const bindNames = headers.map((_, ci) => `:c${ci}`).join(', ');
        const insertSql = `INSERT INTO ${tableName} (${headers.map((h) => `"${h}"`).join(', ')}) VALUES (${bindNames})`;

        for (const row of batch) {
          const binds: Record<string, unknown> = {};
          row.forEach((val, ci) => {
            binds[`c${ci}`] = castValue(val, columnSchema[ci].type);
          });
          await conn.execute(insertSql, binds);
        }
      }
    });

    const durationMs = Math.round(performance.now() - startTime);

    await withConnection(async (oraConn) => {
      await oraConn.execute(
        `UPDATE NB_FILE_UPLOADS
         SET INGEST_STATUS = 'COMPLETE', DUCKDB_TABLE = :stagingTable,
             CREATED_AT = SYSTIMESTAMP
         WHERE FILE_ID = :fileId AND TENANT_ID = :tenantId`,
        { fileId, tenantId, stagingTable: tableName },
      );
      await oraConn.commit();
    });

    return { fileId, stagingTable: tableName, rowCount: rows.length, columnSchema, durationMs };
  } catch (error) {
    const errMsg = error instanceof Error ? error.message : 'Unknown error';
    await withConnection(async (conn) => {
      await conn.execute(
        `UPDATE NB_FILE_UPLOADS SET INGEST_STATUS = 'ERROR' WHERE FILE_ID = :fileId AND TENANT_ID = :tenantId`,
        { fileId, tenantId },
      );
      await conn.commit();
    });
    throw error;
  }
}

'use client';

/**
 * Browser-side query client. Replaces @cubejs-client/core.
 * POSTs queries to /api/cube/v1/load which calls the in-app query engine.
 */

import type { Query, QueryResult } from '@/lib/query-engine';
export type { Query, QueryResult } from '@/lib/query-engine';

export interface CubeMetaMember {
  name: string;
  title: string;
  type: string;
  shortTitle: string;
  description?: string;
}

export interface CubeMeta {
  cubes: Array<{
    name: string;
    title: string;
    measures: CubeMetaMember[];
    dimensions: CubeMetaMember[];
  }>;
}

export interface ResultSet {
  rawData(): Array<Record<string, unknown>>;
  tablePivot(): Array<Record<string, unknown>>;
  query(): Query;
  annotation(): QueryResult['annotation'];
}

function wrapResult(r: QueryResult): ResultSet {
  return {
    rawData: () => r.data,
    tablePivot: () => r.data,
    query: () => r.query,
    annotation: () => r.annotation,
  };
}

export async function executeQuery(query: Query): Promise<ResultSet> {
  const res = await fetch('/api/cube/v1/load', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query }),
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`Query failed (${res.status}): ${text}`);
  }
  const body = await res.json();
  if (body.error) throw new Error(body.error);
  return wrapResult(body as QueryResult);
}

export async function fetchMeta(): Promise<CubeMeta> {
  const res = await fetch('/api/cube/v1/meta');
  if (!res.ok) throw new Error(`Meta fetch failed: ${res.status}`);
  return res.json() as Promise<CubeMeta>;
}

/**
 * Kept for backward compatibility with existing imports.
 * Returns a shim that exposes .load(query) → executeQuery(query).
 */
export function getCubeClient() {
  return {
    load: executeQuery,
    meta: fetchMeta,
  };
}

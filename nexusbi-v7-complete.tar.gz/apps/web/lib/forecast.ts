import type { ForecastConfig, ForecastResult, ForecastPoint } from '@nexusbi/shared-types';

/**
 * Self-contained forecasting (no external deps).
 * All three methods produce confidence intervals via residual standard error.
 */

function linearRegression(y: number[]): { slope: number; intercept: number; predictions: number[]; residuals: number[] } {
  const n = y.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (let i = 0; i < n; i++) {
    sumX += i; sumY += y[i]; sumXY += i * y[i]; sumXX += i * i;
  }
  const denom = n * sumXX - sumX * sumX;
  const slope = denom === 0 ? 0 : (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  const predictions = y.map((_, i) => intercept + slope * i);
  const residuals = y.map((v, i) => v - predictions[i]);
  return { slope, intercept, predictions, residuals };
}

function expSmoothing(y: number[], alpha = 0.3): { fitted: number[]; level: number } {
  if (y.length === 0) return { fitted: [], level: 0 };
  const fitted: number[] = [y[0]];
  for (let i = 1; i < y.length; i++) {
    fitted.push(alpha * y[i] + (1 - alpha) * fitted[i - 1]);
  }
  return { fitted, level: fitted[fitted.length - 1] };
}

function holtWinters(y: number[], period: number, alpha = 0.3, beta = 0.1, gamma = 0.1): {
  fitted: number[]; forecast: (horizon: number) => number[]; residuals: number[];
} {
  if (y.length < 2 * period) {
    const es = expSmoothing(y, alpha);
    return {
      fitted: es.fitted,
      forecast: (h) => Array.from({ length: h }, () => es.level),
      residuals: y.map((v, i) => v - es.fitted[i]),
    };
  }

  let level = y.slice(0, period).reduce((a, b) => a + b, 0) / period;
  let trend = 0;
  for (let i = 0; i < period; i++) {
    trend += (y[i + period] - y[i]) / period;
  }
  trend /= period;

  const seasonals: number[] = new Array(period);
  for (let i = 0; i < period; i++) {
    seasonals[i] = y[i] / level;
  }

  const fitted: number[] = [];
  const residuals: number[] = [];

  for (let i = 0; i < y.length; i++) {
    const seasonIdx = i % period;
    const forecast = (level + trend) * seasonals[seasonIdx];
    fitted.push(forecast);
    residuals.push(y[i] - forecast);

    const newLevel = alpha * (y[i] / seasonals[seasonIdx]) + (1 - alpha) * (level + trend);
    const newTrend = beta * (newLevel - level) + (1 - beta) * trend;
    const newSeason = gamma * (y[i] / newLevel) + (1 - gamma) * seasonals[seasonIdx];

    level = newLevel;
    trend = newTrend;
    seasonals[seasonIdx] = newSeason;
  }

  const finalLevel = level;
  const finalTrend = trend;
  const finalSeasons = [...seasonals];

  return {
    fitted,
    residuals,
    forecast: (horizon: number) => {
      const out: number[] = [];
      for (let h = 1; h <= horizon; h++) {
        const seasonIdx = (y.length + h - 1) % period;
        out.push((finalLevel + h * finalTrend) * finalSeasons[seasonIdx]);
      }
      return out;
    },
  };
}

function zScore(confidence: number): number {
  if (confidence >= 0.99) return 2.576;
  if (confidence >= 0.95) return 1.96;
  return 1.645;
}

function stdDev(residuals: number[]): number {
  if (residuals.length < 2) return 0;
  const mean = residuals.reduce((a, b) => a + b, 0) / residuals.length;
  const variance = residuals.reduce((s, r) => s + (r - mean) ** 2, 0) / (residuals.length - 1);
  return Math.sqrt(variance);
}

function rmse(residuals: number[]): number {
  if (residuals.length === 0) return 0;
  const sumSq = residuals.reduce((s, r) => s + r * r, 0);
  return Math.sqrt(sumSq / residuals.length);
}

function mape(actuals: number[], predictions: number[]): number {
  let sum = 0; let count = 0;
  for (let i = 0; i < actuals.length; i++) {
    if (actuals[i] !== 0) {
      sum += Math.abs((actuals[i] - predictions[i]) / actuals[i]);
      count++;
    }
  }
  return count === 0 ? 0 : (sum / count) * 100;
}

export function computeForecast(
  data: Array<{ timestamp: string; value: number }>,
  config: ForecastConfig,
): ForecastResult {
  const sorted = [...data].sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  const values = sorted.map((d) => d.value);
  const z = zScore(config.confidenceInterval);

  let fitted: number[];
  let futurePredictions: number[];
  let residuals: number[];

  if (config.method === 'linear') {
    const lr = linearRegression(values);
    fitted = lr.predictions;
    residuals = lr.residuals;
    futurePredictions = Array.from({ length: config.periods }, (_, i) =>
      lr.intercept + lr.slope * (values.length + i));
  } else if (config.method === 'exponential') {
    const es = expSmoothing(values);
    fitted = es.fitted;
    residuals = values.map((v, i) => v - fitted[i]);
    futurePredictions = Array.from({ length: config.periods }, () => es.level);
  } else {
    const period = config.seasonality && config.seasonality >= 2 ? config.seasonality : 12;
    const hw = holtWinters(values, period);
    fitted = hw.fitted;
    residuals = hw.residuals;
    futurePredictions = hw.forecast(config.periods);
  }

  const sigma = stdDev(residuals);

  const points: ForecastPoint[] = [];
  sorted.forEach((d, i) => {
    points.push({
      timestamp: d.timestamp,
      actual: d.value,
      predicted: fitted[i] ?? null,
      lower: fitted[i] != null ? fitted[i] - z * sigma : null,
      upper: fitted[i] != null ? fitted[i] + z * sigma : null,
    });
  });

  const lastTs = sorted.length > 0 ? new Date(sorted[sorted.length - 1].timestamp).getTime() : Date.now();
  const stepMs = sorted.length > 1
    ? new Date(sorted[sorted.length - 1].timestamp).getTime() - new Date(sorted[sorted.length - 2].timestamp).getTime()
    : 24 * 60 * 60 * 1000;

  futurePredictions.forEach((p, i) => {
    const futureMs = lastTs + (i + 1) * stepMs;
    points.push({
      timestamp: new Date(futureMs).toISOString(),
      actual: null,
      predicted: p,
      lower: p - z * sigma * Math.sqrt(i + 1),
      upper: p + z * sigma * Math.sqrt(i + 1),
    });
  });

  return {
    points,
    method: config.method,
    rmse: rmse(residuals),
    mape: mape(values, fitted),
  };
}

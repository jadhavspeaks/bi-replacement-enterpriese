import { auth } from '@/lib/auth';

export const authOptions = auth;

export async function getServerSession() {
  const session = await auth();
  return session;
}

export async function requireSession() {
  const session = await getServerSession();
  if (!session?.user) {
    throw new AuthenticationError('Unauthorized');
  }
  return session;
}

export class AuthenticationError extends Error {
  public readonly statusCode = 401;
  constructor(message: string = 'Unauthorized') {
    super(message);
    this.name = 'AuthenticationError';
  }
}

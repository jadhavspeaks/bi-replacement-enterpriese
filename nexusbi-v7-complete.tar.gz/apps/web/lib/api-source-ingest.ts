/**
 * Minimal JSONPath-like resolver, replaces the `jmespath` package.
 * Supports simple dot paths (`a.b.c`) and array indices (`a.b[0].c`).
 * For complex JMESPath queries, reinstall `jmespath` and swap back.
 */
const jmespath = {
  search(data: unknown, path: string): unknown {
    if (!path || !data) return data;
    const parts = path.replace(/\[(\d+)\]/g, '.$1').split('.').filter(Boolean);
    let cur: unknown = data;
    for (const key of parts) {
      if (cur == null) return null;
      if (Array.isArray(cur)) {
        const idx = Number(key);
        cur = Number.isFinite(idx) ? cur[idx] : null;
      } else if (typeof cur === 'object') {
        cur = (cur as Record<string, unknown>)[key];
      } else {
        return null;
      }
    }
    return cur;
  },
};
import type {
  ApiSource,
  ApiRequestConfig,
  ApiResponseMapping,
  ApiAuthConfig,
  ApiPollResult,
} from '@nexusbi/shared-types';
import { withConnection, withTransaction } from '@/lib/oracle-pool';
import { decryptJson } from '@/lib/encryption';

async function buildAuthHeaders(authConfig: ApiAuthConfig): Promise<Record<string, string>> {
  const headers: Record<string, string> = {};
  switch (authConfig.method) {
    case 'api_key':
      if (authConfig.apiKeyHeader && authConfig.apiKeyValue) {
        headers[authConfig.apiKeyHeader] = authConfig.apiKeyValue;
      }
      break;
    case 'bearer':
      if (authConfig.bearerToken) {
        headers['Authorization'] = `Bearer ${authConfig.bearerToken}`;
      }
      break;
    case 'basic':
      if (authConfig.basicUsername && authConfig.basicPassword) {
        const encoded = Buffer.from(`${authConfig.basicUsername}:${authConfig.basicPassword}`).toString('base64');
        headers['Authorization'] = `Basic ${encoded}`;
      }
      break;
    case 'oauth2':
      if (authConfig.oauth2TokenUrl && authConfig.oauth2ClientId && authConfig.oauth2ClientSecret) {
        const tokenRes = await fetch(authConfig.oauth2TokenUrl, {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            grant_type: 'client_credentials',
            client_id: authConfig.oauth2ClientId,
            client_secret: authConfig.oauth2ClientSecret,
            scope: authConfig.oauth2Scope || '',
          }),
        });
        if (!tokenRes.ok) throw new Error(`OAuth2 token request failed: ${tokenRes.status}`);
        const tokenData = await tokenRes.json() as { access_token: string };
        headers['Authorization'] = `Bearer ${tokenData.access_token}`;
      }
      break;
  }
  return headers;
}

async function fetchRestData(
  baseUrl: string, requestConfig: ApiRequestConfig, authHeaders: Record<string, string>,
): Promise<unknown> {
  const url = new URL(requestConfig.path || '', baseUrl);
  if (requestConfig.queryParams) {
    for (const [key, value] of Object.entries(requestConfig.queryParams)) {
      url.searchParams.set(key, value);
    }
  }
  const headers: Record<string, string> = { 'Content-Type': 'application/json', ...authHeaders, ...(requestConfig.headers || {}) };
  const fetchOptions: RequestInit = { method: requestConfig.method || 'GET', headers };
  if (requestConfig.body && ['POST', 'PUT', 'PATCH'].includes(requestConfig.method || '')) {
    fetchOptions.body = JSON.stringify(requestConfig.body);
  }
  const response = await fetch(url.toString(), fetchOptions);
  if (!response.ok) throw new Error(`API request failed: ${response.status} ${response.statusText}`);
  return response.json();
}

async function fetchWithPagination(
  baseUrl: string, requestConfig: ApiRequestConfig, authHeaders: Record<string, string>, responseMapping: ApiResponseMapping,
): Promise<unknown[]> {
  const allData: unknown[] = [];
  const pagination = requestConfig.paginationConfig;
  const paginationType = requestConfig.paginationType || 'none';
  if (paginationType === 'none' || !pagination) {
    const data = await fetchRestData(baseUrl, requestConfig, authHeaders);
    const extracted = jmespath.search(data, responseMapping.dataPath);
    return Array.isArray(extracted) ? extracted : [extracted];
  }
  let page = 0;
  let cursor: string | null = null;
  const maxPages = pagination.maxPages || 100;
  const pageSize = pagination.pageSize || 100;
  for (let i = 0; i < maxPages; i++) {
    const configCopy = { ...requestConfig, queryParams: { ...(requestConfig.queryParams || {}) } };
    switch (paginationType) {
      case 'offset':
        configCopy.queryParams[pagination.limitParam || 'limit'] = String(pageSize);
        configCopy.queryParams[pagination.offsetParam || 'offset'] = String(page * pageSize);
        break;
      case 'page':
        configCopy.queryParams[pagination.pageSizeParam || 'pageSize'] = String(pageSize);
        configCopy.queryParams[pagination.pageParam || 'page'] = String(page + 1);
        break;
      case 'cursor':
        configCopy.queryParams[pagination.limitParam || 'limit'] = String(pageSize);
        if (cursor) configCopy.queryParams[pagination.cursorParam || 'cursor'] = cursor;
        break;
    }
    const data = await fetchRestData(baseUrl, configCopy, authHeaders);
    const extracted = jmespath.search(data, responseMapping.dataPath);
    const items = Array.isArray(extracted) ? extracted : [extracted];
    if (items.length === 0) break;
    allData.push(...items);
    if (paginationType === 'cursor' && pagination.cursorPath) {
      cursor = jmespath.search(data, pagination.cursorPath) as string | null;
      if (!cursor) break;
    }
    if (items.length < pageSize) break;
    page++;
  }
  return allData;
}

function mapDataToColumns(
  data: unknown[], responseMapping: ApiResponseMapping,
): { headers: string[]; rows: unknown[][] } {
  const headers = responseMapping.columnMappings.map((cm) => cm.targetColumn.toUpperCase().replace(/[^A-Z0-9_]/g, '_'));
  const rows: unknown[][] = [];
  for (const item of data) {
    const row: unknown[] = [];
    for (const mapping of responseMapping.columnMappings) {
      let value = jmespath.search(item, mapping.sourcePath);
      if (value === null || value === undefined) value = mapping.defaultValue ?? null;
      switch (mapping.dataType) {
        case 'number': value = value !== null ? Number(value) : null; break;
        case 'boolean': value = value !== null ? (Boolean(value) ? 1 : 0) : null; break;
        case 'json': value = value !== null ? JSON.stringify(value) : null; break;
        default: value = value !== null ? String(value) : null;
      }
      row.push(value);
    }
    rows.push(row);
  }
  return { headers, rows };
}

function oracleTypeFromApiType(dataType: string): string {
  switch (dataType) {
    case 'number': return 'NUMBER(38,10)';
    case 'boolean': return 'NUMBER(1)';
    case 'json': return 'CLOB';
    default: return 'VARCHAR2(4000)';
  }
}

export async function pollApiSource(
  source: ApiSource, encryptedAuthConfig: string | null,
): Promise<ApiPollResult> {
  const startTime = performance.now();
  const errors: string[] = [];
  let authConfig: ApiAuthConfig = { method: 'none' };
  if (encryptedAuthConfig) {
    try { authConfig = decryptJson<ApiAuthConfig>(encryptedAuthConfig); }
    catch { errors.push('Failed to decrypt auth config'); }
  }
  if (!source.requestConfig || !source.responseMapping) {
    throw new Error('API source missing request config or response mapping');
  }
  const authHeaders = await buildAuthHeaders(authConfig);
  const rawData = await fetchWithPagination(source.baseUrl, source.requestConfig, authHeaders, source.responseMapping);
  const { headers, rows } = mapDataToColumns(rawData, source.responseMapping);
  const stagingTable = 'NB_STG_API_' + source.sourceId.replace(/-/g, '_').toUpperCase().substring(0, 100);

  await withTransaction(async (conn) => {
    try { await conn.execute(`DROP TABLE ${stagingTable} PURGE`); } catch { /* may not exist */ }
    const oracleTypes = source.responseMapping!.columnMappings.map((cm) => oracleTypeFromApiType(cm.dataType));
    const createCols = headers.map((h, i) => `"${h}" ${oracleTypes[i]}`).join(', ');
    await conn.execute(`CREATE TABLE ${stagingTable} (${createCols})`);
    const bindNames = headers.map((_, ci) => `:c${ci}`).join(', ');
    const insertSql = `INSERT INTO ${stagingTable} (${headers.map((h) => `"${h}"`).join(', ')}) VALUES (${bindNames})`;
    for (const row of rows) {
      const binds: Record<string, unknown> = {};
      row.forEach((val, ci) => { binds[`c${ci}`] = val; });
      await conn.execute(insertSql, binds);
    }
  });

  const durationMs = Math.round(performance.now() - startTime);

  await withConnection(async (oraConn) => {
    await oraConn.execute(
      `UPDATE NB_API_SOURCES
       SET LAST_POLL_AT = SYSTIMESTAMP, LAST_POLL_STATUS = 'SUCCESS',
           LAST_ROW_COUNT = :rowCount, DUCKDB_TABLE = :stagingTable
       WHERE SOURCE_ID = :sourceId`,
      { rowCount: rows.length, stagingTable, sourceId: source.sourceId },
    );
    await oraConn.commit();
  });

  return { rowCount: rows.length, stagingTable, durationMs, errors };
}

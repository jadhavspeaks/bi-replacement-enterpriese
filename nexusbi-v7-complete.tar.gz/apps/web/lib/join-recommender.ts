import type { JoinSuggestion } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';

/**
 * Recommend join keys between two tables using:
 *   name similarity (Levenshtein + normalize) × 0.3 +
 *   value overlap (Jaccard on sample) × 0.7
 */

function levenshtein(a: string, b: string): number {
  if (!a.length) return b.length;
  if (!b.length) return a.length;
  const matrix: number[][] = Array.from({ length: b.length + 1 }, () => new Array(a.length + 1).fill(0));
  for (let i = 0; i <= a.length; i++) matrix[0][i] = i;
  for (let j = 0; j <= b.length; j++) matrix[j][0] = j;
  for (let j = 1; j <= b.length; j++) {
    for (let i = 1; i <= a.length; i++) {
      const cost = a[i - 1] === b[j - 1] ? 0 : 1;
      matrix[j][i] = Math.min(matrix[j][i - 1] + 1, matrix[j - 1][i] + 1, matrix[j - 1][i - 1] + cost);
    }
  }
  return matrix[b.length][a.length];
}

function normalize(name: string): string {
  return name.toLowerCase().replace(/[_\s-]/g, '').replace(/(id|key|code)$/, '');
}

function nameSimilarity(left: string, right: string): number {
  const a = normalize(left);
  const b = normalize(right);
  if (a === b) return 1.0;
  if (a.includes(b) || b.includes(a)) return 0.85;
  const maxLen = Math.max(a.length, b.length);
  if (maxLen === 0) return 0;
  const dist = levenshtein(a, b);
  return Math.max(0, 1 - dist / maxLen);
}

async function getColumns(tableName: string): Promise<Array<{ name: string; type: string }>> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ COLUMN_NAME: string; DATA_TYPE: string }>(
      `SELECT COLUMN_NAME, DATA_TYPE FROM USER_TAB_COLUMNS WHERE TABLE_NAME = :t ORDER BY COLUMN_ID`,
      { t: tableName.toUpperCase() }, { outFormat: 4002 },
    );
    return (r.rows ?? []).map((x) => ({ name: x.COLUMN_NAME, type: x.DATA_TYPE }));
  });
}

async function sampleValues(tableName: string, columnName: string, sampleSize: number): Promise<Set<string>> {
  const values = await withConnection(async (conn) => {
    const r = await conn.execute<{ V: unknown }>(
      `SELECT "${columnName}" AS V FROM ${tableName} SAMPLE (10)
       WHERE "${columnName}" IS NOT NULL FETCH FIRST ${sampleSize} ROWS ONLY`,
      {}, { outFormat: 4002 },
    );
    return (r.rows ?? []).map((x) => String(x.V));
  });
  return new Set(values);
}

async function rowCount(tableName: string): Promise<number> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ CNT: number }>(
      `SELECT COUNT(*) AS CNT FROM ${tableName}`, {}, { outFormat: 4002 },
    );
    return r.rows?.[0]?.CNT ?? 0;
  });
}

function jaccard(a: Set<string>, b: Set<string>): number {
  if (a.size === 0 && b.size === 0) return 0;
  const intersection = new Set<string>();
  for (const v of a) if (b.has(v)) intersection.add(v);
  const union = new Set<string>([...a, ...b]);
  return union.size === 0 ? 0 : intersection.size / union.size;
}

export async function suggestJoins(
  leftTable: string, rightTable: string, sampleSize = 500,
): Promise<JoinSuggestion[]> {
  const [leftCols, rightCols, leftRows, rightRows] = await Promise.all([
    getColumns(leftTable), getColumns(rightTable),
    rowCount(leftTable), rowCount(rightTable),
  ]);

  const candidates: Array<{ left: string; right: string; nameScore: number }> = [];
  for (const lc of leftCols) {
    for (const rc of rightCols) {
      if (lc.type !== rc.type && !(isNumericType(lc.type) && isNumericType(rc.type))) continue;
      const nameScore = nameSimilarity(lc.name, rc.name);
      if (nameScore >= 0.3) candidates.push({ left: lc.name, right: rc.name, nameScore });
    }
  }

  candidates.sort((a, b) => b.nameScore - a.nameScore);
  const topCandidates = candidates.slice(0, 10);

  const suggestions: JoinSuggestion[] = [];
  for (const c of topCandidates) {
    const [leftVals, rightVals] = await Promise.all([
      sampleValues(leftTable, c.left, sampleSize),
      sampleValues(rightTable, c.right, sampleSize),
    ]);
    const overlap = jaccard(leftVals, rightVals);
    const totalScore = c.nameScore * 0.3 + overlap * 0.7;

    const estimatedMatchRate = overlap;
    const joinType: 'inner' | 'left' | 'right' | 'outer' =
      estimatedMatchRate > 0.8 ? 'inner' :
      estimatedMatchRate > 0.3 ? 'left' : 'outer';

    if (totalScore >= 0.2) {
      suggestions.push({
        leftColumn: c.left, rightColumn: c.right,
        nameScore: c.nameScore, valueOverlap: overlap, totalScore,
        joinType, leftRows, rightRows, estimatedMatchRate,
      });
    }
  }

  return suggestions.sort((a, b) => b.totalScore - a.totalScore).slice(0, 5);
}

function isNumericType(t: string): boolean {
  return /NUMBER|FLOAT|INTEGER|DECIMAL/.test(t);
}

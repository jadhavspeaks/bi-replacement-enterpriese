import { createCipheriv, createDecipheriv, randomBytes } from 'crypto';

const ALGORITHM = 'aes-256-gcm';
const IV_LENGTH = 12;
const AUTH_TAG_LENGTH = 16;
const ENCODING = 'base64' as const;

function getEncryptionKey(): Buffer {
  const key = process.env.ENCRYPTION_KEY;
  if (!key) {
    throw new Error('ENCRYPTION_KEY environment variable is required');
  }
  const keyBuffer = Buffer.from(key, 'hex');
  if (keyBuffer.length !== 32) {
    throw new Error('ENCRYPTION_KEY must be exactly 32 bytes (64 hex characters)');
  }
  return keyBuffer;
}

export function encrypt(plainText: string): string {
  const key = getEncryptionKey();
  const iv = randomBytes(IV_LENGTH);
  const cipher = createCipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  });

  let encrypted = cipher.update(plainText, 'utf8', ENCODING);
  encrypted += cipher.final(ENCODING);

  const authTag = cipher.getAuthTag();

  // Format: iv:authTag:encryptedData (all base64)
  return [
    iv.toString(ENCODING),
    authTag.toString(ENCODING),
    encrypted,
  ].join(':');
}

export function decrypt(encryptedText: string): string {
  const key = getEncryptionKey();

  const parts = encryptedText.split(':');
  if (parts.length !== 3) {
    throw new Error('Invalid encrypted text format');
  }

  const [ivStr, authTagStr, dataStr] = parts;
  const iv = Buffer.from(ivStr, ENCODING);
  const authTag = Buffer.from(authTagStr, ENCODING);

  if (iv.length !== IV_LENGTH) {
    throw new Error('Invalid IV length');
  }
  if (authTag.length !== AUTH_TAG_LENGTH) {
    throw new Error('Invalid auth tag length');
  }

  const decipher = createDecipheriv(ALGORITHM, key, iv, {
    authTagLength: AUTH_TAG_LENGTH,
  });
  decipher.setAuthTag(authTag);

  let decrypted = decipher.update(dataStr, ENCODING, 'utf8');
  decrypted += decipher.final('utf8');

  return decrypted;
}

export function encryptJson(data: Record<string, unknown>): string {
  return encrypt(JSON.stringify(data));
}

export function decryptJson<T = Record<string, unknown>>(encryptedText: string): T {
  const decrypted = decrypt(encryptedText);
  return JSON.parse(decrypted) as T;
}

export function maskConfig(config: Record<string, unknown>): Record<string, unknown> {
  const masked: Record<string, unknown> = {};
  const sensitiveKeys = [
    'password', 'secret', 'token', 'key', 'credentials',
    'apiKeyValue', 'bearerToken', 'basicPassword',
    'clientSecret', 'secretAccessKey', 'secretValue',
  ];

  for (const [k, v] of Object.entries(config)) {
    const isSecret = sensitiveKeys.some(
      (sk) => k.toLowerCase().includes(sk.toLowerCase()),
    );
    if (isSecret && typeof v === 'string' && v.length > 0) {
      masked[k] = v.length > 4
        ? '****' + v.slice(-4)
        : '****';
    } else if (typeof v === 'object' && v !== null && !Array.isArray(v)) {
      masked[k] = maskConfig(v as Record<string, unknown>);
    } else {
      masked[k] = v;
    }
  }

  return masked;
}

import type { Hierarchy, DrillState } from '@nexusbi/shared-types';

/**
 * Drill-down state management. Pure functions — UI holds state in Zustand.
 */

export function drillDown(
  state: DrillState,
  hierarchy: Hierarchy,
  clickedValue: unknown,
): DrillState {
  if (state.currentLevel >= hierarchy.levels.length - 1) return state;
  return {
    ...state,
    currentLevel: state.currentLevel + 1,
    filterPath: [...state.filterPath, { level: state.currentLevel, value: clickedValue }],
  };
}

export function drillUp(state: DrillState): DrillState {
  if (state.currentLevel === 0) return state;
  return {
    ...state,
    currentLevel: state.currentLevel - 1,
    filterPath: state.filterPath.slice(0, -1),
  };
}

export function jumpToLevel(state: DrillState, level: number): DrillState {
  const clamped = Math.max(0, level);
  return {
    ...state,
    currentLevel: clamped,
    filterPath: state.filterPath.slice(0, clamped),
  };
}

export function currentDimension(state: DrillState, hierarchy: Hierarchy): string {
  return hierarchy.levels[Math.min(state.currentLevel, hierarchy.levels.length - 1)];
}

export function buildDrillFilters(
  state: DrillState,
  hierarchy: Hierarchy,
): Array<{ dimension: string; operator: 'equals'; values: unknown[] }> {
  return state.filterPath.map((p) => ({
    dimension: hierarchy.levels[p.level],
    operator: 'equals' as const,
    values: [p.value],
  }));
}

export function breadcrumbs(
  state: DrillState,
  hierarchy: Hierarchy,
): Array<{ level: number; dimension: string; value: unknown | null; isActive: boolean }> {
  const items: Array<{ level: number; dimension: string; value: unknown | null; isActive: boolean }> = [];
  for (let i = 0; i <= state.currentLevel; i++) {
    const filterEntry = state.filterPath.find((p) => p.level === i);
    items.push({
      level: i,
      dimension: hierarchy.levels[i],
      value: filterEntry?.value ?? null,
      isActive: i === state.currentLevel,
    });
  }
  return items;
}

export function initDrillState(widgetId: string, hierarchy: Hierarchy): DrillState {
  return {
    widgetId,
    hierarchyId: hierarchy.hierId,
    currentLevel: 0,
    filterPath: [],
  };
}

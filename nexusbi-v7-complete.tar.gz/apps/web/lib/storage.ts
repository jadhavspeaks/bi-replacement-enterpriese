/**
 * Local filesystem storage — replaces MinIO for zero-Docker deployments.
 * Files are stored under STORAGE_ROOT (default: ./data/storage/).
 * Same exported API as minio-client.ts so consumers only change the import path.
 */

import { promises as fs } from 'fs';
import path from 'path';
import { Readable } from 'stream';

const STORAGE_ROOT = process.env.STORAGE_ROOT || path.join(process.cwd(), 'data', 'storage');

const DEFAULT_BUCKET = 'nexusbi-files';
const TABLEAU_BUCKET = 'nexusbi-tableau';
const EXPORT_BUCKET = 'nexusbi-exports';
const TEMPLATE_BUCKET = 'nexusbi-templates';

function bucketPath(bucketName: string): string {
  return path.join(STORAGE_ROOT, bucketName);
}

function objectPath(bucketName: string, objectName: string): string {
  return path.join(STORAGE_ROOT, bucketName, objectName);
}

export async function ensureBucket(bucketName: string): Promise<void> {
  const dir = bucketPath(bucketName);
  await fs.mkdir(dir, { recursive: true });
}

export async function initBuckets(): Promise<void> {
  await ensureBucket(DEFAULT_BUCKET);
  await ensureBucket(TABLEAU_BUCKET);
  await ensureBucket(EXPORT_BUCKET);
  await ensureBucket(TEMPLATE_BUCKET);
}

export async function uploadFile(
  bucketName: string,
  objectName: string,
  data: Buffer | Readable,
  _size?: number,
  _contentType?: string,
): Promise<string> {
  await ensureBucket(bucketName);

  const filePath = objectPath(bucketName, objectName);
  const dir = path.dirname(filePath);
  await fs.mkdir(dir, { recursive: true });

  if (Buffer.isBuffer(data)) {
    await fs.writeFile(filePath, data);
  } else {
    const chunks: Buffer[] = [];
    for await (const chunk of data) {
      chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk));
    }
    await fs.writeFile(filePath, Buffer.concat(chunks));
  }

  return `${bucketName}/${objectName}`;
}

export async function downloadFile(
  bucketName: string,
  objectName: string,
): Promise<Buffer> {
  const filePath = objectPath(bucketName, objectName);
  return fs.readFile(filePath);
}

export async function getFileStream(
  bucketName: string,
  objectName: string,
): Promise<Readable> {
  const buffer = await downloadFile(bucketName, objectName);
  return Readable.from(buffer);
}

export async function deleteFile(
  bucketName: string,
  objectName: string,
): Promise<void> {
  const filePath = objectPath(bucketName, objectName);
  try {
    await fs.unlink(filePath);
  } catch (err) {
    if ((err as NodeJS.ErrnoException).code !== 'ENOENT') throw err;
  }
}

export async function getPresignedUrl(
  bucketName: string,
  objectName: string,
  _expirySeconds: number = 3600,
): Promise<string> {
  const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';
  return `${baseUrl}/api/files/serve?bucket=${encodeURIComponent(bucketName)}&key=${encodeURIComponent(objectName)}`;
}

export async function fileExists(
  bucketName: string,
  objectName: string,
): Promise<boolean> {
  try {
    await fs.access(objectPath(bucketName, objectName));
    return true;
  } catch {
    return false;
  }
}

export async function getFileSize(
  bucketName: string,
  objectName: string,
): Promise<number> {
  const stat = await fs.stat(objectPath(bucketName, objectName));
  return stat.size;
}

export function buildObjectName(tenantId: string, prefix: string, fileName: string): string {
  const timestamp = Date.now();
  const sanitized = fileName.replace(/[^a-zA-Z0-9._-]/g, '_');
  return `${tenantId}/${prefix}/${timestamp}_${sanitized}`;
}

export const BUCKETS = {
  files: DEFAULT_BUCKET,
  tableau: TABLEAU_BUCKET,
  exports: EXPORT_BUCKET,
  templates: TEMPLATE_BUCKET,
} as const;

export function getStorageRoot(): string {
  return STORAGE_ROOT;
}

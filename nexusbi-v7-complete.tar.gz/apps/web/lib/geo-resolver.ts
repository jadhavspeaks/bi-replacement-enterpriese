import type { GeoResolution, GeoFeature } from '@nexusbi/shared-types';

/**
 * Geographic resolver. Minimal embedded lookup for common cases.
 * For broader coverage, swap in `@turf/turf` + `world-atlas` TopoJSON at runtime.
 */

const COUNTRIES_ISO2: Record<string, GeoFeature> = {
  US: { id: 'US', name: 'United States', iso2: 'US', iso3: 'USA', bbox: [-125, 24, -66, 49] },
  GB: { id: 'GB', name: 'United Kingdom', iso2: 'GB', iso3: 'GBR', bbox: [-8, 49, 2, 59] },
  DE: { id: 'DE', name: 'Germany', iso2: 'DE', iso3: 'DEU', bbox: [5, 47, 15, 55] },
  FR: { id: 'FR', name: 'France', iso2: 'FR', iso3: 'FRA', bbox: [-5, 41, 10, 51] },
  JP: { id: 'JP', name: 'Japan', iso2: 'JP', iso3: 'JPN', bbox: [129, 31, 146, 46] },
  CN: { id: 'CN', name: 'China', iso2: 'CN', iso3: 'CHN', bbox: [73, 18, 135, 54] },
  IN: { id: 'IN', name: 'India', iso2: 'IN', iso3: 'IND', bbox: [68, 6, 97, 36] },
  BR: { id: 'BR', name: 'Brazil', iso2: 'BR', iso3: 'BRA', bbox: [-74, -34, -34, 6] },
  AU: { id: 'AU', name: 'Australia', iso2: 'AU', iso3: 'AUS', bbox: [112, -44, 154, -10] },
  CA: { id: 'CA', name: 'Canada', iso2: 'CA', iso3: 'CAN', bbox: [-141, 41, -52, 84] },
  MX: { id: 'MX', name: 'Mexico', iso2: 'MX', iso3: 'MEX', bbox: [-118, 14, -86, 33] },
  SG: { id: 'SG', name: 'Singapore', iso2: 'SG', iso3: 'SGP', bbox: [103.6, 1.1, 104.1, 1.5] },
  KR: { id: 'KR', name: 'South Korea', iso2: 'KR', iso3: 'KOR', bbox: [125, 33, 131, 39] },
  ID: { id: 'ID', name: 'Indonesia', iso2: 'ID', iso3: 'IDN', bbox: [95, -11, 141, 6] },
  NZ: { id: 'NZ', name: 'New Zealand', iso2: 'NZ', iso3: 'NZL', bbox: [166, -47, 179, -34] },
};

const ISO3_TO_ISO2: Record<string, string> = {};
for (const iso2 of Object.keys(COUNTRIES_ISO2)) {
  const c = COUNTRIES_ISO2[iso2];
  if (c.iso3) ISO3_TO_ISO2[c.iso3] = iso2;
}

const NAME_TO_ISO2: Record<string, string> = {};
for (const iso2 of Object.keys(COUNTRIES_ISO2)) {
  const c = COUNTRIES_ISO2[iso2];
  NAME_TO_ISO2[c.name.toLowerCase()] = iso2;
  NAME_TO_ISO2[c.name.toLowerCase().replace(/\s/g, '')] = iso2;
}

const US_STATE_NAMES: Record<string, string> = {
  alabama: 'AL', alaska: 'AK', arizona: 'AZ', arkansas: 'AR', california: 'CA',
  colorado: 'CO', connecticut: 'CT', delaware: 'DE', florida: 'FL', georgia: 'GA',
  hawaii: 'HI', idaho: 'ID', illinois: 'IL', indiana: 'IN', iowa: 'IA', kansas: 'KS',
  kentucky: 'KY', louisiana: 'LA', maine: 'ME', maryland: 'MD', massachusetts: 'MA',
  michigan: 'MI', minnesota: 'MN', mississippi: 'MS', missouri: 'MO', montana: 'MT',
  nebraska: 'NE', nevada: 'NV', 'new hampshire': 'NH', 'new jersey': 'NJ',
  'new mexico': 'NM', 'new york': 'NY', 'north carolina': 'NC', 'north dakota': 'ND',
  ohio: 'OH', oklahoma: 'OK', oregon: 'OR', pennsylvania: 'PA', 'rhode island': 'RI',
  'south carolina': 'SC', 'south dakota': 'SD', tennessee: 'TN', texas: 'TX',
  utah: 'UT', vermont: 'VT', virginia: 'VA', washington: 'WA', 'west virginia': 'WV',
  wisconsin: 'WI', wyoming: 'WY',
};

export function resolveGeo(value: unknown, resolution: GeoResolution): GeoFeature | null {
  if (value === null || value === undefined) return null;
  const str = String(value).trim();

  switch (resolution) {
    case 'country_iso2':
      return COUNTRIES_ISO2[str.toUpperCase()] ?? null;
    case 'country_iso3': {
      const iso2 = ISO3_TO_ISO2[str.toUpperCase()];
      return iso2 ? COUNTRIES_ISO2[iso2] : null;
    }
    case 'country_name': {
      const iso2 = NAME_TO_ISO2[str.toLowerCase()];
      return iso2 ? COUNTRIES_ISO2[iso2] : null;
    }
    case 'us_state_abbr':
      return { id: str.toUpperCase(), name: str.toUpperCase(), bbox: [-125, 24, -66, 49] };
    case 'us_state_name': {
      const abbr = US_STATE_NAMES[str.toLowerCase()];
      return abbr ? { id: abbr, name: str, bbox: [-125, 24, -66, 49] } : null;
    }
    case 'lat_lng': {
      const match = str.match(/(-?\d+(?:\.\d+)?)\s*,\s*(-?\d+(?:\.\d+)?)/);
      if (match) {
        const lat = parseFloat(match[1]); const lng = parseFloat(match[2]);
        return { id: str, name: str, bbox: [lng, lat, lng, lat] };
      }
      return null;
    }
    default:
      return null;
  }
}

export function getBoundingBox(features: GeoFeature[]): [number, number, number, number] {
  if (features.length === 0) return [-180, -90, 180, 90];
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const f of features) {
    if (f.bbox[0] < minX) minX = f.bbox[0];
    if (f.bbox[1] < minY) minY = f.bbox[1];
    if (f.bbox[2] > maxX) maxX = f.bbox[2];
    if (f.bbox[3] > maxY) maxY = f.bbox[3];
  }
  return [minX, minY, maxX, maxY];
}

export function computeChoroplethScale(
  values: number[],
  bins = 5,
): { breakpoints: number[]; colors: string[] } {
  if (values.length === 0) return { breakpoints: [], colors: [] };
  const sorted = [...values].sort((a, b) => a - b);
  const breakpoints: number[] = [];
  for (let i = 1; i < bins; i++) {
    const idx = Math.floor((i / bins) * sorted.length);
    breakpoints.push(sorted[idx]);
  }
  const baseColors = ['#fef3c7', '#fde68a', '#fbbf24', '#f59e0b', '#d97706', '#b45309', '#92400e'];
  const colors = baseColors.slice(0, bins);
  return { breakpoints, colors };
}

/**
 * Hive / Impala connector — uses the generic `hive-driver` npm package
 * (NOT `@cubejs-backend/hive-driver`). Dynamically imported so the app installs
 * cleanly if the package isn't in your artifactory; queries against Hive/Impala
 * data sources will throw a clear error at runtime in that case.
 *
 * Supports NOSASL, PLAIN, and KERBEROS auth mechanisms.
 */

import { decrypt } from '@/lib/encryption';

export interface HiveConnConfig {
  host: string;
  port: number;
  database: string;
  username?: string;
  password?: string;
  authMechanism: 'NOSASL' | 'PLAIN' | 'KERBEROS';
  kerberosPrincipal?: string;
  kerberosKeytab?: string;
  ssl?: boolean;
}

export async function runHiveQuery(
  cfg: HiveConnConfig,
  sql: string,
): Promise<Array<Record<string, unknown>>> {
  let hiveDriver: typeof import('hive-driver');
  try {
    hiveDriver = await import('hive-driver');
  } catch {
    throw new Error(
      'hive-driver not installed. Run: cd apps/web && npm install hive-driver',
    );
  }

  const { TCLIService, TCLIService_types } = hiveDriver.thrift;
  const client = new hiveDriver.HiveClient(TCLIService, TCLIService_types);

  const connConfig = {
    host: cfg.host,
    port: cfg.port,
    options: {
      https: cfg.ssl === true,
    },
  };

  let authProvider: unknown;
  if (cfg.authMechanism === 'KERBEROS' && cfg.kerberosPrincipal) {
    authProvider = new hiveDriver.auth.KerberosTcpAuthentication({
      username: cfg.kerberosPrincipal,
      password: '',
    });
  } else if (cfg.authMechanism === 'PLAIN' && cfg.username) {
    authProvider = new hiveDriver.auth.PlainTcpAuthentication({
      username: cfg.username,
      password: cfg.password || '',
    });
  } else {
    authProvider = new hiveDriver.auth.NoSaslAuthentication();
  }

  try {
    // `client.connect(connConfig, authProvider)` — types vary between hive-driver versions.
    // Cast to a callable-shaped type to allow the call across versions.
    await (client as unknown as {
      connect: (cfg: unknown, auth: unknown) => Promise<unknown>;
    }).connect(connConfig, authProvider);

    const session = await (client as unknown as {
      openSession: (req: unknown) => Promise<unknown>;
    }).openSession({
      client_protocol: TCLIService_types.TProtocolVersion.HIVE_CLI_SERVICE_PROTOCOL_V10,
    });

    const statement = await (session as unknown as {
      executeStatement: (sql: string, opts: unknown) => Promise<unknown>;
    }).executeStatement(sql, { runAsync: true });

    const rows = await (statement as unknown as { fetchAll: () => Promise<unknown[]> }).fetchAll();
    await (statement as unknown as { close: () => Promise<unknown> }).close();
    await (session as unknown as { close: () => Promise<unknown> }).close();

    return rows as Array<Record<string, unknown>>;
  } finally {
    try {
      await (client as unknown as { close: () => Promise<unknown> }).close();
    } catch {
      /* ignore */
    }
  }
}

export function decryptConfig(encrypted: string): HiveConnConfig {
  return JSON.parse(decrypt(encrypted)) as HiveConnConfig;
}

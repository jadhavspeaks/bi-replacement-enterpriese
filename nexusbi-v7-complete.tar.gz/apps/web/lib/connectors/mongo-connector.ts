/**
 * MongoDB connector — uses the official `mongodb` npm package.
 * Dynamically imported so the app installs cleanly even if mongodb isn't in
 * your artifactory; queries against MongoDB data sources will throw a clear
 * error message at runtime in that case.
 */

import { decrypt } from '@/lib/encryption';

export interface MongoConnConfig {
  host?: string;
  port?: number;
  database: string;
  user?: string;
  password?: string;
  authSource?: string;
  ssl?: boolean;
  connectionString?: string;
}

export async function runMongoQuery(
  cfg: MongoConnConfig,
  collection: string,
  pipeline: Array<Record<string, unknown>>,
): Promise<Array<Record<string, unknown>>> {
  let mongodb: typeof import('mongodb');
  try {
    mongodb = await import('mongodb');
  } catch {
    throw new Error(
      'mongodb driver not installed. Run: cd apps/web && npm install mongodb',
    );
  }

  const uri =
    cfg.connectionString ||
    (cfg.user && cfg.password
      ? `mongodb://${encodeURIComponent(cfg.user)}:${encodeURIComponent(cfg.password)}@${cfg.host}:${cfg.port}/${cfg.database}?authSource=${cfg.authSource || 'admin'}`
      : `mongodb://${cfg.host}:${cfg.port}/${cfg.database}`);

  const client = new mongodb.MongoClient(uri, {
    serverSelectionTimeoutMS: 10000,
    tls: cfg.ssl === true,
  });

  try {
    await client.connect();
    const db = client.db(cfg.database);
    const result = await db.collection(collection).aggregate(pipeline).toArray();
    return result as Array<Record<string, unknown>>;
  } finally {
    try { await client.close(); } catch { /* ignore */ }
  }
}

export function decryptConfig(encrypted: string): MongoConnConfig {
  return JSON.parse(decrypt(encrypted)) as MongoConnConfig;
}

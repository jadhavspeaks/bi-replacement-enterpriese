/**
 * Oracle connector — uses oracledb (already a dep).
 * This is the primary execution engine. All staged file/API/MongoDB/Hive data
 * ends up in Oracle NB_STG_* tables before being queried from here.
 */

import oracledb from 'oracledb';
import { decrypt } from '@/lib/encryption';

export interface OracleConnConfig {
  host: string;
  port: number;
  serviceName: string;
  user: string;
  password: string;
}

export async function runOracleQuery(
  cfg: OracleConnConfig,
  sql: string,
  binds: Record<string, unknown> = {},
): Promise<Array<Record<string, unknown>>> {
  let conn: oracledb.Connection | null = null;
  try {
    conn = await oracledb.getConnection({
      user: cfg.user,
      password: cfg.password,
      connectString: `${cfg.host}:${cfg.port}/${cfg.serviceName}`,
    });
    const result = await conn.execute(sql, binds, { outFormat: oracledb.OUT_FORMAT_OBJECT });
    return (result.rows as Array<Record<string, unknown>>) || [];
  } finally {
    if (conn) {
      try { await conn.close(); } catch { /* ignore */ }
    }
  }
}

export function decryptConfig(encrypted: string): OracleConnConfig {
  return JSON.parse(decrypt(encrypted)) as OracleConnConfig;
}

/**
 * In-memory cache with TTL — replaces Redis for single-process deployments.
 * All functions exported here match the redis.ts contract so consumers
 * only need to change their import path from '@/lib/redis' to '@/lib/cache'.
 */

interface CacheEntry {
  value: string;
  expiresAt: number;
}

const store = new Map<string, CacheEntry>();
const MAX_ENTRIES = 10_000;

function now(): number {
  return Date.now();
}

function evictExpired(): void {
  const t = now();
  for (const [key, entry] of store) {
    if (entry.expiresAt <= t) {
      store.delete(key);
    }
  }
}

function evictIfFull(): void {
  if (store.size < MAX_ENTRIES) return;
  evictExpired();
  if (store.size < MAX_ENTRIES) return;
  const keysToDelete = Array.from(store.keys()).slice(0, Math.floor(MAX_ENTRIES * 0.2));
  for (const key of keysToDelete) {
    store.delete(key);
  }
}

// Run eviction every 30 seconds
if (typeof setInterval !== 'undefined') {
  setInterval(evictExpired, 30_000).unref?.();
}

// ── Key Helpers ──────────────────────────────────────────

export const CACHE_KEYS = {
  permissions: (userId: string, tenantId: string) => `perms:${userId}:${tenantId}`,
  config: (key: string) => `config:${key}`,
  datasource: (dsId: string) => `ds:${dsId}`,
  schema: (dsId: string) => `schema:${dsId}`,
  schedulerLock: (jobName: string) => `lock:scheduler:${jobName}`,
  cubeCache: (queryHash: string) => `cube:cache:${queryHash}`,
} as const;

export const CACHE_TTL = {
  permissions: 60,
  config: 60,
  datasource: 60,
  schema: 300,
  schedulerLock: 300,
  cubeCache: 300,
} as const;

// ── Core Operations ─────────────────────────────────────

export async function cacheGet(key: string): Promise<string | null> {
  const entry = store.get(key);
  if (!entry) return null;
  if (entry.expiresAt <= now()) {
    store.delete(key);
    return null;
  }
  return entry.value;
}

export async function cacheSet(key: string, value: string, ttlSeconds: number): Promise<void> {
  evictIfFull();
  store.set(key, { value, expiresAt: now() + ttlSeconds * 1000 });
}

export async function cacheDel(key: string): Promise<void> {
  store.delete(key);
}

// ── Cache Helpers ────────────────────────────────────────

export async function getCachedOrFetch<T>(
  key: string,
  ttlSeconds: number,
  fetcher: () => Promise<T>,
): Promise<T> {
  const cached = await cacheGet(key);
  if (cached !== null) {
    try {
      return JSON.parse(cached) as T;
    } catch {
      // Invalid cache, fall through to fetcher
    }
  }

  const value = await fetcher();
  await cacheSet(key, JSON.stringify(value), ttlSeconds);
  return value;
}

export async function invalidateCache(pattern: string): Promise<void> {
  if (pattern.includes('*')) {
    const prefix = pattern.replace(/\*.*$/, '');
    for (const key of store.keys()) {
      if (key.startsWith(prefix)) {
        store.delete(key);
      }
    }
  } else {
    store.delete(pattern);
  }
}

export async function acquireLock(
  lockKey: string,
  ttlSeconds: number = 300,
): Promise<boolean> {
  const existing = await cacheGet(lockKey);
  if (existing !== null) return false;
  await cacheSet(lockKey, '1', ttlSeconds);
  return true;
}

export async function releaseLock(lockKey: string): Promise<void> {
  store.delete(lockKey);
}

// ── Debug / Test Helpers ────────────────────────────────

export function cacheSize(): number {
  return store.size;
}

export function cacheClear(): void {
  store.clear();
}

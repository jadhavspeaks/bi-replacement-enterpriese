import type {
  ClusterConfig, ClusterResult,
  TrendLineConfig, TrendLineResult, TrendType,
} from '@nexusbi/shared-types';

/** k-means++ initialisation and Lloyd iteration. */
export function kMeans(
  points: Array<{ x: number; y: number }>,
  config: ClusterConfig,
): ClusterResult {
  const k = Math.max(1, Math.min(config.k, points.length));
  const maxIter = config.maxIterations ?? 50;
  const n = points.length;

  if (n === 0) return { assignments: [], centroids: [], inertia: 0 };

  // k-means++ init
  const centroids: Array<{ x: number; y: number }> = [points[Math.floor(Math.random() * n)]];
  while (centroids.length < k) {
    const distances = points.map((p) => {
      let minD = Infinity;
      for (const c of centroids) {
        const d = (p.x - c.x) ** 2 + (p.y - c.y) ** 2;
        if (d < minD) minD = d;
      }
      return minD;
    });
    const sum = distances.reduce((a, b) => a + b, 0);
    if (sum === 0) { centroids.push(points[Math.floor(Math.random() * n)]); continue; }
    const r = Math.random() * sum;
    let acc = 0;
    for (let i = 0; i < distances.length; i++) {
      acc += distances[i];
      if (acc >= r) { centroids.push(points[i]); break; }
    }
  }

  const assignments = new Array<number>(n).fill(0);

  for (let iter = 0; iter < maxIter; iter++) {
    // assign step
    let changed = false;
    for (let i = 0; i < n; i++) {
      let bestK = 0;
      let bestD = Infinity;
      for (let c = 0; c < k; c++) {
        const d = (points[i].x - centroids[c].x) ** 2 + (points[i].y - centroids[c].y) ** 2;
        if (d < bestD) { bestD = d; bestK = c; }
      }
      if (assignments[i] !== bestK) { assignments[i] = bestK; changed = true; }
    }

    // update step
    const sums = Array.from({ length: k }, () => ({ x: 0, y: 0, n: 0 }));
    for (let i = 0; i < n; i++) {
      const c = assignments[i];
      sums[c].x += points[i].x;
      sums[c].y += points[i].y;
      sums[c].n += 1;
    }
    for (let c = 0; c < k; c++) {
      if (sums[c].n > 0) {
        centroids[c] = { x: sums[c].x / sums[c].n, y: sums[c].y / sums[c].n };
      }
    }

    if (!changed) break;
  }

  let inertia = 0;
  for (let i = 0; i < n; i++) {
    const c = centroids[assignments[i]];
    inertia += (points[i].x - c.x) ** 2 + (points[i].y - c.y) ** 2;
  }

  return { assignments, centroids, inertia };
}

/** Linear / polynomial / exponential / logarithmic regression for trend lines. */
export function computeTrendLine(
  points: Array<{ x: number; y: number }>,
  config: TrendLineConfig,
): TrendLineResult {
  if (points.length < 2) {
    return { type: config.type, equation: 'y = 0', rSquared: 0, points: [] };
  }

  switch (config.type) {
    case 'linear':
      return linearTrend(points);
    case 'polynomial':
      return polynomialTrend(points, config.polynomialDegree ?? 2);
    case 'exponential':
      return exponentialTrend(points);
    case 'logarithmic':
      return logarithmicTrend(points);
    default:
      return linearTrend(points);
  }
}

function linearTrend(points: Array<{ x: number; y: number }>): TrendLineResult {
  const n = points.length;
  let sumX = 0, sumY = 0, sumXY = 0, sumXX = 0;
  for (const p of points) { sumX += p.x; sumY += p.y; sumXY += p.x * p.y; sumXX += p.x * p.x; }
  const denom = n * sumXX - sumX * sumX;
  const slope = denom === 0 ? 0 : (n * sumXY - sumX * sumY) / denom;
  const intercept = (sumY - slope * sumX) / n;
  const meanY = sumY / n;
  let ssTot = 0, ssRes = 0;
  for (const p of points) {
    const predicted = intercept + slope * p.x;
    ssTot += (p.y - meanY) ** 2;
    ssRes += (p.y - predicted) ** 2;
  }
  const rSquared = ssTot === 0 ? 0 : 1 - ssRes / ssTot;
  const trendPts = points.map((p) => ({ x: p.x, y: intercept + slope * p.x }));
  return {
    type: 'linear',
    equation: `y = ${slope.toFixed(4)}x + ${intercept.toFixed(4)}`,
    rSquared,
    points: trendPts,
  };
}

function polynomialTrend(points: Array<{ x: number; y: number }>, degree: number): TrendLineResult {
  const n = points.length;
  const d = Math.min(degree, n - 1);
  // Build Vandermonde matrix
  const X: number[][] = [];
  for (let i = 0; i < n; i++) {
    const row: number[] = [];
    for (let j = 0; j <= d; j++) row.push(points[i].x ** j);
    X.push(row);
  }
  const y = points.map((p) => p.y);
  // Normal equations: (X^T X) β = X^T y
  const XT = transpose(X);
  const XTX = multiply(XT, X);
  const XTy = multiplyVec(XT, y);
  const coefs = solveLinearSystem(XTX, XTy);

  const meanY = y.reduce((a, b) => a + b, 0) / n;
  let ssTot = 0, ssRes = 0;
  const trendPts: Array<{ x: number; y: number }> = [];
  for (const p of points) {
    let pred = 0;
    for (let j = 0; j <= d; j++) pred += coefs[j] * (p.x ** j);
    trendPts.push({ x: p.x, y: pred });
    ssTot += (p.y - meanY) ** 2;
    ssRes += (p.y - pred) ** 2;
  }
  const rSquared = ssTot === 0 ? 0 : 1 - ssRes / ssTot;

  const eqParts: string[] = [];
  for (let j = coefs.length - 1; j >= 0; j--) {
    const c = coefs[j];
    if (Math.abs(c) < 1e-9) continue;
    eqParts.push(j === 0 ? c.toFixed(3) : j === 1 ? `${c.toFixed(3)}x` : `${c.toFixed(3)}x^${j}`);
  }

  return { type: 'polynomial', equation: `y = ${eqParts.join(' + ')}`, rSquared, points: trendPts };
}

function exponentialTrend(points: Array<{ x: number; y: number }>): TrendLineResult {
  const valid = points.filter((p) => p.y > 0);
  if (valid.length < 2) return { type: 'exponential', equation: 'y = 0', rSquared: 0, points: [] };
  const transformed = valid.map((p) => ({ x: p.x, y: Math.log(p.y) }));
  const linear = linearTrend(transformed);
  const a = Math.exp(linear.points[0].y - (linear.equation.includes('x + ') ? 0 : 0));
  // Reconstruct: y = e^intercept * e^(slope * x) but we already have linear fit in log space
  const meanY = valid.reduce((a, b) => a + b.y, 0) / valid.length;
  let ssTot = 0, ssRes = 0;
  const match = linear.equation.match(/y = ([-\d.]+)x \+ ([-\d.]+)/);
  const slope = match ? parseFloat(match[1]) : 0;
  const intercept = match ? parseFloat(match[2]) : 0;
  const trendPts = valid.map((p) => {
    const pred = Math.exp(intercept) * Math.exp(slope * p.x);
    ssTot += (p.y - meanY) ** 2;
    ssRes += (p.y - pred) ** 2;
    return { x: p.x, y: pred };
  });
  const rSquared = ssTot === 0 ? 0 : 1 - ssRes / ssTot;
  return {
    type: 'exponential',
    equation: `y = ${Math.exp(intercept).toFixed(4)} × e^(${slope.toFixed(4)}x)`,
    rSquared, points: trendPts,
  };
}

function logarithmicTrend(points: Array<{ x: number; y: number }>): TrendLineResult {
  const valid = points.filter((p) => p.x > 0);
  if (valid.length < 2) return { type: 'logarithmic', equation: 'y = 0', rSquared: 0, points: [] };
  const transformed = valid.map((p) => ({ x: Math.log(p.x), y: p.y }));
  const linear = linearTrend(transformed);
  const match = linear.equation.match(/y = ([-\d.]+)x \+ ([-\d.]+)/);
  const slope = match ? parseFloat(match[1]) : 0;
  const intercept = match ? parseFloat(match[2]) : 0;
  const trendPts = valid.map((p) => ({ x: p.x, y: intercept + slope * Math.log(p.x) }));
  return {
    type: 'logarithmic',
    equation: `y = ${intercept.toFixed(4)} + ${slope.toFixed(4)} × ln(x)`,
    rSquared: linear.rSquared, points: trendPts,
  };
}

// ── Linear algebra helpers ──
function transpose(m: number[][]): number[][] {
  const rows = m.length, cols = m[0].length;
  const out: number[][] = Array.from({ length: cols }, () => new Array(rows).fill(0));
  for (let i = 0; i < rows; i++) for (let j = 0; j < cols; j++) out[j][i] = m[i][j];
  return out;
}
function multiply(a: number[][], b: number[][]): number[][] {
  const n = a.length, m = b[0].length, p = b.length;
  const out: number[][] = Array.from({ length: n }, () => new Array(m).fill(0));
  for (let i = 0; i < n; i++) for (let j = 0; j < m; j++) for (let k = 0; k < p; k++) out[i][j] += a[i][k] * b[k][j];
  return out;
}
function multiplyVec(a: number[][], b: number[]): number[] {
  const n = a.length, p = b.length;
  const out: number[] = new Array(n).fill(0);
  for (let i = 0; i < n; i++) for (let k = 0; k < p; k++) out[i] += a[i][k] * b[k];
  return out;
}
function solveLinearSystem(A: number[][], b: number[]): number[] {
  const n = A.length;
  const M: number[][] = A.map((row, i) => [...row, b[i]]);
  for (let i = 0; i < n; i++) {
    let maxRow = i;
    for (let k = i + 1; k < n; k++) {
      if (Math.abs(M[k][i]) > Math.abs(M[maxRow][i])) maxRow = k;
    }
    [M[i], M[maxRow]] = [M[maxRow], M[i]];
    if (Math.abs(M[i][i]) < 1e-12) continue;
    for (let k = i + 1; k < n; k++) {
      const factor = M[k][i] / M[i][i];
      for (let j = i; j <= n; j++) M[k][j] -= factor * M[i][j];
    }
  }
  const x = new Array(n).fill(0);
  for (let i = n - 1; i >= 0; i--) {
    let sum = M[i][n];
    for (let j = i + 1; j < n; j++) sum -= M[i][j] * x[j];
    x[i] = Math.abs(M[i][i]) < 1e-12 ? 0 : sum / M[i][i];
  }
  return x;
}

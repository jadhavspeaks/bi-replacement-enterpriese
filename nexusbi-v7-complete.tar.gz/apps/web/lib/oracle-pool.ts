/**
 * Compatibility shim. The DB layer now lives in lib/db/ and supports both
 * SQLite (default) and Oracle (opt-in via DB_BACKEND=oracle). Existing files
 * that import from '@/lib/oracle-pool' keep working unchanged — they are
 * actually getting the backend-agnostic facade under the hood.
 *
 * When you migrate a file, update its imports to '@/lib/db' instead.
 */

export {
  getOrInitPool,
  getOraclePool,
  initOraclePool,
  withConnection,
  withTransaction,
  clobToString,
  parseJsonClob,
  generateId,
  createOrgScopedQuery,
} from '@/lib/db';

export type { DbConnection, DbPool, DbBackend, OrgScopedQuery } from '@/lib/db';

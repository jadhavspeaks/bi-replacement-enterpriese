import type {
  FlowNode, FlowNodeType, FlowNodeExecutor, NodeValidationResult,
} from '@nexusbi/shared-types';
import type { ColumnSchemaEntry } from '@nexusbi/shared-types';

/** Registry of node executors. Each node type knows how to validate itself,
 *  generate Oracle SQL from upstream staging tables, and project an output schema. */

function col(name: string): string {
  return `"${name.toUpperCase().replace(/[^A-Z0-9_]/g, '_')}"`;
}

function table(name: string): string {
  return name.toUpperCase().replace(/[^A-Z0-9_]/g, '_');
}

// ── Input nodes ─────────────────────────────────────────────────────
const inputSourceExec: FlowNodeExecutor = {
  nodeType: 'input_source',
  validate(node) {
    const errors: string[] = [];
    const cfg = node.config as { dsId?: string; tableName?: string };
    if (!cfg.dsId) errors.push('Datasource is required');
    if (!cfg.tableName) errors.push('Table name is required');
    return { valid: errors.length === 0, errors, warnings: [] };
  },
  buildSQL(node) {
    const cfg = node.config as { tableName: string };
    return `SELECT * FROM ${table(cfg.tableName)}`;
  },
  outputSchema() { return []; },
};

const inputFileExec: FlowNodeExecutor = {
  nodeType: 'input_file',
  validate(node) {
    const cfg = node.config as { fileId?: string };
    return { valid: !!cfg.fileId, errors: cfg.fileId ? [] : ['fileId required'], warnings: [] };
  },
  buildSQL(node) {
    const cfg = node.config as { fileId: string };
    return `SELECT * FROM NB_STG_${cfg.fileId.toUpperCase()}`;
  },
  outputSchema() { return []; },
};

// ── Cleaning nodes ─────────────────────────────────────────────────
const cleanNullsExec: FlowNodeExecutor = {
  nodeType: 'clean_nulls',
  validate(node) {
    const cfg = node.config as { columns?: string[]; action?: string };
    const errors: string[] = [];
    if (!cfg.columns?.length) errors.push('Select at least one column');
    if (!cfg.action || !['remove', 'fill_zero', 'fill_mean', 'fill_prev'].includes(cfg.action)) {
      errors.push('Invalid action');
    }
    return { valid: errors.length === 0, errors, warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { columns: string[]; action: string };
    const src = inputs[0];
    if (cfg.action === 'remove') {
      const where = cfg.columns.map((c) => `${col(c)} IS NOT NULL`).join(' AND ');
      return `SELECT * FROM ${src} WHERE ${where}`;
    }
    if (cfg.action === 'fill_zero') {
      const selects = `* , ${cfg.columns.map((c) => `NVL(${col(c)}, 0) AS ${col(c + '_clean')}`).join(', ')}`;
      return `SELECT ${selects} FROM ${src}`;
    }
    if (cfg.action === 'fill_mean') {
      const meanSubqueries = cfg.columns
        .map((c) => `, NVL(${col(c)}, (SELECT AVG(${col(c)}) FROM ${src})) AS ${col(c + '_clean')}`)
        .join('');
      return `SELECT *${meanSubqueries} FROM ${src}`;
    }
    return `SELECT * FROM ${src}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

const cleanDuplicatesExec: FlowNodeExecutor = {
  nodeType: 'clean_duplicates',
  validate(node) {
    const cfg = node.config as { columns?: string[] };
    return { valid: !!cfg.columns?.length, errors: cfg.columns?.length ? [] : ['Select key columns'], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { columns: string[] };
    const keys = cfg.columns.map(col).join(', ');
    return `SELECT ${keys}, MAX(ROWID) AS keep_rowid FROM ${inputs[0]} GROUP BY ${keys}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

const renameColumnsExec: FlowNodeExecutor = {
  nodeType: 'rename_columns',
  validate(node) {
    const cfg = node.config as { renames?: Array<{ from: string; to: string }> };
    return { valid: !!cfg.renames?.length, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { renames: Array<{ from: string; to: string }> };
    const renameMap = new Map(cfg.renames.map((r) => [r.from.toUpperCase(), r.to]));
    return `SELECT * FROM ${inputs[0]}`;
  },
  outputSchema(node, inputs) {
    const cfg = node.config as { renames: Array<{ from: string; to: string }> };
    const inSchema = inputs[0] ?? [];
    const renameMap = new Map(cfg.renames.map((r) => [r.from, r.to]));
    return inSchema.map((c) => ({ ...c, name: renameMap.get(c.name) ?? c.name }));
  },
};

const changeTypeExec: FlowNodeExecutor = {
  nodeType: 'change_type',
  validate() { return { valid: true, errors: [], warnings: [] }; },
  buildSQL(node, inputs) {
    const cfg = node.config as { column: string; newType: 'number' | 'string' | 'date' };
    const typeMap: Record<string, string> = { number: 'NUMBER', string: 'VARCHAR2(4000)', date: 'TIMESTAMP' };
    return `SELECT *, CAST(${col(cfg.column)} AS ${typeMap[cfg.newType] ?? 'VARCHAR2(4000)'}) AS ${col(cfg.column + '_cast')} FROM ${inputs[0]}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

// ── Transform nodes ────────────────────────────────────────────────
const filterExec: FlowNodeExecutor = {
  nodeType: 'filter',
  validate(node) {
    const cfg = node.config as { condition?: string };
    return { valid: !!cfg.condition, errors: cfg.condition ? [] : ['Condition required'], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { condition: string };
    return `SELECT * FROM ${inputs[0]} WHERE ${cfg.condition}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

const sortExec: FlowNodeExecutor = {
  nodeType: 'sort',
  validate(node) {
    const cfg = node.config as { sortBy?: Array<{ column: string; dir: 'asc' | 'desc' }> };
    return { valid: !!cfg.sortBy?.length, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { sortBy: Array<{ column: string; dir: 'asc' | 'desc' }> };
    const orderBy = cfg.sortBy.map((s) => `${col(s.column)} ${s.dir.toUpperCase()}`).join(', ');
    return `SELECT * FROM ${inputs[0]} ORDER BY ${orderBy}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

const limitExec: FlowNodeExecutor = {
  nodeType: 'limit',
  validate(node) {
    const cfg = node.config as { n?: number };
    return { valid: (cfg.n ?? 0) > 0, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { n: number };
    return `SELECT * FROM ${inputs[0]} FETCH FIRST ${Math.floor(cfg.n)} ROWS ONLY`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

const sampleExec: FlowNodeExecutor = {
  nodeType: 'sample',
  validate(node) {
    const cfg = node.config as { pct?: number };
    return { valid: (cfg.pct ?? 0) > 0 && (cfg.pct ?? 100) <= 100, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { pct: number };
    return `SELECT * FROM ${inputs[0]} SAMPLE (${cfg.pct})`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

// ── Aggregation nodes ──────────────────────────────────────────────
const aggregateExec: FlowNodeExecutor = {
  nodeType: 'aggregate',
  validate(node) {
    const cfg = node.config as { groupBy?: string[]; aggs?: Array<{ fn: string; col: string; alias: string }> };
    return { valid: !!cfg.aggs?.length, errors: cfg.aggs?.length ? [] : ['Add at least one aggregation'], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { groupBy: string[]; aggs: Array<{ fn: string; col: string; alias: string }> };
    const groupCols = cfg.groupBy.map(col).join(', ');
    const aggCols = cfg.aggs.map((a) => {
      const fn = a.fn.toUpperCase();
      const expr = fn === 'COUNTD' ? `COUNT(DISTINCT ${col(a.col)})` : `${fn}(${col(a.col)})`;
      return `${expr} AS ${col(a.alias)}`;
    }).join(', ');
    if (cfg.groupBy.length === 0) {
      return `SELECT ${aggCols} FROM ${inputs[0]}`;
    }
    return `SELECT ${groupCols}, ${aggCols} FROM ${inputs[0]} GROUP BY ${groupCols}`;
  },
  outputSchema(node) {
    const cfg = node.config as { groupBy: string[]; aggs: Array<{ alias: string; fn: string }> };
    const out: ColumnSchemaEntry[] = [];
    for (const g of cfg.groupBy) out.push({ name: g, type: 'VARCHAR2(4000)', nullable: true, sampleValues: [] });
    for (const a of cfg.aggs) out.push({ name: a.alias, type: 'NUMBER(38,10)', nullable: true, sampleValues: [] });
    return out;
  },
};

const deriveColumnExec: FlowNodeExecutor = {
  nodeType: 'derive_column',
  validate(node) {
    const cfg = node.config as { expression?: string; alias?: string };
    return { valid: !!cfg.expression && !!cfg.alias, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { expression: string; alias: string };
    return `SELECT *, (${cfg.expression}) AS ${col(cfg.alias)} FROM ${inputs[0]}`;
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

// ── Pivot / unpivot ────────────────────────────────────────────────
const pivotExec: FlowNodeExecutor = {
  nodeType: 'pivot',
  validate(node) {
    const cfg = node.config as { keyColumn?: string; valueColumn?: string; agg?: string; pivotValues?: string[] };
    const errors: string[] = [];
    if (!cfg.keyColumn) errors.push('Key column required');
    if (!cfg.valueColumn) errors.push('Value column required');
    if (!cfg.pivotValues?.length) errors.push('Pivot values required');
    return { valid: errors.length === 0, errors, warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { keyColumn: string; valueColumn: string; agg: string; pivotValues: string[] };
    const vals = cfg.pivotValues.map((v) => `'${v.replace(/'/g, "''")}' AS ${col(v)}`).join(', ');
    const aggFn = (cfg.agg ?? 'SUM').toUpperCase();
    return `SELECT * FROM ${inputs[0]}
            PIVOT (${aggFn}(${col(cfg.valueColumn)}) FOR ${col(cfg.keyColumn)} IN (${vals}))`;
  },
  outputSchema() { return []; },
};

const unpivotExec: FlowNodeExecutor = {
  nodeType: 'unpivot',
  validate(node) {
    const cfg = node.config as { columns?: string[]; keyName?: string; valueName?: string };
    return { valid: !!cfg.columns?.length && !!cfg.keyName && !!cfg.valueName, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { columns: string[]; keyName: string; valueName: string };
    const cols = cfg.columns.map(col).join(', ');
    return `SELECT * FROM ${inputs[0]}
            UNPIVOT (${col(cfg.valueName)} FOR ${col(cfg.keyName)} IN (${cols}))`;
  },
  outputSchema() { return []; },
};

// ── Join / union ───────────────────────────────────────────────────
const joinExec: FlowNodeExecutor = {
  nodeType: 'join',
  validate(node) {
    const cfg = node.config as { onLeft?: string; onRight?: string; joinType?: string };
    const errors: string[] = [];
    if (!cfg.onLeft || !cfg.onRight) errors.push('Join columns required');
    return { valid: errors.length === 0, errors, warnings: [] };
  },
  buildSQL(node, inputs) {
    if (inputs.length < 2) throw new Error('Join requires 2 inputs');
    const cfg = node.config as { onLeft: string; onRight: string; joinType: 'inner' | 'left' | 'right' | 'outer' };
    const joinKw = (cfg.joinType ?? 'inner').toUpperCase().replace('OUTER', 'FULL OUTER');
    return `SELECT L.*, R.* FROM ${inputs[0]} L ${joinKw} JOIN ${inputs[1]} R ON L.${col(cfg.onLeft)} = R.${col(cfg.onRight)}`;
  },
  outputSchema() { return []; },
};

const unionExec: FlowNodeExecutor = {
  nodeType: 'union',
  validate(node) {
    const cfg = node.config as { mode?: 'union' | 'union_all' };
    return { valid: true, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    if (inputs.length < 2) throw new Error('Union requires 2 inputs');
    const cfg = node.config as { mode?: 'union' | 'union_all' };
    const kw = cfg.mode === 'union' ? 'UNION' : 'UNION ALL';
    return inputs.map((t) => `SELECT * FROM ${t}`).join(` ${kw} `);
  },
  outputSchema(_n, inputs) { return inputs[0] ?? []; },
};

// ── Output nodes ───────────────────────────────────────────────────
const outputOracleExec: FlowNodeExecutor = {
  nodeType: 'output_oracle',
  validate(node) {
    const cfg = node.config as { targetTable?: string };
    return { valid: !!cfg.targetTable, errors: cfg.targetTable ? [] : ['Target table required'], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { targetTable: string };
    return `CREATE TABLE ${table(cfg.targetTable)} AS SELECT * FROM ${inputs[0]}`;
  },
  outputSchema() { return []; },
};

const outputCubeExec: FlowNodeExecutor = {
  nodeType: 'output_cube',
  validate(node) {
    const cfg = node.config as { cubeName?: string; targetTable?: string };
    return { valid: !!cfg.cubeName && !!cfg.targetTable, errors: [], warnings: [] };
  },
  buildSQL(node, inputs) {
    const cfg = node.config as { targetTable: string };
    return `CREATE TABLE ${table(cfg.targetTable)} AS SELECT * FROM ${inputs[0]}`;
  },
  outputSchema() { return []; },
};

// ── Registry ───────────────────────────────────────────────────────
const REGISTRY: Record<FlowNodeType, FlowNodeExecutor> = {
  input_source: inputSourceExec,
  input_file: inputFileExec,
  input_api: inputSourceExec,
  input_extract: inputSourceExec,
  clean_nulls: cleanNullsExec,
  clean_duplicates: cleanDuplicatesExec,
  rename_columns: renameColumnsExec,
  change_type: changeTypeExec,
  trim_whitespace: {
    nodeType: 'trim_whitespace',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(_n, inputs) { return `SELECT * FROM ${inputs[0]}`; },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  filter: filterExec,
  sort: sortExec,
  limit: limitExec,
  sample: sampleExec,
  pivot: pivotExec,
  unpivot: unpivotExec,
  join: joinExec,
  union: unionExec,
  cross_join: {
    nodeType: 'cross_join',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(_n, inputs) { return `SELECT * FROM ${inputs[0]} CROSS JOIN ${inputs[1]}`; },
    outputSchema() { return []; },
  },
  aggregate: aggregateExec,
  derive_column: deriveColumnExec,
  split_column: {
    nodeType: 'split_column',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(node, inputs) {
      const cfg = node.config as { column: string; delim: string; maxParts?: number };
      const parts = Array.from({ length: cfg.maxParts ?? 3 }, (_, i) =>
        `REGEXP_SUBSTR(${col(cfg.column)}, '[^${cfg.delim}]+', 1, ${i + 1}) AS ${col(cfg.column + '_part' + (i + 1))}`).join(', ');
      return `SELECT *, ${parts} FROM ${inputs[0]}`;
    },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  concatenate: {
    nodeType: 'concatenate',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(node, inputs) {
      const cfg = node.config as { columns: string[]; separator: string; alias: string };
      const concat = cfg.columns.map(col).join(` || '${cfg.separator}' || `);
      return `SELECT *, ${concat} AS ${col(cfg.alias)} FROM ${inputs[0]}`;
    },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  date_part: {
    nodeType: 'date_part',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(node, inputs) {
      const cfg = node.config as { column: string; part: string; alias: string };
      return `SELECT *, EXTRACT(${cfg.part.toUpperCase()} FROM ${col(cfg.column)}) AS ${col(cfg.alias)} FROM ${inputs[0]}`;
    },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  date_trunc: {
    nodeType: 'date_trunc',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(node, inputs) {
      const cfg = node.config as { column: string; granularity: string; alias: string };
      return `SELECT *, TRUNC(${col(cfg.column)}, '${cfg.granularity.toUpperCase()}') AS ${col(cfg.alias)} FROM ${inputs[0]}`;
    },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  date_diff: {
    nodeType: 'date_diff',
    validate() { return { valid: true, errors: [], warnings: [] }; },
    buildSQL(node, inputs) {
      const cfg = node.config as { startCol: string; endCol: string; alias: string };
      return `SELECT *, (${col(cfg.endCol)} - ${col(cfg.startCol)}) AS ${col(cfg.alias)} FROM ${inputs[0]}`;
    },
    outputSchema(_n, inputs) { return inputs[0] ?? []; },
  },
  output_oracle: outputOracleExec,
  output_cube: outputCubeExec,
  output_export: outputOracleExec,
  output_csv: outputOracleExec,
};

export function getExecutor(nodeType: FlowNodeType): FlowNodeExecutor {
  const exec = REGISTRY[nodeType];
  if (!exec) throw new Error(`No executor registered for node type: ${nodeType}`);
  return exec;
}

export function validateNode(node: FlowNode, inputSchemas: ColumnSchemaEntry[][]): NodeValidationResult {
  return getExecutor(node.type).validate(node, inputSchemas);
}

export function buildNodeSQL(node: FlowNode, inputTables: string[]): string {
  return getExecutor(node.type).buildSQL(node, inputTables);
}

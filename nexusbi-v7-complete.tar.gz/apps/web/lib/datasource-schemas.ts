import { z } from 'zod';
import type { DataSourceType } from '@nexusbi/shared-types';

/**
 * NexusBI — Data source configuration schemas.
 *
 * Only 12 connector types are supported in this release:
 *   Databases:  oracle, mongodb
 *   Hadoop:     hive, impala (Thrift + Kerberos/PLAIN/NOSASL)
 *   Files:      file_csv, file_excel, file_json, file_parquet
 *   APIs:       api_rest, api_graphql, api_oauth_rest, api_webhook
 */

// ── Oracle ────────────────────────────────────────────────
export const OracleConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(1521),
  serviceName: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  schema: z.string().optional(),
});

// ── MongoDB ───────────────────────────────────────────────
export const MongoDBConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(27017),
  database: z.string().min(1),
  user: z.string().optional(),
  password: z.string().optional(),
  authSource: z.string().default('admin'),
  ssl: z.boolean().default(false),
  connectionString: z.string().optional(),
});

// ── Hive (Hadoop ecosystem) ───────────────────────────────
export const HiveConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(10000),
  database: z.string().default('default'),
  username: z.string().optional(),
  authMechanism: z.enum(['NOSASL', 'PLAIN', 'KERBEROS']).default('NOSASL'),
  kerberosPrincipal: z.string().optional(),
  kerberosKeytab: z.string().optional(),
});

// ── Impala (Hadoop ecosystem) ─────────────────────────────
export const ImpalaConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(21050),
  database: z.string().default('default'),
  username: z.string().optional(),
  authMechanism: z.enum(['NOSASL', 'PLAIN', 'KERBEROS']).default('NOSASL'),
  kerberosPrincipal: z.string().optional(),
  kerberosKeytab: z.string().optional(),
  ssl: z.boolean().default(false),
});

// ── Files (staged into Oracle NB_STG_*) ───────────────────
export const FileConfigSchema = z.object({
  fileName: z.string().min(1),
  delimiter: z.string().default(','),
  hasHeader: z.boolean().default(true),
  encoding: z.string().default('utf-8'),
  sheetName: z.string().optional(),
  skipRows: z.number().int().min(0).default(0),
});

// ── REST API ──────────────────────────────────────────────
export const ApiRestConfigSchema = z.object({
  baseUrl: z.string().url(),
  authMethod: z.enum(['none', 'api_key', 'bearer', 'basic']).default('none'),
  apiKeyHeader: z.string().optional(),
  apiKeyValue: z.string().optional(),
  bearerToken: z.string().optional(),
  basicUsername: z.string().optional(),
  basicPassword: z.string().optional(),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

// ── GraphQL API ───────────────────────────────────────────
export const ApiGraphqlConfigSchema = z.object({
  baseUrl: z.string().url(),
  authMethod: z.enum(['none', 'api_key', 'bearer', 'basic']).default('none'),
  apiKeyHeader: z.string().optional(),
  apiKeyValue: z.string().optional(),
  bearerToken: z.string().optional(),
  basicUsername: z.string().optional(),
  basicPassword: z.string().optional(),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

// ── OAuth2 REST API ───────────────────────────────────────
export const ApiOAuthRestConfigSchema = z.object({
  baseUrl: z.string().url(),
  tokenUrl: z.string().url(),
  clientId: z.string().min(1),
  clientSecret: z.string().min(1),
  scope: z.string().optional(),
  grantType: z.enum(['client_credentials', 'authorization_code']).default('client_credentials'),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

// ── Webhook ───────────────────────────────────────────────
export const ApiWebhookConfigSchema = z.object({
  secretHeader: z.string().default('X-Webhook-Secret'),
  secretValue: z.string().min(16),
  payloadPath: z.string().optional(),
});

// ── Master schema map ─────────────────────────────────────
export const DS_CONFIG_SCHEMAS = {
  oracle: OracleConfigSchema,
  mongodb: MongoDBConfigSchema,
  hive: HiveConfigSchema,
  impala: ImpalaConfigSchema,
  file_csv: FileConfigSchema,
  file_excel: FileConfigSchema,
  file_json: FileConfigSchema,
  file_parquet: FileConfigSchema,
  api_rest: ApiRestConfigSchema,
  api_graphql: ApiGraphqlConfigSchema,
  api_oauth_rest: ApiOAuthRestConfigSchema,
  api_webhook: ApiWebhookConfigSchema,
} as const satisfies Record<DataSourceType, z.ZodTypeAny>;

export type DsConfigSchemaMap = typeof DS_CONFIG_SCHEMAS;

export function getConfigSchema(dsType: DataSourceType): z.ZodTypeAny {
  const schema = DS_CONFIG_SCHEMAS[dsType];
  if (!schema) {
    throw new Error(`Unsupported data source type: ${dsType}`);
  }
  return schema;
}

export function validateDsConfig(
  dsType: DataSourceType,
  config: unknown,
): z.SafeParseReturnType<unknown, unknown> {
  return getConfigSchema(dsType).safeParse(config);
}

export const SUPPORTED_DATA_SOURCE_TYPES: DataSourceType[] = [
  'oracle',
  'mongodb',
  'hive',
  'impala',
  'file_csv',
  'file_excel',
  'file_json',
  'file_parquet',
  'api_rest',
  'api_graphql',
  'api_oauth_rest',
  'api_webhook',
];

import { NextResponse } from 'next/server';
import type { PermissionCode, SessionUser } from '@nexusbi/shared-types';
import { checkPermission } from '@/lib/rbac';
import type { ApiResponse } from '@nexusbi/shared-types';

export async function requirePermission(
  user: SessionUser,
  permission: PermissionCode,
): Promise<NextResponse<ApiResponse<never>> | null> {
  const allowed = await checkPermission(
    user.id,
    user.tenantId,
    user.roles,
    permission,
  );

  if (!allowed) {
    return NextResponse.json<ApiResponse<never>>(
      {
        success: false,
        error: {
          code: 'RBAC_DENIED',
          message: `Permission denied: ${permission}`,
          details: { requiredPermission: permission },
        },
      },
      { status: 403 },
    );
  }

  return null;
}

export async function requireAnyPermission(
  user: SessionUser,
  permissions: PermissionCode[],
): Promise<NextResponse<ApiResponse<never>> | null> {
  for (const permission of permissions) {
    const allowed = await checkPermission(
      user.id,
      user.tenantId,
      user.roles,
      permission,
    );
    if (allowed) return null;
  }

  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'RBAC_DENIED',
        message: `Permission denied: requires one of [${permissions.join(', ')}]`,
        details: { requiredPermissions: permissions },
      },
    },
    { status: 403 },
  );
}

export async function requireAllPermissions(
  user: SessionUser,
  permissions: PermissionCode[],
): Promise<NextResponse<ApiResponse<never>> | null> {
  for (const permission of permissions) {
    const denied = await requirePermission(user, permission);
    if (denied) return denied;
  }
  return null;
}

export function unauthorizedResponse(message: string = 'Unauthorized'): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'RBAC_DENIED',
        message,
      },
    },
    { status: 401 },
  );
}

export function forbiddenResponse(message: string = 'Forbidden'): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'RBAC_DENIED',
        message,
      },
    },
    { status: 403 },
  );
}

export function notFoundResponse(message: string = 'Not found'): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'NOT_FOUND',
        message,
      },
    },
    { status: 404 },
  );
}

export function invalidInputResponse(message: string, details?: Record<string, unknown>): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'INVALID_INPUT',
        message,
        details,
      },
    },
    { status: 400 },
  );
}

export function conflictResponse(message: string): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'CONFLICT',
        message,
      },
    },
    { status: 409 },
  );
}

export function internalErrorResponse(message: string = 'Internal server error'): NextResponse<ApiResponse<never>> {
  return NextResponse.json<ApiResponse<never>>(
    {
      success: false,
      error: {
        code: 'INTERNAL_ERROR',
        message,
      },
    },
    { status: 500 },
  );
}

/**
 * Compatibility alias used by older route files.
 * Prefer requirePermission directly in new code.
 */
export async function requireAuthAndPermission(
  user: SessionUser,
  permission: PermissionCode,
): Promise<NextResponse<ApiResponse<never>> | null> {
  return requirePermission(user, permission);
}

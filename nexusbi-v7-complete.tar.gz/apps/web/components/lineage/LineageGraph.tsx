'use client';

import { useEffect, useMemo, useCallback } from 'react';
import {
  ReactFlow,
  Background,
  Controls,
  MiniMap,
  useNodesState,
  useEdgesState,
  type Node,
  type Edge,
  Position,
  MarkerType,
} from '@xyflow/react';
import '@xyflow/react/dist/style.css';
import type { LineageGraph as LineageGraphType, LineageNodeType } from '@nexusbi/shared-types';

interface LineageGraphProps {
  graph: LineageGraphType;
}

const NODE_COLORS: Record<LineageNodeType, string> = {
  datasource: '#1e40af',
  table: '#059669',
  cube: '#7c3aed',
  measure: '#dc2626',
  dimension: '#ea580c',
  dashboard: '#0891b2',
  widget: '#64748b',
};

const NODE_STYLES: Record<LineageNodeType, React.CSSProperties> = {
  datasource: { background: '#dbeafe', border: '2px solid #1e40af', borderRadius: '8px', padding: '10px 16px' },
  table: { background: '#d1fae5', border: '2px solid #059669', borderRadius: '6px', padding: '8px 14px' },
  cube: { background: '#ede9fe', border: '2px solid #7c3aed', borderRadius: '12px', padding: '10px 16px' },
  measure: { background: '#fee2e2', border: '1px solid #dc2626', borderRadius: '4px', padding: '6px 12px', fontSize: '11px' },
  dimension: { background: '#ffedd5', border: '1px solid #ea580c', borderRadius: '4px', padding: '6px 12px', fontSize: '11px' },
  dashboard: { background: '#cffafe', border: '2px solid #0891b2', borderRadius: '8px', padding: '10px 16px' },
  widget: { background: '#f1f5f9', border: '1px solid #64748b', borderRadius: '4px', padding: '6px 12px', fontSize: '11px' },
};

function layoutNodes(graphNodes: LineageGraphType['nodes']): Node[] {
  const typeOrder: LineageNodeType[] = ['datasource', 'table', 'cube', 'measure', 'dimension', 'dashboard', 'widget'];
  const nodesByType = new Map<LineageNodeType, typeof graphNodes>();

  for (const node of graphNodes) {
    const list = nodesByType.get(node.type) || [];
    list.push(node);
    nodesByType.set(node.type, list);
  }

  const flowNodes: Node[] = [];
  let xOffset = 0;

  for (const type of typeOrder) {
    const nodesOfType = nodesByType.get(type) || [];
    let yOffset = 0;

    for (const node of nodesOfType) {
      const isSmall = ['measure', 'dimension', 'widget'].includes(type);
      flowNodes.push({
        id: node.id,
        position: { x: xOffset, y: yOffset },
        data: {
          label: (
            <div className="text-center">
              <div className="text-[10px] uppercase tracking-wider opacity-60 mb-0.5">{type}</div>
              <div className={isSmall ? 'text-xs' : 'text-sm font-medium'}>{node.label}</div>
            </div>
          ),
        },
        style: NODE_STYLES[type],
        sourcePosition: Position.Right,
        targetPosition: Position.Left,
      });

      yOffset += isSmall ? 50 : 80;
    }

    if (nodesOfType.length > 0) {
      xOffset += ['measure', 'dimension', 'widget'].includes(type) ? 200 : 260;
    }
  }

  return flowNodes;
}

function convertEdges(graphEdges: LineageGraphType['edges']): Edge[] {
  return graphEdges.map((edge) => ({
    id: edge.id,
    source: edge.source,
    target: edge.target,
    label: edge.label,
    type: 'smoothstep',
    animated: edge.label === 'queries',
    markerEnd: { type: MarkerType.ArrowClosed, width: 12, height: 12 },
    style: { stroke: '#94a3b8', strokeWidth: 1.5 },
    labelStyle: { fontSize: 10, fill: '#64748b' },
  }));
}

export function LineageGraph({ graph }: LineageGraphProps) {
  const initialNodes = useMemo(() => layoutNodes(graph.nodes), [graph.nodes]);
  const initialEdges = useMemo(() => convertEdges(graph.edges), [graph.edges]);

  const [nodes, setNodes, onNodesChange] = useNodesState(initialNodes);
  const [edges, setEdges, onEdgesChange] = useEdgesState(initialEdges);

  useEffect(() => {
    setNodes(layoutNodes(graph.nodes));
    setEdges(convertEdges(graph.edges));
  }, [graph, setNodes, setEdges]);

  return (
    <div className="h-[600px] w-full rounded-lg border bg-white">
      <ReactFlow
        nodes={nodes}
        edges={edges}
        onNodesChange={onNodesChange}
        onEdgesChange={onEdgesChange}
        fitView
        fitViewOptions={{ padding: 0.2 }}
        minZoom={0.1}
        maxZoom={2}
        proOptions={{ hideAttribution: true }}
      >
        <Background gap={20} size={1} color="#f1f5f9" />
        <Controls position="bottom-right" />
        <MiniMap
          nodeStrokeWidth={2}
          nodeColor={(node) => {
            const type = node.id.split(':')[0] as LineageNodeType;
            return NODE_COLORS[type] || '#64748b';
          }}
          maskColor="rgba(0,0,0,0.08)"
          position="bottom-left"
        />
      </ReactFlow>
    </div>
  );
}

'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Loader2, Wand2, Table2 } from 'lucide-react';
import type { IntrospectedTable } from '@nexusbi/shared-types';

interface AutoGenerateButtonProps {
  dsId: string;
  onGenerated?: (schemas: Array<{ cubeName: string; schemaJs: string }>) => void;
}

export function AutoGenerateButton({ dsId, onGenerated }: AutoGenerateButtonProps) {
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(false);
  const [generating, setGenerating] = useState(false);
  const [tables, setTables] = useState<IntrospectedTable[]>([]);
  const [selectedTables, setSelectedTables] = useState<Set<string>>(new Set());
  const [error, setError] = useState<string | null>(null);

  const handleIntrospect = useCallback(async () => {
    setLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/datasources/introspect', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ dsId }),
      });

      const data = await response.json();
      if (data.success && data.data) {
        setTables(data.data.tables || []);
        setSelectedTables(new Set(data.data.tables.map((t: IntrospectedTable) => t.tableName)));
        setOpen(true);
      } else {
        setError(data.error?.message || 'Introspection failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to introspect');
    }

    setLoading(false);
  }, [dsId]);

  const toggleTable = useCallback((tableName: string) => {
    setSelectedTables((prev) => {
      const next = new Set(prev);
      if (next.has(tableName)) {
        next.delete(tableName);
      } else {
        next.add(tableName);
      }
      return next;
    });
  }, []);

  const handleGenerate = useCallback(async () => {
    setGenerating(true);

    try {
      const selected = tables.filter((t) => selectedTables.has(t.tableName));
      const schemas: Array<{ cubeName: string; schemaJs: string }> = [];

      for (const table of selected) {
        const cubeName = table.tableName
          .split('_')
          .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
          .join('');

        const pkCol = table.columns.find((c) => c.isPrimaryKey);
        const measures: string[] = [];
        const dimensions: string[] = [];

        measures.push(`    count: {\n      type: \`count\`,\n      drillMembers: [${pkCol ? pkCol.columnName.toLowerCase() : ''}]\n    }`);

        for (const col of table.columns) {
          const name = col.columnName.toLowerCase().replace(/[^a-z0-9]/g, '_');
          const upperType = col.dataType.toUpperCase();
          const isNumeric = /NUMBER|INT|FLOAT|DOUBLE|DECIMAL|NUMERIC|REAL|MONEY/.test(upperType);
          const isDate = /DATE|TIMESTAMP|TIME/.test(upperType);
          const isBoolean = /BOOLEAN|BOOL|BIT/.test(upperType);

          if (isNumeric && !col.isPrimaryKey && !col.isForeignKey) {
            measures.push(`    ${name}: {\n      sql: \`\${CUBE}.${col.columnName}\`,\n      type: \`sum\`\n    }`);
          } else {
            const dimType = isDate ? 'time' : isNumeric ? 'number' : isBoolean ? 'boolean' : 'string';
            const dimLines = [
              `      sql: \`\${CUBE}.${col.columnName}\``,
              `      type: \`${dimType}\``,
            ];
            if (col.isPrimaryKey) dimLines.push(`      primaryKey: true`);
            dimensions.push(`    ${name}: {\n${dimLines.join(',\n')}\n    }`);
          }
        }

        const schemaJs = [
          `cube(\`${cubeName}\`, {`,
          `  sql: \`SELECT * FROM ${table.schemaName ? table.schemaName + '.' : ''}${table.tableName}\`,`,
          ``,
          `  measures: {`,
          measures.join(',\n\n'),
          `  },`,
          ``,
          `  dimensions: {`,
          dimensions.join(',\n\n'),
          `  }`,
          `});`,
        ].join('\n');

        schemas.push({ cubeName, schemaJs });
      }

      onGenerated?.(schemas);
      setOpen(false);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Generation failed');
    }

    setGenerating(false);
  }, [tables, selectedTables, onGenerated]);

  return (
    <>
      <Button variant="outline" onClick={handleIntrospect} disabled={loading}>
        {loading ? (
          <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Introspecting...</>
        ) : (
          <><Wand2 className="mr-2 h-4 w-4" />Auto-Generate Schemas</>
        )}
      </Button>

      {error && (
        <p className="text-xs text-destructive mt-1">{error}</p>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-w-lg">
          <DialogHeader>
            <DialogTitle>Select Tables for Schema Generation</DialogTitle>
          </DialogHeader>

          <ScrollArea className="max-h-80">
            <div className="space-y-2 pr-4">
              {tables.map((table) => (
                <div
                  key={table.tableName}
                  className="flex items-center gap-3 rounded-md border p-3 hover:bg-muted/50"
                >
                  <Checkbox
                    checked={selectedTables.has(table.tableName)}
                    onCheckedChange={() => toggleTable(table.tableName)}
                    id={`table-${table.tableName}`}
                  />
                  <Label htmlFor={`table-${table.tableName}`} className="flex-1 cursor-pointer">
                    <div className="flex items-center gap-2">
                      <Table2 className="h-4 w-4 text-muted-foreground" />
                      <span className="text-sm font-medium">{table.tableName}</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-0.5">
                      {table.columns.length} columns
                      {table.estimatedRowCount !== null && ` • ~${table.estimatedRowCount.toLocaleString()} rows`}
                    </p>
                  </Label>
                </div>
              ))}

              {tables.length === 0 && (
                <p className="text-sm text-muted-foreground text-center py-4">
                  No tables found. Make sure the datasource connection is active.
                </p>
              )}
            </div>
          </ScrollArea>

          <DialogFooter>
            <Button variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
            <Button onClick={handleGenerate} disabled={generating || selectedTables.size === 0}>
              {generating ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Generating...</>
              ) : (
                <>Generate {selectedTables.size} Schema(s)</>
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

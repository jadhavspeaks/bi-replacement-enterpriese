'use client';

import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Trash2 } from 'lucide-react';
import { MEASURE_TYPES, MEASURE_FORMATS, type MeasureType, type MeasureFormat } from '@nexusbi/shared-types';

interface MeasureDefinition {
  name: string;
  type: MeasureType;
  sql: string;
  title?: string;
  description?: string;
  format?: MeasureFormat;
}

interface MeasureBuilderProps {
  measures: MeasureDefinition[];
  onChange: (measures: MeasureDefinition[]) => void;
}

const EMPTY_MEASURE: MeasureDefinition = {
  name: '',
  type: 'count',
  sql: '',
  title: '',
  description: '',
  format: undefined,
};

export function MeasureBuilder({ measures, onChange }: MeasureBuilderProps) {
  const [expanded, setExpanded] = useState<number | null>(null);

  const addMeasure = () => {
    const newMeasures = [...measures, { ...EMPTY_MEASURE, name: `measure_${measures.length + 1}` }];
    onChange(newMeasures);
    setExpanded(newMeasures.length - 1);
  };

  const updateMeasure = (index: number, updates: Partial<MeasureDefinition>) => {
    const newMeasures = measures.map((m, i) => (i === index ? { ...m, ...updates } : m));
    onChange(newMeasures);
  };

  const removeMeasure = (index: number) => {
    onChange(measures.filter((_, i) => i !== index));
    if (expanded === index) setExpanded(null);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold">Measures ({measures.length})</h4>
        <Button type="button" variant="outline" size="sm" onClick={addMeasure}>
          <Plus className="mr-1 h-3 w-3" />
          Add Measure
        </Button>
      </div>

      {measures.map((measure, index) => (
        <Card key={index} className="border">
          <CardHeader
            className="p-3 cursor-pointer"
            onClick={() => setExpanded(expanded === index ? null : index)}
          >
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium">
                {measure.name || `Measure ${index + 1}`}
                <span className="ml-2 text-xs text-muted-foreground font-normal">
                  ({measure.type})
                </span>
              </CardTitle>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-destructive"
                onClick={(e) => { e.stopPropagation(); removeMeasure(index); }}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </CardHeader>

          {expanded === index && (
            <CardContent className="p-3 pt-0 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Name</Label>
                  <Input
                    placeholder="revenue"
                    value={measure.name}
                    onChange={(e) => updateMeasure(index, { name: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Type</Label>
                  <Select
                    value={measure.type}
                    onValueChange={(v) => updateMeasure(index, { type: v as MeasureType })}
                  >
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {MEASURE_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">SQL Expression</Label>
                <Textarea
                  placeholder="${CUBE}.amount"
                  value={measure.sql}
                  onChange={(e) => updateMeasure(index, { sql: e.target.value })}
                  rows={2}
                  className="font-mono text-xs"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Title (optional)</Label>
                  <Input
                    placeholder="Total Revenue"
                    value={measure.title || ''}
                    onChange={(e) => updateMeasure(index, { title: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Format (optional)</Label>
                  <Select
                    value={measure.format || ''}
                    onValueChange={(v) => updateMeasure(index, { format: (v || undefined) as MeasureFormat | undefined })}
                  >
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue placeholder="None" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">None</SelectItem>
                      {MEASURE_FORMATS.map((f) => (
                        <SelectItem key={f} value={f}>{f}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">Description (optional)</Label>
                <Input
                  placeholder="Brief description of this measure"
                  value={measure.description || ''}
                  onChange={(e) => updateMeasure(index, { description: e.target.value })}
                  className="h-8 text-sm"
                />
              </div>
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
}

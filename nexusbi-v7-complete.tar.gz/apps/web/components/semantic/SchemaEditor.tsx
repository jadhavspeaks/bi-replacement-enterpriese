'use client';

import { useState, useCallback } from 'react';
// Monaco editor removed — using textarea. Reinstall with 'npm i @monaco-editor/react' and swap back if rich editing is needed.
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Save, CheckCircle2, XCircle, Loader2, AlertTriangle } from 'lucide-react';

interface ValidationResult {
  valid: boolean;
  errors: Array<{ line: number | null; message: string; severity: string }>;
  warnings: Array<{ line: number | null; message: string; severity: string }>;
  cubeName: string | null;
  measuresCount: number;
  dimensionsCount: number;
}

interface SchemaEditorProps {
  schemaId?: string;
  dsId: string;
  initialValue?: string;
  cubeName?: string;
  onSave?: (schemaJs: string) => Promise<void>;
  readOnly?: boolean;
}

export function SchemaEditor({
  schemaId,
  dsId,
  initialValue = '',
  cubeName,
  onSave,
  readOnly = false,
}: SchemaEditorProps) {
  const [code, setCode] = useState(initialValue);
  const [saving, setSaving] = useState(false);
  const [validation, setValidation] = useState<ValidationResult | null>(null);
  const [dirty, setDirty] = useState(false);

  const handleChange = useCallback((value: string | undefined) => {
    const newCode = value || '';
    setCode(newCode);
    setDirty(newCode !== initialValue);
    setValidation(null);
  }, [initialValue]);

  const handleValidate = useCallback(async () => {
    try {
      // Client-side basic validation
      const errors: ValidationResult['errors'] = [];
      const warnings: ValidationResult['warnings'] = [];

      if (!code.match(/cube\s*\(/)) {
        errors.push({ line: null, message: 'Schema must be wrapped in a cube() call', severity: 'error' });
      }
      if (!code.match(/sql\s*:/)) {
        errors.push({ line: null, message: 'Missing required "sql" property', severity: 'error' });
      }
      if (!code.match(/measures\s*:\s*\{/)) {
        errors.push({ line: null, message: 'Missing "measures" section', severity: 'error' });
      }
      if (!code.match(/dimensions\s*:\s*\{/)) {
        errors.push({ line: null, message: 'Missing "dimensions" section', severity: 'error' });
      }
      if (!code.match(/primaryKey\s*:\s*true/)) {
        warnings.push({ line: null, message: 'No dimension marked as primaryKey', severity: 'warning' });
      }

      const cubeNameMatch = code.match(/cube\s*\(\s*[`'"]([\w]+)[`'"]/);
      const extractedName = cubeNameMatch ? cubeNameMatch[1] : null;

      setValidation({
        valid: errors.length === 0,
        errors,
        warnings,
        cubeName: extractedName,
        measuresCount: (code.match(/type\s*:\s*[`'"](?:count|sum|avg|min|max)/g) || []).length,
        dimensionsCount: (code.match(/type\s*:\s*[`'"](?:string|number|boolean|time|geo)/g) || []).length,
      });
    } catch {
      setValidation({
        valid: false,
        errors: [{ line: null, message: 'Validation failed', severity: 'error' }],
        warnings: [],
        cubeName: null,
        measuresCount: 0,
        dimensionsCount: 0,
      });
    }
  }, [code]);

  const handleSave = useCallback(async () => {
    if (!onSave) return;

    await handleValidate();

    setSaving(true);
    try {
      await onSave(code);
      setDirty(false);
    } catch {
      // error handled by parent
    }
    setSaving(false);
  }, [code, onSave, handleValidate]);

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-base">
            {cubeName ? `Schema: ${cubeName}` : 'Cube Schema Editor'}
          </CardTitle>
          <div className="flex items-center gap-2">
            {validation && (
              <div className="flex items-center gap-2">
                {validation.valid ? (
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                    <CheckCircle2 className="mr-1 h-3 w-3" />
                    Valid ({validation.measuresCount}m, {validation.dimensionsCount}d)
                  </Badge>
                ) : (
                  <Badge variant="outline" className="bg-red-50 text-red-700 border-red-200">
                    <XCircle className="mr-1 h-3 w-3" />
                    {validation.errors.length} error(s)
                  </Badge>
                )}
                {validation.warnings.length > 0 && (
                  <Badge variant="outline" className="bg-amber-50 text-amber-700 border-amber-200">
                    <AlertTriangle className="mr-1 h-3 w-3" />
                    {validation.warnings.length} warning(s)
                  </Badge>
                )}
              </div>
            )}
            {dirty && <Badge variant="secondary">Unsaved</Badge>}
            <Button variant="outline" size="sm" onClick={handleValidate}>
              Validate
            </Button>
            {!readOnly && (
              <Button size="sm" onClick={handleSave} disabled={saving || !dirty}>
                {saving ? (
                  <><Loader2 className="mr-1 h-3 w-3 animate-spin" />Saving...</>
                ) : (
                  <><Save className="mr-1 h-3 w-3" />Save</>
                )}
              </Button>
            )}
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-0">
        <div className="border-t">
          <textarea
            className="w-full h-[500px] font-mono text-xs p-3 bg-slate-950 text-slate-100 outline-none resize-none"
            value={code}
            onChange={(e) => handleChange(e.target.value)}
            readOnly={readOnly}
            spellCheck={false}
          />
        </div>

        {validation && (validation.errors.length > 0 || validation.warnings.length > 0) && (
          <div className="border-t p-3 max-h-40 overflow-y-auto">
            {validation.errors.map((err, i) => (
              <div key={`e${i}`} className="flex items-start gap-2 text-xs text-red-700 mb-1">
                <XCircle className="h-3 w-3 mt-0.5 shrink-0" />
                <span>{err.line ? `Line ${err.line}: ` : ''}{err.message}</span>
              </div>
            ))}
            {validation.warnings.map((warn, i) => (
              <div key={`w${i}`} className="flex items-start gap-2 text-xs text-amber-700 mb-1">
                <AlertTriangle className="h-3 w-3 mt-0.5 shrink-0" />
                <span>{warn.line ? `Line ${warn.line}: ` : ''}{warn.message}</span>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

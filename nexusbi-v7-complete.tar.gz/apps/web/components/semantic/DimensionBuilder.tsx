'use client';

import { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Trash2, Key } from 'lucide-react';
import { DIMENSION_TYPES, type DimensionType } from '@nexusbi/shared-types';

interface DimensionDefinition {
  name: string;
  type: DimensionType;
  sql: string;
  title?: string;
  description?: string;
  primaryKey?: boolean;
  shown?: boolean;
}

interface DimensionBuilderProps {
  dimensions: DimensionDefinition[];
  onChange: (dimensions: DimensionDefinition[]) => void;
}

const EMPTY_DIMENSION: DimensionDefinition = {
  name: '',
  type: 'string',
  sql: '',
  title: '',
  description: '',
  primaryKey: false,
  shown: true,
};

export function DimensionBuilder({ dimensions, onChange }: DimensionBuilderProps) {
  const [expanded, setExpanded] = useState<number | null>(null);

  const addDimension = () => {
    const newDims = [...dimensions, { ...EMPTY_DIMENSION, name: `dim_${dimensions.length + 1}` }];
    onChange(newDims);
    setExpanded(newDims.length - 1);
  };

  const updateDimension = (index: number, updates: Partial<DimensionDefinition>) => {
    const newDims = dimensions.map((d, i) => (i === index ? { ...d, ...updates } : d));
    // Ensure only one primary key
    if (updates.primaryKey) {
      newDims.forEach((d, i) => {
        if (i !== index) d.primaryKey = false;
      });
    }
    onChange(newDims);
  };

  const removeDimension = (index: number) => {
    onChange(dimensions.filter((_, i) => i !== index));
    if (expanded === index) setExpanded(null);
  };

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <h4 className="text-sm font-semibold">Dimensions ({dimensions.length})</h4>
        <Button type="button" variant="outline" size="sm" onClick={addDimension}>
          <Plus className="mr-1 h-3 w-3" />
          Add Dimension
        </Button>
      </div>

      {dimensions.map((dimension, index) => (
        <Card key={index} className="border">
          <CardHeader
            className="p-3 cursor-pointer"
            onClick={() => setExpanded(expanded === index ? null : index)}
          >
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium flex items-center gap-2">
                {dimension.primaryKey && <Key className="h-3 w-3 text-amber-500" />}
                {dimension.name || `Dimension ${index + 1}`}
                <span className="text-xs text-muted-foreground font-normal">
                  ({dimension.type})
                </span>
              </CardTitle>
              <Button
                type="button"
                variant="ghost"
                size="icon"
                className="h-7 w-7 text-destructive"
                onClick={(e) => { e.stopPropagation(); removeDimension(index); }}
              >
                <Trash2 className="h-3.5 w-3.5" />
              </Button>
            </div>
          </CardHeader>

          {expanded === index && (
            <CardContent className="p-3 pt-0 space-y-3">
              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1">
                  <Label className="text-xs">Name</Label>
                  <Input
                    placeholder="customer_id"
                    value={dimension.name}
                    onChange={(e) => updateDimension(index, { name: e.target.value })}
                    className="h-8 text-sm"
                  />
                </div>
                <div className="space-y-1">
                  <Label className="text-xs">Type</Label>
                  <Select
                    value={dimension.type}
                    onValueChange={(v) => updateDimension(index, { type: v as DimensionType })}
                  >
                    <SelectTrigger className="h-8 text-sm">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {DIMENSION_TYPES.map((t) => (
                        <SelectItem key={t} value={t}>{t}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-1">
                <Label className="text-xs">SQL Expression</Label>
                <Textarea
                  placeholder="${CUBE}.customer_id"
                  value={dimension.sql}
                  onChange={(e) => updateDimension(index, { sql: e.target.value })}
                  rows={2}
                  className="font-mono text-xs"
                />
              </div>

              <div className="space-y-1">
                <Label className="text-xs">Title (optional)</Label>
                <Input
                  placeholder="Customer ID"
                  value={dimension.title || ''}
                  onChange={(e) => updateDimension(index, { title: e.target.value })}
                  className="h-8 text-sm"
                />
              </div>

              <div className="flex flex-wrap gap-6">
                <div className="flex items-center gap-2">
                  <Switch
                    checked={dimension.primaryKey || false}
                    onCheckedChange={(checked) => updateDimension(index, { primaryKey: checked })}
                    id={`pk-${index}`}
                  />
                  <Label htmlFor={`pk-${index}`} className="text-xs">Primary Key</Label>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={dimension.shown !== false}
                    onCheckedChange={(checked) => updateDimension(index, { shown: checked })}
                    id={`shown-${index}`}
                  />
                  <Label htmlFor={`shown-${index}`} className="text-xs">Visible</Label>
                </div>
              </div>
            </CardContent>
          )}
        </Card>
      ))}
    </div>
  );
}

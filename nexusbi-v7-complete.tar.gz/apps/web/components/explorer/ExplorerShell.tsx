'use client';

import { DataSourcePicker } from '@/components/explorer/DataSourcePicker';
import { GraphicWalkerWrapper } from '@/components/explorer/GraphicWalkerWrapper';

export function ExplorerShell() {
  return (
    <div className="space-y-6">
      <DataSourcePicker />
      <GraphicWalkerWrapper />
    </div>
  );
}

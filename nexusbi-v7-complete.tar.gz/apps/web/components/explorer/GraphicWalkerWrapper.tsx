'use client';

import { useMemo, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useExplorerStore } from '@/store/explorer.store';

interface DataRow {
  [key: string]: string | number | boolean | null;
}

/**
 * Explorer — self-contained field picker + tabular viewer.
 * Previously used @kanaries/graphic-walker which has a peer-dep conflict with
 * React 19. This implementation covers the core exploration workflow
 * (pick dimensions/measures, view tabular output) without external deps.
 */
export function GraphicWalkerWrapper() {
  const { selectedDsId, selectedCubeName, cubes } = useExplorerStore();
  const [data, setData] = useState<DataRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [pickedDims, setPickedDims] = useState<string[]>([]);
  const [pickedMeasures, setPickedMeasures] = useState<string[]>([]);

  const selectedCube = useMemo(
    () => cubes.find((c) => c.name === selectedCubeName),
    [cubes, selectedCubeName],
  );

  useEffect(() => {
    if (!selectedCube) {
      setPickedDims([]);
      setPickedMeasures([]);
      return;
    }
    setPickedDims(selectedCube.dimensions.slice(0, 2).map((d) => d.name));
    setPickedMeasures(selectedCube.measures.slice(0, 2).map((m) => m.name));
  }, [selectedCube]);

  useEffect(() => {
    if (!selectedCube || !selectedDsId) {
      setData([]);
      return;
    }
    if (pickedDims.length === 0 && pickedMeasures.length === 0) {
      setData([]);
      return;
    }

    let cancelled = false;
    async function loadData() {
      setLoading(true);
      try {
        const response = await fetch('/api/cube/v1/load', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            query: {
              measures: pickedMeasures,
              dimensions: pickedDims,
              limit: 500,
            },
          }),
        });
        if (!response.ok) throw new Error('Query failed');
        const result = await response.json();
        if (!cancelled && result.data) {
          setData(result.data);
        }
      } catch (error) {
        console.error('Explorer data load error:', error);
        if (!cancelled) setData([]);
      }
      if (!cancelled) setLoading(false);
    }
    loadData();
    return () => {
      cancelled = true;
    };
  }, [selectedCube, selectedDsId, pickedDims, pickedMeasures]);

  const allFields = useMemo(
    () => [...pickedDims, ...pickedMeasures],
    [pickedDims, pickedMeasures],
  );

  const toggle = (list: string[], set: (xs: string[]) => void, name: string) => {
    if (list.includes(name)) set(list.filter((x) => x !== name));
    else set([...list, name]);
  };

  if (!selectedCubeName) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-16">
          <p className="text-sm text-muted-foreground">
            Select a data source and cube to start exploring.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (!selectedCube) return null;

  return (
    <div className="grid grid-cols-[220px_1fr] gap-4">
      <Card>
        <CardContent className="p-4 space-y-4">
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-2">
              Dimensions
            </div>
            <div className="space-y-1">
              {selectedCube.dimensions.map((d) => (
                <label key={d.name} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-accent px-2 py-1 rounded">
                  <input
                    type="checkbox"
                    checked={pickedDims.includes(d.name)}
                    onChange={() => toggle(pickedDims, setPickedDims, d.name)}
                  />
                  <span>{d.title || d.name.split('.').pop()}</span>
                </label>
              ))}
            </div>
          </div>
          <div>
            <div className="text-xs font-semibold text-muted-foreground uppercase mb-2">
              Measures
            </div>
            <div className="space-y-1">
              {selectedCube.measures.map((m) => (
                <label key={m.name} className="flex items-center gap-2 text-xs cursor-pointer hover:bg-accent px-2 py-1 rounded">
                  <input
                    type="checkbox"
                    checked={pickedMeasures.includes(m.name)}
                    onChange={() => toggle(pickedMeasures, setPickedMeasures, m.name)}
                  />
                  <span>{m.title || m.name.split('.').pop()}</span>
                </label>
              ))}
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-0">
          {loading ? (
            <div className="p-6 space-y-2">
              <Skeleton className="h-8 w-full" />
              <Skeleton className="h-64 w-full" />
            </div>
          ) : data.length === 0 ? (
            <div className="p-16 text-center text-sm text-muted-foreground">
              No data. Adjust the field selection on the left.
            </div>
          ) : (
            <div className="overflow-auto max-h-[600px]">
              <table className="w-full text-xs">
                <thead className="bg-muted sticky top-0">
                  <tr>
                    {allFields.map((f) => (
                      <th key={f} className="text-left p-2 border-b font-semibold">
                        {f.split('.').pop()}
                      </th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.slice(0, 500).map((row, i) => (
                    <tr key={i} className="hover:bg-muted/50">
                      {allFields.map((f) => (
                        <td key={f} className="p-2 border-b">
                          {row[f] === null || row[f] === undefined ? '' : String(row[f])}
                        </td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              {data.length > 500 && (
                <div className="p-2 text-center text-xs text-muted-foreground border-t">
                  Showing first 500 of {data.length} rows.
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

'use client';

import { useEffect } from 'react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Skeleton } from '@/components/ui/skeleton';
import { useDataSourceStore } from '@/store/datasource.store';
import { useExplorerStore } from '@/store/explorer.store';
import { DS_TYPE_LABELS } from '@nexusbi/shared-types';

export function DataSourcePicker() {
  const { dataSources, loading: dsLoading, fetchDataSources } = useDataSourceStore();
  const {
    selectedDsId,
    selectedCubeName,
    cubes,
    cubesLoading,
    setSelectedDsId,
    setSelectedCubeName,
  } = useExplorerStore();

  useEffect(() => {
    if (dataSources.length === 0) {
      fetchDataSources();
    }
  }, [dataSources.length, fetchDataSources]);

  const activeSources = dataSources.filter((ds) => ds.status === 'ACTIVE');

  return (
    <div className="flex items-end gap-4">
      <div className="space-y-1.5 min-w-48">
        <Label className="text-xs text-muted-foreground">Data Source</Label>
        {dsLoading ? (
          <Skeleton className="h-9 w-full" />
        ) : (
          <Select value={selectedDsId || ''} onValueChange={setSelectedDsId}>
            <SelectTrigger>
              <SelectValue placeholder="Select a data source..." />
            </SelectTrigger>
            <SelectContent>
              {activeSources.map((ds) => (
                <SelectItem key={ds.dsId} value={ds.cubeDsId || ds.dsId}>
                  <div className="flex items-center gap-2">
                    <span>{ds.dsName}</span>
                    <span className="text-xs text-muted-foreground">
                      ({DS_TYPE_LABELS[ds.dsType]})
                    </span>
                  </div>
                </SelectItem>
              ))}
              {activeSources.length === 0 && (
                <div className="px-2 py-4 text-center text-sm text-muted-foreground">
                  No active data sources. Create and test a data source first.
                </div>
              )}
            </SelectContent>
          </Select>
        )}
      </div>

      <div className="space-y-1.5 min-w-48">
        <Label className="text-xs text-muted-foreground">Cube</Label>
        {cubesLoading ? (
          <Skeleton className="h-9 w-full" />
        ) : (
          <Select
            value={selectedCubeName || ''}
            onValueChange={setSelectedCubeName}
            disabled={!selectedDsId || cubes.length === 0}
          >
            <SelectTrigger>
              <SelectValue placeholder={
                !selectedDsId ? 'Select a data source first' :
                cubes.length === 0 ? 'No cubes available' :
                'Select a cube...'
              } />
            </SelectTrigger>
            <SelectContent>
              {cubes.map((cube) => (
                <SelectItem key={cube.name} value={cube.name}>
                  <div>
                    <span>{cube.title || cube.name}</span>
                    <span className="ml-2 text-xs text-muted-foreground">
                      {cube.measures.length}m / {cube.dimensions.length}d
                    </span>
                  </div>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>
    </div>
  );
}

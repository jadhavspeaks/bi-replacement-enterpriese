'use client';

import { useEffect, useState } from 'react';
import { StatusBadge } from '@nexusbi/ui-components';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import type { WebhookDeliveryLog as DeliveryLogType } from '@nexusbi/shared-types';

interface WebhookDeliveryLogProps {
  endpointId: string;
}

export function WebhookDeliveryLog({ endpointId }: WebhookDeliveryLogProps) {
  const [logs, setLogs] = useState<DeliveryLogType[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/webhooks/${endpointId}/log?limit=50`);
        const data = await response.json();
        if (data.success) setLogs(data.data || []);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [endpointId]);

  if (loading) {
    return <div className="space-y-2">{Array.from({ length: 5 }).map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}</div>;
  }

  if (logs.length === 0) {
    return <p className="text-sm text-muted-foreground text-center py-8">No delivery attempts recorded.</p>;
  }

  return (
    <div className="space-y-2">
      {logs.map((log) => (
        <div key={log.deliveryId} className="rounded-md border p-3">
          <div className="flex items-center justify-between mb-1">
            <div className="flex items-center gap-2">
              <StatusBadge status={log.status} size="sm" />
              <span className="text-sm font-medium">{log.triggerEvent}</span>
            </div>
            <div className="flex items-center gap-2 text-xs text-muted-foreground">
              {log.httpStatus && (
                <Badge variant="outline" className={`text-xs ${
                  log.httpStatus >= 200 && log.httpStatus < 300 ? 'text-green-700' : 'text-red-700'
                }`}>
                  HTTP {log.httpStatus}
                </Badge>
              )}
              <span>Attempt #{log.attemptCount}</span>
            </div>
          </div>
          <div className="text-xs text-muted-foreground">
            {log.deliveredAt && <span>Delivered: {new Date(log.deliveredAt).toLocaleString()}</span>}
            {log.nextRetryAt && <span className="ml-3">Next retry: {new Date(log.nextRetryAt).toLocaleString()}</span>}
          </div>
          {log.responseBody && (
            <pre className="mt-2 rounded bg-muted p-2 text-xs font-mono overflow-x-auto max-h-20">
              {log.responseBody.substring(0, 500)}
            </pre>
          )}
        </div>
      ))}
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { DataTable } from '@nexusbi/ui-components';
import { Loader2, Plus, Timer, RefreshCw } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';
import type { TimedAccess, TimedAccessResourceType } from '@nexusbi/shared-types';

export function TimedAccessManager() {
  const [accessList, setAccessList] = useState<TimedAccess[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving] = useState(false);
  const [renewingId, setRenewingId] = useState<string | null>(null);

  const [resourceType, setResourceType] = useState<TimedAccessResourceType>('datasource');
  const [resourceId, setResourceId] = useState('');
  const [userId, setUserId] = useState('');
  const [expiresAt, setExpiresAt] = useState('');

  const fetchAccess = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/timed-access');
      const data = await response.json();
      if (data.success) setAccessList(data.data || []);
    } catch { /* handle */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchAccess(); }, [fetchAccess]);

  const handleCreate = useCallback(async () => {
    setSaving(true);
    try {
      const response = await fetch('/api/admin/timed-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ resourceType, resourceId, userId: userId || undefined, expiresAt: new Date(expiresAt).toISOString() }),
      });
      if (response.ok) {
        setCreateOpen(false);
        setResourceId(''); setUserId(''); setExpiresAt('');
        fetchAccess();
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [resourceType, resourceId, userId, expiresAt, fetchAccess]);

  const handleRenew = useCallback(async (accessId: string) => {
    const newExpiry = prompt('Enter new expiry date (YYYY-MM-DD):');
    if (!newExpiry) return;

    setRenewingId(accessId);
    try {
      await fetch(`/api/admin/timed-access/${accessId}/renew`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ expiresAt: new Date(newExpiry).toISOString() }),
      });
      fetchAccess();
    } catch { /* handle */ }
    setRenewingId(null);
  }, [fetchAccess]);

  const columns: ColumnDef<TimedAccess>[] = [
    { accessorKey: 'resourceType', header: 'Type', cell: ({ row }) => (
      <Badge variant="outline" className="text-xs">{row.original.resourceType}</Badge>
    )},
    { accessorKey: 'resourceId', header: 'Resource ID', cell: ({ row }) => (
      <span className="font-mono text-xs">{row.original.resourceId.substring(0, 12)}...</span>
    )},
    { accessorKey: 'userId', header: 'User/Role', cell: ({ row }) => (
      <span className="text-sm">{row.original.userId || row.original.roleId || '—'}</span>
    )},
    { accessorKey: 'expiresAt', header: 'Expires', cell: ({ row }) => {
      const expired = new Date(row.original.expiresAt) < new Date();
      return (
        <span className={`text-sm ${expired ? 'text-red-600' : ''}`}>
          {new Date(row.original.expiresAt).toLocaleDateString()}
          {expired && <Badge variant="destructive" className="ml-2 text-[10px]">Expired</Badge>}
        </span>
      );
    }},
    { accessorKey: 'isActive', header: 'Active', cell: ({ row }) => (
      <Badge variant={row.original.isActive ? 'default' : 'secondary'} className="text-xs">
        {row.original.isActive ? 'Active' : 'Inactive'}
      </Badge>
    )},
    { id: 'actions', header: '', cell: ({ row }) => (
      <Button variant="ghost" size="sm" onClick={() => handleRenew(row.original.accessId)}
        disabled={renewingId === row.original.accessId}>
        {renewingId === row.original.accessId ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <RefreshCw className="h-3.5 w-3.5" />}
      </Button>
    )},
  ];

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Timer className="h-5 w-5" />
            Time-Bounded Access
          </h3>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            Grant Access
          </Button>
        </div>
        <DataTable columns={columns} data={accessList} emptyMessage="No timed access grants." searchPlaceholder="Search..." />
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Grant Time-Bounded Access</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Resource Type</Label>
              <Select value={resourceType} onValueChange={(v) => setResourceType(v as TimedAccessResourceType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="datasource">Data Source</SelectItem>
                  <SelectItem value="dashboard">Dashboard</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Resource ID</Label>
              <Input placeholder="Paste resource ID..." value={resourceId} onChange={(e) => setResourceId(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>User ID (optional)</Label>
              <Input placeholder="User ID" value={userId} onChange={(e) => setUserId(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Expires At</Label>
              <Input type="datetime-local" value={expiresAt} onChange={(e) => setExpiresAt(e.target.value)} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving || !resourceId || !expiresAt}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Granting...</> : 'Grant Access'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

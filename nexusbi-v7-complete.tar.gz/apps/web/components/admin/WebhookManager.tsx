'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { StatusBadge } from '@nexusbi/ui-components';
import { DataTable } from '@nexusbi/ui-components';
import { WebhookDeliveryLog } from './WebhookDeliveryLog';
import { Loader2, Plus, Webhook, Zap, ScrollText } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';
import type { WebhookEndpoint, WebhookTriggerType } from '@nexusbi/shared-types';

export function WebhookManager() {
  const [endpoints, setEndpoints] = useState<WebhookEndpoint[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [logEndpointId, setLogEndpointId] = useState<string | null>(null);
  const [saving, setSaving] = useState(false);
  const [testing, setTesting] = useState<string | null>(null);

  const [name, setName] = useState('');
  const [url, setUrl] = useState('');
  const [secret, setSecret] = useState('');
  const [triggerType, setTriggerType] = useState<WebhookTriggerType>('approval');

  const fetchEndpoints = useCallback(async () => {
    try {
      const response = await fetch('/api/webhooks');
      const data = await response.json();
      if (data.success) setEndpoints(data.data || []);
    } catch { /* handle */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchEndpoints(); }, [fetchEndpoints]);

  const handleCreate = useCallback(async () => {
    setSaving(true);
    try {
      const response = await fetch('/api/webhooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ endpointName: name, url, secret, triggerType }),
      });
      if (response.ok) {
        setCreateOpen(false);
        setName(''); setUrl(''); setSecret(''); setTriggerType('approval');
        fetchEndpoints();
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [name, url, secret, triggerType, fetchEndpoints]);

  const handleTest = useCallback(async (endpointId: string) => {
    setTesting(endpointId);
    try {
      await fetch(`/api/webhooks/${endpointId}/test`, { method: 'POST' });
    } catch { /* handle */ }
    setTesting(null);
  }, []);

  const columns: ColumnDef<WebhookEndpoint>[] = [
    { accessorKey: 'endpointName', header: 'Name' },
    { accessorKey: 'url', header: 'URL', cell: ({ row }) => (
      <span className="font-mono text-xs truncate max-w-48 block">{row.original.url}</span>
    )},
    { accessorKey: 'triggerType', header: 'Trigger', cell: ({ row }) => (
      <StatusBadge status={row.original.triggerType.toUpperCase()} showDot={false} size="sm" />
    )},
    { accessorKey: 'isActive', header: 'Status', cell: ({ row }) => (
      <StatusBadge status={row.original.isActive ? 'ACTIVE' : 'INACTIVE'} size="sm" />
    )},
    { id: 'actions', header: '', cell: ({ row }) => (
      <div className="flex items-center gap-1">
        <Button variant="ghost" size="sm" onClick={() => handleTest(row.original.endpointId)}
          disabled={testing === row.original.endpointId}>
          {testing === row.original.endpointId ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Zap className="h-3.5 w-3.5" />}
        </Button>
        <Button variant="ghost" size="sm" onClick={() => setLogEndpointId(row.original.endpointId)}>
          <ScrollText className="h-3.5 w-3.5" />
        </Button>
      </div>
    )},
  ];

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Webhook className="h-5 w-5" />
            Outbound Webhooks
          </h3>
          <Button onClick={() => setCreateOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            New Webhook
          </Button>
        </div>

        <DataTable columns={columns} data={endpoints} searchColumn="endpointName" searchPlaceholder="Search webhooks..." emptyMessage="No webhook endpoints configured." />
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create Webhook Endpoint</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Name</Label>
              <Input placeholder="My Webhook" value={name} onChange={(e) => setName(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>URL</Label>
              <Input placeholder="https://example.com/webhook" value={url} onChange={(e) => setUrl(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Signing Secret</Label>
              <Input type="password" placeholder="••••••••" value={secret} onChange={(e) => setSecret(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Trigger Type</Label>
              <Select value={triggerType} onValueChange={(v) => setTriggerType(v as WebhookTriggerType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="approval">Dashboard Approval</SelectItem>
                  <SelectItem value="threshold">Metric Threshold</SelectItem>
                  <SelectItem value="schedule">Scheduled</SelectItem>
                  <SelectItem value="manual">Manual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving || !name || !url || !secret}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Creating...</> : 'Create'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {logEndpointId && (
        <Dialog open={true} onOpenChange={() => setLogEndpointId(null)}>
          <DialogContent className="max-w-3xl max-h-[80vh] overflow-y-auto">
            <DialogHeader><DialogTitle>Delivery Log</DialogTitle></DialogHeader>
            <WebhookDeliveryLog endpointId={logEndpointId} />
          </DialogContent>
        </Dialog>
      )}
    </>
  );
}

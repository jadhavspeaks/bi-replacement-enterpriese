'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';
import { Shield, Lock } from 'lucide-react';
import type { RoleWithPermissions } from '@nexusbi/shared-types';

export function RoleManager() {
  const [roles, setRoles] = useState<RoleWithPermissions[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch('/api/admin/roles');
        const data = await response.json();
        if (data.success) setRoles(data.data || []);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Skeleton key={i} className="h-16 w-full" />)}</div>;
  }

  // Group permissions by category
  const groupPermissions = (permissions: RoleWithPermissions['permissions']) => {
    const groups = new Map<string, typeof permissions>();
    for (const p of permissions) {
      const cat = p.permCategory || 'Other';
      const list = groups.get(cat) || [];
      list.push(p);
      groups.set(cat, list);
    }
    return groups;
  };

  return (
    <div className="space-y-4">
      <Accordion type="multiple" className="space-y-2">
        {roles.map((role) => {
          const permGroups = groupPermissions(role.permissions);

          return (
            <AccordionItem key={role.roleId} value={role.roleId} className="border rounded-lg">
              <AccordionTrigger className="px-4 py-3 hover:no-underline">
                <div className="flex items-center gap-3">
                  <Shield className="h-4 w-4 text-nexus-500" />
                  <span className="font-semibold text-sm">{role.roleName}</span>
                  {role.isSystemRole && (
                    <Badge variant="secondary" className="text-[10px]">
                      <Lock className="h-2.5 w-2.5 mr-0.5" />
                      System
                    </Badge>
                  )}
                  <Badge variant="outline" className="text-[10px]">
                    {role.permissions.length} permissions
                  </Badge>
                </div>
              </AccordionTrigger>
              <AccordionContent className="px-4 pb-4">
                {role.roleDescription && (
                  <p className="text-sm text-muted-foreground mb-3">{role.roleDescription}</p>
                )}
                <div className="space-y-3">
                  {Array.from(permGroups.entries()).map(([category, perms]) => (
                    <div key={category}>
                      <p className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1.5">
                        {category}
                      </p>
                      <div className="flex flex-wrap gap-1.5">
                        {perms.map((p) => (
                          <Badge key={p.permId} variant="outline" className="text-xs">
                            {p.permCode}
                          </Badge>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </AccordionContent>
            </AccordionItem>
          );
        })}
      </Accordion>
    </div>
  );
}

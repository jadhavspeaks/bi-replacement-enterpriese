'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { DataTable } from '@nexusbi/ui-components';
import { Loader2, Plus, Users, UserPlus } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';

interface UserListItem {
  userId: string;
  email: string;
  username: string;
  displayName: string | null;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  roles: string[];
}

export function UserManager() {
  const [users, setUsers] = useState<UserListItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [createOpen, setCreateOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [email, setEmail] = useState('');
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [password, setPassword] = useState('');

  const fetchUsers = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/users');
      const data = await response.json();
      if (data.success) setUsers(data.data || []);
    } catch { /* handle */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchUsers(); }, [fetchUsers]);

  const handleCreate = useCallback(async () => {
    setSaving(true);
    try {
      const response = await fetch('/api/admin/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, username, displayName: displayName || username, password }),
      });

      const data = await response.json();
      if (data.success) {
        setCreateOpen(false);
        setEmail(''); setUsername(''); setDisplayName(''); setPassword('');
        fetchUsers();
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [email, username, displayName, password, fetchUsers]);

  const columns: ColumnDef<UserListItem>[] = [
    { accessorKey: 'username', header: 'Username', cell: ({ row }) => (
      <span className="font-medium text-sm">{row.original.username}</span>
    )},
    { accessorKey: 'email', header: 'Email' },
    { accessorKey: 'displayName', header: 'Name' },
    { accessorKey: 'roles', header: 'Roles', cell: ({ row }) => (
      <div className="flex flex-wrap gap-1">
        {row.original.roles.map((r) => (
          <Badge key={r} variant="outline" className="text-[10px]">{r}</Badge>
        ))}
      </div>
    )},
    { accessorKey: 'isActive', header: 'Status', cell: ({ row }) => (
      <Badge variant={row.original.isActive ? 'default' : 'secondary'} className="text-xs">
        {row.original.isActive ? 'Active' : 'Inactive'}
      </Badge>
    )},
    { accessorKey: 'lastLoginAt', header: 'Last Login', cell: ({ row }) => (
      <span className="text-xs text-muted-foreground">
        {row.original.lastLoginAt ? new Date(row.original.lastLoginAt).toLocaleDateString() : 'Never'}
      </span>
    )},
  ];

  return (
    <>
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold flex items-center gap-2">
            <Users className="h-5 w-5" />
            User Management
          </h3>
          <Button onClick={() => setCreateOpen(true)}>
            <UserPlus className="h-4 w-4 mr-2" />
            Create User
          </Button>
        </div>

        <DataTable columns={columns} data={users} searchColumn="username" searchPlaceholder="Search users..." emptyMessage="No users found." />
      </div>

      <Dialog open={createOpen} onOpenChange={setCreateOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>Create User</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Username</Label>
                <Input placeholder="jdoe" value={username} onChange={(e) => setUsername(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Display Name</Label>
                <Input placeholder="John Doe" value={displayName} onChange={(e) => setDisplayName(e.target.value)} />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Email</Label>
              <Input type="email" placeholder="john@example.com" value={email} onChange={(e) => setEmail(e.target.value)} />
            </div>
            <div className="space-y-2">
              <Label>Password</Label>
              <Input type="password" placeholder="Min 8 chars, uppercase, number, special" value={password} onChange={(e) => setPassword(e.target.value)} />
              <p className="text-xs text-muted-foreground">Must contain uppercase, lowercase, digit, and special character</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreateOpen(false)}>Cancel</Button>
            <Button onClick={handleCreate} disabled={saving || !email || !username || !password}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Creating...</> : 'Create User'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}

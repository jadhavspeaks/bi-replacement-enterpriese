'use client';

import { useState, useCallback, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Loader2, Plus, X } from 'lucide-react';
import type { Role } from '@nexusbi/shared-types';

interface UserRoleAssignerProps {
  userId: string;
  currentRoles: string[];
  onRolesChange?: () => void;
}

export function UserRoleAssigner({ userId, currentRoles, onRolesChange }: UserRoleAssignerProps) {
  const [roles, setRoles] = useState<Role[]>([]);
  const [selectedRoleId, setSelectedRoleId] = useState('');
  const [assigning, setAssigning] = useState(false);
  const [removing, setRemoving] = useState<string | null>(null);

  useEffect(() => {
    async function loadRoles() {
      try {
        const response = await fetch('/api/admin/roles');
        const data = await response.json();
        if (data.success) setRoles(data.data || []);
      } catch { /* handle */ }
    }
    loadRoles();
  }, []);

  const handleAssign = useCallback(async () => {
    if (!selectedRoleId) return;
    setAssigning(true);

    try {
      // This would be a dedicated endpoint in a full implementation
      // For now we use the user update flow
      const response = await fetch(`/api/admin/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          action: 'assignRole',
          roleId: selectedRoleId,
        }),
      });

      if (response.ok) {
        setSelectedRoleId('');
        onRolesChange?.();
      }
    } catch { /* handle */ }
    setAssigning(false);
  }, [userId, selectedRoleId, onRolesChange]);

  const availableRoles = roles.filter((r) => !currentRoles.includes(r.roleName));

  return (
    <div className="space-y-3">
      <Label className="text-sm font-medium">Assigned Roles</Label>

      <div className="flex flex-wrap gap-1.5">
        {currentRoles.map((roleName) => (
          <Badge key={roleName} variant="secondary" className="text-xs gap-1">
            {roleName}
          </Badge>
        ))}
        {currentRoles.length === 0 && (
          <p className="text-xs text-muted-foreground">No roles assigned</p>
        )}
      </div>

      {availableRoles.length > 0 && (
        <div className="flex items-end gap-2">
          <div className="flex-1 space-y-1">
            <Label className="text-xs text-muted-foreground">Add Role</Label>
            <Select value={selectedRoleId} onValueChange={setSelectedRoleId}>
              <SelectTrigger className="h-8">
                <SelectValue placeholder="Select role..." />
              </SelectTrigger>
              <SelectContent>
                {availableRoles.map((role) => (
                  <SelectItem key={role.roleId} value={role.roleId}>
                    {role.roleName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button
            size="sm"
            className="h-8"
            onClick={handleAssign}
            disabled={!selectedRoleId || assigning}
          >
            {assigning ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Plus className="h-3.5 w-3.5" />}
          </Button>
        </div>
      )}
    </div>
  );
}

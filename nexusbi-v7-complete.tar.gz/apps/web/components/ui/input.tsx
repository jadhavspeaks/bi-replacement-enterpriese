import * as React from "react";
import { cn } from "@/lib/utils";

/**
 * Base Input component.
 *
 * `suppressHydrationWarning` is deliberately set on the underlying <input>.
 * Enterprise browsers and password managers (Island Enterprise Browser,
 * 1Password, LastPass, Bitwarden, Dashlane) inject DOM attributes such as
 * `island_form_infra_autocomplete`, `island_form_infra_field_type`, or
 * `data-lpignore` into form fields after the server-rendered HTML arrives but
 * before React hydrates, producing a hydration mismatch warning in dev mode.
 * The injected attributes are additive and do not affect subsequent React
 * diffs, so suppressing the warning for this one element is the correct
 * escape hatch.
 * See https://react.dev/reference/react-dom/client/hydrateRoot#suppressing-unavoidable-hydration-mismatch-errors
 */
const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>(
  ({ className, type, ...props }, ref) => (
    <input
      type={type}
      className={cn(
        "flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors file:border-0 file:bg-transparent file:text-sm file:font-medium placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50",
        className,
      )}
      ref={ref}
      suppressHydrationWarning
      {...props}
    />
  ),
);
Input.displayName = "Input";

export { Input };

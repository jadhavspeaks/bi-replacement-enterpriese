'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, ArrowRight } from 'lucide-react';
import { useDataSourceStore } from '@/store/datasource.store';
import type { DashTemplate, WidgetConfig } from '@nexusbi/shared-types';

interface TemplateInstallDialogProps {
  template: DashTemplate;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TemplateInstallDialog({ template, open, onOpenChange }: TemplateInstallDialogProps) {
  const router = useRouter();
  const { dataSources, fetchDataSources } = useDataSourceStore();
  const [installing, setInstalling] = useState(false);
  const [dashName, setDashName] = useState(`${template.templateName} (installed)`);
  const [dsMapping, setDsMapping] = useState<Record<string, string>>({});
  const [error, setError] = useState<string | null>(null);

  // Extract unique dsIds from template widgets
  const requiredDsIds = Array.from(
    new Set(
      (template.widgetsJson || [])
        .filter((w: WidgetConfig) => w.dsId)
        .map((w: WidgetConfig) => w.dsId!),
    ),
  );

  useEffect(() => {
    if (open && dataSources.length === 0) {
      fetchDataSources();
    }
  }, [open, dataSources.length, fetchDataSources]);

  const handleInstall = useCallback(async () => {
    if (requiredDsIds.length > 0 && Object.keys(dsMapping).length < requiredDsIds.length) {
      setError('Please map all required data sources');
      return;
    }

    setInstalling(true);
    setError(null);

    try {
      const response = await fetch(`/api/templates/${template.templateId}/install`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dsMapping: requiredDsIds.length > 0 ? dsMapping : { _: '_' },
          dashName,
        }),
      });

      const data = await response.json();
      if (data.success) {
        onOpenChange(false);
        router.push(`/dashboards/${data.data.dashId}/edit`);
      } else {
        setError(data.error?.message || 'Installation failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    }

    setInstalling(false);
  }, [template.templateId, dsMapping, dashName, requiredDsIds, onOpenChange, router]);

  const activeSources = dataSources.filter((ds) => ds.status === 'ACTIVE');

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Install Template: {template.templateName}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-2">
            <Label>Dashboard Name</Label>
            <Input
              value={dashName}
              onChange={(e) => setDashName(e.target.value)}
              placeholder="My Dashboard"
            />
          </div>

          {requiredDsIds.length > 0 && (
            <div className="space-y-3">
              <Label>Map Data Sources</Label>
              <p className="text-xs text-muted-foreground">
                This template requires {requiredDsIds.length} data source(s). Map each to a local data source.
              </p>

              {requiredDsIds.map((dsId) => (
                <div key={dsId} className="flex items-center gap-2">
                  <div className="flex-1">
                    <p className="text-xs font-mono text-muted-foreground truncate">
                      {dsId.substring(0, 16)}...
                    </p>
                  </div>
                  <ArrowRight className="h-4 w-4 text-muted-foreground shrink-0" />
                  <Select
                    value={dsMapping[dsId] || ''}
                    onValueChange={(value) => setDsMapping((prev) => ({ ...prev, [dsId]: value }))}
                  >
                    <SelectTrigger className="flex-1">
                      <SelectValue placeholder="Select..." />
                    </SelectTrigger>
                    <SelectContent>
                      {activeSources.map((ds) => (
                        <SelectItem key={ds.dsId} value={ds.cubeDsId || ds.dsId}>
                          {ds.dsName}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              ))}
            </div>
          )}

          {requiredDsIds.length === 0 && (
            <p className="text-sm text-muted-foreground">
              This template does not require data source mapping. It will be installed as a draft dashboard.
            </p>
          )}

          {error && (
            <div className="rounded-md border border-red-200 bg-red-50 p-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
          <Button onClick={handleInstall} disabled={installing || !dashName}>
            {installing ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Installing...</>
            ) : (
              'Install Template'
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

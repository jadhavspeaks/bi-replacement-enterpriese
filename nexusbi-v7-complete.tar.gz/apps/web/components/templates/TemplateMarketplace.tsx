'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from '@nexusbi/ui-components';
import { TemplateCard } from './TemplateCard';
import { Search, Store } from 'lucide-react';
import type { DashTemplate } from '@nexusbi/shared-types';

export function TemplateMarketplace() {
  const router = useRouter();
  const [templates, setTemplates] = useState<DashTemplate[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('all');

  useEffect(() => {
    async function load() {
      try {
        const params = new URLSearchParams();
        if (search) params.set('search', search);
        if (category !== 'all') params.set('category', category);

        const response = await fetch(`/api/templates?${params.toString()}`);
        const data = await response.json();
        if (data.success) setTemplates(data.data || []);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [search, category]);

  const categories = [...new Set(templates.map((t) => t.category).filter(Boolean))] as string[];

  if (loading) {
    return (
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-48" />)}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search templates..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={category} onValueChange={setCategory}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="All categories" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Categories</SelectItem>
            {categories.map((cat) => (
              <SelectItem key={cat} value={cat}>{cat}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {templates.length === 0 ? (
        <EmptyState
          icon={<Store className="h-8 w-8 text-muted-foreground" />}
          title="No templates available"
          description="Publish approved dashboards as templates to share with your organization."
        />
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {templates.map((template) => (
            <TemplateCard
              key={template.templateId}
              template={template}
              onClick={() => router.push(`/templates/${template.templateId}`)}
            />
          ))}
        </div>
      )}
    </div>
  );
}

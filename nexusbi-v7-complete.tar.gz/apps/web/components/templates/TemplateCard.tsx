'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Store, Download, Globe } from 'lucide-react';
import type { DashTemplate } from '@nexusbi/shared-types';

interface TemplateCardProps {
  template: DashTemplate;
  onClick?: () => void;
}

export function TemplateCard({ template, onClick }: TemplateCardProps) {
  const tags = template.tags?.split(',').map((t) => t.trim()).filter(Boolean) || [];

  return (
    <Card
      className="cursor-pointer transition-all hover:shadow-md hover:border-nexus-300 overflow-hidden"
      onClick={onClick}
    >
      {template.thumbnailUrl ? (
        <div className="h-32 bg-muted overflow-hidden">
          <img
            src={template.thumbnailUrl}
            alt={template.templateName}
            className="h-full w-full object-cover"
          />
        </div>
      ) : (
        <div className="h-32 bg-gradient-to-br from-nexus-50 to-nexus-100 flex items-center justify-center">
          <Store className="h-10 w-10 text-nexus-300" />
        </div>
      )}

      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-2">
          <h3 className="font-semibold text-sm line-clamp-1">{template.templateName}</h3>
          {template.isGlobal && (
            <Badge variant="outline" className="shrink-0 text-[10px] bg-blue-50 text-blue-700 border-blue-200">
              <Globe className="h-2.5 w-2.5 mr-0.5" />
              Global
            </Badge>
          )}
        </div>

        {template.description && (
          <p className="mt-1 text-xs text-muted-foreground line-clamp-2">
            {template.description}
          </p>
        )}

        {tags.length > 0 && (
          <div className="mt-2 flex flex-wrap gap-1">
            {tags.slice(0, 3).map((tag) => (
              <Badge key={tag} variant="secondary" className="text-[10px]">
                {tag}
              </Badge>
            ))}
            {tags.length > 3 && (
              <Badge variant="secondary" className="text-[10px]">
                +{tags.length - 3}
              </Badge>
            )}
          </div>
        )}

        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
          {template.category && <span>{template.category}</span>}
          <span className="flex items-center gap-1">
            <Download className="h-3 w-3" />
            {template.installCount} installs
          </span>
        </div>
      </CardContent>
    </Card>
  );
}

'use client';

import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Loader2, BookTemplate, CheckCircle2 } from 'lucide-react';

interface TemplatePublisherProps {
  dashId: string;
  dashName: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function TemplatePublisher({ dashId, dashName, open, onOpenChange }: TemplatePublisherProps) {
  const [publishing, setPublishing] = useState(false);
  const [success, setSuccess] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [templateName, setTemplateName] = useState(dashName);
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState('');
  const [tags, setTags] = useState('');
  const [isGlobal, setIsGlobal] = useState(false);

  const handlePublish = useCallback(async () => {
    setPublishing(true);
    setError(null);

    try {
      const response = await fetch('/api/templates', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dashId,
          templateName,
          description: description || undefined,
          category: category || undefined,
          tags: tags || undefined,
          isGlobal,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setSuccess(true);
      } else {
        setError(data.error?.message || 'Publishing failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    }

    setPublishing(false);
  }, [dashId, templateName, description, category, tags, isGlobal]);

  const handleClose = useCallback(() => {
    setSuccess(false);
    setError(null);
    onOpenChange(false);
  }, [onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <BookTemplate className="h-5 w-5" />
            Publish as Template
          </DialogTitle>
        </DialogHeader>

        {success ? (
          <div className="py-8 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-green-500 mb-3" />
            <h3 className="text-lg font-semibold">Template Published</h3>
            <p className="text-sm text-muted-foreground mt-1">
              Your dashboard is now available in the template marketplace.
            </p>
            <Button className="mt-4" onClick={handleClose}>Done</Button>
          </div>
        ) : (
          <>
            <div className="space-y-4">
              <div className="space-y-2">
                <Label>Template Name</Label>
                <Input
                  value={templateName}
                  onChange={(e) => setTemplateName(e.target.value)}
                  placeholder="My Template"
                />
              </div>

              <div className="space-y-2">
                <Label>Description (optional)</Label>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="Describe what this template provides..."
                  rows={3}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Category (optional)</Label>
                  <Input
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    placeholder="e.g., Sales, Finance"
                  />
                </div>
                <div className="space-y-2">
                  <Label>Tags (optional)</Label>
                  <Input
                    value={tags}
                    onChange={(e) => setTags(e.target.value)}
                    placeholder="revenue, quarterly"
                  />
                  <p className="text-[10px] text-muted-foreground">Comma-separated</p>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <Switch
                  checked={isGlobal}
                  onCheckedChange={setIsGlobal}
                  id="isGlobal"
                />
                <Label htmlFor="isGlobal">
                  Make available to all tenants
                </Label>
              </div>

              {error && (
                <div className="rounded-md border border-red-200 bg-red-50 p-3">
                  <p className="text-sm text-red-800">{error}</p>
                </div>
              )}
            </div>

            <DialogFooter>
              <Button variant="outline" onClick={handleClose}>Cancel</Button>
              <Button onClick={handlePublish} disabled={publishing || !templateName}>
                {publishing ? (
                  <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Publishing...</>
                ) : (
                  'Publish Template'
                )}
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}

'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import { useUserStore } from '@/store/user.store';
import { PermissionGate } from '@/components/shared/PermissionGate';
import type { PermissionCode } from '@nexusbi/shared-types';
import {
  BarChart3, Database, Globe, Upload, Compass, Blocks, LayoutDashboard,
  ClipboardCheck, GitFork, Store, Shield, Users, Settings, ScrollText,
  Gauge, Webhook, Timer, ChevronLeft, ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';

interface NavItem {
  label: string;
  href: string;
  icon: typeof BarChart3;
  permission?: PermissionCode;
  children?: NavItem[];
}

const NAV_ITEMS: NavItem[] = [
  { label: 'Overview', href: '/', icon: BarChart3 },
  { label: 'Data Sources', href: '/datasources', icon: Database, permission: 'datasource.view' },
  { label: 'API Sources', href: '/api-sources', icon: Globe, permission: 'datasource.view' },
  { label: 'Tableau Import', href: '/tableau/import', icon: Upload, permission: 'tableau.import' },
  { label: 'Explorer', href: '/explorer', icon: Compass, permission: 'explorer.use' },
  { label: 'Semantic Layer', href: '/semantic', icon: Blocks, permission: 'schema.view' },
  { label: 'Dashboards', href: '/dashboards', icon: LayoutDashboard, permission: 'dashboard.view' },
  { label: 'Review Queue', href: '/checker', icon: ClipboardCheck, permission: 'dashboard.approve' },
  { label: 'Data Lineage', href: '/lineage', icon: GitFork, permission: 'lineage.view' },
  { label: 'Templates', href: '/templates', icon: Store, permission: 'template.view' },
];

const ADMIN_ITEMS: NavItem[] = [
  { label: 'Admin', href: '/admin', icon: Shield, permission: 'admin.platform' },
  { label: 'Roles', href: '/admin/roles', icon: Shield, permission: 'admin.roles' },
  { label: 'Users', href: '/admin/users', icon: Users, permission: 'admin.users' },
  { label: 'Platform', href: '/admin/platform', icon: Settings, permission: 'admin.platform' },
  { label: 'Audit Log', href: '/admin/audit', icon: ScrollText, permission: 'audit.view' },
  { label: 'Webhooks', href: '/admin/webhooks', icon: Webhook, permission: 'webhook.manage' },
  { label: 'Timed Access', href: '/admin/timed-access', icon: Timer, permission: 'admin.platform' },
];

interface SidebarProps {
  open: boolean;
  onToggle: () => void;
}

export function Sidebar({ open, onToggle }: SidebarProps) {
  const pathname = usePathname();

  return (
    <>
      {/* Mobile overlay */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/50 lg:hidden"
          onClick={onToggle}
        />
      )}

      <aside
        className={`
          fixed inset-y-0 left-0 z-50 flex flex-col border-r bg-background transition-all duration-300
          lg:relative lg:z-auto
          ${open ? 'w-60' : 'w-0 lg:w-16'}
        `}
      >
        {/* Logo */}
        <div className="flex h-14 items-center justify-between border-b px-4 shrink-0">
          {open && (
            <Link href="/" className="flex items-center gap-2">
              <BarChart3 className="h-6 w-6 text-nexus-500" />
              <span className="font-bold text-lg">NexusBI</span>
            </Link>
          )}
          <Button
            variant="ghost"
            size="icon"
            className="h-7 w-7 hidden lg:flex"
            onClick={onToggle}
          >
            {open ? <ChevronLeft className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
          </Button>
        </div>

        {/* Nav items */}
        <nav className="flex-1 overflow-y-auto py-2">
          <div className="space-y-0.5 px-2">
            {NAV_ITEMS.map((item) => (
              <NavLink key={item.href} item={item} pathname={pathname} collapsed={!open} />
            ))}
          </div>

          <div className="my-3 mx-2 border-t" />

          <div className="space-y-0.5 px-2">
            {open && (
              <p className="px-3 py-1 text-xs font-semibold uppercase tracking-wider text-muted-foreground">
                Administration
              </p>
            )}
            {ADMIN_ITEMS.map((item) => (
              <NavLink key={item.href} item={item} pathname={pathname} collapsed={!open} />
            ))}
          </div>
        </nav>
      </aside>
    </>
  );
}

function NavLink({ item, pathname, collapsed }: { item: NavItem; pathname: string; collapsed: boolean }) {
  const isActive = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href));
  const Icon = item.icon;

  const link = (
    <Link
      href={item.href}
      className={`
        flex items-center gap-3 rounded-md px-3 py-2 text-sm font-medium transition-colors
        ${isActive
          ? 'bg-nexus-50 text-nexus-700'
          : 'text-muted-foreground hover:bg-muted hover:text-foreground'
        }
        ${collapsed ? 'justify-center' : ''}
      `}
      title={collapsed ? item.label : undefined}
    >
      <Icon className={`h-4 w-4 shrink-0 ${isActive ? 'text-nexus-600' : ''}`} />
      {!collapsed && <span className="truncate">{item.label}</span>}
    </Link>
  );

  if (item.permission) {
    return (
      <PermissionGate permission={item.permission}>
        {link}
      </PermissionGate>
    );
  }

  return link;
}

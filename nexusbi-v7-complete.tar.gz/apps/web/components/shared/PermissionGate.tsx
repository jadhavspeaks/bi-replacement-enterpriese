'use client';

import type { ReactNode } from 'react';
import { useUserStore } from '@/store/user.store';
import type { PermissionCode } from '@nexusbi/shared-types';

interface PermissionGateProps {
  permission: PermissionCode | PermissionCode[];
  mode?: 'all' | 'any';
  children: ReactNode;
  fallback?: ReactNode;
}

export function PermissionGate({
  permission,
  mode = 'all',
  children,
  fallback = null,
}: PermissionGateProps) {
  const permissions = useUserStore((s) => s.permissions);

  const perms = Array.isArray(permission) ? permission : [permission];

  const hasAccess = mode === 'all'
    ? perms.every((p) => permissions.has(p))
    : perms.some((p) => permissions.has(p));

  if (!hasAccess) return <>{fallback}</>;

  return <>{children}</>;
}

export function useHasPermission(permission: PermissionCode): boolean {
  const permissions = useUserStore((s) => s.permissions);
  return permissions.has(permission);
}

export function useHasAnyPermission(perms: PermissionCode[]): boolean {
  const permissions = useUserStore((s) => s.permissions);
  return perms.some((p) => permissions.has(p));
}

export function useHasAllPermissions(perms: PermissionCode[]): boolean {
  const permissions = useUserStore((s) => s.permissions);
  return perms.every((p) => permissions.has(p));
}

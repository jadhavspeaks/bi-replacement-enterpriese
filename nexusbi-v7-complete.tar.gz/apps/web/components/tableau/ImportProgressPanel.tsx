'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { StatusBadge } from '@nexusbi/ui-components';
import { Loader2, FileCheck, AlertTriangle } from 'lucide-react';
import type { TableauImport } from '@nexusbi/shared-types';

interface ImportProgressPanelProps {
  importId: string;
  pollInterval?: number;
}

export function ImportProgressPanel({ importId, pollInterval = 3000 }: ImportProgressPanelProps) {
  const [importData, setImportData] = useState<TableauImport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;

    async function poll() {
      try {
        const response = await fetch(`/api/tableau/import/${importId}`);
        if (!response.ok) return;

        const data = await response.json();
        if (data.success && active) {
          setImportData(data.data);
          setLoading(false);

          if (data.data.importStatus === 'COMPLETE' || data.data.importStatus === 'ERROR') {
            return; // stop polling
          }
        }
      } catch {
        // continue polling
      }

      if (active) {
        setTimeout(poll, pollInterval);
      }
    }

    poll();
    return () => { active = false; };
  }, [importId, pollInterval]);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground mr-2" />
          <span className="text-sm text-muted-foreground">Loading import status...</span>
        </CardContent>
      </Card>
    );
  }

  if (!importData) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-sm text-muted-foreground">Import not found.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <FileCheck className="h-4 w-4" />
            {importData.originalName}
          </CardTitle>
          <StatusBadge status={importData.importStatus} />
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div>
            <p className="text-muted-foreground">Status</p>
            <p className="font-medium">{importData.importStatus}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Widgets Created</p>
            <p className="font-medium">{importData.widgetsCreated ?? '—'}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Started</p>
            <p className="font-medium">{new Date(importData.createdAt).toLocaleString()}</p>
          </div>
          <div>
            <p className="text-muted-foreground">Completed</p>
            <p className="font-medium">
              {importData.completedAt ? new Date(importData.completedAt).toLocaleString() : '—'}
            </p>
          </div>
        </div>

        {importData.warnings && importData.warnings.length > 0 && (
          <div className="rounded-md border border-amber-200 bg-amber-50 p-3">
            <div className="flex items-center gap-2 mb-2">
              <AlertTriangle className="h-4 w-4 text-amber-600" />
              <p className="text-sm font-medium text-amber-800">Warnings</p>
            </div>
            {importData.warnings.map((w, i) => (
              <p key={i} className="text-xs text-amber-700">{w}</p>
            ))}
          </div>
        )}

        {importData.unmappedItems && importData.unmappedItems.length > 0 && (
          <div className="rounded-md border p-3">
            <p className="text-sm font-medium mb-2">Unmapped Items</p>
            {importData.unmappedItems.map((item, i) => (
              <div key={i} className="text-xs text-muted-foreground">
                <span className="font-medium">{item.worksheetName}</span>
                {item.fieldName && <span> — {item.fieldName}</span>}
                <span>: {item.reason}</span>
              </div>
            ))}
          </div>
        )}

        {importData.importStatus === 'PROCESSING' && (
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin" />
            Processing workbook...
          </div>
        )}
      </CardContent>
    </Card>
  );
}

'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Upload, File, X, Loader2, CheckCircle2 } from 'lucide-react';

export function TableauImportForm() {
  const router = useRouter();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [result, setResult] = useState<{
    importId: string;
    dashId: string | null;
    widgetsCreated: number | null;
    warnings: string[] | null;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleFileChange = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (!file.name.endsWith('.twbx')) {
        setError('Please select a .twbx Tableau workbook file');
        return;
      }
      setSelectedFile(file);
      setError(null);
      setResult(null);
    }
  }, []);

  const handleUpload = useCallback(async () => {
    if (!selectedFile) return;

    setUploading(true);
    setError(null);

    try {
      const formData = new FormData();
      formData.append('file', selectedFile);

      const response = await fetch('/api/tableau/import', {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();

      if (data.success) {
        setResult({
          importId: data.data.importId,
          dashId: data.data.dashId,
          widgetsCreated: data.data.widgetsCreated,
          warnings: data.data.warnings,
        });
      } else {
        setError(data.error?.message || 'Import failed');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed');
    } finally {
      setUploading(false);
    }
  }, [selectedFile]);

  return (
    <div className="space-y-4 max-w-lg">
      {!result ? (
        <>
          {selectedFile ? (
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-3">
                  <File className="h-8 w-8 text-nexus-500 shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{selectedFile.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-7 w-7"
                    onClick={() => { setSelectedFile(null); setError(null); }}
                  >
                    <X className="h-4 w-4" />
                  </Button>
                </div>
              </CardContent>
            </Card>
          ) : (
            <label className="flex cursor-pointer flex-col items-center justify-center rounded-lg border-2 border-dashed p-12 transition-colors hover:border-nexus-400 hover:bg-muted/50">
              <Upload className="mb-3 h-10 w-10 text-muted-foreground" />
              <p className="font-medium">Upload Tableau Workbook</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Select a .twbx file to import
              </p>
              <input
                type="file"
                accept=".twbx"
                className="hidden"
                onChange={handleFileChange}
              />
            </label>
          )}

          {error && (
            <div className="rounded-md border border-red-200 bg-red-50 p-3">
              <p className="text-sm text-red-800">{error}</p>
            </div>
          )}

          {selectedFile && (
            <Button onClick={handleUpload} disabled={uploading} className="w-full">
              {uploading ? (
                <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Importing...</>
              ) : (
                <><Upload className="mr-2 h-4 w-4" />Start Import</>
              )}
            </Button>
          )}
        </>
      ) : (
        <Card>
          <CardContent className="p-6 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-green-500 mb-3" />
            <h3 className="text-lg font-semibold">Import Complete</h3>
            <p className="text-sm text-muted-foreground mt-1">
              {result.widgetsCreated} widgets created from the Tableau workbook.
            </p>
            {result.warnings && result.warnings.length > 0 && (
              <div className="mt-3 text-left rounded-md border border-amber-200 bg-amber-50 p-3">
                <p className="text-xs font-medium text-amber-800 mb-1">Warnings:</p>
                {result.warnings.map((w, i) => (
                  <p key={i} className="text-xs text-amber-700">{w}</p>
                ))}
              </div>
            )}
            <div className="mt-4 flex gap-2 justify-center">
              {result.dashId && (
                <Button onClick={() => router.push(`/dashboards/${result.dashId}`)}>
                  View Dashboard
                </Button>
              )}
              <Button variant="outline" onClick={() => { setSelectedFile(null); setResult(null); }}>
                Import Another
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

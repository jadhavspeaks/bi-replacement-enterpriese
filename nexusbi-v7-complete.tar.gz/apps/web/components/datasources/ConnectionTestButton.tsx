'use client';

import { useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Loader2, CheckCircle2, XCircle, Zap } from 'lucide-react';
import type { ConnectionTestResult } from '@nexusbi/shared-types';

interface ConnectionTestButtonProps {
  dsId: string;
  onTestComplete?: (result: ConnectionTestResult) => void;
}

export function ConnectionTestButton({ dsId, onTestComplete }: ConnectionTestButtonProps) {
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<ConnectionTestResult | null>(null);

  const handleTest = useCallback(async () => {
    setTesting(true);
    setResult(null);

    try {
      const response = await fetch(`/api/datasources/${dsId}/test`, {
        method: 'POST',
      });

      const data = await response.json();
      if (data.success && data.data) {
        setResult(data.data);
        onTestComplete?.(data.data);
      } else {
        setResult({
          success: false,
          latencyMs: 0,
          tableCount: null,
          errorMessage: data.error?.message || 'Test failed',
        });
      }
    } catch (error) {
      setResult({
        success: false,
        latencyMs: 0,
        tableCount: null,
        errorMessage: error instanceof Error ? error.message : 'Network error',
      });
    } finally {
      setTesting(false);
    }
  }, [dsId, onTestComplete]);

  return (
    <div className="space-y-2">
      <Button
        type="button"
        variant="outline"
        onClick={handleTest}
        disabled={testing}
      >
        {testing ? (
          <>
            <Loader2 className="mr-2 h-4 w-4 animate-spin" />
            Testing...
          </>
        ) : (
          <>
            <Zap className="mr-2 h-4 w-4" />
            Test Connection
          </>
        )}
      </Button>

      {result && (
        <div
          className={`flex items-start gap-2 rounded-md border p-3 text-sm ${
            result.success
              ? 'border-green-200 bg-green-50 text-green-800'
              : 'border-red-200 bg-red-50 text-red-800'
          }`}
        >
          {result.success ? (
            <CheckCircle2 className="h-4 w-4 mt-0.5 shrink-0" />
          ) : (
            <XCircle className="h-4 w-4 mt-0.5 shrink-0" />
          )}
          <div>
            <p className="font-medium">
              {result.success ? 'Connection successful' : 'Connection failed'}
            </p>
            {result.success && (
              <p className="text-xs mt-0.5">
                Latency: {result.latencyMs}ms
                {result.tableCount !== null && ` • ${result.tableCount} tables found`}
              </p>
            )}
            {result.errorMessage && (
              <p className="text-xs mt-0.5">{result.errorMessage}</p>
            )}
          </div>
        </div>
      )}
    </div>
  );
}

'use client';

import { Card, CardContent } from '@/components/ui/card';
import { StatusBadge } from '@nexusbi/ui-components';
import { DS_TYPE_LABELS, type DataSource } from '@nexusbi/shared-types';
import { Database, Clock } from 'lucide-react';

interface DataSourceCardProps {
  dataSource: DataSource;
  onClick?: () => void;
}

export function DataSourceCard({ dataSource, onClick }: DataSourceCardProps) {
  const lastTested = dataSource.lastTestedAt
    ? new Date(dataSource.lastTestedAt).toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit',
      })
    : null;

  return (
    <Card
      className="cursor-pointer transition-all hover:shadow-md hover:border-nexus-300"
      onClick={onClick}
    >
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-nexus-50">
              <Database className="h-5 w-5 text-nexus-600" />
            </div>
            <div className="min-w-0">
              <h3 className="font-semibold text-sm truncate">{dataSource.dsName}</h3>
              <p className="text-xs text-muted-foreground">
                {DS_TYPE_LABELS[dataSource.dsType] || dataSource.dsType}
              </p>
            </div>
          </div>
          <StatusBadge status={dataSource.status} size="sm" />
        </div>

        {dataSource.description && (
          <p className="mt-3 text-xs text-muted-foreground line-clamp-2">
            {dataSource.description}
          </p>
        )}

        <div className="mt-3 flex items-center justify-between text-xs text-muted-foreground">
          {lastTested ? (
            <span className="flex items-center gap-1">
              <Clock className="h-3 w-3" />
              Tested {lastTested}
            </span>
          ) : (
            <span>Not tested</span>
          )}
          {dataSource.lastTestResult && (
            <StatusBadge status={dataSource.lastTestResult} size="sm" showDot={false} />
          )}
        </div>
      </CardContent>
    </Card>
  );
}

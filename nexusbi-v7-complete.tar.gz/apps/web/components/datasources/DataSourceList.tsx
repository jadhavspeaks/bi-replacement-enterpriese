'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { useDataSourceStore } from '@/store/datasource.store';
import { DataSourceCard } from '@/components/datasources/DataSourceCard';
import { EmptyState } from '@nexusbi/ui-components';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, Database } from 'lucide-react';
import type { DataSourceType } from '@nexusbi/shared-types';

export function DataSourceList() {
  const router = useRouter();
  const { dataSources, loading, error, fetchDataSources } = useDataSourceStore();
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<string>('all');

  useEffect(() => {
    fetchDataSources();
  }, [fetchDataSources]);

  const filtered = dataSources.filter((ds) => {
    const matchesSearch = !search ||
      ds.dsName.toLowerCase().includes(search.toLowerCase()) ||
      ds.dsType.toLowerCase().includes(search.toLowerCase());
    const matchesType = typeFilter === 'all' || ds.dsType === typeFilter;
    return matchesSearch && matchesType;
  });

  const uniqueTypes = [...new Set(dataSources.map((ds) => ds.dsType))].sort();

  if (loading && dataSources.length === 0) {
    return (
      <div className="space-y-4">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-24 w-full" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="rounded-md border border-destructive/50 bg-destructive/10 p-4">
        <p className="text-sm text-destructive">{error}</p>
      </div>
    );
  }

  if (dataSources.length === 0) {
    return (
      <EmptyState
        icon={<Database className="h-8 w-8 text-muted-foreground" />}
        title="No data sources yet"
        description="Connect your first database, file, or API to start building dashboards."
        actionLabel="Add Data Source"
        actionHref="/datasources/new"
      />
    );
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3">
        <div className="relative flex-1 max-w-sm">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search data sources..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger className="w-48">
            <SelectValue placeholder="All types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All types</SelectItem>
            {uniqueTypes.map((type) => (
              <SelectItem key={type} value={type}>{type}</SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((ds) => (
          <DataSourceCard
            key={ds.dsId}
            dataSource={ds}
            onClick={() => router.push(`/datasources/${ds.dsId}`)}
          />
        ))}
      </div>

      {filtered.length === 0 && dataSources.length > 0 && (
        <p className="text-center text-sm text-muted-foreground py-8">
          No data sources match your search criteria.
        </p>
      )}
    </div>
  );
}

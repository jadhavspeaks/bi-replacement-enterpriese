'use client';

import { useState, useCallback } from 'react';
import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Upload, File, X } from 'lucide-react';
import type { DataSourceType } from '@nexusbi/shared-types';

interface FileUploadFormProps {
  dsType: DataSourceType;
  onFileSelect?: (file: File) => void;
}

const TYPE_LABELS: Record<string, string> = {
  file_csv: 'CSV',
  file_excel: 'Excel',
  file_parquet: 'Parquet',
  file_json: 'JSON',
};

const ACCEPT_MAP: Record<string, string> = {
  file_csv: '.csv,.tsv,.txt',
  file_excel: '.xlsx,.xls',
  file_parquet: '.parquet',
  file_json: '.json,.jsonl',
};

export function FileUploadForm({ dsType, onFileSelect }: FileUploadFormProps) {
  const { register, setValue, watch } = useFormContext();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const hasHeader = watch('config.hasHeader');
  const label = TYPE_LABELS[dsType] || 'File';

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
        setSelectedFile(file);
        onFileSelect?.(file);
      }
    },
    [onFileSelect],
  );

  const clearFile = useCallback(() => {
    setSelectedFile(null);
  }, []);

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label>Upload {label} File</Label>
        {selectedFile ? (
          <div className="flex items-center gap-3 rounded-md border p-3">
            <File className="h-5 w-5 text-muted-foreground shrink-0" />
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium truncate">{selectedFile.name}</p>
              <p className="text-xs text-muted-foreground">
                {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
              </p>
            </div>
            <Button variant="ghost" size="icon" className="h-7 w-7 shrink-0" onClick={clearFile}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <label className="flex cursor-pointer flex-col items-center justify-center rounded-md border-2 border-dashed p-8 transition-colors hover:border-primary hover:bg-muted/50">
            <Upload className="mb-2 h-8 w-8 text-muted-foreground" />
            <p className="text-sm font-medium">Click to upload or drag and drop</p>
            <p className="mt-1 text-xs text-muted-foreground">
              {label} files up to 500MB
            </p>
            <input
              type="file"
              accept={ACCEPT_MAP[dsType] || '*'}
              className="hidden"
              onChange={handleFileChange}
            />
          </label>
        )}
      </div>

      {(dsType === 'file_csv' || dsType === 'file_json') && (
        <>
          <div className="flex items-center gap-3">
            <Switch
              id="config.hasHeader"
              checked={hasHeader ?? true}
              onCheckedChange={(checked) => setValue('config.hasHeader', checked)}
            />
            <Label htmlFor="config.hasHeader">First row is header</Label>
          </div>

          <div className="space-y-2">
            <Label htmlFor="config.encoding">Encoding</Label>
            <Select
              defaultValue="utf-8"
              onValueChange={(value) => setValue('config.encoding', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="utf-8">UTF-8</SelectItem>
                <SelectItem value="latin1">Latin-1 (ISO-8859-1)</SelectItem>
                <SelectItem value="utf-16">UTF-16</SelectItem>
                <SelectItem value="ascii">ASCII</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </>
      )}

      {dsType === 'file_csv' && (
        <div className="space-y-2">
          <Label htmlFor="config.delimiter">Delimiter</Label>
          <Select
            defaultValue=","
            onValueChange={(value) => setValue('config.delimiter', value)}
          >
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value=",">Comma (,)</SelectItem>
              <SelectItem value="	">Tab (\t)</SelectItem>
              <SelectItem value=";">Semicolon (;)</SelectItem>
              <SelectItem value="|">Pipe (|)</SelectItem>
            </SelectContent>
          </Select>
        </div>
      )}

      {dsType === 'file_excel' && (
        <div className="space-y-2">
          <Label htmlFor="config.sheetName">Sheet Name (optional)</Label>
          <Input
            id="config.sheetName"
            placeholder="Leave empty for first sheet"
            {...register('config.sheetName')}
          />
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="config.skipRows">Skip Rows</Label>
        <Input
          id="config.skipRows"
          type="number"
          placeholder="0"
          defaultValue={0}
          {...register('config.skipRows', { valueAsNumber: true })}
        />
        <p className="text-xs text-muted-foreground">
          Number of rows to skip from the beginning of the file
        </p>
      </div>
    </div>
  );
}

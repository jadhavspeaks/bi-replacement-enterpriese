'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function ApiOAuthRestForm() {
  const { register, setValue, watch } = useFormContext();
  const grantType = watch('config.grantType') || 'client_credentials';

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.baseUrl">Base URL</Label>
        <Input
          id="config.baseUrl"
          placeholder="https://api.example.com/v1"
          {...register('config.baseUrl', { required: true })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.tokenUrl">Token Endpoint URL</Label>
        <Input
          id="config.tokenUrl"
          placeholder="https://auth.example.com/oauth/token"
          {...register('config.tokenUrl', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-2">
          <Label htmlFor="config.clientId">Client ID</Label>
          <Input
            id="config.clientId"
            {...register('config.clientId', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.clientSecret">Client Secret</Label>
          <Input
            id="config.clientSecret"
            type="password"
            {...register('config.clientSecret', { required: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Grant Type</Label>
        <Select
          value={grantType}
          onValueChange={(value) => setValue('config.grantType', value)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="client_credentials">Client Credentials</SelectItem>
            <SelectItem value="authorization_code">Authorization Code</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.scope">Scope (optional, space-separated)</Label>
        <Input
          id="config.scope"
          placeholder="read write"
          {...register('config.scope')}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.timeoutMs">Timeout (ms)</Label>
        <Input
          id="config.timeoutMs"
          type="number"
          defaultValue={30000}
          {...register('config.timeoutMs', { valueAsNumber: true })}
        />
      </div>
    </div>
  );
}

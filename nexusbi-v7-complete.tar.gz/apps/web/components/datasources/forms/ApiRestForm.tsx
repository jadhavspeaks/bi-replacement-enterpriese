'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';

export function ApiRestForm() {
  const { register, setValue, watch } = useFormContext();
  const authMethod = watch('config.authMethod') || 'none';

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.baseUrl">Base URL</Label>
        <Input
          id="config.baseUrl"
          placeholder="https://api.example.com/v1"
          {...register('config.baseUrl', { required: true })}
        />
      </div>

      <div className="space-y-2">
        <Label>Authentication Method</Label>
        <Select
          value={authMethod}
          onValueChange={(value) => setValue('config.authMethod', value)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="none">None</SelectItem>
            <SelectItem value="api_key">API Key</SelectItem>
            <SelectItem value="bearer">Bearer Token</SelectItem>
            <SelectItem value="basic">Basic Auth</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {authMethod === 'api_key' && (
        <div className="space-y-4 rounded-md border p-4">
          <div className="space-y-2">
            <Label htmlFor="config.apiKeyHeader">Header Name</Label>
            <Input
              id="config.apiKeyHeader"
              placeholder="X-API-Key"
              {...register('config.apiKeyHeader', { required: authMethod === 'api_key' })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="config.apiKeyValue">API Key Value</Label>
            <Input
              id="config.apiKeyValue"
              type="password"
              placeholder="••••••••"
              {...register('config.apiKeyValue', { required: authMethod === 'api_key' })}
            />
          </div>
        </div>
      )}

      {authMethod === 'bearer' && (
        <div className="space-y-2 rounded-md border p-4">
          <Label htmlFor="config.bearerToken">Bearer Token</Label>
          <Input
            id="config.bearerToken"
            type="password"
            placeholder="••••••••"
            {...register('config.bearerToken', { required: authMethod === 'bearer' })}
          />
        </div>
      )}

      {authMethod === 'basic' && (
        <div className="space-y-4 rounded-md border p-4">
          <div className="space-y-2">
            <Label htmlFor="config.basicUsername">Username</Label>
            <Input
              id="config.basicUsername"
              {...register('config.basicUsername', { required: authMethod === 'basic' })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="config.basicPassword">Password</Label>
            <Input
              id="config.basicPassword"
              type="password"
              placeholder="••••••••"
              {...register('config.basicPassword', { required: authMethod === 'basic' })}
            />
          </div>
        </div>
      )}

      <div className="space-y-2">
        <Label htmlFor="config.defaultHeaders">Default Headers (optional, JSON)</Label>
        <Textarea
          id="config.defaultHeaders"
          placeholder='{"Accept": "application/json"}'
          rows={3}
          className="font-mono text-xs"
          {...register('config.defaultHeaders')}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.timeoutMs">Timeout (ms)</Label>
        <Input
          id="config.timeoutMs"
          type="number"
          placeholder="30000"
          defaultValue={30000}
          {...register('config.timeoutMs', { valueAsNumber: true })}
        />
      </div>
    </div>
  );
}

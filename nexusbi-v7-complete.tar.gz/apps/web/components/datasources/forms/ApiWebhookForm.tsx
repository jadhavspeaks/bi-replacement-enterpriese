'use client';

import { useState, useCallback } from 'react';
import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Copy, Check, RefreshCw } from 'lucide-react';

export function ApiWebhookForm() {
  const { register, setValue, watch } = useFormContext();
  const [copied, setCopied] = useState(false);
  const secretValue = watch('config.secretValue') || '';

  const generateSecret = useCallback(() => {
    const array = new Uint8Array(32);
    crypto.getRandomValues(array);
    const secret = Array.from(array, (b) => b.toString(16).padStart(2, '0')).join('');
    setValue('config.secretValue', secret);
  }, [setValue]);

  const copySecret = useCallback(async () => {
    await navigator.clipboard.writeText(secretValue);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  }, [secretValue]);

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Configure an inbound webhook endpoint. External systems will POST data to your NexusBI webhook URL.
        The secret header is used to verify the authenticity of incoming requests.
      </p>

      <div className="space-y-2">
        <Label htmlFor="config.secretHeader">Secret Header Name</Label>
        <Input
          id="config.secretHeader"
          placeholder="X-Webhook-Secret"
          defaultValue="X-Webhook-Secret"
          {...register('config.secretHeader', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          The HTTP header that will carry the verification secret
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.secretValue">Secret Value</Label>
        <div className="flex gap-2">
          <Input
            id="config.secretValue"
            type="text"
            placeholder="Generate or enter a secret..."
            className="font-mono text-xs"
            {...register('config.secretValue', { required: true, minLength: 16 })}
          />
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={generateSecret}
            title="Generate random secret"
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button
            type="button"
            variant="outline"
            size="icon"
            onClick={copySecret}
            disabled={!secretValue}
            title="Copy secret"
          >
            {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground">
          Minimum 16 characters. Share this secret with the external system that will send webhooks.
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.payloadPath">Payload JSON Path (optional)</Label>
        <Input
          id="config.payloadPath"
          placeholder="data.records"
          {...register('config.payloadPath')}
        />
        <p className="text-xs text-muted-foreground">
          JMESPath expression to extract data from the webhook payload. Leave empty to use the full payload.
        </p>
      </div>

      <div className="rounded-md border bg-muted/50 p-4">
        <p className="text-sm font-medium mb-2">Webhook URL</p>
        <p className="text-xs text-muted-foreground">
          After creating this source, external systems should POST data to:
        </p>
        <code className="mt-1 block text-xs font-mono text-foreground">
          POST /api/webhook/ingest/{'<SOURCE_ID>'}
        </code>
      </div>
    </div>
  );
}

'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

export function MongoDBForm() {
  const { register, setValue, watch } = useFormContext();
  const ssl = watch('config.ssl');

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Connect via the MongoDB BI Connector (mongosqld). This provides a MySQL-compatible interface for SQL queries against MongoDB.
      </p>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">BI Connector Host</Label>
          <Input
            id="config.host"
            placeholder="localhost"
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder="3307"
            defaultValue={3307}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.database">Database</Label>
        <Input
          id="config.database"
          placeholder="mydb"
          {...register('config.database', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.user">Username (optional)</Label>
          <Input
            id="config.user"
            placeholder="mongouser"
            {...register('config.user')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.password">Password (optional)</Label>
          <Input
            id="config.password"
            type="password"
            placeholder="••••••••"
            {...register('config.password')}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.authSource">Auth Source</Label>
        <Input
          id="config.authSource"
          placeholder="admin"
          defaultValue="admin"
          {...register('config.authSource')}
        />
      </div>

      <div className="flex items-center gap-3">
        <Switch
          id="config.ssl"
          checked={ssl || false}
          onCheckedChange={(checked) => setValue('config.ssl', checked)}
        />
        <Label htmlFor="config.ssl">Use SSL</Label>
      </div>
    </div>
  );
}

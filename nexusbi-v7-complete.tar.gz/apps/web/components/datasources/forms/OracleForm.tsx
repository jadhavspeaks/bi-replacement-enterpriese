'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

export function OracleForm() {
  const { register, setValue, watch } = useFormContext();
  const useThin = watch('config.useThinDriver');

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">Host</Label>
          <Input
            id="config.host"
            placeholder="oracle-host"
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder="1521"
            defaultValue={1521}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.serviceName">Service Name</Label>
        <Input
          id="config.serviceName"
          placeholder="ORCL"
          {...register('config.serviceName', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.user">Username</Label>
          <Input
            id="config.user"
            placeholder="dbuser"
            {...register('config.user', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.password">Password</Label>
          <Input
            id="config.password"
            type="password"
            placeholder="••••••••"
            {...register('config.password', { required: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.schema">Schema (optional)</Label>
        <Input
          id="config.schema"
          placeholder="Leave empty for user default schema"
          {...register('config.schema')}
        />
      </div>

      <div className="flex items-center gap-3">
        <Switch
          id="config.useThinDriver"
          checked={useThin ?? true}
          onCheckedChange={(checked) => setValue('config.useThinDriver', checked)}
        />
        <Label htmlFor="config.useThinDriver">Use Thin Driver (recommended)</Label>
      </div>
    </div>
  );
}

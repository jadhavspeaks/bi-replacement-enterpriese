'use client';

import { useState, useEffect, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2, Shield, Save } from 'lucide-react';
import type { DsAccess, Role } from '@nexusbi/shared-types';

interface DataSourceAccessPanelProps {
  dsId: string;
}

interface AccessEntry extends DsAccess {
  roleName: string;
}

export function DataSourceAccessPanel({ dsId }: DataSourceAccessPanelProps) {
  const [accessList, setAccessList] = useState<AccessEntry[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState<string | null>(null);

  const [selectedRoleId, setSelectedRoleId] = useState('');
  const [canQuery, setCanQuery] = useState(true);
  const [canExport, setCanExport] = useState(false);
  const [canManage, setCanManage] = useState(false);
  const [rowFilterSql, setRowFilterSql] = useState('');
  const [expiresAt, setExpiresAt] = useState('');

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const [accessRes, rolesRes] = await Promise.all([
          fetch(`/api/datasources/${dsId}/access`),
          fetch('/api/admin/roles'),
        ]);

        if (accessRes.ok) {
          const accessData = await accessRes.json();
          if (accessData.success) setAccessList(accessData.data || []);
        }

        if (rolesRes.ok) {
          const rolesData = await rolesRes.json();
          if (rolesData.success) setRoles(rolesData.data || []);
        }
      } catch {
        // handle silently
      }
      setLoading(false);
    }
    load();
  }, [dsId]);

  const handleSave = useCallback(async () => {
    if (!selectedRoleId) return;

    setSaving(selectedRoleId);
    try {
      const response = await fetch(`/api/datasources/${dsId}/access`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          roleId: selectedRoleId,
          canQuery,
          canExport,
          canManage,
          rowFilterSql: rowFilterSql || undefined,
          expiresAt: expiresAt || undefined,
        }),
      });

      if (response.ok) {
        // Refresh access list
        const refreshRes = await fetch(`/api/datasources/${dsId}/access`);
        if (refreshRes.ok) {
          const refreshData = await refreshRes.json();
          if (refreshData.success) setAccessList(refreshData.data || []);
        }

        setSelectedRoleId('');
        setCanQuery(true);
        setCanExport(false);
        setCanManage(false);
        setRowFilterSql('');
        setExpiresAt('');
      }
    } catch {
      // handle silently
    }
    setSaving(null);
  }, [dsId, selectedRoleId, canQuery, canExport, canManage, rowFilterSql, expiresAt]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="text-base flex items-center gap-2">
            <Shield className="h-4 w-4" />
            Current Access Grants
          </CardTitle>
        </CardHeader>
        <CardContent>
          {accessList.length === 0 ? (
            <p className="text-sm text-muted-foreground">No access grants configured.</p>
          ) : (
            <div className="space-y-2">
              {accessList.map((entry) => (
                <div key={entry.accessId} className="flex items-center justify-between rounded-md border p-3">
                  <div>
                    <p className="text-sm font-medium">{entry.roleName}</p>
                    <p className="text-xs text-muted-foreground">
                      Query: {entry.canQuery ? 'Yes' : 'No'} •
                      Export: {entry.canExport ? 'Yes' : 'No'} •
                      Manage: {entry.canManage ? 'Yes' : 'No'}
                      {entry.expiresAt && ` • Expires: ${new Date(entry.expiresAt).toLocaleDateString()}`}
                    </p>
                    {entry.rowFilterSql && (
                      <p className="text-xs text-muted-foreground mt-1 font-mono">
                        RLS: {entry.rowFilterSql}
                      </p>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-base">Add / Update Access</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <Label>Role</Label>
            <Select value={selectedRoleId} onValueChange={setSelectedRoleId}>
              <SelectTrigger>
                <SelectValue placeholder="Select a role..." />
              </SelectTrigger>
              <SelectContent>
                {roles.map((role) => (
                  <SelectItem key={role.roleId} value={role.roleId}>
                    {role.roleName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <Switch checked={canQuery} onCheckedChange={setCanQuery} id="canQuery" />
              <Label htmlFor="canQuery">Can Query</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={canExport} onCheckedChange={setCanExport} id="canExport" />
              <Label htmlFor="canExport">Can Export</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={canManage} onCheckedChange={setCanManage} id="canManage" />
              <Label htmlFor="canManage">Can Manage</Label>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="rowFilterSql">Row-Level Security SQL (optional)</Label>
            <Textarea
              id="rowFilterSql"
              placeholder="e.g., region = 'APAC'"
              rows={2}
              className="font-mono text-xs"
              value={rowFilterSql}
              onChange={(e) => setRowFilterSql(e.target.value)}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="expiresAt">Access Expiry (optional)</Label>
            <Input
              id="expiresAt"
              type="datetime-local"
              value={expiresAt}
              onChange={(e) => setExpiresAt(e.target.value)}
            />
          </div>

          <Button onClick={handleSave} disabled={!selectedRoleId || saving !== null}>
            {saving ? (
              <><Loader2 className="mr-2 h-4 w-4 animate-spin" />Saving...</>
            ) : (
              <><Save className="mr-2 h-4 w-4" />Save Access</>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}

'use client';

import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CodeBlock } from '@nexusbi/ui-components';
import { Loader2, Code2, Copy, Check } from 'lucide-react';

interface EmbedDialogProps {
  dashId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

interface EmbedResult {
  token: string;
  embedCode: {
    iframe: string;
    react: string;
    script: string;
  };
}

export function EmbedDialog({ dashId, open, onOpenChange }: EmbedDialogProps) {
  const [generating, setGenerating] = useState(false);
  const [result, setResult] = useState<EmbedResult | null>(null);
  const [theme, setTheme] = useState<'light' | 'dark'>('light');
  const [expiresHours, setExpiresHours] = useState(24);
  const [copied, setCopied] = useState<string | null>(null);

  const handleGenerate = useCallback(async () => {
    setGenerating(true);

    try {
      const response = await fetch(`/api/dashboards/${dashId}/embed`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          expiresInHours: expiresHours,
          theme,
        }),
      });

      const data = await response.json();
      if (data.success) {
        setResult(data.data);
      }
    } catch {
      // handle error
    }

    setGenerating(false);
  }, [dashId, expiresHours, theme]);

  const copyCode = useCallback(async (code: string, type: string) => {
    await navigator.clipboard.writeText(code);
    setCopied(type);
    setTimeout(() => setCopied(null), 2000);
  }, []);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Code2 className="h-5 w-5" />
            Embed Dashboard
          </DialogTitle>
        </DialogHeader>

        {!result ? (
          <div className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Theme</Label>
                <Select value={theme} onValueChange={(v) => setTheme(v as 'light' | 'dark')}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="light">Light</SelectItem>
                    <SelectItem value="dark">Dark</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Token Expiry (hours)</Label>
                <Input
                  type="number"
                  value={expiresHours}
                  onChange={(e) => setExpiresHours(parseInt(e.target.value) || 24)}
                  min={1}
                  max={8760}
                />
              </div>
            </div>

            <Button onClick={handleGenerate} disabled={generating} className="w-full">
              {generating ? (
                <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Generating Token...</>
              ) : (
                <>Generate Embed Token</>
              )}
            </Button>
          </div>
        ) : (
          <Tabs defaultValue="iframe" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="iframe">iframe</TabsTrigger>
              <TabsTrigger value="react">React</TabsTrigger>
              <TabsTrigger value="script">Script</TabsTrigger>
            </TabsList>

            <TabsContent value="iframe" className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>HTML iframe Embed</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyCode(result.embedCode.iframe, 'iframe')}
                >
                  {copied === 'iframe' ? <Check className="h-3.5 w-3.5 mr-1" /> : <Copy className="h-3.5 w-3.5 mr-1" />}
                  {copied === 'iframe' ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <CodeBlock code={result.embedCode.iframe} language="html" maxHeight="200px" showCopy={false} />
            </TabsContent>

            <TabsContent value="react" className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>React Component</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyCode(result.embedCode.react, 'react')}
                >
                  {copied === 'react' ? <Check className="h-3.5 w-3.5 mr-1" /> : <Copy className="h-3.5 w-3.5 mr-1" />}
                  {copied === 'react' ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <CodeBlock code={result.embedCode.react} language="typescript" maxHeight="200px" showCopy={false} />
            </TabsContent>

            <TabsContent value="script" className="space-y-2">
              <div className="flex items-center justify-between">
                <Label>JavaScript SDK</Label>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => copyCode(result.embedCode.script, 'script')}
                >
                  {copied === 'script' ? <Check className="h-3.5 w-3.5 mr-1" /> : <Copy className="h-3.5 w-3.5 mr-1" />}
                  {copied === 'script' ? 'Copied' : 'Copy'}
                </Button>
              </div>
              <CodeBlock code={result.embedCode.script} language="html" maxHeight="200px" showCopy={false} />
            </TabsContent>

            <div className="rounded-md border bg-muted/50 p-3">
              <p className="text-xs text-muted-foreground">
                Token expires in {expiresHours} hours. Generate a new token when needed.
              </p>
            </div>

            <Button variant="outline" onClick={() => setResult(null)} className="w-full">
              Generate New Token
            </Button>
          </Tabs>
        )}
      </DialogContent>
    </Dialog>
  );
}

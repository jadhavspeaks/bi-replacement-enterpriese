'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ScrollArea } from '@/components/ui/scroll-area';
import { ConfirmDialog } from '@nexusbi/ui-components';
import { Loader2, History, RotateCcw, Clock } from 'lucide-react';
import type { DashboardVersion } from '@nexusbi/shared-types';

interface VersionHistoryProps {
  dashId: string;
}

export function VersionHistory({ dashId }: VersionHistoryProps) {
  const [versions, setVersions] = useState<DashboardVersion[]>([]);
  const [loading, setLoading] = useState(true);
  const [restoring, setRestoring] = useState(false);
  const [confirmRestore, setConfirmRestore] = useState<string | null>(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      try {
        const response = await fetch(`/api/dashboards/${dashId}/versions`);
        const data = await response.json();
        if (data.success) setVersions(data.data || []);
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  const handleRestore = useCallback(async (versionId: string) => {
    setRestoring(true);
    try {
      const response = await fetch(`/api/dashboards/${dashId}/restore`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ versionId }),
      });

      if (response.ok) {
        window.location.reload();
      }
    } catch {
      // handle error
    }
    setRestoring(false);
    setConfirmRestore(null);
  }, [dashId]);

  if (loading) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-8">
          <Loader2 className="h-6 w-6 animate-spin text-muted-foreground" />
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-base flex items-center gap-2">
            <History className="h-4 w-4" />
            Version History ({versions.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <ScrollArea className="max-h-96">
            <div className="divide-y">
              {versions.map((version, index) => (
                <div
                  key={version.versionId}
                  className="flex items-center justify-between px-4 py-3 hover:bg-muted/50"
                >
                  <div className="flex items-start gap-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-muted text-sm font-medium">
                      v{version.version}
                    </div>
                    <div>
                      <p className="text-sm font-medium">
                        {version.changeSummary || `Version ${version.version}`}
                      </p>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-0.5">
                        <Clock className="h-3 w-3" />
                        <span>{new Date(version.savedAt).toLocaleString()}</span>
                        <span>by {version.savedBy}</span>
                      </div>
                    </div>
                  </div>

                  {index > 0 && (
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setConfirmRestore(version.versionId)}
                      disabled={restoring}
                    >
                      <RotateCcw className="h-3.5 w-3.5 mr-1" />
                      Restore
                    </Button>
                  )}
                </div>
              ))}

              {versions.length === 0 && (
                <div className="px-4 py-8 text-center text-sm text-muted-foreground">
                  No version history available.
                </div>
              )}
            </div>
          </ScrollArea>
        </CardContent>
      </Card>

      <ConfirmDialog
        open={confirmRestore !== null}
        onOpenChange={(open) => { if (!open) setConfirmRestore(null); }}
        title="Restore Version"
        description="This will restore the dashboard to the selected version. The current state will be saved as a new version. This will also reset the approval status to DRAFT."
        confirmLabel="Restore"
        onConfirm={() => confirmRestore && handleRestore(confirmRestore)}
        loading={restoring}
      />
    </>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { DashboardGrid } from './DashboardGrid';
import { Smartphone } from 'lucide-react';
import type { MobileLayout } from '@nexusbi/shared-types';

interface MobilePreviewProps {
  dashId: string;
}

export function MobilePreview({ dashId }: MobilePreviewProps) {
  const [mobileLayout, setMobileLayout] = useState<MobileLayout | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/mobile`);
        const data = await response.json();
        if (data.success && data.data) {
          setMobileLayout(data.data);
        }
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  if (loading) {
    return <Skeleton className="h-96 w-64 mx-auto" />;
  }

  if (!mobileLayout) {
    return (
      <Card className="max-w-64 mx-auto">
        <CardContent className="py-8 text-center">
          <Smartphone className="mx-auto h-8 w-8 text-muted-foreground mb-2" />
          <p className="text-sm text-muted-foreground">
            No mobile layout configured. The default stacked layout will be used.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="max-w-sm mx-auto">
      <CardHeader className="p-3">
        <CardTitle className="text-sm flex items-center gap-2">
          <Smartphone className="h-4 w-4" />
          Mobile Preview (375px)
        </CardTitle>
      </CardHeader>
      <CardContent className="p-3 pt-0">
        <div className="mx-auto w-[375px] max-w-full rounded-lg border bg-white overflow-y-auto max-h-[667px]">
          <DashboardGrid
            dashId={dashId}
            isEditing={false}
            readOnly={true}
            mobileLayout={mobileLayout}
          />
        </div>
      </CardContent>
    </Card>
  );
}

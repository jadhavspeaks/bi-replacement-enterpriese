'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { StatCard } from '@nexusbi/ui-components';
import { Gauge, AlertTriangle, ArrowRight } from 'lucide-react';
import type { PerfScorecard as PerfScorecardType } from '@nexusbi/shared-types';

interface PerfScorecardProps {
  dashId: string;
}

function getBarColor(p95: number): string {
  if (p95 <= 500) return '#22c55e';
  if (p95 <= 1000) return '#f59e0b';
  if (p95 <= 2000) return '#f97316';
  return '#ef4444';
}

function truncate(s: string, n: number): string {
  return s.length > n ? s.substring(0, n) + '…' : s;
}

interface InlineBarChartProps {
  data: Array<{ name: string; p95: number }>;
}

function InlineBarChart({ data }: InlineBarChartProps) {
  if (data.length === 0) return null;
  const max = Math.max(...data.map((d) => d.p95), 100);
  const labelWidth = 160;
  const chartWidth = 500;
  const barHeight = 22;
  const rowHeight = 30;
  const height = data.length * rowHeight + 20;

  return (
    <svg width="100%" viewBox={`0 0 ${labelWidth + chartWidth + 20} ${height}`} role="img" aria-label="Widget load times P95">
      {data.map((d, i) => {
        const y = i * rowHeight + 10;
        const w = Math.max(2, (d.p95 / max) * chartWidth);
        return (
          <g key={i}>
            <text x={labelWidth - 8} y={y + barHeight / 2 + 4} fontSize="11" textAnchor="end" fill="#374151">
              {truncate(d.name, 22)}
            </text>
            <rect x={labelWidth} y={y} width={w} height={barHeight} rx="3" ry="3" fill={getBarColor(d.p95)} />
            <text x={labelWidth + w + 6} y={y + barHeight / 2 + 4} fontSize="10" fill="#6b7280">
              {d.p95}ms
            </text>
          </g>
        );
      })}
    </svg>
  );
}

export function PerfScorecard({ dashId }: PerfScorecardProps) {
  const router = useRouter();
  const [scorecard, setScorecard] = useState<PerfScorecardType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/perf`);
        const data = await response.json();
        if (data.success) setScorecard(data.data);
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!scorecard || scorecard.widgets.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Gauge className="mx-auto h-12 w-12 text-muted-foreground mb-3" />
          <h3 className="text-lg font-semibold">No Performance Data</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Performance metrics are collected as users view the dashboard.
          </p>
        </CardContent>
      </Card>
    );
  }

  const chartData = scorecard.widgets.map((w) => ({
    name: w.widgetTitle,
    p95: w.p95LoadMs,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <StatCard title="Overall P50" value={`${scorecard.overallP50Ms}ms`} trendDirection="down-good" />
        <StatCard title="Overall P95" value={`${scorecard.overallP95Ms}ms`} trendDirection="down-good" />
        
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-base">Widget Load Times (P95)</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <InlineBarChart data={chartData} />
          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-green-500" />{'<'}500ms</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" />500-1000ms</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-orange-500" />1-2s</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-500" />{'>'}2s</span>
          </div>
        </CardContent>
      </Card>

      {scorecard.recommendations.length > 0 && (
        <Card>
          <CardHeader className="p-4">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Recommendations ({scorecard.recommendations.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 space-y-3">
            {scorecard.recommendations.map((rec, i) => (
              <div key={i} className="rounded-md border p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{rec.widgetTitle}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{rec.reason}</p>
                    <p className="text-xs text-nexus-600 mt-1">{rec.suggestedAction}</p>
                    {rec.estimatedImprovement && (
                      <Badge variant="outline" className="mt-1 text-xs bg-green-50 text-green-700 border-green-200">
                        Estimated: {rec.estimatedImprovement}
                      </Badge>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

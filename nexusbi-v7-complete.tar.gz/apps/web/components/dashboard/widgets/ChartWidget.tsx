'use client';

import { useMemo, useEffect, useState } from 'react';
import ReactEChartsCore from 'echarts-for-react';
import { BaseWidget } from './BaseWidget';
import { Skeleton } from '@/components/ui/skeleton';
import type { WidgetConfig, ChartConfig, CubeQuery } from '@nexusbi/shared-types';

interface ChartWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
  data?: Record<string, unknown>[];
  loading?: boolean;
}

function buildEChartsOption(
  data: Record<string, unknown>[],
  chartConfig: ChartConfig,
  query?: CubeQuery,
): Record<string, unknown> {
  if (!data || data.length === 0) {
    return { title: { text: 'No data', left: 'center', top: 'center', textStyle: { color: '#94a3b8', fontSize: 14 } } };
  }

  const xKey = query?.dimensions?.[0] || Object.keys(data[0])[0];
  const yKeys = query?.measures || Object.keys(data[0]).filter((k) => k !== xKey);

  const xData = data.map((row) => String(row[xKey] ?? ''));

  const palette = chartConfig.colorPalette || [
    '#3b82f6', '#22c55e', '#f59e0b', '#ef4444', '#8b5cf6',
    '#06b6d4', '#ec4899', '#f97316', '#14b8a6', '#6366f1',
  ];

  const series = yKeys.map((key, i) => {
    const seriesData = data.map((row) => Number(row[key]) || 0);
    const base: Record<string, unknown> = {
      name: key.split('.').pop(),
      data: seriesData,
      itemStyle: { color: palette[i % palette.length] },
    };

    switch (chartConfig.chartType) {
      case 'bar':
        return { ...base, type: 'bar', stack: chartConfig.stacked ? 'total' : undefined };
      case 'line':
        return { ...base, type: 'line', smooth: chartConfig.smooth ?? false };
      case 'area':
        return { ...base, type: 'line', smooth: chartConfig.smooth ?? false, areaStyle: { opacity: chartConfig.areaOpacity ?? 0.3 } };
      case 'scatter':
        return { ...base, type: 'scatter', symbolSize: 8 };
      default:
        return { ...base, type: 'bar' };
    }
  });

  // Pie/donut uses different structure
  if (chartConfig.chartType === 'pie' || chartConfig.chartType === 'donut') {
    const pieData = data.map((row, i) => ({
      name: String(row[xKey] ?? `Item ${i}`),
      value: Number(row[yKeys[0]] ?? 0),
    }));

    return {
      tooltip: { trigger: 'item' },
      legend: chartConfig.showLegend !== false ? { bottom: 0 } : undefined,
      series: [{
        type: 'pie',
        radius: chartConfig.chartType === 'donut' ? ['40%', '70%'] : '70%',
        data: pieData,
        label: { show: chartConfig.showDataLabels ?? false },
        itemStyle: { borderRadius: 4, borderColor: '#fff', borderWidth: 2 },
      }],
    };
  }

  return {
    tooltip: { trigger: 'axis' },
    legend: chartConfig.showLegend !== false ? { bottom: 0 } : undefined,
    grid: { left: '3%', right: '4%', bottom: chartConfig.showLegend !== false ? '15%' : '3%', top: '8%', containLabel: true },
    xAxis: { type: 'category', data: xData, axisLabel: { rotate: xData.length > 10 ? 45 : 0, fontSize: 11 } },
    yAxis: { type: 'value', axisLabel: { fontSize: 11 } },
    series,
    color: palette,
  };
}

export function ChartWidget({ widget, dashId, isEditing, data: externalData, loading }: ChartWidgetProps) {
  const [queryData, setQueryData] = useState<Record<string, unknown>[]>([]);
  const [queryLoading, setQueryLoading] = useState(false);

  useEffect(() => {
    if (externalData) {
      setQueryData(externalData);
      return;
    }

    if (!widget.cubeQuery || !widget.cubeQuery.measures?.length) return;

    let cancelled = false;
    setQueryLoading(true);

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: widget.cubeQuery }),
    })
      .then((res) => res.json())
      .then((result) => {
        if (!cancelled) setQueryData(result.data || []);
      })
      .catch(() => {
        if (!cancelled) setQueryData([]);
      })
      .finally(() => {
        if (!cancelled) setQueryLoading(false);
      });

    return () => { cancelled = true; };
  }, [widget.cubeQuery, externalData]);

  const chartOption = useMemo(
    () => buildEChartsOption(queryData, widget.chartConfig || { chartType: 'bar' }, widget.cubeQuery),
    [queryData, widget.chartConfig, widget.cubeQuery],
  );

  const isLoading = loading || queryLoading;

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      {isLoading ? (
        <Skeleton className="h-full w-full" />
      ) : (
        <ReactEChartsCore
          option={chartOption}
          style={{ height: '100%', width: '100%' }}
          notMerge={true}
          opts={{ renderer: 'svg' }}
        />
      )}
    </BaseWidget>
  );
}

'use client';

import { useEffect, useState, useMemo } from 'react';
import { BaseWidget } from './BaseWidget';
import { Skeleton } from '@/components/ui/skeleton';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';
import type { WidgetConfig, KPIConfig } from '@nexusbi/shared-types';

interface KPIWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
  data?: Record<string, unknown>[];
  loading?: boolean;
}

function formatKPIValue(value: number, config: KPIConfig): string {
  let formatted: string;
  switch (config.format) {
    case 'currency':
      formatted = new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);
      break;
    case 'percent':
      formatted = `${value.toFixed(1)}%`;
      break;
    default:
      if (Math.abs(value) >= 1_000_000_000) formatted = `${(value / 1_000_000_000).toFixed(1)}B`;
      else if (Math.abs(value) >= 1_000_000) formatted = `${(value / 1_000_000).toFixed(1)}M`;
      else if (Math.abs(value) >= 1_000) formatted = `${(value / 1_000).toFixed(1)}K`;
      else formatted = new Intl.NumberFormat('en-US', { maximumFractionDigits: 2 }).format(value);
  }
  return `${config.prefix || ''}${formatted}${config.suffix || ''}`;
}

function getThresholdColor(value: number, thresholds?: KPIConfig['thresholds']): string {
  if (!thresholds) return '';
  if (thresholds.critical !== undefined && value <= thresholds.critical) return 'text-red-600';
  if (thresholds.warning !== undefined && value <= thresholds.warning) return 'text-amber-600';
  if (thresholds.good !== undefined && value >= thresholds.good) return 'text-green-600';
  return '';
}

export function KPIWidget({ widget, dashId, isEditing, data: externalData, loading }: KPIWidgetProps) {
  const [queryData, setQueryData] = useState<Record<string, unknown>[]>([]);
  const [queryLoading, setQueryLoading] = useState(false);
  const kpiConfig = widget.kpiConfig;

  useEffect(() => {
    if (externalData) { setQueryData(externalData); return; }
    if (!widget.cubeQuery?.measures?.length) return;

    let cancelled = false;
    setQueryLoading(true);

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: widget.cubeQuery }),
    })
      .then((res) => res.json())
      .then((result) => { if (!cancelled) setQueryData(result.data || []); })
      .catch(() => { if (!cancelled) setQueryData([]); })
      .finally(() => { if (!cancelled) setQueryLoading(false); });

    return () => { cancelled = true; };
  }, [widget.cubeQuery, externalData]);

  const { mainValue, comparisonValue, delta } = useMemo(() => {
    if (!kpiConfig || queryData.length === 0) return { mainValue: null, comparisonValue: null, delta: null };

    const row = queryData[0];
    const main = Number(row[kpiConfig.measure] ?? 0);
    let comp: number | null = null;
    let d: number | null = null;

    if (kpiConfig.comparisonMeasure && row[kpiConfig.comparisonMeasure] !== undefined) {
      comp = Number(row[kpiConfig.comparisonMeasure]);
      if (comp !== 0) d = ((main - comp) / Math.abs(comp)) * 100;
    }

    return { mainValue: main, comparisonValue: comp, delta: d };
  }, [queryData, kpiConfig]);

  const isLoading = loading || queryLoading;

  if (!kpiConfig) {
    return (
      <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
          Configure KPI settings
        </div>
      </BaseWidget>
    );
  }

  const trendDirection = kpiConfig.trendDirection || 'up-good';
  const thresholdColor = mainValue !== null ? getThresholdColor(mainValue, kpiConfig.thresholds) : '';

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      <div className="flex h-full flex-col items-center justify-center text-center">
        {isLoading ? (
          <>
            <Skeleton className="h-10 w-32 mb-2" />
            <Skeleton className="h-4 w-20" />
          </>
        ) : (
          <>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-1">
              {kpiConfig.label}
            </p>
            <p className={`text-3xl font-bold tracking-tight ${thresholdColor}`}>
              {mainValue !== null ? formatKPIValue(mainValue, kpiConfig) : '—'}
            </p>
            {delta !== null && (
              <div className={`mt-2 flex items-center gap-1 text-sm ${
                delta > 0
                  ? trendDirection === 'up-good' ? 'text-green-600' : 'text-red-600'
                  : delta < 0
                    ? trendDirection === 'up-good' ? 'text-red-600' : 'text-green-600'
                    : 'text-muted-foreground'
              }`}>
                {delta > 0 ? <TrendingUp className="h-4 w-4" /> :
                 delta < 0 ? <TrendingDown className="h-4 w-4" /> :
                 <Minus className="h-4 w-4" />}
                <span>{delta > 0 ? '+' : ''}{delta.toFixed(1)}%</span>
                {kpiConfig.comparisonLabel && (
                  <span className="text-muted-foreground text-xs">{kpiConfig.comparisonLabel}</span>
                )}
              </div>
            )}
          </>
        )}
      </div>
    </BaseWidget>
  );
}

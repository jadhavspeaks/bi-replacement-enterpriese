'use client';

import { useState, useCallback, useEffect } from 'react';
import { BaseWidget } from './BaseWidget';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { X, Search } from 'lucide-react';
import { useDashboardStore } from '@/store/dashboard.store';
import type { WidgetConfig, FilterConfig, CubeFilter } from '@nexusbi/shared-types';

interface FilterWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
}

export function FilterWidget({ widget, dashId, isEditing }: FilterWidgetProps) {
  const filterConfig = widget.filterConfig;
  const addGlobalFilter = useDashboardStore((s) => s.addGlobalFilter);
  const removeGlobalFilter = useDashboardStore((s) => s.removeGlobalFilter);
  const filters = useDashboardStore((s) => s.filters);

  const [inputValue, setInputValue] = useState('');
  const [selectedValues, setSelectedValues] = useState<string[]>([]);
  const [options, setOptions] = useState<string[]>([]);

  // Load filter options from cube metadata
  useEffect(() => {
    if (!filterConfig?.dimension) return;

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        query: {
          dimensions: [filterConfig.dimension],
          limit: 200,
          order: { [filterConfig.dimension]: 'asc' },
        },
      }),
    })
      .then((res) => res.json())
      .then((result) => {
        const values = (result.data || [])
          .map((row: Record<string, unknown>) => String(row[filterConfig.dimension] ?? ''))
          .filter((v: string) => v !== '');
        setOptions([...new Set(values)] as string[]);
      })
      .catch(() => setOptions([]));
  }, [filterConfig?.dimension]);

  const applyFilter = useCallback(() => {
    if (!filterConfig?.dimension) return;

    const filter: CubeFilter = {
      member: filterConfig.dimension,
      operator: selectedValues.length > 1 ? 'equals' : 'equals',
      values: selectedValues.length > 0 ? selectedValues : inputValue ? [inputValue] : [],
    };

    if (filter.values && filter.values.length > 0) {
      addGlobalFilter(filter);
    }
  }, [filterConfig, selectedValues, inputValue, addGlobalFilter]);

  const handleSelectChange = useCallback((value: string) => {
    if (filterConfig?.filterType === 'multi-select') {
      setSelectedValues((prev) =>
        prev.includes(value) ? prev.filter((v) => v !== value) : [...prev, value],
      );
    } else {
      setSelectedValues([value]);
      // Auto-apply for single select
      if (filterConfig?.dimension) {
        addGlobalFilter({
          member: filterConfig.dimension,
          operator: 'equals',
          values: [value],
        });
      }
    }
  }, [filterConfig, addGlobalFilter]);

  if (!filterConfig) {
    return (
      <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
        <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
          Configure filter settings
        </div>
      </BaseWidget>
    );
  }

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      <div className="space-y-2">
        <p className="text-xs font-medium text-muted-foreground">{filterConfig.label}</p>

        {(filterConfig.filterType === 'select' || filterConfig.filterType === 'multi-select') && (
          <Select onValueChange={handleSelectChange}>
            <SelectTrigger className="h-8 text-sm">
              <SelectValue placeholder={`Select ${filterConfig.label}...`} />
            </SelectTrigger>
            <SelectContent>
              {options.map((opt) => (
                <SelectItem key={opt} value={opt}>{opt}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {filterConfig.filterType === 'search' && (
          <div className="flex gap-2">
            <div className="relative flex-1">
              <Search className="absolute left-2 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder={`Search ${filterConfig.label}...`}
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') applyFilter(); }}
                className="h-8 pl-7 text-sm"
              />
            </div>
            <Button size="sm" variant="outline" className="h-8" onClick={applyFilter}>
              Apply
            </Button>
          </div>
        )}

        {filterConfig.filterType === 'date-range' && (
          <div className="flex gap-2">
            <Input
              type="date"
              className="h-8 text-sm"
              onChange={(e) => setSelectedValues((prev) => [e.target.value, prev[1] || ''])}
            />
            <Input
              type="date"
              className="h-8 text-sm"
              onChange={(e) => setSelectedValues((prev) => [prev[0] || '', e.target.value])}
            />
            <Button size="sm" variant="outline" className="h-8" onClick={applyFilter}>
              Apply
            </Button>
          </div>
        )}

        {selectedValues.length > 0 && filterConfig.filterType === 'multi-select' && (
          <div className="flex flex-wrap gap-1">
            {selectedValues.map((v) => (
              <Badge key={v} variant="secondary" className="text-xs gap-1">
                {v}
                <button onClick={() => setSelectedValues((prev) => prev.filter((x) => x !== v))}>
                  <X className="h-3 w-3" />
                </button>
              </Badge>
            ))}
            <Button size="sm" variant="outline" className="h-6 text-xs" onClick={applyFilter}>
              Apply All
            </Button>
          </div>
        )}
      </div>
    </BaseWidget>
  );
}

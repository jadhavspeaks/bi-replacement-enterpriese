'use client';

import { useState, useCallback } from 'react';
import { BaseWidget } from './BaseWidget';
import { Textarea } from '@/components/ui/textarea';
import { useDashboardStore } from '@/store/dashboard.store';
import type { WidgetConfig } from '@nexusbi/shared-types';

interface TextWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
}

function renderSimpleMarkdown(text: string): string {
  return text
    .replace(/^### (.+)$/gm, '<h3 class="text-lg font-semibold mt-3 mb-1">$1</h3>')
    .replace(/^## (.+)$/gm, '<h2 class="text-xl font-bold mt-4 mb-1">$1</h2>')
    .replace(/^# (.+)$/gm, '<h1 class="text-2xl font-bold mt-4 mb-2">$1</h1>')
    .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
    .replace(/\*(.+?)\*/g, '<em>$1</em>')
    .replace(/`(.+?)`/g, '<code class="bg-muted px-1 py-0.5 rounded text-sm font-mono">$1</code>')
    .replace(/\[(.+?)\]\((.+?)\)/g, '<a href="$2" class="text-nexus-600 underline" target="_blank" rel="noopener">$1</a>')
    .replace(/^- (.+)$/gm, '<li class="ml-4 list-disc">$1</li>')
    .replace(/\n/g, '<br/>');
}

export function TextWidget({ widget, dashId, isEditing }: TextWidgetProps) {
  const updateWidget = useDashboardStore((s) => s.updateWidget);
  const content = widget.textConfig?.content || '';
  const [editing, setEditing] = useState(false);
  const [localContent, setLocalContent] = useState(content);

  const handleBlur = useCallback(() => {
    setEditing(false);
    if (localContent !== content) {
      updateWidget(widget.widgetId, {
        textConfig: {
          ...widget.textConfig,
          content: localContent,
        },
      });
    }
  }, [localContent, content, widget.widgetId, widget.textConfig, updateWidget]);

  const style: React.CSSProperties = {
    fontSize: widget.textConfig?.fontSize ? `${widget.textConfig.fontSize}px` : undefined,
    textAlign: widget.textConfig?.textAlign || undefined,
    backgroundColor: widget.textConfig?.backgroundColor || undefined,
    color: widget.textConfig?.textColor || undefined,
  };

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      {isEditing && editing ? (
        <Textarea
          value={localContent}
          onChange={(e) => setLocalContent(e.target.value)}
          onBlur={handleBlur}
          autoFocus
          className="h-full resize-none border-0 focus-visible:ring-0 text-sm"
          placeholder="Enter markdown text..."
        />
      ) : (
        <div
          className="h-full overflow-auto text-sm cursor-text"
          style={style}
          onClick={() => { if (isEditing) setEditing(true); }}
          dangerouslySetInnerHTML={{
            __html: content ? renderSimpleMarkdown(content) : (
              isEditing
                ? '<span class="text-muted-foreground">Click to edit text...</span>'
                : ''
            ),
          }}
        />
      )}
    </BaseWidget>
  );
}

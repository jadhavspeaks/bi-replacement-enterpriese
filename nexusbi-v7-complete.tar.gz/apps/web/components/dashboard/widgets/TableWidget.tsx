'use client';

import { useMemo, useEffect, useState } from 'react';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-alpine.css';
import { BaseWidget } from './BaseWidget';
import { Skeleton } from '@/components/ui/skeleton';
import type { WidgetConfig, TableConfig, TableColumnConfig } from '@nexusbi/shared-types';
import type { ColDef, ValueFormatterParams } from 'ag-grid-community';

interface TableWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  isEditing?: boolean;
  data?: Record<string, unknown>[];
  loading?: boolean;
}

function formatCellValue(value: unknown, format?: TableColumnConfig['format']): string {
  if (value === null || value === undefined) return '—';

  switch (format) {
    case 'number':
      return new Intl.NumberFormat('en-US').format(Number(value));
    case 'currency':
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
      }).format(Number(value));
    case 'percent':
      return `${Number(value).toFixed(1)}%`;
    case 'date':
      return new Date(String(value)).toLocaleDateString();
    case 'datetime':
      return new Date(String(value)).toLocaleString();
    default:
      return String(value);
  }
}

function buildColumnDefs(
  data: Record<string, unknown>[],
  tableConfig?: TableConfig,
): ColDef[] {
  if (tableConfig?.columns && tableConfig.columns.length > 0) {
    return tableConfig.columns.map((col) => ({
      field: col.field,
      headerName: col.headerName,
      width: col.width,
      sortable: col.sortable !== false,
      filter: col.filterable !== false,
      valueFormatter: col.format
        ? (params: ValueFormatterParams) => formatCellValue(params.value, col.format)
        : undefined,
      resizable: true,
    }));
  }

  if (data.length === 0) return [];

  return Object.keys(data[0]).map((key) => ({
    field: key,
    headerName: key.split('.').pop()?.replace(/_/g, ' ') || key,
    sortable: true,
    filter: true,
    resizable: true,
  }));
}

export function TableWidget({ widget, dashId, isEditing, data: externalData, loading }: TableWidgetProps) {
  const [queryData, setQueryData] = useState<Record<string, unknown>[]>([]);
  const [queryLoading, setQueryLoading] = useState(false);

  useEffect(() => {
    if (externalData) {
      setQueryData(externalData);
      return;
    }

    if (!widget.cubeQuery) return;

    let cancelled = false;
    setQueryLoading(true);

    fetch('/api/cube/v1/load', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query: widget.cubeQuery }),
    })
      .then((res) => res.json())
      .then((result) => {
        if (!cancelled) setQueryData(result.data || []);
      })
      .catch(() => {
        if (!cancelled) setQueryData([]);
      })
      .finally(() => {
        if (!cancelled) setQueryLoading(false);
      });

    return () => { cancelled = true; };
  }, [widget.cubeQuery, externalData]);

  const columnDefs = useMemo(
    () => buildColumnDefs(queryData, widget.tableConfig),
    [queryData, widget.tableConfig],
  );

  const isLoading = loading || queryLoading;
  const pageSize = widget.tableConfig?.pageSize || 25;
  const rowHeight = widget.tableConfig?.rowHeight === 'compact' ? 32
    : widget.tableConfig?.rowHeight === 'comfortable' ? 48
    : 40;

  return (
    <BaseWidget widget={widget} dashId={dashId} isEditing={isEditing}>
      {isLoading ? (
        <div className="space-y-2">
          <Skeleton className="h-8 w-full" />
          {Array.from({ length: 5 }).map((_, i) => (
            <Skeleton key={i} className="h-6 w-full" />
          ))}
        </div>
      ) : (
        <div className="ag-theme-alpine h-full w-full" style={{ fontSize: '13px' }}>
          <AgGridReact
            rowData={queryData}
            columnDefs={columnDefs}
            pagination={true}
            paginationPageSize={pageSize}
            rowHeight={rowHeight}
            headerHeight={36}
            animateRows={true}
            domLayout="autoHeight"
            suppressCellFocus={true}
            defaultColDef={{
              flex: 1,
              minWidth: 80,
              sortable: true,
              filter: widget.tableConfig?.enableFiltering !== false,
              resizable: true,
            }}
          />
        </div>
      )}
    </BaseWidget>
  );
}

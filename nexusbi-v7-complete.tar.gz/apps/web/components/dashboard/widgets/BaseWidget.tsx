'use client';

import { useEffect, useRef, useState, type ReactNode } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreVertical, Copy, Trash2, Settings, Maximize2 } from 'lucide-react';
import { useDashboardStore } from '@/store/dashboard.store';
import type { WidgetConfig } from '@nexusbi/shared-types';

interface BaseWidgetProps {
  widget: WidgetConfig;
  dashId?: string;
  children: ReactNode;
  isEditing?: boolean;
  onConfigure?: () => void;
}

export function BaseWidget({ widget, dashId, children, isEditing = false, onConfigure }: BaseWidgetProps) {
  const mountTime = useRef(performance.now());
  const [dataReady, setDataReady] = useState(false);
  const removeWidget = useDashboardStore((s) => s.removeWidget);
  const duplicateWidget = useDashboardStore((s) => s.duplicateWidget);
  const selectWidget = useDashboardStore((s) => s.selectWidget);
  const selectedWidgetId = useDashboardStore((s) => s.selectedWidgetId);

  const isSelected = selectedWidgetId === widget.widgetId;

  // Log perf when data becomes ready
  useEffect(() => {
    if (dataReady && dashId) {
      const loadMs = Math.round(performance.now() - mountTime.current);

      fetch(`/api/dashboards/${dashId}/perf/log`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          widgetId: widget.widgetId,
          loadMs,
          cubeQueryMs: 0,
          renderMs: loadMs,
        }),
      }).catch(() => {
        // Fire and forget
      });
    }
  }, [dataReady, dashId, widget.widgetId]);

  // Mark data ready after initial render
  useEffect(() => {
    const timer = setTimeout(() => setDataReady(true), 100);
    return () => clearTimeout(timer);
  }, []);

  return (
    <Card
      className={`h-full flex flex-col transition-shadow ${
        isSelected && isEditing ? 'ring-2 ring-nexus-500 shadow-lg' : ''
      }`}
      onClick={(e) => {
        if (isEditing) {
          e.stopPropagation();
          selectWidget(widget.widgetId);
        }
      }}
      data-widget-id={widget.widgetId}
    >
      <CardHeader className="p-3 pb-1 flex-row items-center justify-between space-y-0 shrink-0">
        <CardTitle className="text-sm font-medium truncate">{widget.title}</CardTitle>
        {isEditing && (
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0">
                <MoreVertical className="h-3.5 w-3.5" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {onConfigure && (
                <DropdownMenuItem onClick={onConfigure}>
                  <Settings className="mr-2 h-3.5 w-3.5" />
                  Configure
                </DropdownMenuItem>
              )}
              <DropdownMenuItem onClick={() => duplicateWidget(widget.widgetId)}>
                <Copy className="mr-2 h-3.5 w-3.5" />
                Duplicate
              </DropdownMenuItem>
              <DropdownMenuItem
                className="text-destructive"
                onClick={() => removeWidget(widget.widgetId)}
              >
                <Trash2 className="mr-2 h-3.5 w-3.5" />
                Remove
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        )}
      </CardHeader>
      <CardContent className="p-3 pt-0 flex-1 min-h-0 overflow-hidden">
        {children}
      </CardContent>
    </Card>
  );
}

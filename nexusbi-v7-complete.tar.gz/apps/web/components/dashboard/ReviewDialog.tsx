'use client';

import { useState, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { DualCheckerBadge } from './DualCheckerBadge';
import { Loader2, CheckCircle2, XCircle } from 'lucide-react';

interface ReviewDialogProps {
  dashId: string;
  dashName: string;
  dualCheckerRequired: boolean;
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onComplete?: () => void;
}

export function ReviewDialog({
  dashId,
  dashName,
  dualCheckerRequired,
  open,
  onOpenChange,
  onComplete,
}: ReviewDialogProps) {
  const [action, setAction] = useState<'approve' | 'reject' | null>(null);
  const [comments, setComments] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const handleSubmit = useCallback(async () => {
    if (!action) return;
    if (action === 'reject' && !comments.trim()) {
      setError('Comments are required when rejecting');
      return;
    }

    setLoading(true);
    setError(null);

    try {
      const endpoint = action === 'approve'
        ? `/api/dashboards/${dashId}/approve`
        : `/api/dashboards/${dashId}/reject`;

      const response = await fetch(endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ comments: comments || undefined }),
      });

      const data = await response.json();

      if (data.success) {
        const status = data.data?.status;
        if (action === 'approve' && status === 'PENDING_REVIEW') {
          setSuccess('First checker approval recorded. Waiting for second checker.');
        } else if (action === 'approve') {
          setSuccess('Dashboard approved successfully.');
        } else {
          setSuccess('Dashboard rejected.');
        }
        onComplete?.();
      } else {
        setError(data.error?.message || `Failed to ${action}`);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    }

    setLoading(false);
  }, [action, comments, dashId, onComplete]);

  const handleClose = useCallback(() => {
    setAction(null);
    setComments('');
    setError(null);
    setSuccess(null);
    onOpenChange(false);
  }, [onOpenChange]);

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle>Review Dashboard</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div>
            <p className="text-sm font-medium">{dashName}</p>
            {dualCheckerRequired && (
              <div className="mt-2">
                <DualCheckerBadge dashId={dashId} />
              </div>
            )}
          </div>

          {success ? (
            <div className="rounded-md border border-green-200 bg-green-50 p-4 text-center">
              <CheckCircle2 className="mx-auto h-8 w-8 text-green-500 mb-2" />
              <p className="text-sm text-green-800">{success}</p>
            </div>
          ) : (
            <>
              {!action && (
                <div className="flex gap-3">
                  <Button
                    className="flex-1 bg-green-600 hover:bg-green-700"
                    onClick={() => setAction('approve')}
                  >
                    <CheckCircle2 className="h-4 w-4 mr-2" />
                    Approve
                  </Button>
                  <Button
                    variant="destructive"
                    className="flex-1"
                    onClick={() => setAction('reject')}
                  >
                    <XCircle className="h-4 w-4 mr-2" />
                    Reject
                  </Button>
                </div>
              )}

              {action && (
                <>
                  <div className="space-y-2">
                    <Label>
                      Comments {action === 'reject' ? '(required)' : '(optional)'}
                    </Label>
                    <Textarea
                      placeholder={
                        action === 'reject'
                          ? 'Explain why this dashboard is being rejected...'
                          : 'Add any review comments...'
                      }
                      value={comments}
                      onChange={(e) => setComments(e.target.value)}
                      rows={4}
                    />
                  </div>

                  {error && (
                    <div className="rounded-md border border-red-200 bg-red-50 p-3">
                      <p className="text-sm text-red-800">{error}</p>
                    </div>
                  )}

                  <DialogFooter>
                    <Button variant="outline" onClick={() => setAction(null)} disabled={loading}>
                      Back
                    </Button>
                    <Button
                      onClick={handleSubmit}
                      disabled={loading || (action === 'reject' && !comments.trim())}
                      className={action === 'approve' ? 'bg-green-600 hover:bg-green-700' : ''}
                      variant={action === 'reject' ? 'destructive' : 'default'}
                    >
                      {loading ? (
                        <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Processing...</>
                      ) : (
                        <>Confirm {action === 'approve' ? 'Approval' : 'Rejection'}</>
                      )}
                    </Button>
                  </DialogFooter>
                </>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

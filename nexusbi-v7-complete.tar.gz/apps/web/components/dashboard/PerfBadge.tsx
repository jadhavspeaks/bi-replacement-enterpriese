'use client';

import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Gauge } from 'lucide-react';

interface PerfBadgeProps {
  p95Ms: number;
  sampleCount?: number;
}

function getColor(p95: number): { bg: string; text: string; label: string } {
  if (p95 <= 500) return { bg: 'bg-green-50', text: 'text-green-700', label: 'Fast' };
  if (p95 <= 1000) return { bg: 'bg-amber-50', text: 'text-amber-700', label: 'OK' };
  if (p95 <= 2000) return { bg: 'bg-orange-50', text: 'text-orange-700', label: 'Slow' };
  return { bg: 'bg-red-50', text: 'text-red-700', label: 'Very Slow' };
}

export function PerfBadge({ p95Ms, sampleCount }: PerfBadgeProps) {
  const { bg, text, label } = getColor(p95Ms);

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger>
          <Badge variant="outline" className={`${bg} ${text} border-current/20 text-[10px] px-1.5 py-0 gap-0.5`}>
            <Gauge className="h-2.5 w-2.5" />
            {p95Ms}ms
          </Badge>
        </TooltipTrigger>
        <TooltipContent>
          <div className="text-xs space-y-0.5">
            <p className="font-medium">P95 Load Time: {p95Ms}ms ({label})</p>
            {sampleCount !== undefined && (
              <p className="text-muted-foreground">Based on {sampleCount} samples</p>
            )}
          </div>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { Badge } from '@/components/ui/badge';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { Users, CheckCircle2, XCircle, Clock } from 'lucide-react';
import type { CheckerAssignmentWithUser } from '@nexusbi/shared-types';

interface DualCheckerBadgeProps {
  dashId: string;
  compact?: boolean;
}

interface ReviewData {
  checkerAssignments: CheckerAssignmentWithUser[];
}

export function DualCheckerBadge({ dashId, compact = false }: DualCheckerBadgeProps) {
  const [assignments, setAssignments] = useState<CheckerAssignmentWithUser[]>([]);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/reviews`);
        const data = await response.json();
        if (data.success && data.data?.length > 0) {
          const latestReview = data.data[0] as ReviewData;
          setAssignments(latestReview.checkerAssignments || []);
        }
      } catch {
        // handle silently
      }
    }
    load();
  }, [dashId]);

  const slot1 = assignments.find((a) => a.checkerSlot === 1);
  const slot2 = assignments.find((a) => a.checkerSlot === 2);

  const approvedCount = assignments.filter((a) => a.decision === 'APPROVED').length;
  const hasRejection = assignments.some((a) => a.decision === 'REJECTED');

  if (compact) {
    return (
      <Badge
        variant="outline"
        className={`text-xs ${
          hasRejection
            ? 'bg-red-50 text-red-700 border-red-200'
            : approvedCount === 2
              ? 'bg-green-50 text-green-700 border-green-200'
              : 'bg-purple-50 text-purple-700 border-purple-200'
        }`}
      >
        <Users className="h-3 w-3 mr-1" />
        {approvedCount}/2
      </Badge>
    );
  }

  return (
    <TooltipProvider>
      <div className="flex items-center gap-2">
        <Badge variant="outline" className="bg-purple-50 text-purple-700 border-purple-200">
          <Users className="h-3 w-3 mr-1" />
          Dual-Checker
        </Badge>

        <div className="flex items-center gap-1.5">
          {/* Slot 1 */}
          <Tooltip>
            <TooltipTrigger>
              <div className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${
                slot1?.decision === 'APPROVED'
                  ? 'bg-green-100 text-green-700'
                  : slot1?.decision === 'REJECTED'
                    ? 'bg-red-100 text-red-700'
                    : 'bg-zinc-100 text-zinc-500'
              }`}>
                {slot1?.decision === 'APPROVED' ? (
                  <CheckCircle2 className="h-3 w-3" />
                ) : slot1?.decision === 'REJECTED' ? (
                  <XCircle className="h-3 w-3" />
                ) : (
                  <Clock className="h-3 w-3" />
                )}
                <span>1</span>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">
                Slot 1: {slot1 ? `${slot1.checkerDisplayName || slot1.checkerId} — ${slot1.decision}` : 'Pending'}
              </p>
            </TooltipContent>
          </Tooltip>

          {/* Slot 2 */}
          <Tooltip>
            <TooltipTrigger>
              <div className={`flex items-center gap-1 rounded-full px-2 py-0.5 text-xs ${
                slot2?.decision === 'APPROVED'
                  ? 'bg-green-100 text-green-700'
                  : slot2?.decision === 'REJECTED'
                    ? 'bg-red-100 text-red-700'
                    : 'bg-zinc-100 text-zinc-500'
              }`}>
                {slot2?.decision === 'APPROVED' ? (
                  <CheckCircle2 className="h-3 w-3" />
                ) : slot2?.decision === 'REJECTED' ? (
                  <XCircle className="h-3 w-3" />
                ) : (
                  <Clock className="h-3 w-3" />
                )}
                <span>2</span>
              </div>
            </TooltipTrigger>
            <TooltipContent>
              <p className="text-xs">
                Slot 2: {slot2 ? `${slot2.checkerDisplayName || slot2.checkerId} — ${slot2.decision}` : 'Pending'}
              </p>
            </TooltipContent>
          </Tooltip>
        </div>
      </div>
    </TooltipProvider>
  );
}

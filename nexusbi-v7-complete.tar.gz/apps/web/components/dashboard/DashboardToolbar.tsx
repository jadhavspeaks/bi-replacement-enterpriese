'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Separator } from '@/components/ui/separator';
import { useDashboardStore } from '@/store/dashboard.store';
import { ApprovalStatusBadge } from '@nexusbi/ui-components';
import { PermissionGate } from '@/components/shared/PermissionGate';
import {
  Save, Undo2, Redo2, Share2, Code2, Send, History,
  PlayCircle, Gauge, Loader2,
} from 'lucide-react';
import { BreakpointToggle } from './BreakpointToggle';

interface DashboardToolbarProps {
  dashId: string;
  onShare?: () => void;
  onEmbed?: () => void;
  onSubmit?: () => void;
}

export function DashboardToolbar({ dashId, onShare, onEmbed, onSubmit }: DashboardToolbarProps) {
  const router = useRouter();
  const dashboard = useDashboardStore((s) => s.dashboard);
  const isDirty = useDashboardStore((s) => s.isDirty);
  const isSaving = useDashboardStore((s) => s.isSaving);
  const save = useDashboardStore((s) => s.save);
  const undo = useDashboardStore((s) => s.undo);
  const redo = useDashboardStore((s) => s.redo);
  const canUndo = useDashboardStore((s) => s.canUndo);
  const canRedo = useDashboardStore((s) => s.canRedo);

  if (!dashboard) return null;

  return (
    <div className="flex items-center justify-between rounded-lg border bg-background p-2 mb-4">
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          onClick={undo}
          disabled={!canUndo()}
          title="Undo"
        >
          <Undo2 className="h-4 w-4" />
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={redo}
          disabled={!canRedo()}
          title="Redo"
        >
          <Redo2 className="h-4 w-4" />
        </Button>

        <Separator orientation="vertical" className="h-6" />

        <BreakpointToggle />

        <Separator orientation="vertical" className="h-6" />

        <ApprovalStatusBadge status={dashboard.approvalStatus} size="sm" />
      </div>

      <div className="flex items-center gap-2">
        <PermissionGate permission="perf.view">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push(`/dashboards/${dashId}/perf`)}
            title="Performance"
          >
            <Gauge className="h-4 w-4 mr-1" />
            Perf
          </Button>
        </PermissionGate>

        <PermissionGate permission="dashboard.replay">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => router.push(`/dashboards/${dashId}/replay`)}
            title="Replay history"
          >
            <PlayCircle className="h-4 w-4 mr-1" />
            Replay
          </Button>
        </PermissionGate>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => router.push(`/dashboards/${dashId}/edit`)}
          title="Version history"
        >
          <History className="h-4 w-4 mr-1" />
          Versions
        </Button>

        <Separator orientation="vertical" className="h-6" />

        <PermissionGate permission="dashboard.share">
          <Button variant="ghost" size="sm" onClick={onShare}>
            <Share2 className="h-4 w-4 mr-1" />
            Share
          </Button>
        </PermissionGate>

        <PermissionGate permission="dashboard.embed">
          <Button variant="ghost" size="sm" onClick={onEmbed}>
            <Code2 className="h-4 w-4 mr-1" />
            Embed
          </Button>
        </PermissionGate>

        <PermissionGate permission="dashboard.submit">
          {dashboard.approvalStatus === 'DRAFT' || dashboard.approvalStatus === 'REJECTED' ? (
            <Button variant="outline" size="sm" onClick={onSubmit}>
              <Send className="h-4 w-4 mr-1" />
              Submit for Review
            </Button>
          ) : null}
        </PermissionGate>

        <Button
          size="sm"
          onClick={save}
          disabled={!isDirty || isSaving}
        >
          {isSaving ? (
            <><Loader2 className="h-4 w-4 mr-1 animate-spin" />Saving...</>
          ) : (
            <><Save className="h-4 w-4 mr-1" />Save</>
          )}
        </Button>
      </div>
    </div>
  );
}

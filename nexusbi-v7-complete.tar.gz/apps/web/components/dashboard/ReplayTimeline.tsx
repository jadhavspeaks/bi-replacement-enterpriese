'use client';

import { Button } from '@/components/ui/button';
import { ScrollArea, ScrollBar } from '@/components/ui/scroll-area';
import { CheckCircle2 } from 'lucide-react';
import type { ApprovalSnapshotListItem } from '@nexusbi/shared-types';

interface ReplayTimelineProps {
  snapshots: ApprovalSnapshotListItem[];
  selectedSnapshotId: string | null;
  onSelect: (snapshotId: string) => void;
}

export function ReplayTimeline({ snapshots, selectedSnapshotId, onSelect }: ReplayTimelineProps) {
  return (
    <div className="rounded-lg border bg-background p-3">
      <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3">
        Approval Timeline
      </p>
      <ScrollArea className="w-full">
        <div className="flex items-center gap-2 pb-2">
          {snapshots.map((snapshot, index) => {
            const isSelected = selectedSnapshotId === snapshot.snapshotId;
            const date = new Date(snapshot.snappedAt);

            return (
              <div key={snapshot.snapshotId} className="flex items-center">
                <Button
                  variant={isSelected ? 'default' : 'outline'}
                  size="sm"
                  className={`shrink-0 h-auto py-2 px-3 flex-col items-center gap-0.5 ${
                    isSelected ? 'ring-2 ring-nexus-500' : ''
                  }`}
                  onClick={() => onSelect(snapshot.snapshotId)}
                >
                  <CheckCircle2 className={`h-4 w-4 ${isSelected ? 'text-white' : 'text-green-500'}`} />
                  <span className="text-xs font-semibold">v{snapshot.version}</span>
                  <span className="text-[10px] opacity-75">
                    {date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                  </span>
                  {snapshot.snappedByDisplayName && (
                    <span className="text-[10px] opacity-60 truncate max-w-20">
                      {snapshot.snappedByDisplayName}
                    </span>
                  )}
                </Button>

                {index < snapshots.length - 1 && (
                  <div className="w-8 h-0.5 bg-border mx-1 shrink-0" />
                )}
              </div>
            );
          })}
        </div>
        <ScrollBar orientation="horizontal" />
      </ScrollArea>
    </div>
  );
}

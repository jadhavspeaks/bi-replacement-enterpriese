'use client';

import { useEffect, useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ApprovalStatusBadge } from '@nexusbi/ui-components';
import { EmptyState } from '@nexusbi/ui-components';
import { ReviewDialog } from './ReviewDialog';
import { Skeleton } from '@/components/ui/skeleton';
import { ClipboardCheck, Eye, Clock, Users } from 'lucide-react';

interface PendingReviewItem {
  reviewId: string;
  dashId: string;
  dashName: string;
  dashVersion: number;
  submittedBy: string;
  submittedByDisplayName: string;
  submittedAt: string;
  dualCheckerRequired: boolean;
  slot1Filled: boolean;
  slot1CheckerName: string | null;
}

export function ReviewQueue() {
  const router = useRouter();
  const [queue, setQueue] = useState<PendingReviewItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewTarget, setReviewTarget] = useState<PendingReviewItem | null>(null);

  const fetchQueue = useCallback(async () => {
    try {
      const response = await fetch('/api/dashboards/pending-review');
      const data = await response.json();
      if (data.success) setQueue(data.data || []);
    } catch {
      // handle error
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchQueue();
  }, [fetchQueue]);

  if (loading) {
    return (
      <div className="space-y-3">
        {Array.from({ length: 3 }).map((_, i) => (
          <Skeleton key={i} className="h-20 w-full" />
        ))}
      </div>
    );
  }

  if (queue.length === 0) {
    return (
      <EmptyState
        icon={<ClipboardCheck className="h-8 w-8 text-muted-foreground" />}
        title="No pending reviews"
        description="All dashboards have been reviewed. Check back later."
      />
    );
  }

  return (
    <>
      <div className="space-y-3">
        {queue.map((item) => (
          <Card key={item.reviewId} className="hover:shadow-md transition-shadow">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold text-sm truncate">{item.dashName}</h3>
                    <ApprovalStatusBadge status="PENDING_REVIEW" size="sm" />
                    {item.dualCheckerRequired && (
                      <Badge variant="outline" className="text-xs bg-purple-50 text-purple-700 border-purple-200">
                        <Users className="h-3 w-3 mr-1" />
                        Dual-Checker
                      </Badge>
                    )}
                  </div>

                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    <span>v{item.dashVersion}</span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      Submitted {new Date(item.submittedAt).toLocaleDateString()}
                    </span>
                    <span>by {item.submittedByDisplayName}</span>
                  </div>

                  {item.dualCheckerRequired && item.slot1Filled && (
                    <p className="mt-1 text-xs text-purple-600">
                      Slot 1 approved by {item.slot1CheckerName} — awaiting second checker
                    </p>
                  )}
                </div>

                <div className="flex items-center gap-2 shrink-0 ml-4">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => router.push(`/dashboards/${item.dashId}`)}
                  >
                    <Eye className="h-3.5 w-3.5 mr-1" />
                    View
                  </Button>
                  <Button
                    size="sm"
                    onClick={() => setReviewTarget(item)}
                  >
                    <ClipboardCheck className="h-3.5 w-3.5 mr-1" />
                    Review
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {reviewTarget && (
        <ReviewDialog
          dashId={reviewTarget.dashId}
          dashName={reviewTarget.dashName}
          dualCheckerRequired={reviewTarget.dualCheckerRequired}
          open={true}
          onOpenChange={(open) => { if (!open) setReviewTarget(null); }}
          onComplete={fetchQueue}
        />
      )}
    </>
  );
}

'use client';

import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useUserStore } from '@/store/user.store';

interface CollaboratorPresenceProps {
  dashId: string;
}

/**
 * CollaboratorPresence — live-presence stub.
 *
 * The real-time presence feature is temporarily disabled because yjs and
 * y-websocket introduce peer-dep complexity that conflicts with React 19 in
 * some CI environments. This stub renders the current user only. When ready
 * to re-enable, install yjs + y-websocket, restore the original awareness
 * wiring, and point WEBSOCKET_URL to your CRDT server.
 */
export function CollaboratorPresence({ dashId: _dashId }: CollaboratorPresenceProps) {
  const user = useUserStore((s) => s.user);

  if (!user) return null;

  const initials = (user.displayName || user.username || 'U')
    .split(/\s+/)
    .map((s) => s[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  return (
    <TooltipProvider>
      <div className="flex items-center -space-x-2">
        <Tooltip>
          <TooltipTrigger asChild>
            <Avatar className="h-7 w-7 border-2 border-white shadow-sm">
              <AvatarFallback className="text-[11px] font-semibold bg-blue-600 text-white">
                {initials}
              </AvatarFallback>
            </Avatar>
          </TooltipTrigger>
          <TooltipContent>{user.displayName || user.username} (you)</TooltipContent>
        </Tooltip>
      </div>
    </TooltipProvider>
  );
}

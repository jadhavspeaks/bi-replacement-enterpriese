'use client';

import { useState, useEffect, useCallback } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Share2, Trash2, Users, User } from 'lucide-react';
import type { DashboardShare, Role } from '@nexusbi/shared-types';

interface ShareDialogProps {
  dashId: string;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ShareDialog({ dashId, open, onOpenChange }: ShareDialogProps) {
  const [shares, setShares] = useState<DashboardShare[]>([]);
  const [roles, setRoles] = useState<Role[]>([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const [shareType, setShareType] = useState<'role' | 'user'>('role');
  const [selectedRoleId, setSelectedRoleId] = useState('');
  const [userId, setUserId] = useState('');
  const [canEdit, setCanEdit] = useState(false);
  const [canShare, setCanShare] = useState(false);

  useEffect(() => {
    if (!open) return;

    setLoading(true);
    Promise.all([
      fetch(`/api/dashboards/${dashId}`).then((r) => r.json()),
      fetch('/api/admin/roles').then((r) => r.json()),
    ]).then(([dashData, rolesData]) => {
      if (rolesData.success) setRoles(rolesData.data || []);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, [dashId, open]);

  const handleShare = useCallback(async () => {
    setSaving(true);
    try {
      const body: Record<string, unknown> = { canEdit, canShare };
      if (shareType === 'role') body.roleId = selectedRoleId;
      else body.userId = userId;

      const response = await fetch(`/api/dashboards/${dashId}/share`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });

      if (response.ok) {
        setSelectedRoleId('');
        setUserId('');
        setCanEdit(false);
        setCanShare(false);
      }
    } catch {
      // handle error
    }
    setSaving(false);
  }, [dashId, shareType, selectedRoleId, userId, canEdit, canShare]);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Share2 className="h-5 w-5" />
            Share Dashboard
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex gap-2">
            <Button
              variant={shareType === 'role' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShareType('role')}
            >
              <Users className="h-3.5 w-3.5 mr-1" />
              By Role
            </Button>
            <Button
              variant={shareType === 'user' ? 'default' : 'outline'}
              size="sm"
              onClick={() => setShareType('user')}
            >
              <User className="h-3.5 w-3.5 mr-1" />
              By User
            </Button>
          </div>

          {shareType === 'role' ? (
            <div className="space-y-2">
              <Label>Role</Label>
              <Select value={selectedRoleId} onValueChange={setSelectedRoleId}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a role..." />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.roleId} value={role.roleId}>
                      {role.roleName}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          ) : (
            <div className="space-y-2">
              <Label>User ID or Email</Label>
              <Input
                placeholder="user@example.com"
                value={userId}
                onChange={(e) => setUserId(e.target.value)}
              />
            </div>
          )}

          <div className="flex gap-6">
            <div className="flex items-center gap-2">
              <Switch checked={canEdit} onCheckedChange={setCanEdit} id="share-edit" />
              <Label htmlFor="share-edit" className="text-sm">Can Edit</Label>
            </div>
            <div className="flex items-center gap-2">
              <Switch checked={canShare} onCheckedChange={setCanShare} id="share-share" />
              <Label htmlFor="share-share" className="text-sm">Can Share</Label>
            </div>
          </div>

          <Button
            onClick={handleShare}
            disabled={saving || (shareType === 'role' ? !selectedRoleId : !userId)}
            className="w-full"
          >
            {saving ? (
              <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Sharing...</>
            ) : (
              <><Share2 className="h-4 w-4 mr-2" />Share</>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

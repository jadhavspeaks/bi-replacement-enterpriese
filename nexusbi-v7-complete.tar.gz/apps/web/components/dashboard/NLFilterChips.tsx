'use client';

import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { useDashboardStore } from '@/store/dashboard.store';
import { X, Filter } from 'lucide-react';
import type { CubeFilter } from '@nexusbi/shared-types';

interface NLFilterChipsProps {
  filters: CubeFilter[];
}

function formatFilterLabel(filter: CubeFilter): string {
  const member = filter.member.split('.').pop() || filter.member;
  const op = filter.operator;
  const values = filter.values?.join(', ') || '';

  const opLabels: Record<string, string> = {
    equals: '=',
    notEquals: '≠',
    contains: 'contains',
    notContains: 'not contains',
    gt: '>',
    gte: '≥',
    lt: '<',
    lte: '≤',
    set: 'is set',
    notSet: 'is not set',
    inDateRange: 'in',
    notInDateRange: 'not in',
    beforeDate: 'before',
    afterDate: 'after',
  };

  const opLabel = opLabels[op] || op;

  if (op === 'set' || op === 'notSet') {
    return `${member} ${opLabel}`;
  }

  if (op === 'inDateRange' && filter.values?.length === 2) {
    return `${member} ${filter.values[0]} to ${filter.values[1]}`;
  }

  return `${member} ${opLabel} ${values}`;
}

export function NLFilterChips({ filters }: NLFilterChipsProps) {
  const removeGlobalFilter = useDashboardStore((s) => s.removeGlobalFilter);
  const clearGlobalFilters = useDashboardStore((s) => s.clearGlobalFilters);

  if (filters.length === 0) return null;

  return (
    <div className="flex flex-wrap items-center gap-1.5">
      <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />

      {filters.map((filter, index) => (
        <Badge
          key={index}
          variant="secondary"
          className="text-xs gap-1 pl-2 pr-1 py-0.5"
        >
          <span>{formatFilterLabel(filter)}</span>
          <button
            className="ml-0.5 rounded-full p-0.5 hover:bg-muted-foreground/20 transition-colors"
            onClick={(e) => {
              e.stopPropagation();
              removeGlobalFilter(index);
            }}
          >
            <X className="h-3 w-3" />
          </button>
        </Badge>
      ))}

      {filters.length > 1 && (
        <Button
          variant="ghost"
          size="sm"
          className="h-6 text-xs px-2 text-muted-foreground"
          onClick={clearGlobalFilters}
        >
          Clear all
        </Button>
      )}
    </div>
  );
}

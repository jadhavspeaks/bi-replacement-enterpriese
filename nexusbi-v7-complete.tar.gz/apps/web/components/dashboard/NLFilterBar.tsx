'use client';

import { useState, useCallback } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { NLFilterChips } from './NLFilterChips';
import { useDashboardStore } from '@/store/dashboard.store';
import { Loader2, Sparkles, X } from 'lucide-react';
import type { CubeFilter, NLFilterParseResult } from '@nexusbi/shared-types';

interface NLFilterBarProps {
  dashId: string;
}

export function NLFilterBar({ dashId }: NLFilterBarProps) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [parseResult, setParseResult] = useState<NLFilterParseResult | null>(null);
  const [error, setError] = useState<string | null>(null);

  const addGlobalFilter = useDashboardStore((s) => s.addGlobalFilter);
  const clearGlobalFilters = useDashboardStore((s) => s.clearGlobalFilters);
  const globalFilters = useDashboardStore((s) => s.filters.globalFilters);

  const handleParse = useCallback(async () => {
    if (!input.trim()) return;

    setLoading(true);
    setError(null);

    try {
      const response = await fetch(`/api/dashboards/${dashId}/nl-filter`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: input }),
      });

      const data = await response.json();

      if (data.success && data.data) {
        const result = data.data as NLFilterParseResult;
        setParseResult(result);

        if (result.filters.length > 0) {
          // Clear existing and apply new
          clearGlobalFilters();
          for (const filter of result.filters) {
            addGlobalFilter(filter);
          }
        } else {
          setError('Could not parse any filters from your input. Try being more specific.');
        }
      } else {
        setError(data.error?.message || 'Failed to parse filter');
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Network error');
    }

    setLoading(false);
  }, [input, dashId, addGlobalFilter, clearGlobalFilters]);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleParse();
    }
  }, [handleParse]);

  const handleClear = useCallback(() => {
    setInput('');
    setParseResult(null);
    setError(null);
    clearGlobalFilters();
  }, [clearGlobalFilters]);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <Sparkles className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-nexus-400" />
          <Input
            placeholder='Try: "show Q3 2024 APAC revenue above 1M"'
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            className="pl-9 pr-8"
            disabled={loading}
          />
          {input && (
            <button
              className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              onClick={handleClear}
            >
              <X className="h-4 w-4" />
            </button>
          )}
        </div>
        <Button onClick={handleParse} disabled={loading || !input.trim()} size="sm">
          {loading ? (
            <><Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />Parsing...</>
          ) : (
            <><Sparkles className="h-3.5 w-3.5 mr-1" />Apply</>
          )}
        </Button>
      </div>

      {error && (
        <p className="text-xs text-destructive">{error}</p>
      )}

      {parseResult && parseResult.confidence > 0 && (
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>Confidence: {parseResult.confidence}%</span>
          {parseResult.unmatched.length > 0 && (
            <span>• Unmatched: {parseResult.unmatched.join(', ')}</span>
          )}
        </div>
      )}

      {globalFilters.length > 0 && (
        <NLFilterChips filters={globalFilters} />
      )}
    </div>
  );
}

'use client';

import { Button } from '@/components/ui/button';
import { useDashboardStore } from '@/store/dashboard.store';
import { Monitor, Smartphone } from 'lucide-react';

export function BreakpointToggle() {
  const editMode = useDashboardStore((s) => s.editMode);
  const setEditMode = useDashboardStore((s) => s.setEditMode);

  return (
    <div className="flex items-center rounded-md border p-0.5">
      <Button
        variant={editMode === 'desktop' ? 'secondary' : 'ghost'}
        size="sm"
        className="h-7 px-2"
        onClick={() => setEditMode('desktop')}
        title="Desktop layout"
      >
        <Monitor className="h-3.5 w-3.5" />
      </Button>
      <Button
        variant={editMode === 'mobile' ? 'secondary' : 'ghost'}
        size="sm"
        className="h-7 px-2"
        onClick={() => setEditMode('mobile')}
        title="Mobile layout"
      >
        <Smartphone className="h-3.5 w-3.5" />
      </Button>
    </div>
  );
}

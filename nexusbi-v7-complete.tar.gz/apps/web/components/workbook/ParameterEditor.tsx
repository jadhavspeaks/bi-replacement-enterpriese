'use client';

import { useEffect, useState, useCallback } from 'react';
import { Plus, Sliders } from 'lucide-react';
import type {
  Parameter, ParameterCreateInput,
  ParameterDataType, ParameterAllowable, ApiResponse,
} from '@nexusbi/shared-types';

interface ParameterEditorProps {
  workbookId: string;
}

export function ParameterEditor({ workbookId }: ParameterEditorProps) {
  const [params, setParams] = useState<Parameter[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // form state
  const [pname, setPname] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [dataType, setDataType] = useState<ParameterDataType>('string');
  const [defaultValue, setDefaultValue] = useState('');
  const [allowableType, setAllowableType] = useState<ParameterAllowable>('all');
  const [listValues, setListValues] = useState('');
  const [rangeMin, setRangeMin] = useState('');
  const [rangeMax, setRangeMax] = useState('');
  const [rangeStep, setRangeStep] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/workbooks/${workbookId}/parameters`);
      const j = (await r.json()) as ApiResponse<Parameter[]>;
      if (j.success) setParams(j.data || []);
      else setError(j.error?.message || 'Load failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [workbookId]);

  useEffect(() => { load(); }, [load]);

  function resetForm() {
    setPname(''); setDisplayName(''); setDataType('string');
    setDefaultValue(''); setAllowableType('all'); setListValues('');
    setRangeMin(''); setRangeMax(''); setRangeStep('');
  }

  async function handleCreate() {
    if (!pname.trim() || !displayName.trim() || !defaultValue.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const body: ParameterCreateInput = {
        parameterName: pname.trim().replace(/[^a-zA-Z0-9_]/g, '_'),
        displayName: displayName.trim(),
        dataType,
        defaultValue: defaultValue.trim(),
        allowableType,
        allowableValues: allowableType === 'list' && listValues.trim()
          ? listValues.split(',').map((v) => v.trim()).filter(Boolean)
          : undefined,
        rangeMin: allowableType === 'range' ? rangeMin.trim() : undefined,
        rangeMax: allowableType === 'range' ? rangeMax.trim() : undefined,
        rangeStep: allowableType === 'range' ? rangeStep.trim() : undefined,
      };
      const r = await fetch(`/api/workbooks/${workbookId}/parameters`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = (await r.json()) as ApiResponse<Parameter>;
      if (j.success) {
        setShowNew(false); resetForm();
        await load();
      } else setError(j.error?.message || 'Create failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Create failed');
    } finally {
      setCreating(false);
    }
  }

  if (loading) return <div className="p-8 text-sm text-gray-500">Loading parameters...</div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Parameters</h3>
          <p className="text-xs text-gray-500">User-input variables that drive worksheet behavior.</p>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="inline-flex items-center gap-2 rounded-md bg-gray-900 px-3 py-1.5 text-sm font-medium text-white hover:bg-gray-800"
        >
          <Plus className="h-4 w-4" /> New Parameter
        </button>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error}</div>
      )}

      {showNew && (
        <div className="rounded-md border border-gray-200 bg-white p-4 space-y-3">
          <h4 className="font-medium">New Parameter</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Internal Name</label>
              <input
                type="text" value={pname} onChange={(e) => setPname(e.target.value)}
                placeholder="e.g. target_region"
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm font-mono"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Display Name</label>
              <input
                type="text" value={displayName} onChange={(e) => setDisplayName(e.target.value)}
                placeholder="e.g. Target Region"
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Data Type</label>
              <select
                value={dataType} onChange={(e) => setDataType(e.target.value as ParameterDataType)}
                className="w-full rounded-md border border-gray-300 px-2 py-1.5 text-sm"
              >
                <option value="string">String</option>
                <option value="integer">Integer</option>
                <option value="float">Float</option>
                <option value="date">Date</option>
                <option value="boolean">Boolean</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Default Value</label>
              <input
                type="text" value={defaultValue} onChange={(e) => setDefaultValue(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm"
              />
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Allowable Values</label>
            <select
              value={allowableType} onChange={(e) => setAllowableType(e.target.value as ParameterAllowable)}
              className="w-full rounded-md border border-gray-300 px-2 py-1.5 text-sm"
            >
              <option value="all">All values</option>
              <option value="list">List of values</option>
              <option value="range">Range</option>
            </select>
          </div>
          {allowableType === 'list' && (
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">List (comma-separated)</label>
              <input
                type="text" value={listValues} onChange={(e) => setListValues(e.target.value)}
                placeholder="APAC, EMEA, Americas, ANZ"
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm"
              />
            </div>
          )}
          {allowableType === 'range' && (
            <div className="grid grid-cols-3 gap-2">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Min</label>
                <input type="text" value={rangeMin} onChange={(e) => setRangeMin(e.target.value)} className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Max</label>
                <input type="text" value={rangeMax} onChange={(e) => setRangeMax(e.target.value)} className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm" />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Step</label>
                <input type="text" value={rangeStep} onChange={(e) => setRangeStep(e.target.value)} className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm" />
              </div>
            </div>
          )}
          <div className="flex gap-2 justify-end">
            <button onClick={() => { setShowNew(false); resetForm(); }} className="rounded-md border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">Cancel</button>
            <button
              onClick={handleCreate}
              disabled={creating || !pname.trim() || !displayName.trim() || !defaultValue.trim()}
              className="rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white hover:bg-gray-800 disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create Parameter'}
            </button>
          </div>
        </div>
      )}

      {params.length === 0 ? (
        <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-8 text-center">
          <Sliders className="mx-auto h-8 w-8 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">No parameters yet.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {params.map((p) => (
            <div key={p.parameterId} className="rounded-md border border-gray-200 bg-white p-3">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="font-semibold text-sm">{p.displayName}</div>
                  <div className="text-xs text-gray-500 font-mono">{p.parameterName}</div>
                </div>
                <span className="inline-block px-2 py-0.5 rounded-full text-xs bg-purple-100 text-purple-800">
                  {p.dataType}
                </span>
              </div>
              <div className="text-xs text-gray-700 space-y-1">
                <div><b>Current:</b> {p.currentValue}</div>
                <div><b>Default:</b> {p.defaultValue}</div>
                <div><b>Allowable:</b> {p.allowableType === 'list' ? `list (${(p.allowableValues || []).join(', ')})`
                  : p.allowableType === 'range' ? `${p.rangeMin} → ${p.rangeMax} step ${p.rangeStep}`
                  : 'all'}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, FileText, Image as ImageIcon, LayoutDashboard, BarChart3, Eye, Send } from 'lucide-react';
import type { Story, StoryPoint, StoryPointCreateInput, ApiResponse } from '@nexusbi/shared-types';

interface StoryBuilderProps {
  storyId: string;
}

export function StoryBuilder({ storyId }: StoryBuilderProps) {
  const [story, setStory] = useState<Story | null>(null);
  const [loading, setLoading] = useState(true);
  const [activePointIdx, setActivePointIdx] = useState(0);
  const [error, setError] = useState<string | null>(null);
  const [showAddPoint, setShowAddPoint] = useState(false);
  const [pointType, setPointType] = useState<StoryPoint['pointType']>('dashboard');
  const [pointTitle, setPointTitle] = useState('');
  const [pointNarrative, setPointNarrative] = useState('');
  const [pointDashId, setPointDashId] = useState('');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/stories/${storyId}`);
      const j = (await r.json()) as ApiResponse<Story>;
      if (j.success && j.data) setStory(j.data);
      else setError(j.error?.message || 'Load failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [storyId]);

  useEffect(() => { load(); }, [load]);

  async function handleAddPoint() {
    if (!pointTitle.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const body: StoryPointCreateInput = {
        pointType, title: pointTitle.trim(),
        narrative: pointNarrative.trim() || undefined,
        dashId: pointType === 'dashboard' ? (pointDashId || undefined) : undefined,
      };
      const r = await fetch(`/api/stories/${storyId}`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = (await r.json()) as ApiResponse<Story>;
      if (j.success && j.data) {
        setStory(j.data);
        setActivePointIdx(j.data.storyPoints.length - 1);
        setShowAddPoint(false);
        setPointTitle(''); setPointNarrative(''); setPointDashId('');
      } else setError(j.error?.message || 'Add failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Add failed');
    } finally {
      setSaving(false);
    }
  }

  async function handlePublish() {
    if (!story) return;
    try {
      const r = await fetch(`/api/stories/${storyId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ isPublished: !story.isPublished }),
      });
      const j = (await r.json()) as ApiResponse<Story>;
      if (j.success && j.data) setStory(j.data);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Publish failed');
    }
  }

  if (loading) return <div className="p-8 text-sm text-gray-500">Loading story...</div>;
  if (!story) return <div className="p-8 text-sm text-red-600">{error || 'Story not found'}</div>;

  const activePoint: StoryPoint | undefined = story.storyPoints[activePointIdx];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-semibold">{story.storyName}</h2>
          {story.description && <p className="text-sm text-gray-500">{story.description}</p>}
        </div>
        <div className="flex gap-2">
          <button
            onClick={handlePublish}
            className={`inline-flex items-center gap-2 rounded-md px-3 py-1.5 text-sm font-medium ${
              story.isPublished
                ? 'border border-green-300 bg-green-50 text-green-700'
                : 'bg-gray-900 text-white hover:bg-gray-800'
            }`}
          >
            {story.isPublished ? <><Eye className="h-4 w-4" /> Published</> : <><Send className="h-4 w-4" /> Publish</>}
          </button>
        </div>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error}</div>
      )}

      {/* Filmstrip */}
      <div className="flex items-stretch gap-2 overflow-x-auto pb-2">
        {story.storyPoints.map((p, i) => (
          <button
            key={p.pointId}
            onClick={() => setActivePointIdx(i)}
            className={`flex-shrink-0 w-44 rounded-md border p-3 text-left transition ${
              i === activePointIdx ? 'border-blue-500 bg-blue-50' : 'border-gray-200 bg-white hover:border-gray-400'
            }`}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-xs font-mono text-gray-500">#{i + 1}</span>
              {p.pointType === 'dashboard' && <LayoutDashboard className="h-3 w-3 text-blue-600" />}
              {p.pointType === 'worksheet' && <BarChart3 className="h-3 w-3 text-amber-600" />}
              {p.pointType === 'text' && <FileText className="h-3 w-3 text-gray-600" />}
              {p.pointType === 'image' && <ImageIcon className="h-3 w-3 text-purple-600" />}
            </div>
            <div className="text-xs font-medium text-gray-900 line-clamp-2">{p.title}</div>
          </button>
        ))}
        <button
          onClick={() => setShowAddPoint(true)}
          className="flex-shrink-0 w-44 rounded-md border border-dashed border-gray-300 p-3 text-sm text-gray-500 hover:border-gray-500 hover:text-gray-700 inline-flex items-center justify-center"
        >
          <Plus className="h-4 w-4 mr-1" /> Add Point
        </button>
      </div>

      {/* Add point form */}
      {showAddPoint && (
        <div className="rounded-md border border-gray-200 bg-white p-4 space-y-3">
          <h4 className="font-medium">New Story Point</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Type</label>
              <select
                value={pointType} onChange={(e) => setPointType(e.target.value as StoryPoint['pointType'])}
                className="w-full rounded-md border border-gray-300 px-2 py-1.5 text-sm"
              >
                <option value="dashboard">Dashboard</option>
                <option value="worksheet">Worksheet</option>
                <option value="text">Text Slide</option>
                <option value="image">Image</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Title</label>
              <input
                type="text" value={pointTitle} onChange={(e) => setPointTitle(e.target.value)}
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm"
              />
            </div>
          </div>
          {pointType === 'dashboard' && (
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Dashboard ID</label>
              <input
                type="text" value={pointDashId} onChange={(e) => setPointDashId(e.target.value)}
                placeholder="DASH_..."
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm font-mono"
              />
            </div>
          )}
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Narrative</label>
            <textarea
              value={pointNarrative} onChange={(e) => setPointNarrative(e.target.value)}
              rows={3}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowAddPoint(false)} className="rounded-md border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">Cancel</button>
            <button
              onClick={handleAddPoint}
              disabled={saving || !pointTitle.trim()}
              className="rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white hover:bg-gray-800 disabled:opacity-50"
            >
              {saving ? 'Adding...' : 'Add Point'}
            </button>
          </div>
        </div>
      )}

      {/* Active point display */}
      {activePoint ? (
        <div className="rounded-md border border-gray-200 bg-white p-6 min-h-[300px]">
          <div className="flex items-center gap-2 text-xs text-gray-500 mb-3">
            <span className="font-mono">Point {activePointIdx + 1} of {story.storyPoints.length}</span>
            <span>·</span>
            <span className="uppercase tracking-wider">{activePoint.pointType}</span>
          </div>
          <h3 className="text-2xl font-semibold mb-3">{activePoint.title}</h3>
          {activePoint.narrative && (
            <p className="text-sm text-gray-700 leading-relaxed mb-4 max-w-3xl">{activePoint.narrative}</p>
          )}
          {activePoint.pointType === 'dashboard' && activePoint.dashId && (
            <div className="rounded-md border border-gray-200 bg-gray-50 p-8 text-center">
              <LayoutDashboard className="mx-auto h-10 w-10 text-blue-600 mb-2" />
              <p className="text-sm font-mono text-gray-700">{activePoint.dashId}</p>
              <p className="text-xs text-gray-500 mt-2">Dashboard would render here in viewer mode.</p>
            </div>
          )}
          {activePoint.pointType === 'worksheet' && activePoint.worksheetId && (
            <div className="rounded-md border border-gray-200 bg-gray-50 p-8 text-center">
              <BarChart3 className="mx-auto h-10 w-10 text-amber-600 mb-2" />
              <p className="text-sm font-mono text-gray-700">{activePoint.worksheetId}</p>
            </div>
          )}
        </div>
      ) : (
        <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-12 text-center text-sm text-gray-500">
          No story points yet. Add one to begin.
        </div>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { BookOpen, Plus, Trash2, Send, Tag, Calendar } from 'lucide-react';
import type { Workbook, ApiResponse } from '@nexusbi/shared-types';

export function WorkbookList() {
  const router = useRouter();
  const [workbooks, setWorkbooks] = useState<Workbook[]>([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [showCreate, setShowCreate] = useState(false);
  const [newName, setNewName] = useState('');
  const [newDesc, setNewDesc] = useState('');
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch('/api/workbooks');
      const j = (await r.json()) as ApiResponse<Workbook[]>;
      if (j.success) setWorkbooks(j.data || []);
      else setError(j.error?.message || 'Failed to load workbooks');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  async function handleCreate() {
    if (!newName.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const r = await fetch('/api/workbooks', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ workbookName: newName.trim(), description: newDesc.trim() || undefined }),
      });
      const j = (await r.json()) as ApiResponse<Workbook>;
      if (j.success && j.data) {
        setShowCreate(false);
        setNewName('');
        setNewDesc('');
        router.push(`/workbooks/${j.data.workbookId}/edit`);
      } else {
        setError(j.error?.message || 'Create failed');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Create failed');
    } finally {
      setCreating(false);
    }
  }

  async function handleDelete(workbookId: string) {
    if (!confirm('Delete this workbook? This cannot be undone.')) return;
    try {
      await fetch(`/api/workbooks/${workbookId}`, { method: 'DELETE' });
      await load();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    }
  }

  async function handlePublish(workbookId: string) {
    try {
      const r = await fetch(`/api/workbooks/${workbookId}/publish`, { method: 'POST' });
      const j = (await r.json()) as ApiResponse<{ dashId: string }>;
      if (j.success && j.data) {
        router.push(`/dashboards/${j.data.dashId}`);
      } else {
        setError(j.error?.message || 'Publish failed');
      }
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Publish failed');
    }
  }

  if (loading) {
    return <div className="p-8 text-sm text-gray-500">Loading workbooks...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-lg font-semibold">My Workbooks</h2>
          <p className="text-sm text-gray-500">
            Personal workspaces with worksheets, calculated fields, and parameters.
          </p>
        </div>
        <button
          onClick={() => setShowCreate(true)}
          className="inline-flex items-center gap-2 rounded-md bg-gray-900 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800"
        >
          <Plus className="h-4 w-4" /> New Workbook
        </button>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 px-3 py-2 text-sm text-red-700 border border-red-200">{error}</div>
      )}

      {showCreate && (
        <div className="rounded-md border border-gray-200 bg-white p-4 space-y-3">
          <h3 className="font-medium">Create new workbook</h3>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Name</label>
            <input
              type="text"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              placeholder="e.g. Q1 Sales Analysis"
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Description</label>
            <textarea
              value={newDesc}
              onChange={(e) => setNewDesc(e.target.value)}
              rows={2}
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => { setShowCreate(false); setNewName(''); setNewDesc(''); }}
              className="rounded-md border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              onClick={handleCreate}
              disabled={creating || !newName.trim()}
              className="rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white hover:bg-gray-800 disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create'}
            </button>
          </div>
        </div>
      )}

      {workbooks.length === 0 ? (
        <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-8 text-center">
          <BookOpen className="mx-auto h-8 w-8 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">No workbooks yet. Create one to start exploring data.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {workbooks.map((wb) => (
            <div
              key={wb.workbookId}
              className="rounded-md border border-gray-200 bg-white p-4 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-start justify-between mb-2">
                <Link
                  href={`/workbooks/${wb.workbookId}/edit`}
                  className="font-semibold text-sm text-gray-900 hover:text-blue-600"
                >
                  {wb.workbookName}
                </Link>
                {wb.isPublished && (
                  <span className="inline-block px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    Published
                  </span>
                )}
              </div>
              {wb.description && (
                <p className="text-xs text-gray-600 mb-3 line-clamp-2">{wb.description}</p>
              )}
              <div className="flex items-center gap-3 text-xs text-gray-500 mb-3">
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3 w-3" /> v{wb.version}
                </span>
                {wb.tags && (
                  <span className="inline-flex items-center gap-1">
                    <Tag className="h-3 w-3" /> {wb.tags}
                  </span>
                )}
              </div>
              <div className="flex gap-2 pt-2 border-t border-gray-100">
                <Link
                  href={`/workbooks/${wb.workbookId}/edit`}
                  className="flex-1 text-center rounded-md border border-gray-300 px-2 py-1 text-xs font-medium hover:bg-gray-50"
                >
                  Edit
                </Link>
                <button
                  onClick={() => handlePublish(wb.workbookId)}
                  className="flex-1 inline-flex items-center justify-center gap-1 rounded-md bg-blue-600 px-2 py-1 text-xs font-medium text-white hover:bg-blue-700"
                >
                  <Send className="h-3 w-3" /> Publish
                </button>
                <button
                  onClick={() => handleDelete(wb.workbookId)}
                  className="rounded-md border border-red-300 p-1 text-red-600 hover:bg-red-50"
                  aria-label="Delete workbook"
                >
                  <Trash2 className="h-3 w-3" />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

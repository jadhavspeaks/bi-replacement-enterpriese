'use client';

import { useEffect, useState, useCallback } from 'react';
import { Plus, Save, Trash2, BarChart3, LineChart, PieChart, Table as TableIcon, Activity, TrendingUp } from 'lucide-react';
import type {
  Worksheet, WorksheetCreateInput, WorksheetUpdateInput, WorksheetShelf,
  WorksheetChartType, ApiResponse,
} from '@nexusbi/shared-types';

interface WorksheetEditorProps {
  workbookId: string;
}

const CHART_TYPES: Array<{ value: WorksheetChartType; label: string; icon: typeof BarChart3 }> = [
  { value: 'bar', label: 'Bar', icon: BarChart3 },
  { value: 'stacked_bar', label: 'Stacked Bar', icon: BarChart3 },
  { value: 'line', label: 'Line', icon: LineChart },
  { value: 'area', label: 'Area', icon: TrendingUp },
  { value: 'pie', label: 'Pie', icon: PieChart },
  { value: 'donut', label: 'Donut', icon: PieChart },
  { value: 'scatter', label: 'Scatter', icon: Activity },
  { value: 'heatmap', label: 'Heatmap', icon: Activity },
  { value: 'table', label: 'Table', icon: TableIcon },
  { value: 'pivot', label: 'Pivot', icon: TableIcon },
  { value: 'kpi', label: 'KPI', icon: TrendingUp },
];

const EMPTY_SHELVES: WorksheetShelf = {
  columns: [], rows: [], color: null, size: null, label: null,
  detail: [], tooltip: [], filters: [], pages: [],
};

export function WorksheetEditor({ workbookId }: WorksheetEditorProps) {
  const [sheets, setSheets] = useState<Worksheet[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeId, setActiveId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [showNew, setShowNew] = useState(false);
  const [newName, setNewName] = useState('');
  const [newType, setNewType] = useState<WorksheetChartType>('bar');
  const [saving, setSaving] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/workbooks/${workbookId}/worksheets`);
      const j = (await r.json()) as ApiResponse<Worksheet[]>;
      if (j.success) {
        setSheets(j.data || []);
        if ((j.data || []).length > 0 && !activeId) setActiveId(j.data![0].worksheetId);
      } else setError(j.error?.message || 'Load failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [workbookId, activeId]);

  useEffect(() => { load(); }, [load]);

  const active = sheets.find((s) => s.worksheetId === activeId) || null;

  async function handleCreate() {
    if (!newName.trim()) return;
    setSaving(true);
    setError(null);
    try {
      const body: WorksheetCreateInput = { worksheetName: newName.trim(), chartType: newType };
      const r = await fetch(`/api/workbooks/${workbookId}/worksheets`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = (await r.json()) as ApiResponse<Worksheet>;
      if (j.success && j.data) {
        setShowNew(false); setNewName(''); setNewType('bar');
        await load();
        setActiveId(j.data.worksheetId);
      } else setError(j.error?.message || 'Create failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Create failed');
    } finally {
      setSaving(false);
    }
  }

  async function handleSave(updates: WorksheetUpdateInput) {
    if (!active) return;
    try {
      const r = await fetch(`/api/workbooks/${workbookId}/worksheets/${active.worksheetId}`, {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updates),
      });
      const j = (await r.json()) as ApiResponse<Worksheet>;
      if (j.success && j.data) {
        setSheets((prev) => prev.map((s) => s.worksheetId === j.data!.worksheetId ? j.data! : s));
      } else setError(j.error?.message || 'Save failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Save failed');
    }
  }

  async function handleDelete(wsId: string) {
    if (!confirm('Delete this worksheet?')) return;
    try {
      await fetch(`/api/workbooks/${workbookId}/worksheets/${wsId}`, { method: 'DELETE' });
      await load();
      if (activeId === wsId) setActiveId(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Delete failed');
    }
  }

  function updateShelf(key: keyof WorksheetShelf, value: WorksheetShelf[keyof WorksheetShelf]) {
    if (!active) return;
    const updated: WorksheetShelf = { ...active.shelves, [key]: value };
    handleSave({ shelves: updated });
  }

  if (loading) return <div className="p-8 text-sm text-gray-500">Loading worksheets...</div>;

  return (
    <div className="grid grid-cols-12 gap-4">
      {/* Worksheet sidebar */}
      <div className="col-span-3 space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-semibold">Worksheets</h3>
          <button
            onClick={() => setShowNew(true)}
            className="rounded-md p-1 text-gray-600 hover:bg-gray-100"
            aria-label="New worksheet"
          >
            <Plus className="h-4 w-4" />
          </button>
        </div>

        {showNew && (
          <div className="rounded-md border border-gray-200 bg-white p-3 space-y-2">
            <input
              type="text" value={newName} onChange={(e) => setNewName(e.target.value)}
              placeholder="Worksheet name" autoFocus
              className="w-full rounded-md border border-gray-300 px-2 py-1 text-sm"
            />
            <select
              value={newType} onChange={(e) => setNewType(e.target.value as WorksheetChartType)}
              className="w-full rounded-md border border-gray-300 px-2 py-1 text-sm"
            >
              {CHART_TYPES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
            </select>
            <div className="flex gap-1">
              <button
                onClick={() => { setShowNew(false); setNewName(''); }}
                className="flex-1 rounded-md border border-gray-300 px-2 py-1 text-xs hover:bg-gray-50"
              >Cancel</button>
              <button
                onClick={handleCreate} disabled={saving || !newName.trim()}
                className="flex-1 rounded-md bg-gray-900 px-2 py-1 text-xs text-white hover:bg-gray-800 disabled:opacity-50"
              >Create</button>
            </div>
          </div>
        )}

        <div className="space-y-1">
          {sheets.map((s) => (
            <div
              key={s.worksheetId}
              className={`flex items-center justify-between rounded-md px-2 py-1.5 text-sm cursor-pointer ${
                s.worksheetId === activeId ? 'bg-blue-50 text-blue-700 font-medium' : 'hover:bg-gray-50'
              }`}
            >
              <button
                onClick={() => setActiveId(s.worksheetId)}
                className="flex-1 text-left truncate"
              >
                {s.worksheetName}
              </button>
              <button
                onClick={() => handleDelete(s.worksheetId)}
                className="ml-2 text-gray-400 hover:text-red-600"
                aria-label="Delete worksheet"
              >
                <Trash2 className="h-3 w-3" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {/* Active worksheet editor */}
      <div className="col-span-9 space-y-3">
        {error && (
          <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error}</div>
        )}

        {!active ? (
          <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-12 text-center text-sm text-gray-500">
            Select a worksheet to edit, or create a new one.
          </div>
        ) : (
          <>
            <div className="flex items-center justify-between">
              <input
                type="text" value={active.worksheetName}
                onChange={(e) => {
                  const newName = e.target.value;
                  setSheets((prev) => prev.map((s) => s.worksheetId === active.worksheetId ? { ...s, worksheetName: newName } : s));
                }}
                onBlur={(e) => handleSave({ worksheetName: e.target.value.trim() })}
                className="text-lg font-semibold rounded-md border border-transparent hover:border-gray-300 px-2 py-1 -mx-2"
              />
              <select
                value={active.chartType}
                onChange={(e) => handleSave({ chartType: e.target.value as WorksheetChartType })}
                className="rounded-md border border-gray-300 px-2 py-1 text-sm"
              >
                {CHART_TYPES.map((c) => <option key={c.value} value={c.value}>{c.label}</option>)}
              </select>
            </div>

            {/* Shelves (columns / rows / color / size / etc.) */}
            <div className="grid grid-cols-2 gap-3">
              <ShelfEditor label="Columns" values={active.shelves.columns} onChange={(v) => updateShelf('columns', v)} />
              <ShelfEditor label="Rows" values={active.shelves.rows} onChange={(v) => updateShelf('rows', v)} />
              <SingleShelfEditor label="Color" value={active.shelves.color} onChange={(v) => updateShelf('color', v)} />
              <SingleShelfEditor label="Size" value={active.shelves.size} onChange={(v) => updateShelf('size', v)} />
              <SingleShelfEditor label="Label" value={active.shelves.label} onChange={(v) => updateShelf('label', v)} />
              <ShelfEditor label="Tooltip" values={active.shelves.tooltip} onChange={(v) => updateShelf('tooltip', v)} />
            </div>

            {/* Cube + reference info */}
            <div className="rounded-md border border-gray-200 bg-gray-50 p-3 text-xs text-gray-600 space-y-1">
              <div><b>Cube:</b> {active.cubeName || 'not set'}</div>
              <div><b>Filters:</b> {active.shelves.filters.length} active</div>
              <div><b>Reference Lines:</b> {active.referenceLines.length}</div>
              <div><b>Annotations:</b> {active.annotations.length}</div>
            </div>

            {/* Preview placeholder */}
            <div className="rounded-md border border-gray-200 bg-white p-12 text-center min-h-[260px]">
              <p className="text-sm font-medium text-gray-700">{active.chartType.replace('_', ' ').toUpperCase()} preview</p>
              <p className="text-xs text-gray-500 mt-2">
                Drop dimensions onto Columns/Rows shelves and measures onto Color/Size to render.
              </p>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function ShelfEditor({ label, values, onChange }: { label: string; values: string[]; onChange: (v: string[]) => void }) {
  const [draft, setDraft] = useState('');
  return (
    <div className="rounded-md border border-gray-200 bg-white p-2">
      <div className="text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">{label}</div>
      <div className="flex flex-wrap gap-1 mb-2">
        {values.map((v, i) => (
          <span key={i} className="inline-flex items-center gap-1 rounded-full bg-blue-100 px-2 py-0.5 text-xs font-medium text-blue-800">
            {v}
            <button onClick={() => onChange(values.filter((_, idx) => idx !== i))} className="text-blue-400 hover:text-blue-700" aria-label={`Remove ${v}`}>
              ×
            </button>
          </span>
        ))}
      </div>
      <div className="flex gap-1">
        <input
          type="text" value={draft} onChange={(e) => setDraft(e.target.value)}
          placeholder="Add field..."
          className="flex-1 rounded-md border border-gray-300 px-2 py-1 text-xs"
        />
        <button
          onClick={() => { if (draft.trim()) { onChange([...values, draft.trim()]); setDraft(''); } }}
          className="rounded-md bg-gray-900 px-2 text-xs text-white hover:bg-gray-800"
        >+</button>
      </div>
    </div>
  );
}

function SingleShelfEditor({ label, value, onChange }: { label: string; value: string | null; onChange: (v: string | null) => void }) {
  return (
    <div className="rounded-md border border-gray-200 bg-white p-2">
      <div className="text-xs font-semibold text-gray-700 uppercase tracking-wider mb-2">{label}</div>
      <div className="flex gap-1">
        <input
          type="text" value={value || ''} onChange={(e) => onChange(e.target.value || null)}
          placeholder="—"
          className="flex-1 rounded-md border border-gray-300 px-2 py-1 text-xs"
        />
        {value && (
          <button onClick={() => onChange(null)} className="rounded-md border border-gray-300 px-2 text-xs text-gray-600 hover:bg-gray-50">×</button>
        )}
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { Plus, Trash2, Code, CheckCircle2, AlertCircle } from 'lucide-react';
import type {
  CalculatedField, CalculatedFieldCreateInput,
  CalcFieldType, CalcFieldDataType, ApiResponse,
} from '@nexusbi/shared-types';

interface CalculatedFieldEditorProps {
  workbookId: string;
}

export function CalculatedFieldEditor({ workbookId }: CalculatedFieldEditorProps) {
  const [fields, setFields] = useState<CalculatedField[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // form state
  const [name, setName] = useState('');
  const [expression, setExpression] = useState('');
  const [fieldType, setFieldType] = useState<CalcFieldType>('measure');
  const [dataType, setDataType] = useState<CalcFieldDataType>('number');
  const [description, setDescription] = useState('');

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const r = await fetch(`/api/workbooks/${workbookId}/calculated-fields`);
      const j = (await r.json()) as ApiResponse<CalculatedField[]>;
      if (j.success) setFields(j.data || []);
      else setError(j.error?.message || 'Load failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Network error');
    } finally {
      setLoading(false);
    }
  }, [workbookId]);

  useEffect(() => { load(); }, [load]);

  function resetForm() {
    setName(''); setExpression(''); setFieldType('measure'); setDataType('number'); setDescription('');
  }

  async function handleCreate() {
    if (!name.trim() || !expression.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const body: CalculatedFieldCreateInput = {
        fieldName: name.trim(), expression: expression.trim(),
        fieldType, dataType, description: description.trim() || undefined,
      };
      const r = await fetch(`/api/workbooks/${workbookId}/calculated-fields`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = (await r.json()) as ApiResponse<CalculatedField>;
      if (j.success) {
        setShowNew(false); resetForm();
        await load();
      } else setError(j.error?.message || 'Create failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Create failed');
    } finally {
      setCreating(false);
    }
  }

  if (loading) return <div className="p-8 text-sm text-gray-500">Loading calculated fields...</div>;

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold">Calculated Fields</h3>
          <p className="text-xs text-gray-500">Custom dimensions and measures defined per workbook.</p>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="inline-flex items-center gap-2 rounded-md bg-gray-900 px-3 py-1.5 text-sm font-medium text-white hover:bg-gray-800"
        >
          <Plus className="h-4 w-4" /> New Calculation
        </button>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error}</div>
      )}

      {showNew && (
        <div className="rounded-md border border-gray-200 bg-white p-4 space-y-3">
          <h4 className="font-medium">New Calculated Field</h4>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold text-gray-700 mb-1">Field Name</label>
              <input
                type="text" value={name} onChange={(e) => setName(e.target.value)}
                placeholder="e.g. profit_margin"
                className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm font-mono"
              />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Type</label>
                <select
                  value={fieldType} onChange={(e) => setFieldType(e.target.value as CalcFieldType)}
                  className="w-full rounded-md border border-gray-300 px-2 py-1.5 text-sm"
                >
                  <option value="measure">Measure</option>
                  <option value="dimension">Dimension</option>
                </select>
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 mb-1">Data Type</label>
                <select
                  value={dataType} onChange={(e) => setDataType(e.target.value as CalcFieldDataType)}
                  className="w-full rounded-md border border-gray-300 px-2 py-1.5 text-sm"
                >
                  <option value="string">String</option>
                  <option value="number">Number</option>
                  <option value="date">Date</option>
                  <option value="boolean">Boolean</option>
                </select>
              </div>
            </div>
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Expression (SQL)</label>
            <textarea
              value={expression} onChange={(e) => setExpression(e.target.value)}
              rows={4} placeholder="e.g. (total_revenue - total_cost) / NULLIF(total_revenue, 0)"
              className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm font-mono"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-700 mb-1">Description</label>
            <input
              type="text" value={description} onChange={(e) => setDescription(e.target.value)}
              placeholder="What this field represents..."
              className="w-full rounded-md border border-gray-300 px-3 py-1.5 text-sm"
            />
          </div>
          <div className="flex gap-2 justify-end">
            <button
              onClick={() => { setShowNew(false); resetForm(); }}
              className="rounded-md border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50"
            >Cancel</button>
            <button
              onClick={handleCreate}
              disabled={creating || !name.trim() || !expression.trim()}
              className="rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white hover:bg-gray-800 disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create Field'}
            </button>
          </div>
        </div>
      )}

      {fields.length === 0 ? (
        <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-8 text-center">
          <Code className="mx-auto h-8 w-8 text-gray-400" />
          <p className="mt-2 text-sm text-gray-600">No calculated fields yet.</p>
        </div>
      ) : (
        <div className="rounded-md border border-gray-200 overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="text-left px-3 py-2 text-xs font-semibold text-gray-700 uppercase tracking-wider">Name</th>
                <th className="text-left px-3 py-2 text-xs font-semibold text-gray-700 uppercase tracking-wider">Type</th>
                <th className="text-left px-3 py-2 text-xs font-semibold text-gray-700 uppercase tracking-wider">Expression</th>
                <th className="text-left px-3 py-2 text-xs font-semibold text-gray-700 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody>
              {fields.map((f) => (
                <tr key={f.fieldId} className="border-b border-gray-100">
                  <td className="px-3 py-2 font-mono text-xs">{f.fieldName}</td>
                  <td className="px-3 py-2">
                    <span className={`inline-block px-2 py-0.5 rounded-full text-xs ${
                      f.fieldType === 'measure' ? 'bg-amber-100 text-amber-800' : 'bg-blue-100 text-blue-800'
                    }`}>
                      {f.fieldType} · {f.dataType}
                    </span>
                  </td>
                  <td className="px-3 py-2 font-mono text-xs text-gray-600 max-w-md truncate">{f.expression}</td>
                  <td className="px-3 py-2">
                    {f.isValid ? (
                      <span className="inline-flex items-center gap-1 text-xs text-green-700">
                        <CheckCircle2 className="h-3 w-3" /> Valid
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 text-xs text-red-700" title={f.validationError || ''}>
                        <AlertCircle className="h-3 w-3" /> Error
                      </span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

import { Badge } from '@/components/ui/badge';
import type { ApprovalStatus } from '@nexusbi/shared-types';
import { FileEdit, Clock, CheckCircle2, XCircle } from 'lucide-react';

interface ApprovalStatusBadgeProps {
  status: ApprovalStatus;
  size?: 'sm' | 'default';
  showIcon?: boolean;
}

const APPROVAL_CONFIG: Record<ApprovalStatus, {
  label: string;
  variant: 'default' | 'secondary' | 'destructive' | 'outline';
  icon: typeof FileEdit;
  className: string;
}> = {
  DRAFT: {
    label: 'Draft',
    variant: 'secondary',
    icon: FileEdit,
    className: 'bg-zinc-100 text-zinc-700 border-zinc-200',
  },
  PENDING_REVIEW: {
    label: 'Pending Review',
    variant: 'outline',
    icon: Clock,
    className: 'bg-amber-50 text-amber-700 border-amber-200',
  },
  APPROVED: {
    label: 'Approved',
    variant: 'default',
    icon: CheckCircle2,
    className: 'bg-green-50 text-green-700 border-green-200',
  },
  REJECTED: {
    label: 'Rejected',
    variant: 'destructive',
    icon: XCircle,
    className: 'bg-red-50 text-red-700 border-red-200',
  },
};

export function ApprovalStatusBadge({ status, size = 'default', showIcon = true }: ApprovalStatusBadgeProps) {
  const config = APPROVAL_CONFIG[status];
  const Icon = config.icon;

  return (
    <Badge
      variant="outline"
      className={`${config.className} ${size === 'sm' ? 'text-xs px-1.5 py-0' : ''}`}
    >
      {showIcon && <Icon className="mr-1 h-3 w-3" />}
      {config.label}
    </Badge>
  );
}

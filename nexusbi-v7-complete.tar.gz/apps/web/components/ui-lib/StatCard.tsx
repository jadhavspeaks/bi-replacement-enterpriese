import { type ReactNode } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface StatCardProps {
  title: string;
  value: string | number;
  delta?: number;
  deltaLabel?: string;
  trendDirection?: 'up-good' | 'down-good';
  icon?: ReactNode;
  format?: 'number' | 'currency' | 'percent';
  loading?: boolean;
}

function formatValue(value: string | number, format?: string): string {
  if (typeof value === 'string') return value;
  switch (format) {
    case 'currency':
      return new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD', maximumFractionDigits: 0 }).format(value);
    case 'percent':
      return `${value.toFixed(1)}%`;
    case 'number':
    default:
      if (Math.abs(value) >= 1_000_000) return `${(value / 1_000_000).toFixed(1)}M`;
      if (Math.abs(value) >= 1_000) return `${(value / 1_000).toFixed(1)}K`;
      return new Intl.NumberFormat('en-US').format(value);
  }
}

function getDeltaColor(delta: number, trendDirection: 'up-good' | 'down-good'): string {
  if (delta === 0) return 'text-muted-foreground';
  const isPositiveTrend = delta > 0;
  const isGood = trendDirection === 'up-good' ? isPositiveTrend : !isPositiveTrend;
  return isGood ? 'text-green-600' : 'text-red-600';
}

export function StatCard({
  title,
  value,
  delta,
  deltaLabel,
  trendDirection = 'up-good',
  icon,
  format,
  loading = false,
}: StatCardProps) {
  const deltaColor = delta !== undefined ? getDeltaColor(delta, trendDirection) : '';

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center justify-between">
          <p className="text-sm font-medium text-muted-foreground">{title}</p>
          {icon && <div className="text-muted-foreground">{icon}</div>}
        </div>
        <div className="mt-2">
          {loading ? (
            <div className="h-8 w-24 animate-pulse rounded bg-muted" />
          ) : (
            <p className="text-3xl font-bold tracking-tight">{formatValue(value, format)}</p>
          )}
        </div>
        {delta !== undefined && !loading && (
          <div className={`mt-2 flex items-center gap-1 text-sm ${deltaColor}`}>
            {delta > 0 ? (
              <TrendingUp className="h-4 w-4" />
            ) : delta < 0 ? (
              <TrendingDown className="h-4 w-4" />
            ) : (
              <Minus className="h-4 w-4" />
            )}
            <span>{delta > 0 ? '+' : ''}{delta.toFixed(1)}%</span>
            {deltaLabel && <span className="text-muted-foreground">{deltaLabel}</span>}
          </div>
        )}
      </CardContent>
    </Card>
  );
}

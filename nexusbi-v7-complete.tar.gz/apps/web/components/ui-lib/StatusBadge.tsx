import { Badge } from '@/components/ui/badge';
import { Circle } from 'lucide-react';

type StatusType = 'ACTIVE' | 'INACTIVE' | 'ERROR' | 'TESTING' | 'SUCCESS' | 'FAILED' | 'PENDING' | 'RUNNING' | string;

interface StatusBadgeProps {
  status: StatusType;
  showDot?: boolean;
  size?: 'sm' | 'default';
}

const STATUS_CONFIG: Record<string, { label: string; variant: 'default' | 'secondary' | 'destructive' | 'outline'; dotColor: string }> = {
  ACTIVE: { label: 'Active', variant: 'default', dotColor: 'text-green-500' },
  INACTIVE: { label: 'Inactive', variant: 'secondary', dotColor: 'text-zinc-400' },
  ERROR: { label: 'Error', variant: 'destructive', dotColor: 'text-red-500' },
  TESTING: { label: 'Testing', variant: 'outline', dotColor: 'text-blue-500' },
  SUCCESS: { label: 'Success', variant: 'default', dotColor: 'text-green-500' },
  FAILED: { label: 'Failed', variant: 'destructive', dotColor: 'text-red-500' },
  PENDING: { label: 'Pending', variant: 'outline', dotColor: 'text-yellow-500' },
  RUNNING: { label: 'Running', variant: 'outline', dotColor: 'text-blue-500' },
  COMPLETE: { label: 'Complete', variant: 'default', dotColor: 'text-green-500' },
  UPLOADED: { label: 'Uploaded', variant: 'outline', dotColor: 'text-blue-500' },
  INGESTING: { label: 'Ingesting', variant: 'outline', dotColor: 'text-yellow-500' },
  PROCESSING: { label: 'Processing', variant: 'outline', dotColor: 'text-yellow-500' },
  RETRYING: { label: 'Retrying', variant: 'outline', dotColor: 'text-orange-500' },
  APPLIED: { label: 'Applied', variant: 'default', dotColor: 'text-green-500' },
  DISMISSED: { label: 'Dismissed', variant: 'secondary', dotColor: 'text-zinc-400' },
};

export function StatusBadge({ status, showDot = true, size = 'default' }: StatusBadgeProps) {
  const config = STATUS_CONFIG[status.toUpperCase()] || {
    label: status,
    variant: 'outline' as const,
    dotColor: 'text-zinc-400',
  };

  return (
    <Badge variant={config.variant} className={size === 'sm' ? 'text-xs px-1.5 py-0' : ''}>
      {showDot && <Circle className={`mr-1 h-2 w-2 fill-current ${config.dotColor}`} />}
      {config.label}
    </Badge>
  );
}

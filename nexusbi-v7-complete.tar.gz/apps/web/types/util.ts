/**
 * Utility helpers re-exported through @nexusbi/shared-types for compatibility.
 * The real implementation is in lib/oracle-pool.ts; this file provides the same
 * function signature so old imports continue to work.
 */

export function generateId(): string {
  // RFC 4122 v4 UUID — matches the server-side generator used for NB_* tables.
  if (typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function') {
    return crypto.randomUUID();
  }
  return 'id_' + Math.random().toString(36).substring(2, 15) + Date.now().toString(36);
}

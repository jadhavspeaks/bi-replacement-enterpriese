export const LINEAGE_NODE_TYPES = ['datasource', 'table', 'cube', 'measure', 'dimension', 'dashboard', 'widget'] as const;
export type LineageNodeType = (typeof LINEAGE_NODE_TYPES)[number];

export interface LineageNode {
  id: string;
  type: LineageNodeType;
  label: string;
  metadata: Record<string, unknown>;
  parentId?: string;
}

export interface LineageEdge {
  id: string;
  source: string;
  target: string;
  label?: string;
  metadata?: Record<string, unknown>;
}

export interface LineageGraph {
  nodes: LineageNode[];
  edges: LineageEdge[];
  generatedAt: string;
}

export interface LineagePathQuery {
  fromNodeId: string;
  toNodeId?: string;
  maxDepth?: number;
  nodeTypes?: LineageNodeType[];
}

export interface LineageImpactAnalysis {
  affectedNodes: LineageNode[];
  affectedEdges: LineageEdge[];
  impactLevel: 'direct' | 'indirect';
}

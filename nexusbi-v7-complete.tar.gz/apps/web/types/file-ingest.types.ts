export const INGEST_STATUSES = ['PENDING', 'UPLOADED', 'INGESTING', 'COMPLETE', 'ERROR'] as const;
export type IngestStatus = (typeof INGEST_STATUSES)[number];

export const FILE_TYPES = ['csv', 'excel', 'parquet', 'json'] as const;
export type FileType = (typeof FILE_TYPES)[number];

export interface FileIngestion {
  fileId: string;
  originalName: string;
  fileType: string;
  fileSizeBytes: number | null;
  minioPath: string | null;
  stagingTable: string | null;
  ingestStatus: IngestStatus;
  rowCount: number | null;
  columnSchema: ColumnSchemaEntry[] | null;
  errorMessage: string | null;
  uploadedBy: string;
  tenantId: string;
  createdAt: string;
  completedAt: string | null;
}

export interface ColumnSchemaEntry {
  name: string;
  type: string;
  nullable: boolean;
  sampleValues?: string[];
}

export interface FileUploadInput {
  fileType: FileType;
  delimiter?: string;
  hasHeader?: boolean;
  sheetName?: string;
  encoding?: string;
}

export interface FileUploadResult {
  fileId: string;
  originalName: string;
  fileType: string;
  fileSizeBytes: number;
  minioPath: string;
  ingestStatus: IngestStatus;
}

export interface IngestOptions {
  stagingTableName?: string;
  ifExists?: 'replace' | 'append' | 'fail';
  skipRows?: number;
  maxRows?: number;
  columnMapping?: Record<string, string>;
  dateFormat?: string;
  nullValues?: string[];
}

export interface IngestResult {
  fileId: string;
  stagingTable: string;
  rowCount: number;
  columnSchema: ColumnSchemaEntry[];
  durationMs: number;
}

export interface IngestProgress {
  fileId: string;
  status: IngestStatus;
  rowsProcessed: number;
  totalRows: number | null;
  errorMessage: string | null;
  startedAt: string | null;
  completedAt: string | null;
}

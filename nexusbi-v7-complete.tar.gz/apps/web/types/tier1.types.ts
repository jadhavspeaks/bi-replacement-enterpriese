// ── Drill-Down Hierarchies ──

export interface Hierarchy {
  hierId: string;
  workbookId: string;
  hierName: string;
  levels: string[];
  createdAt: string;
}

export interface HierarchyCreateInput {
  hierName: string;
  levels: string[];
}

export interface DrillState {
  widgetId: string;
  hierarchyId: string;
  currentLevel: number;
  filterPath: Array<{ level: number; value: unknown }>;
}

// ── Forecasting ──

export type ForecastMethod = 'linear' | 'exponential' | 'holt_winters';
export type ConfidenceInterval = 0.90 | 0.95 | 0.99;

export interface ForecastConfig {
  enabled: boolean;
  periods: number;
  method: ForecastMethod;
  seasonality?: number;
  confidenceInterval: ConfidenceInterval;
  measureField: string;
  timeField: string;
}

export interface ForecastPoint {
  timestamp: string;
  actual: number | null;
  predicted: number | null;
  lower: number | null;
  upper: number | null;
}

export interface ForecastResult {
  points: ForecastPoint[];
  method: ForecastMethod;
  rmse: number;
  mape: number;
}

// ── Trend Lines & Clustering ──

export type TrendType = 'linear' | 'polynomial' | 'exponential' | 'logarithmic';

export interface TrendLineConfig {
  enabled: boolean;
  type: TrendType;
  polynomialDegree?: number;
  color: string;
  showEquation: boolean;
  showRSquared: boolean;
}

export interface TrendLineResult {
  type: TrendType;
  equation: string;
  rSquared: number;
  points: Array<{ x: number; y: number }>;
}

export interface ClusterConfig {
  enabled: boolean;
  algorithm: 'kmeans';
  k: number;
  xField: string;
  yField: string;
  maxIterations?: number;
}

export interface ClusterResult {
  assignments: number[];
  centroids: Array<{ x: number; y: number }>;
  inertia: number;
}

// ── Show Me Panel ──

export interface ShowMeRecommendation {
  chartType: string;
  score: number;
  compatible: boolean;
  reason: string;
  autoMap?: Record<string, string>;
}

export interface ShowMeContext {
  shelves: {
    columns: string[];
    rows: string[];
    color: string | null;
    size: string | null;
  };
  schemas: FieldSchemaMeta[];
}

export interface FieldSchemaMeta {
  name: string;
  fieldClass: 'dimension' | 'measure';
  dataType: 'string' | 'number' | 'date' | 'boolean' | 'geo';
  cardinality?: number;
}

// ── Pages Shelf (Animation Playback) ──

export interface PagesPlayback {
  widgetId: string;
  pagesField: string;
  values: unknown[];
  currentIndex: number;
  isPlaying: boolean;
  speed: 1 | 2 | 4;
  loop: boolean;
}

export interface PagesPlaybackConfig {
  field: string;
  sortOrder: 'asc' | 'desc' | 'manual';
  manualOrder?: unknown[];
  autoPlay: boolean;
  frameMs: number;
}

// ── Quick Table Calculations ──

export type TableCalcType =
  | 'running_total' | 'pct_of_total' | 'difference' | 'pct_difference'
  | 'rank' | 'dense_rank' | 'moving_avg' | 'percentile' | 'z_score'
  | 'ntile' | 'first_diff' | 'compound_growth';

export type TableCalcDirection = 'table_across' | 'table_down' | 'pane_across' | 'pane_down' | 'cell';

export interface TableCalc {
  id: string;
  type: TableCalcType;
  targetMeasure: string;
  alias: string;
  direction: TableCalcDirection;
  window?: number;
  partitionBy?: string[];
  orderBy?: string[];
  percentileValue?: number;
  ntileBuckets?: number;
}

export interface TableCalcResult {
  rows: Array<Record<string, unknown>>;
  computedColumns: string[];
}

// ── Set Actions ──

export type SetActionBehavior = 'add_to_set' | 'remove_from_set' | 'replace_set';

export interface SetAction {
  actionId: string;
  dashId: string;
  sourceWidgetId: string;
  targetSetId: string;
  behavior: SetActionBehavior;
  clearOnDeselect: boolean;
  sourceField: string;
}

export interface ActiveSetState {
  setId: string;
  members: unknown[];
  scope: 'session' | 'workbook';
  lastUpdated: string;
}

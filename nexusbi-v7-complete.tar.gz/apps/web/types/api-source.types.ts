export const API_TYPES = ['REST_POLL', 'GRAPHQL_POLL', 'WEBHOOK_PUSH', 'OAUTH_REST'] as const;
export type ApiType = (typeof API_TYPES)[number];

export const AUTH_METHODS = ['none', 'api_key', 'bearer', 'basic', 'oauth2'] as const;
export type AuthMethod = (typeof AUTH_METHODS)[number];

export interface ApiAuthConfig {
  method: AuthMethod;
  apiKeyHeader?: string;
  apiKeyValue?: string;
  bearerToken?: string;
  basicUsername?: string;
  basicPassword?: string;
  oauth2TokenUrl?: string;
  oauth2ClientId?: string;
  oauth2ClientSecret?: string;
  oauth2Scope?: string;
}

export interface ApiRequestConfig {
  method: 'GET' | 'POST' | 'PUT' | 'PATCH';
  path?: string;
  headers?: Record<string, string>;
  queryParams?: Record<string, string>;
  body?: Record<string, unknown>;
  paginationType?: 'offset' | 'cursor' | 'page' | 'none';
  paginationConfig?: {
    limitParam?: string;
    offsetParam?: string;
    cursorParam?: string;
    cursorPath?: string;
    pageParam?: string;
    pageSizeParam?: string;
    maxPages?: number;
    pageSize?: number;
  };
}

export interface ApiResponseMapping {
  dataPath: string;
  columnMappings: ApiColumnMapping[];
  totalCountPath?: string;
  nextCursorPath?: string;
}

export interface ApiColumnMapping {
  sourcePath: string;
  targetColumn: string;
  dataType: 'string' | 'number' | 'boolean' | 'date' | 'datetime' | 'json';
  transform?: string;
  defaultValue?: string;
}

export interface GraphqlRequestConfig {
  query: string;
  variables?: Record<string, unknown>;
  operationName?: string;
}

export interface WebhookPushConfig {
  secretHeader: string;
  secretValue: string;
  payloadPath?: string;
}

export interface ApiSource {
  sourceId: string;
  sourceName: string;
  apiType: ApiType;
  baseUrl: string;
  authConfig: ApiAuthConfig | null;
  requestConfig: ApiRequestConfig | null;
  responseMapping: ApiResponseMapping | null;
  pollCron: string | null;
  stagingTable: string | null;
  lastPolledAt: string | null;
  lastPollStatus: string | null;
  lastRowCount: number | null;
  dsId: string | null;
  tenantId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface ApiSourceCreateInput {
  sourceName: string;
  apiType: ApiType;
  baseUrl: string;
  authConfig?: ApiAuthConfig;
  requestConfig?: ApiRequestConfig;
  responseMapping?: ApiResponseMapping;
  pollCron?: string;
}

export interface ApiSourceUpdateInput {
  sourceName?: string;
  baseUrl?: string;
  authConfig?: ApiAuthConfig;
  requestConfig?: ApiRequestConfig;
  responseMapping?: ApiResponseMapping;
  pollCron?: string;
  isActive?: boolean;
}

export interface ApiPollResult {
  rowCount: number;
  stagingTable: string;
  durationMs: number;
  errors: string[];
}

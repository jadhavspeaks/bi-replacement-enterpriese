// ── Geographic / Map Widgets ──

export type GeoResolution = 'country_iso2' | 'country_iso3' | 'country_name'
  | 'us_state_abbr' | 'us_state_name' | 'us_county_fips' | 'zip_us' | 'lat_lng';

export type MapWidgetType = 'map_choropleth' | 'map_point' | 'map_heatmap' | 'map_hex';

export interface GeoDimension {
  fieldName: string;
  geoType: 'country' | 'state' | 'county' | 'zip' | 'city' | 'lat_lng' | 'custom_geojson';
  resolution: GeoResolution;
  latField?: string;
  lngField?: string;
}

export interface MapWidgetConfig {
  widgetType: MapWidgetType;
  geoDimension: GeoDimension;
  colorMeasure?: string;
  sizeMeasure?: string;
  radiusMultiplier: number;
  colorPalette: string;
  basemap: 'light' | 'dark' | 'satellite' | 'streets';
  initialCenter?: [number, number];
  initialZoom?: number;
  clusteringEnabled: boolean;
  hexResolution?: number;
}

export interface GeoFeature {
  id: string;
  name: string;
  iso2?: string;
  iso3?: string;
  bbox: [number, number, number, number];
}

// ── Custom Shape Marks ──

export interface ShapeDef {
  shapeId: string;
  tenantId: string;
  shapeName: string;
  shapeCategory: string;
  svgContent: string;
  viewBox: string;
  isSystem: boolean;
  createdAt: string;
}

export interface ShapeMapping {
  field: string;
  mapping: Record<string, string>;
  defaultShape: string;
}

// ── Dual-Axis Charts ──

export interface AxisConfig {
  label?: string;
  scale: 'linear' | 'log' | 'time';
  format?: string;
  min?: number;
  max?: number;
  tickCount?: number;
}

export interface DualAxisConfig {
  primary: AxisConfig & { measures: string[] };
  secondary?: AxisConfig & { measures: string[] };
  synchronized: boolean;
  alignZero: boolean;
}

// ── Density / Contour Plots ──

export interface DensityConfig {
  xField: string;
  yField: string;
  binsX: number;
  binsY: number;
  renderType: 'heatmap' | 'contour' | 'hexbin';
  colorPalette: string;
  contourLevels?: number;
  bandwidth?: number;
}

export interface DensityBin {
  xBin: number;
  yBin: number;
  xLow: number;
  xHigh: number;
  yLow: number;
  yHigh: number;
  density: number;
}

export interface DensityResult {
  bins: DensityBin[];
  xRange: [number, number];
  yRange: [number, number];
  maxDensity: number;
}

// ── Sparklines ──

export interface SparklineConfig {
  enabled: boolean;
  sparkField: string;
  groupBy: string[];
  timeField?: string;
  color: string;
  showMinMax: boolean;
  width: number;
  height: number;
}

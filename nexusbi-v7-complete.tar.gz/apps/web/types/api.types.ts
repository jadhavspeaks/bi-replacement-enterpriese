export const API_ERROR_CODES = [
  'RBAC_DENIED',
  'INVALID_INPUT',
  'DS_CONNECTION_FAILED',
  'SCHEMA_INVALID',
  'INGEST_FAILED',
  'CUBE_QUERY_FAILED',
  'NOT_FOUND',
  'CONFLICT',
  'INTERNAL_ERROR',
] as const;

export type ApiErrorCode = (typeof API_ERROR_CODES)[number];

export interface ApiError {
  code: ApiErrorCode;
  message: string;
  details?: Record<string, unknown>;
}

export interface ApiResponse<T = unknown> {
  success: boolean;
  data?: T;
  error?: ApiError;
  meta?: {
    total?: number;
    page?: number;
    pageSize?: number;
    duration_ms?: number;
  };
}

export interface PaginationParams {
  page?: number;
  pageSize?: number;
  sortBy?: string;
  sortDir?: 'asc' | 'desc';
}

export interface PaginatedResult<T> {
  items: T[];
  total: number;
  page: number;
  pageSize: number;
}

export function createApiError(code: ApiErrorCode, message: string, details?: Record<string, unknown>): ApiError {
  return { code, message, details };
}

export function createApiResponse<T>(data: T, meta?: ApiResponse<T>['meta']): ApiResponse<T> {
  return { success: true, data, meta };
}

export function createApiErrorResponse(error: ApiError, meta?: ApiResponse['meta']): ApiResponse<never> {
  return { success: false, error, meta };
}

export const SENSITIVITY_LEVELS = ['PII', 'CONFIDENTIAL', 'INTERNAL', 'PUBLIC'] as const;
export type SensitivityLevel = (typeof SENSITIVITY_LEVELS)[number];

export const CUBE_MEMBER_TYPES = ['measure', 'dimension', 'timeDimension', 'segment'] as const;
export type CubeMemberType = (typeof CUBE_MEMBER_TYPES)[number];

export const MEASURE_TYPES = [
  'count',
  'countDistinct',
  'countDistinctApprox',
  'sum',
  'avg',
  'min',
  'max',
  'number',
  'runningTotal',
] as const;
export type MeasureType = (typeof MEASURE_TYPES)[number];

export const DIMENSION_TYPES = ['string', 'number', 'boolean', 'time', 'geo'] as const;
export type DimensionType = (typeof DIMENSION_TYPES)[number];

export const MEASURE_FORMATS = ['number', 'currency', 'percent'] as const;
export type MeasureFormat = (typeof MEASURE_FORMATS)[number];

export interface CubeSchema {
  schemaId: string;
  dsId: string;
  cubeName: string;
  schemaJs: string;
  isActive: boolean;
  version: number;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
}

export interface CubeSchemaCreateInput {
  dsId: string;
  cubeName: string;
  schemaJs: string;
}

export interface CubeSchemaUpdateInput {
  cubeName?: string;
  schemaJs?: string;
  isActive?: boolean;
}

export interface ColumnTag {
  tagId: string;
  dsId: string;
  cubeName: string;
  columnName: string;
  sensitivity: SensitivityLevel;
  tagDescription: string | null;
  taggedBy: string;
  taggedAt: string;
}

export interface ColumnTagInput {
  dsId: string;
  cubeName: string;
  columnName: string;
  sensitivity: SensitivityLevel;
  tagDescription?: string;
}

export interface IntrospectedColumn {
  columnName: string;
  dataType: string;
  nullable: boolean;
  isPrimaryKey: boolean;
  isForeignKey: boolean;
  referencedTable?: string;
  referencedColumn?: string;
  defaultValue?: string;
  characterMaxLength?: number;
  numericPrecision?: number;
  numericScale?: number;
}

export interface IntrospectedTable {
  tableName: string;
  schemaName: string;
  estimatedRowCount: number | null;
  columns: IntrospectedColumn[];
}

export interface IntrospectionResult {
  dsId: string;
  tables: IntrospectedTable[];
  introspectedAt: string;
}

export interface CubeMeasureDefinition {
  name: string;
  type: MeasureType;
  sql: string;
  title?: string;
  description?: string;
  format?: MeasureFormat;
  drillMembers?: string[];
  filters?: Array<{ sql: string }>;
  rollingWindow?: {
    trailing?: string;
    leading?: string;
    offset?: string;
  };
}

export interface CubeDimensionDefinition {
  name: string;
  type: DimensionType;
  sql: string;
  title?: string;
  description?: string;
  primaryKey?: boolean;
  shown?: boolean;
  subQuery?: boolean;
  propagateFiltersToSubQuery?: boolean;
}

export interface CubeJoinDefinition {
  name: string;
  sql: string;
  relationship: 'one_to_one' | 'one_to_many' | 'many_to_one';
}

export interface ParsedCubeSchema {
  cubeName: string;
  sql: string;
  title?: string;
  description?: string;
  measures: CubeMeasureDefinition[];
  dimensions: CubeDimensionDefinition[];
  joins: CubeJoinDefinition[];
  preAggregations?: Record<string, unknown>[];
  refreshKey?: Record<string, unknown>;
}

export interface AutoGenerateOptions {
  dsId: string;
  tables: string[];
  includeJoins?: boolean;
  inferMeasures?: boolean;
  namingConvention?: 'camelCase' | 'snake_case';
}

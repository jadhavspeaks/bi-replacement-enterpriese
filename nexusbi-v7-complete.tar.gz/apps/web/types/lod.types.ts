export type LODType = 'fixed' | 'include' | 'exclude';
export type LODAggregation = 'SUM' | 'AVG' | 'COUNT' | 'COUNTD' | 'MIN' | 'MAX' | 'MEDIAN';

export interface LODExpression {
  type: LODType;
  dimensions: string[];
  aggregation: LODAggregation;
  measureField: string;
  filter?: string;
  alias: string;
}

export interface ParsedLOD {
  expr: LODExpression;
  raw: string;
  errors: string[];
}

export interface CompiledLOD {
  sql: string;
  cubeQuery: Record<string, unknown> | null;
  joinKeys: string[];
  requiresRawSQL: boolean;
}

export interface LODContext {
  vizDimensions: string[];
  vizMeasures: string[];
  cubeName: string;
}

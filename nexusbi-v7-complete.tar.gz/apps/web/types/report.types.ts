export const DELIVERY_TYPES = ['email', 'slack', 'teams'] as const;
export type DeliveryType = (typeof DELIVERY_TYPES)[number];

export const REPORT_STATUSES = ['SUCCESS', 'FAILED', 'RUNNING', 'SKIPPED'] as const;
export type ReportRunStatus = (typeof REPORT_STATUSES)[number];

export interface EmailDeliveryConfig {
  recipients: string[];
  cc?: string[];
  bcc?: string[];
  subject: string;
  bodyTemplate?: string;
  attachFormat: 'pdf' | 'png' | 'csv';
}

export interface SlackDeliveryConfig {
  webhookUrl: string;
  channel: string;
  mentionUsers?: string[];
  includeScreenshot: boolean;
}

export interface TeamsDeliveryConfig {
  webhookUrl: string;
  mentionUsers?: string[];
  includeScreenshot: boolean;
}

export type DeliveryConfig = EmailDeliveryConfig | SlackDeliveryConfig | TeamsDeliveryConfig;

export interface ScheduledReport {
  reportId: string;
  dashId: string;
  reportName: string;
  cronExpression: string;
  deliveryType: DeliveryType;
  deliveryConfig: DeliveryConfig;
  isActive: boolean;
  lastRunAt: string | null;
  lastRunStatus: string | null;
  nextRunAt: string | null;
  createdBy: string;
  createdAt: string;
}

export interface ScheduledReportCreateInput {
  dashId: string;
  reportName: string;
  cronExpression: string;
  deliveryType: DeliveryType;
  deliveryConfig: DeliveryConfig;
}

export interface ScheduledReportUpdateInput {
  reportName?: string;
  cronExpression?: string;
  deliveryType?: DeliveryType;
  deliveryConfig?: DeliveryConfig;
  isActive?: boolean;
}

export const IMPORT_STATUSES = ['PENDING', 'PROCESSING', 'COMPLETE', 'ERROR'] as const;
export type ImportStatus = (typeof IMPORT_STATUSES)[number];

export interface TableauImport {
  importId: string;
  originalName: string;
  minioPath: string | null;
  dashId: string | null;
  importStatus: ImportStatus;
  widgetsCreated: number | null;
  warnings: string[] | null;
  unmappedItems: TableauUnmappedItem[] | null;
  importedBy: string;
  tenantId: string;
  createdAt: string;
  completedAt: string | null;
}

export interface TableauUnmappedItem {
  worksheetName: string;
  fieldName: string;
  reason: string;
}

export interface TableauWorksheetMap {
  worksheetName: string;
  widgetType: 'chart' | 'table' | 'kpi' | 'text';
  chartType?: string;
  dimensions: string[];
  measures: string[];
  filters: TableauFilterMap[];
  calculatedFields: TableauCalculatedField[];
}

export interface TableauFilterMap {
  fieldName: string;
  filterType: string;
  values?: string[];
  range?: { min?: string; max?: string };
}

export interface TableauCalculatedField {
  name: string;
  formula: string;
  dataType: string;
  convertedSql?: string;
}

export interface TableauDataSourceRef {
  name: string;
  connectionType: string;
  server?: string;
  database?: string;
  tables: string[];
}

export interface TableauParseResult {
  worksheets: TableauWorksheetMap[];
  dataSources: TableauDataSourceRef[];
  parameters: Array<{ name: string; dataType: string; currentValue?: string }>;
  dashboardLayout?: {
    width: number;
    height: number;
    zones: Array<{
      worksheetName: string;
      x: number;
      y: number;
      w: number;
      h: number;
    }>;
  };
}

export interface TableauImportOptions {
  mapToExistingDs?: string;
  autoCreateCubeSchema?: boolean;
  preserveLayout?: boolean;
}

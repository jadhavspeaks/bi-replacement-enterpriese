// ── Workbook (Tableau .twbx equivalent) ──────────────────────────

export interface Workbook {
  workbookId: string;
  workbookName: string;
  description: string | null;
  ownerId: string;
  tenantId: string;
  dsId: string | null;
  tags: string | null;
  isPublished: boolean;
  publishedDashId: string | null;
  thumbnailUrl: string | null;
  version: number;
  createdAt: string;
  updatedAt: string;
}

export interface WorkbookCreateInput {
  workbookName: string;
  description?: string;
  dsId?: string;
  tags?: string;
}

export interface WorkbookUpdateInput {
  workbookName?: string;
  description?: string;
  dsId?: string;
  tags?: string;
}

// ── Worksheet (single analysis view inside a workbook) ───────────

export type WorksheetChartType =
  | 'bar' | 'stacked_bar' | 'grouped_bar'
  | 'line' | 'area' | 'stacked_area'
  | 'pie' | 'donut' | 'treemap' | 'sunburst'
  | 'scatter' | 'bubble' | 'heatmap'
  | 'histogram' | 'box_plot'
  | 'waterfall' | 'funnel' | 'gauge'
  | 'map' | 'choropleth'
  | 'table' | 'pivot' | 'crosstab'
  | 'kpi' | 'text';

export interface WorksheetShelf {
  columns: string[];
  rows: string[];
  color: string | null;
  size: string | null;
  label: string | null;
  detail: string[];
  tooltip: string[];
  filters: WorksheetFilter[];
  pages: string[];
}

export interface WorksheetFilter {
  field: string;
  filterType: 'include' | 'exclude' | 'range' | 'top_n' | 'condition' | 'relative_date';
  values?: unknown[];
  rangeMin?: unknown;
  rangeMax?: unknown;
  topN?: number;
  topNBy?: string;
  topNDirection?: 'top' | 'bottom';
  condition?: { operator: string; value: unknown };
  relativeDatePeriod?: string;
  relativeDateAnchor?: 'today' | 'specific';
}

export interface WorksheetSortSpec {
  field: string;
  direction: 'asc' | 'desc';
  sortBy: 'data' | 'manual' | 'nested';
  manualOrder?: string[];
}

export interface Worksheet {
  worksheetId: string;
  workbookId: string;
  worksheetName: string;
  sortOrder: number;
  chartType: WorksheetChartType;
  shelves: WorksheetShelf;
  cubeQuery: Record<string, unknown> | null;
  cubeName: string | null;
  sortSpecs: WorksheetSortSpec[];
  markType: string | null;
  colorPalette: string | null;
  axisConfig: Record<string, unknown> | null;
  tooltipConfig: Record<string, unknown> | null;
  referenceLines: ReferenceLine[];
  annotations: Annotation[];
  createdAt: string;
  updatedAt: string;
}

export interface ReferenceLine {
  id: string;
  axis: 'x' | 'y';
  type: 'constant' | 'average' | 'median' | 'percentile';
  value?: number;
  percentile?: number;
  label: string;
  color: string;
  lineStyle: 'solid' | 'dashed' | 'dotted';
}

export interface Annotation {
  id: string;
  type: 'mark' | 'point' | 'area';
  text: string;
  position: { x: number; y: number };
  color: string;
}

export interface WorksheetCreateInput {
  worksheetName: string;
  chartType: WorksheetChartType;
  shelves?: Partial<WorksheetShelf>;
  cubeName?: string;
}

export interface WorksheetUpdateInput {
  worksheetName?: string;
  sortOrder?: number;
  chartType?: WorksheetChartType;
  shelves?: WorksheetShelf;
  cubeQuery?: Record<string, unknown>;
  cubeName?: string;
  sortSpecs?: WorksheetSortSpec[];
  markType?: string;
  colorPalette?: string;
  axisConfig?: Record<string, unknown>;
  tooltipConfig?: Record<string, unknown>;
  referenceLines?: ReferenceLine[];
  annotations?: Annotation[];
}

// ── Calculated Fields (custom measures/dimensions) ───────────────

export type CalcFieldType = 'dimension' | 'measure';
export type CalcFieldDataType = 'string' | 'number' | 'date' | 'boolean';

export interface CalculatedField {
  fieldId: string;
  workbookId: string;
  fieldName: string;
  expression: string;
  fieldType: CalcFieldType;
  dataType: CalcFieldDataType;
  description: string | null;
  isValid: boolean;
  validationError: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface CalculatedFieldCreateInput {
  fieldName: string;
  expression: string;
  fieldType: CalcFieldType;
  dataType: CalcFieldDataType;
  description?: string;
}

export interface CalculatedFieldUpdateInput {
  fieldName?: string;
  expression?: string;
  fieldType?: CalcFieldType;
  dataType?: CalcFieldDataType;
  description?: string;
}

// ── Parameters (user-configurable variables) ─────────────────────

export type ParameterDataType = 'string' | 'integer' | 'float' | 'date' | 'boolean';
export type ParameterAllowable = 'all' | 'list' | 'range';

export interface Parameter {
  parameterId: string;
  workbookId: string;
  parameterName: string;
  displayName: string;
  dataType: ParameterDataType;
  currentValue: string;
  defaultValue: string;
  allowableType: ParameterAllowable;
  allowableValues: string[] | null;
  rangeMin: string | null;
  rangeMax: string | null;
  rangeStep: string | null;
  createdAt: string;
  updatedAt: string;
}

export interface ParameterCreateInput {
  parameterName: string;
  displayName: string;
  dataType: ParameterDataType;
  defaultValue: string;
  allowableType: ParameterAllowable;
  allowableValues?: string[];
  rangeMin?: string;
  rangeMax?: string;
  rangeStep?: string;
}

export interface ParameterUpdateInput {
  displayName?: string;
  currentValue?: string;
  defaultValue?: string;
  allowableType?: ParameterAllowable;
  allowableValues?: string[];
  rangeMin?: string;
  rangeMax?: string;
  rangeStep?: string;
}

// ── Stories (multi-dashboard narratives, like Tableau Story) ──────

export interface Story {
  storyId: string;
  storyName: string;
  description: string | null;
  ownerId: string;
  tenantId: string;
  isPublished: boolean;
  version: number;
  storyPoints: StoryPoint[];
  createdAt: string;
  updatedAt: string;
}

export interface StoryPoint {
  pointId: string;
  storyId: string;
  sortOrder: number;
  pointType: 'dashboard' | 'worksheet' | 'text' | 'image';
  title: string;
  narrative: string | null;
  dashId: string | null;
  worksheetId: string | null;
  contentJson: Record<string, unknown> | null;
  filterOverrides: Record<string, unknown> | null;
}

export interface StoryCreateInput {
  storyName: string;
  description?: string;
}

export interface StoryPointCreateInput {
  pointType: StoryPoint['pointType'];
  title: string;
  narrative?: string;
  dashId?: string;
  worksheetId?: string;
  contentJson?: Record<string, unknown>;
  filterOverrides?: Record<string, unknown>;
}

// ── Dashboard Actions (inter-widget interactions) ────────────────

export type DashboardActionType = 'filter' | 'highlight' | 'url' | 'parameter';
export type DashboardActionTrigger = 'select' | 'hover' | 'menu';

export interface DashboardAction {
  actionId: string;
  dashId: string;
  actionName: string;
  actionType: DashboardActionType;
  trigger: DashboardActionTrigger;
  sourceWidgetId: string;
  targetWidgetIds: string[];
  sourceField: string | null;
  targetField: string | null;
  urlTemplate: string | null;
  parameterName: string | null;
  isEnabled: boolean;
}

export interface DashboardActionCreateInput {
  actionName: string;
  actionType: DashboardActionType;
  trigger: DashboardActionTrigger;
  sourceWidgetId: string;
  targetWidgetIds: string[];
  sourceField?: string;
  targetField?: string;
  urlTemplate?: string;
  parameterName?: string;
}

// ── Data Extract (scheduled Oracle snapshot) ─────────────────────

export interface DataExtract {
  extractId: string;
  dsId: string;
  extractName: string;
  queryExpression: string;
  refreshSchedule: string | null;
  lastRefreshedAt: string | null;
  rowCount: number;
  stagingTable: string;
  isIncremental: boolean;
  incrementalColumn: string | null;
  tenantId: string;
  createdAt: string;
}

// ── Sets & Groups (Tableau equivalent) ───────────────────────────

export interface DataSet {
  setId: string;
  workbookId: string;
  setName: string;
  setType: 'static' | 'computed';
  baseDimension: string;
  staticMembers: string[] | null;
  condition: { operator: string; value: unknown; field?: string } | null;
  topN: { n: number; by: string; direction: 'top' | 'bottom' } | null;
  createdAt: string;
}

export interface DataGroup {
  groupId: string;
  workbookId: string;
  groupName: string;
  baseDimension: string;
  groupMembers: Record<string, string[]>;
  includeOther: boolean;
  otherLabel: string;
  createdAt: string;
}

import type { LayoutConfig, WidgetConfig, DashboardFiltersState, CubeQuery } from './dashboard.types';

export interface ApprovalSnapshot {
  snapshotId: string;
  dashId: string;
  reviewId: string;
  version: number;
  layoutJson: LayoutConfig | null;
  widgetsJson: WidgetConfig[] | null;
  filtersJson: DashboardFiltersState | null;
  cubeQueriesJson: Record<string, CubeQuery> | null;
  snappedAt: string;
  snappedBy: string;
  tenantId: string;
}

export interface ApprovalSnapshotListItem {
  snapshotId: string;
  dashId: string;
  reviewId: string;
  version: number;
  snappedAt: string;
  snappedBy: string;
  snappedByDisplayName?: string;
}

export const CHECKER_DECISIONS = ['PENDING', 'APPROVED', 'REJECTED'] as const;
export type CheckerDecision = (typeof CHECKER_DECISIONS)[number];

export interface CheckerAssignment {
  assignmentId: string;
  reviewId: string;
  checkerSlot: 1 | 2;
  checkerId: string;
  assignedAt: string;
  decision: CheckerDecision;
  decidedAt: string | null;
  comments: string | null;
}

export interface CheckerAssignmentWithUser extends CheckerAssignment {
  checkerDisplayName?: string;
  checkerEmail?: string;
}

export interface DualCheckerStatus {
  required: boolean;
  slot1: CheckerAssignment | null;
  slot2: CheckerAssignment | null;
  isFullyApproved: boolean;
}

export const TIMED_ACCESS_RESOURCE_TYPES = ['datasource', 'dashboard'] as const;
export type TimedAccessResourceType = (typeof TIMED_ACCESS_RESOURCE_TYPES)[number];

export interface TimedAccess {
  accessId: string;
  resourceType: TimedAccessResourceType;
  resourceId: string;
  roleId: string | null;
  userId: string | null;
  grantedBy: string;
  grantedAt: string;
  expiresAt: string;
  isActive: boolean;
  tenantId: string;
}

export interface TimedAccessWithDetails extends TimedAccess {
  resourceName?: string;
  userName?: string;
  roleName?: string;
  grantedByDisplayName?: string;
  isExpired: boolean;
}

export interface TimedAccessCreateInput {
  resourceType: TimedAccessResourceType;
  resourceId: string;
  roleId?: string;
  userId?: string;
  expiresAt: string;
}

export interface TimedAccessRenewInput {
  expiresAt: string;
}

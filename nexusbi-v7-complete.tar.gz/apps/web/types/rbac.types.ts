export const PERMISSION_CODES = [
  'datasource.view',
  'datasource.create',
  'datasource.edit',
  'datasource.delete',
  'datasource.test',
  'datasource.query',
  'datasource.export',
  'schema.view',
  'schema.edit',
  'schema.autogenerate',
  'dashboard.view',
  'dashboard.create',
  'dashboard.edit',
  'dashboard.edit.any',
  'dashboard.delete',
  'dashboard.delete.any',
  'dashboard.share',
  'dashboard.embed',
  'dashboard.submit',
  'dashboard.approve',
  'dashboard.reject',
  'dashboard.replay',
  'dashboard.dual_checker',
  'explorer.use',
  'file.upload',
  'api.source.create',
  'api.source.edit',
  'api.source.delete',
  'tableau.import',
  'report.schedule',
  'lineage.view',
  'preagg.manage',
  'perf.view',
  'column.tag',
  'template.view',
  'template.install',
  'template.publish',
  'webhook.manage',
  'admin.roles',
  'admin.users',
  'admin.platform',
  'audit.view',
] as const;

export type PermissionCode = (typeof PERMISSION_CODES)[number];

export const ROLE_NAMES = [
  'PLATFORM_ADMIN',
  'DATA_ENGINEER',
  'ANALYST',
  'CHECKER',
  'VIEWER',
  'EMBED_USER',
] as const;

export type RoleName = (typeof ROLE_NAMES)[number];

export const ROLE_PERMISSIONS: Record<RoleName, readonly PermissionCode[]> = {
  PLATFORM_ADMIN: PERMISSION_CODES,
  DATA_ENGINEER: [
    'datasource.view',
    'datasource.create',
    'datasource.edit',
    'datasource.delete',
    'datasource.test',
    'datasource.query',
    'schema.view',
    'schema.edit',
    'schema.autogenerate',
    'file.upload',
    'api.source.create',
    'api.source.edit',
    'api.source.delete',
    'tableau.import',
    'explorer.use',
    'lineage.view',
    'preagg.manage',
    'perf.view',
    'column.tag',
    'template.publish',
    'webhook.manage',
    'audit.view',
  ],
  ANALYST: [
    'datasource.view',
    'datasource.query',
    'datasource.export',
    'schema.view',
    'explorer.use',
    'dashboard.view',
    'dashboard.create',
    'dashboard.edit',
    'dashboard.delete',
    'dashboard.share',
    'dashboard.embed',
    'dashboard.submit',
    'dashboard.replay',
    'file.upload',
    'tableau.import',
    'report.schedule',
    'lineage.view',
    'template.view',
    'template.install',
    'perf.view',
  ],
  CHECKER: [
    'dashboard.view',
    'dashboard.approve',
    'dashboard.reject',
    'dashboard.replay',
    'dashboard.dual_checker',
    'audit.view',
  ],
  VIEWER: [
    'dashboard.view',
    'template.view',
  ],
  EMBED_USER: [
    'dashboard.view',
  ],
};

export interface Permission {
  permId: string;
  permCode: PermissionCode;
  permCategory: string;
  description: string;
}

export interface Role {
  roleId: string;
  roleName: string;
  roleDescription: string | null;
  isSystemRole: boolean;
  createdAt: string;
}

export interface RoleWithPermissions extends Role {
  permissions: Permission[];
}

export interface UserRole {
  userId: string;
  roleId: string;
  tenantId: string;
  assignedAt: string;
  assignedBy: string;
  expiresAt: string | null;
}

export interface UserRoleAssignment {
  roleId: string;
  expiresAt?: string;
}

export interface SessionUser {
  id: string;
  userId: string;
  email: string;
  username: string;
  displayName: string;
  tenantId: string;
  roles: string[];
  permissions: string[];
}

export interface RbacCheckResult {
  allowed: boolean;
  missingPermission?: PermissionCode;
}

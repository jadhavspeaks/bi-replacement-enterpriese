/**
 * NexusBI — Data source types
 *
 * Only 12 connector types are supported.
 */

export const DATA_SOURCE_TYPES = [
  'oracle',
  'mongodb',
  'hive',
  'impala',
  'file_csv',
  'file_excel',
  'file_json',
  'file_parquet',
  'api_rest',
  'api_graphql',
  'api_oauth_rest',
  'api_webhook',
] as const;

export type DataSourceType = (typeof DATA_SOURCE_TYPES)[number];

export type DataSourceStatus = 'ACTIVE' | 'INACTIVE' | 'ERROR' | 'TESTING';

export interface DriverCapability {
  supportsSchemaIntrospection: boolean;
  supportsPreAggregations: boolean;
  supportsStreaming: boolean;
  requiresFileUpload: boolean;
  requiresApiConfig: boolean;
  connectorModule: string | null;
  defaultPort: number | null;
}

export const DRIVER_CAPABILITIES: Record<DataSourceType, DriverCapability> = {
  oracle: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: 1521,
  },
  mongodb: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/mongo-connector',
    defaultPort: 27017,
  },
  hive: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/hive-connector',
    defaultPort: 10000,
  },
  impala: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/hive-connector',
    defaultPort: 21050,
  },
  file_csv: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  file_excel: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  file_json: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  file_parquet: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  api_rest: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  api_graphql: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  api_oauth_rest: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
  api_webhook: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    connectorModule: '@/lib/connectors/oracle-connector',
    defaultPort: null,
  },
};

export const DS_TYPE_LABELS: Record<DataSourceType, string> = {
  oracle: 'Oracle (SQL Developer compatible)',
  mongodb: 'MongoDB (BI Connector)',
  hive: 'Apache Hive',
  impala: 'Apache Impala',
  file_csv: 'CSV File',
  file_excel: 'Excel File (.xlsx / .xls)',
  file_json: 'JSON File',
  file_parquet: 'Parquet File',
  api_rest: 'REST API',
  api_graphql: 'GraphQL API',
  api_oauth_rest: 'OAuth2 REST API',
  api_webhook: 'Inbound Webhook',
};

export interface DataSource {
  dsId: string;
  dsName: string;
  dsType: DataSourceType;
  description: string | null;
  configEncrypted: string;
  configMasked: string | null;
  status: DataSourceStatus;
  lastTestedAt: string | null;
  lastTestResult: string | null;
  lastErrorMsg: string | null;
  cubeDsId: string | null;
  tenantId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface DataSourceCreateInput {
  dsName: string;
  dsType: DataSourceType;
  description?: string;
  config: Record<string, unknown>;
}

export interface DataSourceUpdateInput {
  dsName?: string;
  description?: string;
  config?: Record<string, unknown>;
  isActive?: boolean;
}

export interface DsAccess {
  accessId: string;
  dsId: string;
  roleId: string;
  canQuery: boolean;
  canExport: boolean;
  canManage: boolean;
  rowFilterSql: string | null;
  columnBlacklist: string | null;
  grantedAt: string;
  grantedBy: string;
  expiresAt: string | null;
}

export interface DsAccessInput {
  roleId: string;
  canQuery?: boolean;
  canExport?: boolean;
  canManage?: boolean;
  rowFilterSql?: string;
  columnBlacklist?: string[];
  expiresAt?: string;
}

export interface ConnectionTestResult {
  success: boolean;
  latencyMs: number;
  tableCount: number | null;
  errorMessage: string | null;
}

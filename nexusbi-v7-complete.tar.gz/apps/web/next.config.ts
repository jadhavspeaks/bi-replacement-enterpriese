import type { NextConfig } from 'next';

/**
 * NOTE: typescript.ignoreBuildErrors and eslint.ignoreDuringBuilds are enabled
 * because the v6/v7 codebase has ~200 pre-existing type errors inherited from
 * before the monorepo was fixed. See KNOWN_ISSUES.md for the list and fixes.
 */
const nextConfig: NextConfig = {
  reactStrictMode: true,
  typescript: {
    ignoreBuildErrors: true,
  },
  eslint: {
    ignoreDuringBuilds: true,
  },
  serverExternalPackages: [
    'oracledb',
    'nodemailer',
    'adm-zip',
    'bcryptjs',
    'mongodb',
    'hive-driver',
  ],
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
  output: 'standalone',
};

export default nextConfig;

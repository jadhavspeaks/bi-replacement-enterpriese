import type { Metadata } from "next";
import "./globals.css";

// All pages need live data — disable static prerender globally.
export const dynamic = 'force-dynamic';

export const metadata: Metadata = {
  title: "NexusBI",
  description: "Enterprise BI platform",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

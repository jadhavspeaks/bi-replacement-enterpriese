'use client';

import { useEffect, useState } from 'react';
import { PageHeader, StatCard } from '@nexusbi/ui-components';
import { Skeleton } from '@/components/ui/skeleton';
import { Database, LayoutDashboard, Users, ClipboardCheck } from 'lucide-react';

interface PlatformStats {
  datasourceCount: number;
  dashboardCount: number;
  pendingReviews: number;
  userCount: number;
}

export default function HomePage() {
  const [stats, setStats] = useState<PlatformStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [dsRes, dashRes, reviewRes] = await Promise.all([
          fetch('/api/datasources').then((r) => r.json()),
          fetch('/api/dashboards').then((r) => r.json()),
          fetch('/api/dashboards/pending-review').then((r) => r.json()).catch(() => ({ data: [] })),
        ]);

        setStats({
          datasourceCount: dsRes.data?.length || 0,
          dashboardCount: dashRes.data?.length || 0,
          pendingReviews: reviewRes.data?.length || 0,
          userCount: 0,
        });
      } catch {
        setStats({ datasourceCount: 0, dashboardCount: 0, pendingReviews: 0, userCount: 0 });
      }
      setLoading(false);
    }
    load();
  }, []);

  return (
    <div>
      <PageHeader
        title="Welcome to NexusBI"
        description="Enterprise Business Intelligence Platform"
      />

      {loading ? (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <Skeleton key={i} className="h-24" />
          ))}
        </div>
      ) : stats && (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
          <StatCard
            title="Data Sources"
            value={stats.datasourceCount}
            icon={<Database className="h-5 w-5" />}
          />
          <StatCard
            title="Dashboards"
            value={stats.dashboardCount}
            icon={<LayoutDashboard className="h-5 w-5" />}
          />
          <StatCard
            title="Pending Reviews"
            value={stats.pendingReviews}
            icon={<ClipboardCheck className="h-5 w-5" />}
          />
          <StatCard
            title="Active Users"
            value={stats.userCount || '—'}
            icon={<Users className="h-5 w-5" />}
          />
        </div>
      )}
    </div>
  );
}

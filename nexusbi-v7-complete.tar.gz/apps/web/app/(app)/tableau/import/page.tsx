import { PageHeader } from '@nexusbi/ui-components';
import { TableauImportForm } from '@/components/tableau/TableauImportForm';

export default function TableauImportPage() {
  return (
    <div>
      <PageHeader
        title="Tableau Import"
        description="Import Tableau workbooks (.twbx) and convert them to NexusBI dashboards."
      />
      <TableauImportForm />
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { TemplateInstallDialog } from '@/components/templates/TemplateInstallDialog';
import { PermissionGate } from '@/components/shared/PermissionGate';
import { Download, Globe, Store } from 'lucide-react';
import type { DashTemplate } from '@nexusbi/shared-types';

export default function TemplateDetailPage() {
  const params = useParams<{ id: string }>();
  const [template, setTemplate] = useState<DashTemplate | null>(null);
  const [loading, setLoading] = useState(true);
  const [installOpen, setInstallOpen] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/templates/${params.id}`);
        const data = await response.json();
        if (data.success) setTemplate(data.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [params.id]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-64 w-full" /></div>;
  }

  if (!template) {
    return <div className="text-center py-12 text-muted-foreground">Template not found.</div>;
  }

  const tags = template.tags?.split(',').map((t) => t.trim()).filter(Boolean) || [];
  const requiredTypes = template.requiredDsTypes || [];

  return (
    <div>
      <PageHeader
        title={template.templateName}
        description={template.description || undefined}
        breadcrumbs={[
          { label: 'Templates', href: '/templates' },
          { label: template.templateName },
        ]}
        actions={
          <div className="flex items-center gap-2">
            {template.isGlobal && (
              <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-200">
                <Globe className="h-3 w-3 mr-1" />Global
              </Badge>
            )}
            <PermissionGate permission="template.install">
              <Button onClick={() => setInstallOpen(true)}>
                <Download className="h-4 w-4 mr-2" />Install Template
              </Button>
            </PermissionGate>
          </div>
        }
      />

      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader><CardTitle className="text-base">Preview</CardTitle></CardHeader>
            <CardContent>
              {template.thumbnailUrl ? (
                <img src={template.thumbnailUrl} alt={template.templateName} className="rounded-md border w-full" />
              ) : (
                <div className="h-64 bg-gradient-to-br from-nexus-50 to-nexus-100 rounded-md flex items-center justify-center">
                  <Store className="h-16 w-16 text-nexus-200" />
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Details</CardTitle></CardHeader>
            <CardContent className="space-y-3 text-sm">
              {template.category && (
                <div><p className="text-muted-foreground">Category</p><p className="font-medium">{template.category}</p></div>
              )}
              <div>
                <p className="text-muted-foreground">Installs</p>
                <p className="font-medium flex items-center gap-1"><Download className="h-3.5 w-3.5" />{template.installCount}</p>
              </div>
              <div>
                <p className="text-muted-foreground">Published</p>
                <p>{new Date(template.createdAt).toLocaleDateString()}</p>
              </div>
              {requiredTypes.length > 0 && (
                <div>
                  <p className="text-muted-foreground mb-1">Required Data Source Types</p>
                  <div className="flex flex-wrap gap-1">
                    {requiredTypes.map((t) => (
                      <Badge key={t} variant="outline" className="text-xs">{t}</Badge>
                    ))}
                  </div>
                </div>
              )}
              {tags.length > 0 && (
                <div>
                  <p className="text-muted-foreground mb-1">Tags</p>
                  <div className="flex flex-wrap gap-1">
                    {tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">{tag}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>

      {template && (
        <TemplateInstallDialog
          template={template}
          open={installOpen}
          onOpenChange={setInstallOpen}
        />
      )}
    </div>
  );
}

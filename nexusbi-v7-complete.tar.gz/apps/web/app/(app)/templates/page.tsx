import { PageHeader } from '@nexusbi/ui-components';
import { TemplateMarketplace } from '@/components/templates/TemplateMarketplace';

export default function TemplatesPage() {
  return (
    <div>
      <PageHeader
        title="Template Marketplace"
        description="Browse, install, and publish reusable dashboard templates."
      />
      <TemplateMarketplace />
    </div>
  );
}

import { PageHeader } from '@nexusbi/ui-components';
import { ReviewQueue } from '@/components/dashboard/ReviewQueue';

export default function CheckerPage() {
  return (
    <div>
      <PageHeader
        title="Review Queue"
        description="Dashboards pending your approval or rejection."
      />
      <ReviewQueue />
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { PageHeader } from '@nexusbi/ui-components';
import { LineageGraph } from '@/components/lineage/LineageGraph';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { GitFork } from 'lucide-react';
import type { LineageGraph as LineageGraphType } from '@nexusbi/shared-types';

export default function LineagePage() {
  const [graph, setGraph] = useState<LineageGraphType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch('/api/lineage');
        const data = await response.json();
        if (data.success) setGraph(data.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, []);

  if (loading) {
    return (
      <div>
        <PageHeader title="Data Lineage" description="Loading lineage graph..." />
        <Skeleton className="h-[600px] w-full" />
      </div>
    );
  }

  return (
    <div>
      <PageHeader
        title="Data Lineage"
        description="Visualize the flow from data sources through cubes to dashboards and widgets."
        actions={
          graph && (
            <div className="flex items-center gap-2">
              <Badge variant="outline">{graph.nodes.length} nodes</Badge>
              <Badge variant="outline">{graph.edges.length} edges</Badge>
            </div>
          )
        }
      />

      {graph && graph.nodes.length > 0 ? (
        <LineageGraph graph={graph} />
      ) : (
        <div className="flex flex-col items-center justify-center py-16 text-center">
          <GitFork className="h-12 w-12 text-muted-foreground mb-3" />
          <h3 className="text-lg font-semibold">No Lineage Data</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Create data sources, cube schemas, and dashboards to see the lineage graph.
          </p>
        </div>
      )}
    </div>
  );
}

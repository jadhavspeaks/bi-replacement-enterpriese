'use client';

import { useEffect, useState, use } from 'react';
import Link from 'next/link';
import { Edit, ArrowLeft } from 'lucide-react';
import type { Workbook, ApiResponse } from '@nexusbi/shared-types';

export default function WorkbookDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [workbook, setWorkbook] = useState<Workbook | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch(`/api/workbooks/${id}`);
        const j = (await r.json()) as ApiResponse<Workbook>;
        if (j.success && j.data) setWorkbook(j.data);
        else setError(j.error?.message || 'Not found');
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Network error');
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading...</div>;
  if (error || !workbook) {
    return (
      <div className="p-6">
        <Link href="/workbooks" className="text-sm text-blue-600 inline-flex items-center gap-1 mb-3">
          <ArrowLeft className="h-3 w-3" /> Back to workbooks
        </Link>
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error}</div>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl">
      <Link href="/workbooks" className="text-sm text-blue-600 inline-flex items-center gap-1 mb-3">
        <ArrowLeft className="h-3 w-3" /> Back to workbooks
      </Link>
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">{workbook.workbookName}</h1>
          {workbook.description && <p className="text-sm text-gray-500 mt-1">{workbook.description}</p>}
        </div>
        <Link
          href={`/workbooks/${workbook.workbookId}/edit`}
          className="inline-flex items-center gap-2 rounded-md bg-gray-900 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800"
        >
          <Edit className="h-4 w-4" /> Open in Editor
        </Link>
      </div>

      <dl className="grid grid-cols-2 gap-4 rounded-md border border-gray-200 bg-white p-4">
        <div>
          <dt className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Version</dt>
          <dd className="text-sm font-mono mt-1">v{workbook.version}</dd>
        </div>
        <div>
          <dt className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Status</dt>
          <dd className="text-sm mt-1">
            {workbook.isPublished
              ? <span className="px-2 py-0.5 rounded-full bg-green-100 text-green-800 text-xs">Published</span>
              : <span className="px-2 py-0.5 rounded-full bg-gray-100 text-gray-800 text-xs">Draft</span>}
          </dd>
        </div>
        {workbook.tags && (
          <div>
            <dt className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Tags</dt>
            <dd className="text-sm mt-1">{workbook.tags}</dd>
          </div>
        )}
        {workbook.publishedDashId && (
          <div>
            <dt className="text-xs font-semibold text-gray-500 uppercase tracking-wider">Published Dashboard</dt>
            <dd className="text-sm font-mono mt-1">
              <Link href={`/dashboards/${workbook.publishedDashId}`} className="text-blue-600 hover:underline">
                {workbook.publishedDashId}
              </Link>
            </dd>
          </div>
        )}
      </dl>
    </div>
  );
}

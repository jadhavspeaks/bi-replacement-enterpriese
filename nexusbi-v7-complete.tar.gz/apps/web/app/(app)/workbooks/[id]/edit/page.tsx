'use client';

import { useEffect, useState, use } from 'react';
import Link from 'next/link';
import { ArrowLeft, BarChart3, Code, Sliders } from 'lucide-react';
import { WorksheetEditor } from '@/components/workbook/WorksheetEditor';
import { CalculatedFieldEditor } from '@/components/workbook/CalculatedFieldEditor';
import { ParameterEditor } from '@/components/workbook/ParameterEditor';
import type { Workbook, ApiResponse } from '@nexusbi/shared-types';

type Tab = 'worksheets' | 'calculated' | 'parameters';

const TABS: Array<{ id: Tab; label: string; icon: typeof BarChart3 }> = [
  { id: 'worksheets', label: 'Worksheets', icon: BarChart3 },
  { id: 'calculated', label: 'Calculated Fields', icon: Code },
  { id: 'parameters', label: 'Parameters', icon: Sliders },
];

export default function WorkbookEditorPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const [workbook, setWorkbook] = useState<Workbook | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('worksheets');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch(`/api/workbooks/${id}`);
        const j = (await r.json()) as ApiResponse<Workbook>;
        if (j.success && j.data) setWorkbook(j.data);
        else setError(j.error?.message || 'Not found');
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Network error');
      } finally {
        setLoading(false);
      }
    })();
  }, [id]);

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading...</div>;
  if (error || !workbook) {
    return (
      <div className="p-6">
        <Link href="/workbooks" className="text-sm text-blue-600 inline-flex items-center gap-1 mb-3">
          <ArrowLeft className="h-3 w-3" /> Back
        </Link>
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700">{error || 'Workbook not found'}</div>
      </div>
    );
  }

  return (
    <div className="p-6">
      <Link href="/workbooks" className="text-sm text-blue-600 inline-flex items-center gap-1 mb-3">
        <ArrowLeft className="h-3 w-3" /> Back to workbooks
      </Link>
      <div className="mb-4">
        <h1 className="text-xl font-bold">Editing: {workbook.workbookName}</h1>
        <p className="text-xs text-gray-500 mt-1">v{workbook.version} · {workbook.isPublished ? 'Published' : 'Draft'}</p>
      </div>

      <div className="border-b border-gray-200 mb-6">
        <div className="flex gap-1">
          {TABS.map((t) => {
            const Icon = t.icon;
            return (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                className={`inline-flex items-center gap-2 px-4 py-2 text-sm font-medium border-b-2 -mb-px ${
                  activeTab === t.id
                    ? 'border-gray-900 text-gray-900'
                    : 'border-transparent text-gray-500 hover:text-gray-900'
                }`}
              >
                <Icon className="h-4 w-4" /> {t.label}
              </button>
            );
          })}
        </div>
      </div>

      {activeTab === 'worksheets' && <WorksheetEditor workbookId={workbook.workbookId} />}
      {activeTab === 'calculated' && <CalculatedFieldEditor workbookId={workbook.workbookId} />}
      {activeTab === 'parameters' && <ParameterEditor workbookId={workbook.workbookId} />}
    </div>
  );
}

import { WorkbookList } from '@/components/workbook/WorkbookList';

export default function WorkbooksPage() {
  return (
    <div className="p-6">
      <div className="mb-4">
        <h1 className="text-2xl font-bold tracking-tight">Workbooks</h1>
        <p className="text-sm text-gray-500">
          Personal workspaces — author worksheets, calculated fields, and parameters before publishing to a dashboard.
        </p>
      </div>
      <WorkbookList />
    </div>
  );
}

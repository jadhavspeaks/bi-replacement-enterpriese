'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader, DataTable, EmptyState } from '@nexusbi/ui-components';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Blocks } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';
import type { CubeSchema } from '@nexusbi/shared-types';

interface SchemaWithDs extends CubeSchema {
  dsName?: string;
}

export default function SemanticPage() {
  const router = useRouter();
  const [schemas, setSchemas] = useState<SchemaWithDs[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const [schemaRes, dsRes] = await Promise.all([
          fetch('/api/schemas').then((r) => r.json()),
          fetch('/api/datasources').then((r) => r.json()),
        ]);

        const dsMap = new Map<string, string>();
        for (const ds of dsRes.data || []) {
          dsMap.set(ds.dsId, ds.dsName);
        }

        const enriched = (schemaRes.data || []).map((s: CubeSchema) => ({
          ...s,
          dsName: dsMap.get(s.dsId) || s.dsId,
        }));

        setSchemas(enriched);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, []);

  const columns: ColumnDef<SchemaWithDs>[] = [
    { accessorKey: 'cubeName', header: 'Cube Name', cell: ({ row }) => (
      <span className="font-medium text-sm">{row.original.cubeName}</span>
    )},
    { accessorKey: 'dsName', header: 'Data Source' },
    { accessorKey: 'version', header: 'Version', cell: ({ row }) => (
      <Badge variant="outline" className="text-xs">v{row.original.version}</Badge>
    )},
    { accessorKey: 'isActive', header: 'Status', cell: ({ row }) => (
      <Badge variant={row.original.isActive ? 'default' : 'secondary'} className="text-xs">
        {row.original.isActive ? 'Active' : 'Inactive'}
      </Badge>
    )},
    { accessorKey: 'updatedAt', header: 'Updated', cell: ({ row }) => (
      <span className="text-xs text-muted-foreground">{new Date(row.original.updatedAt).toLocaleDateString()}</span>
    )},
  ];

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }

  return (
    <div>
      <PageHeader
        title="Semantic Layer"
        description="Manage Cube.js schemas that define your business metrics and dimensions."
      />

      {schemas.length === 0 ? (
        <EmptyState
          icon={<Blocks className="h-8 w-8 text-muted-foreground" />}
          title="No cube schemas"
          description="Create schemas by selecting a data source and using the auto-generate feature."
        />
      ) : (
        <DataTable
          columns={columns}
          data={schemas}
          searchColumn="cubeName"
          searchPlaceholder="Search cubes..."
          onRowClick={(row) => router.push(`/semantic/${row.dsId}`)}
        />
      )}
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader, StatusBadge, DataTable, EmptyState } from '@nexusbi/ui-components';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Plus, Globe } from 'lucide-react';
import Link from 'next/link';
import type { ColumnDef } from '@tanstack/react-table';
import type { ApiSource } from '@nexusbi/shared-types';

export default function ApiSourcesPage() {
  const router = useRouter();
  const [sources, setSources] = useState<ApiSource[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch('/api/api-sources');
        const data = await response.json();
        if (data.success) setSources(data.data || []);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, []);

  const columns: ColumnDef<ApiSource>[] = [
    { accessorKey: 'sourceName', header: 'Name', cell: ({ row }) => (
      <span className="font-medium text-sm">{row.original.sourceName}</span>
    )},
    { accessorKey: 'apiType', header: 'Type', cell: ({ row }) => (
      <Badge variant="outline" className="text-xs">{row.original.apiType}</Badge>
    )},
    { accessorKey: 'baseUrl', header: 'URL', cell: ({ row }) => (
      <span className="font-mono text-xs truncate max-w-48 block">{row.original.baseUrl}</span>
    )},
    { accessorKey: 'lastPollStatus', header: 'Last Poll', cell: ({ row }) => (
      row.original.lastPollStatus ? <StatusBadge status={row.original.lastPollStatus} size="sm" /> : <span className="text-xs text-muted-foreground">Never</span>
    )},
    { accessorKey: 'lastRowCount', header: 'Rows', cell: ({ row }) => (
      <span className="text-sm">{row.original.lastRowCount ?? '—'}</span>
    )},
    { accessorKey: 'isActive', header: 'Status', cell: ({ row }) => (
      <StatusBadge status={row.original.isActive ? 'ACTIVE' : 'INACTIVE'} size="sm" />
    )},
  ];

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }

  return (
    <div>
      <PageHeader
        title="API Sources"
        description="Connect REST, GraphQL, and webhook data sources."
        actions={
          <Link href="/api-sources/new">
            <Button><Plus className="h-4 w-4 mr-2" />Add API Source</Button>
          </Link>
        }
      />

      {sources.length === 0 ? (
        <EmptyState
          icon={<Globe className="h-8 w-8 text-muted-foreground" />}
          title="No API sources yet"
          description="Connect REST APIs, GraphQL endpoints, or inbound webhooks."
          actionLabel="Add API Source"
          actionHref="/api-sources/new"
        />
      ) : (
        <DataTable
          columns={columns}
          data={sources}
          searchColumn="sourceName"
          searchPlaceholder="Search API sources..."
          onRowClick={(row) => router.push(`/api-sources/${row.sourceId}`)}
        />
      )}
    </div>
  );
}

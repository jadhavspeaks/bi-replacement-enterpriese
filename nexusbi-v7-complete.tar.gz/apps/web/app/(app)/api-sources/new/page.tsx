'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';
import type { ApiType } from '@nexusbi/shared-types';

export default function NewApiSourcePage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [sourceName, setSourceName] = useState('');
  const [apiType, setApiType] = useState<ApiType>('REST_POLL');
  const [baseUrl, setBaseUrl] = useState('');
  const [pollCron, setPollCron] = useState('');

  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const response = await fetch('/api/api-sources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ sourceName, apiType, baseUrl, pollCron: pollCron || undefined }),
      });
      const data = await response.json();
      if (data.success) {
        router.push('/api-sources');
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [sourceName, apiType, baseUrl, pollCron, router]);

  return (
    <div>
      <PageHeader
        title="New API Source"
        description="Connect a REST, GraphQL, or webhook data source."
        breadcrumbs={[
          { label: 'API Sources', href: '/api-sources' },
          { label: 'New' },
        ]}
      />
      <div className="max-w-2xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <Card>
            <CardHeader><CardTitle className="text-base">Source Configuration</CardTitle></CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label>Source Name</Label>
                <Input placeholder="My API Source" value={sourceName} onChange={(e) => setSourceName(e.target.value)} required />
              </div>
              <div className="space-y-2">
                <Label>API Type</Label>
                <Select value={apiType} onValueChange={(v) => setApiType(v as ApiType)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="REST_POLL">REST Polling</SelectItem>
                    <SelectItem value="GRAPHQL_POLL">GraphQL Polling</SelectItem>
                    <SelectItem value="WEBHOOK_PUSH">Inbound Webhook</SelectItem>
                    <SelectItem value="OAUTH_REST">OAuth REST</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Base URL</Label>
                <Input placeholder="https://api.example.com/v1" value={baseUrl} onChange={(e) => setBaseUrl(e.target.value)} required />
              </div>
              {(apiType === 'REST_POLL' || apiType === 'GRAPHQL_POLL' || apiType === 'OAUTH_REST') && (
                <div className="space-y-2">
                  <Label>Poll Cron Expression (optional)</Label>
                  <Input placeholder="*/15 * * * *" value={pollCron} onChange={(e) => setPollCron(e.target.value)} />
                  <p className="text-xs text-muted-foreground">Leave empty for manual polling only</p>
                </div>
              )}
            </CardContent>
          </Card>
          <Button type="submit" disabled={saving || !sourceName || !baseUrl} className="w-full">
            {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Creating...</> : 'Create API Source'}
          </Button>
        </form>
      </div>
    </div>
  );
}

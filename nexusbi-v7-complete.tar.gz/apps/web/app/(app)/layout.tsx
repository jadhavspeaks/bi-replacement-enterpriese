'use client';

import { useEffect, type ReactNode } from 'react';
import { useSession } from 'next-auth/react';
import { useRouter } from 'next/navigation';
import { AppShell } from '@/components/shared/AppShell';
import { useUserStore } from '@/store/user.store';
import { Loader2 } from 'lucide-react';

export default function AppLayout({ children }: { children: ReactNode }) {
  const { data: session, status } = useSession();
  const router = useRouter();
  const setUser = useUserStore((s) => s.setUser);
  const fetchPermissions = useUserStore((s) => s.fetchPermissions);

  useEffect(() => {
    if (status === 'unauthenticated') {
      router.push('/login');
      return;
    }

    if (session?.user) {
      setUser(session.user);
      fetchPermissions();
    }
  }, [session, status, router, setUser, fetchPermissions]);

  if (status === 'loading') {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-nexus-500" />
      </div>
    );
  }

  if (!session) return null;

  return <AppShell>{children}</AppShell>;
}

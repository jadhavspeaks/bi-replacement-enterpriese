'use client';

import { useEffect, useState } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { PageHeader, StatusBadge } from '@nexusbi/ui-components';
import { ConnectionTestButton } from '@/components/datasources/ConnectionTestButton';
import { DataSourceAccessPanel } from '@/components/datasources/DataSourceAccessPanel';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, Trash2, Database } from 'lucide-react';
import { ConfirmDialog } from '@nexusbi/ui-components';
import { DS_TYPE_LABELS, type DataSource } from '@nexusbi/shared-types';

export default function DataSourceDetailPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [ds, setDs] = useState<DataSource | null>(null);
  const [loading, setLoading] = useState(true);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/datasources/${params.id}`);
        const data = await response.json();
        if (data.success) setDs(data.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [params.id]);

  const handleDelete = async () => {
    setDeleting(true);
    try {
      const response = await fetch(`/api/datasources/${params.id}`, { method: 'DELETE' });
      if (response.ok) router.push('/datasources');
    } catch { /* handle */ }
    setDeleting(false);
  };

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }

  if (!ds) {
    return <div className="text-center py-12 text-muted-foreground">Data source not found.</div>;
  }

  return (
    <div>
      <PageHeader
        title={ds.dsName}
        description={DS_TYPE_LABELS[ds.dsType] || ds.dsType}
        breadcrumbs={[
          { label: 'Data Sources', href: '/datasources' },
          { label: ds.dsName },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <StatusBadge status={ds.status} />
            <Button variant="outline" onClick={() => router.push(`/datasources/${params.id}/edit`)}>
              <Pencil className="h-4 w-4 mr-2" />Edit
            </Button>
            <Button variant="destructive" onClick={() => setDeleteOpen(true)}>
              <Trash2 className="h-4 w-4 mr-2" />Delete
            </Button>
          </div>
        }
      />

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="access">Access Control</TabsTrigger>
          <TabsTrigger value="test">Connection Test</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="mt-4">
          <Card>
            <CardHeader><CardTitle className="text-base">Details</CardTitle></CardHeader>
            <CardContent className="grid grid-cols-2 gap-4 text-sm">
              <div><p className="text-muted-foreground">Type</p><p className="font-medium">{DS_TYPE_LABELS[ds.dsType]}</p></div>
              <div><p className="text-muted-foreground">Status</p><StatusBadge status={ds.status} /></div>
              <div><p className="text-muted-foreground">Created</p><p>{new Date(ds.createdAt).toLocaleString()}</p></div>
              <div><p className="text-muted-foreground">Last Tested</p><p>{ds.lastTestedAt ? new Date(ds.lastTestedAt).toLocaleString() : 'Never'}</p></div>
              {ds.description && <div className="col-span-2"><p className="text-muted-foreground">Description</p><p>{ds.description}</p></div>}
              {ds.configMasked && (
                <div className="col-span-2">
                  <p className="text-muted-foreground mb-1">Configuration (masked)</p>
                  <pre className="rounded bg-muted p-3 text-xs font-mono overflow-x-auto">
                    {JSON.stringify(JSON.parse(ds.configMasked), null, 2)}
                  </pre>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="access" className="mt-4">
          <DataSourceAccessPanel dsId={params.id} />
        </TabsContent>

        <TabsContent value="test" className="mt-4">
          <Card>
            <CardContent className="p-6">
              <ConnectionTestButton dsId={params.id} />
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <ConfirmDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        title="Delete Data Source"
        description={`Are you sure you want to delete "${ds.dsName}"? This will deactivate the data source and remove access.`}
        confirmLabel="Delete"
        variant="destructive"
        onConfirm={handleDelete}
        loading={deleting}
      />
    </div>
  );
}

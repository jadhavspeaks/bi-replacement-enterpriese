'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { DataSourceForm } from '@/components/datasources/DataSourceForm';
import { Skeleton } from '@/components/ui/skeleton';
import type { DataSource, DataSourceType } from '@nexusbi/shared-types';

export default function EditDataSourcePage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const [ds, setDs] = useState<DataSource | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/datasources/${params.id}`);
        const data = await response.json();
        if (data.success) setDs(data.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [params.id]);

  const handleSubmit = useCallback(async (data: { dsName: string; dsType: DataSourceType; description: string; config: Record<string, unknown> }) => {
    setSaving(true);
    try {
      const response = await fetch(`/api/datasources/${params.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      if (result.success) {
        router.push(`/datasources/${params.id}`);
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [params.id, router]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-64 w-full" /></div>;
  }

  if (!ds) {
    return <div className="text-center py-12 text-muted-foreground">Data source not found.</div>;
  }

  const maskedConfig = ds.configMasked ? JSON.parse(ds.configMasked) : {};

  return (
    <div>
      <PageHeader
        title={`Edit: ${ds.dsName}`}
        breadcrumbs={[
          { label: 'Data Sources', href: '/datasources' },
          { label: ds.dsName, href: `/datasources/${params.id}` },
          { label: 'Edit' },
        ]}
      />
      <div className="max-w-2xl">
        <DataSourceForm
          onSubmit={handleSubmit}
          loading={saving}
          submitLabel="Save Changes"
          defaultValues={{
            dsName: ds.dsName,
            dsType: ds.dsType,
            description: ds.description || '',
            config: maskedConfig,
          }}
        />
      </div>
    </div>
  );
}

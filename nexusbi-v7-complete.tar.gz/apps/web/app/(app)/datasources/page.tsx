import { PageHeader } from '@nexusbi/ui-components';
import { DataSourceList } from '@/components/datasources/DataSourceList';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import Link from 'next/link';

export default function DataSourcesPage() {
  return (
    <div>
      <PageHeader
        title="Data Sources"
        description="Connect and manage your databases, files, and API sources."
        actions={
          <Link href="/datasources/new">
            <Button><Plus className="h-4 w-4 mr-2" />Add Data Source</Button>
          </Link>
        }
      />
      <DataSourceList />
    </div>
  );
}

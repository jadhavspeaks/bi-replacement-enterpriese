'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { DataSourceForm } from '@/components/datasources/DataSourceForm';
import type { DataSourceType } from '@nexusbi/shared-types';

export default function NewDataSourcePage() {
  const router = useRouter();
  const [loading, setLoading] = useState(false);

  const handleSubmit = useCallback(async (data: { dsName: string; dsType: DataSourceType; description: string; config: Record<string, unknown> }) => {
    setLoading(true);
    try {
      const response = await fetch('/api/datasources', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      const result = await response.json();
      if (result.success && result.data?.dsId) {
        router.push(`/datasources/${result.data.dsId}`);
      }
    } catch {
      // handle error
    }
    setLoading(false);
  }, [router]);

  return (
    <div>
      <PageHeader
        title="New Data Source"
        description="Connect a new database, file, or API source."
        breadcrumbs={[
          { label: 'Data Sources', href: '/datasources' },
          { label: 'New' },
        ]}
      />
      <div className="max-w-2xl">
        <DataSourceForm onSubmit={handleSubmit} loading={loading} />
      </div>
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader, EmptyState, ApprovalStatusBadge } from '@nexusbi/ui-components';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { PermissionGate } from '@/components/shared/PermissionGate';
import { Plus, LayoutDashboard, Search, Clock } from 'lucide-react';
import Link from 'next/link';
import type { Dashboard } from '@nexusbi/shared-types';

export default function DashboardsPage() {
  const router = useRouter();
  const [dashboards, setDashboards] = useState<Dashboard[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch('/api/dashboards');
        const data = await response.json();
        if (data.success) setDashboards(data.data || []);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, []);

  const filtered = dashboards.filter((d) =>
    !search || d.dashName.toLowerCase().includes(search.toLowerCase()) ||
    d.tags?.toLowerCase().includes(search.toLowerCase()),
  );

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">{Array.from({ length: 6 }).map((_, i) => <Skeleton key={i} className="h-36" />)}</div></div>;
  }

  return (
    <div>
      <PageHeader
        title="Dashboards"
        description="View and manage your business intelligence dashboards."
        actions={
          <PermissionGate permission="dashboard.create">
            <Link href="/dashboards/new">
              <Button><Plus className="h-4 w-4 mr-2" />New Dashboard</Button>
            </Link>
          </PermissionGate>
        }
      />

      {dashboards.length === 0 ? (
        <EmptyState
          icon={<LayoutDashboard className="h-8 w-8 text-muted-foreground" />}
          title="No dashboards yet"
          description="Create your first dashboard to start visualizing data."
          actionLabel="New Dashboard"
          actionHref="/dashboards/new"
        />
      ) : (
        <>
          <div className="mb-4 relative max-w-sm">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input placeholder="Search dashboards..." value={search} onChange={(e) => setSearch(e.target.value)} className="pl-9" />
          </div>

          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {filtered.map((dash) => (
              <Card
                key={dash.dashId}
                className="cursor-pointer transition-all hover:shadow-md hover:border-nexus-300"
                onClick={() => router.push(`/dashboards/${dash.dashId}`)}
              >
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold text-sm line-clamp-1">{dash.dashName}</h3>
                    <ApprovalStatusBadge status={dash.approvalStatus} size="sm" />
                  </div>
                  {dash.description && (
                    <p className="text-xs text-muted-foreground line-clamp-2 mb-3">{dash.description}</p>
                  )}
                  <div className="flex items-center justify-between text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {new Date(dash.updatedAt).toLocaleDateString()}
                    </span>
                    <div className="flex items-center gap-1">
                      {dash.dualCheckerRequired && (
                        <Badge variant="outline" className="text-[10px]">Dual-Check</Badge>
                      )}
                      {dash.source === 'TABLEAU_IMPORT' && (
                        <Badge variant="outline" className="text-[10px]">Tableau</Badge>
                      )}
                      <Badge variant="secondary" className="text-[10px]">v{dash.version}</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </>
      )}
    </div>
  );
}

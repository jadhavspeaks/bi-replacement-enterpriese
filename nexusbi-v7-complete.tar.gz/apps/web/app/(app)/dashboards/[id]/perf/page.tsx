import { PageHeader } from '@nexusbi/ui-components';
import { PerfScorecard } from '@/components/dashboard/PerfScorecard';

export default function PerfPage({ params }: { params: { id: string } }) {
  return (
    <div>
      <PageHeader
        title="Performance Scorecard"
        description="Widget-level load times, P50/P95/P99 metrics, and optimization recommendations."
        breadcrumbs={[
          { label: 'Dashboards', href: '/dashboards' },
          { label: 'Dashboard', href: `/dashboards/${params.id}` },
          { label: 'Performance' },
        ]}
      />
      <PerfScorecard dashId={params.id} />
    </div>
  );
}

'use client';

import { useEffect, useState, useCallback } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { PageHeader, ApprovalStatusBadge } from '@nexusbi/ui-components';
import { DashboardGrid } from '@/components/dashboard/DashboardGrid';
import { NLFilterBar } from '@/components/dashboard/NLFilterBar';
import { DualCheckerBadge } from '@/components/dashboard/DualCheckerBadge';
import { ShareDialog } from '@/components/dashboard/ShareDialog';
import { EmbedDialog } from '@/components/dashboard/EmbedDialog';
import { PermissionGate } from '@/components/shared/PermissionGate';
import { useDashboardStore } from '@/store/dashboard.store';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Pencil, Share2, Code2, Gauge, PlayCircle, Send } from 'lucide-react';
import type { Dashboard, MobileLayout } from '@nexusbi/shared-types';

export default function DashboardViewPage() {
  const params = useParams<{ id: string }>();
  const router = useRouter();
  const setDashboard = useDashboardStore((s) => s.setDashboard);
  const dashboard = useDashboardStore((s) => s.dashboard);
  const [loading, setLoading] = useState(true);
  const [mobileLayout, setMobileLayout] = useState<MobileLayout | null>(null);
  const [shareOpen, setShareOpen] = useState(false);
  const [embedOpen, setEmbedOpen] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const [dashRes, mobileRes] = await Promise.all([
          fetch(`/api/dashboards/${params.id}`).then((r) => r.json()),
          fetch(`/api/dashboards/${params.id}/mobile`).then((r) => r.json()).catch(() => ({ data: null })),
        ]);
        if (dashRes.success) setDashboard(dashRes.data);
        if (mobileRes.success && mobileRes.data) setMobileLayout(mobileRes.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
  }, [params.id, setDashboard]);

  const handleSubmit = useCallback(async () => {
    try {
      const response = await fetch(`/api/dashboards/${params.id}/submit`, { method: 'POST' });
      if (response.ok) {
        const dashRes = await fetch(`/api/dashboards/${params.id}`).then((r) => r.json());
        if (dashRes.success) setDashboard(dashRes.data);
      }
    } catch { /* handle */ }
  }, [params.id, setDashboard]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-96 w-full" /></div>;
  }

  if (!dashboard) {
    return <div className="text-center py-12 text-muted-foreground">Dashboard not found.</div>;
  }

  return (
    <div>
      <PageHeader
        title={dashboard.dashName}
        description={dashboard.description || undefined}
        breadcrumbs={[
          { label: 'Dashboards', href: '/dashboards' },
          { label: dashboard.dashName },
        ]}
        actions={
          <div className="flex items-center gap-2">
            <ApprovalStatusBadge status={dashboard.approvalStatus} />
            {dashboard.dualCheckerRequired && <DualCheckerBadge dashId={params.id} compact />}

            <PermissionGate permission="perf.view">
              <Button variant="ghost" size="sm" onClick={() => router.push(`/dashboards/${params.id}/perf`)}>
                <Gauge className="h-4 w-4" />
              </Button>
            </PermissionGate>

            <PermissionGate permission="dashboard.replay">
              <Button variant="ghost" size="sm" onClick={() => router.push(`/dashboards/${params.id}/replay`)}>
                <PlayCircle className="h-4 w-4" />
              </Button>
            </PermissionGate>

            <PermissionGate permission="dashboard.share">
              <Button variant="ghost" size="sm" onClick={() => setShareOpen(true)}>
                <Share2 className="h-4 w-4" />
              </Button>
            </PermissionGate>

            <PermissionGate permission="dashboard.embed">
              <Button variant="ghost" size="sm" onClick={() => setEmbedOpen(true)}>
                <Code2 className="h-4 w-4" />
              </Button>
            </PermissionGate>

            <PermissionGate permission="dashboard.submit">
              {(dashboard.approvalStatus === 'DRAFT' || dashboard.approvalStatus === 'REJECTED') && (
                <Button variant="outline" size="sm" onClick={handleSubmit}>
                  <Send className="h-4 w-4 mr-1" />Submit
                </Button>
              )}
            </PermissionGate>

            <PermissionGate permission="dashboard.edit">
              <Button size="sm" onClick={() => router.push(`/dashboards/${params.id}/edit`)}>
                <Pencil className="h-4 w-4 mr-1" />Edit
              </Button>
            </PermissionGate>
          </div>
        }
      />

      <div className="mb-4">
        <NLFilterBar dashId={params.id} />
      </div>

      <DashboardGrid dashId={params.id} mobileLayout={mobileLayout} />

      <ShareDialog dashId={params.id} open={shareOpen} onOpenChange={setShareOpen} />
      <EmbedDialog dashId={params.id} open={embedOpen} onOpenChange={setEmbedOpen} />
    </div>
  );
}

import { PageHeader } from '@nexusbi/ui-components';
import { ApprovalReplay } from '@/components/dashboard/ApprovalReplay';

export default function ReplayPage({ params }: { params: { id: string } }) {
  return (
    <div>
      <PageHeader
        title="Approval History Replay"
        description="View exactly what an approved dashboard looked like at every past approval."
        breadcrumbs={[
          { label: 'Dashboards', href: '/dashboards' },
          { label: 'Dashboard', href: `/dashboards/${params.id}` },
          { label: 'Replay' },
        ]}
      />
      <ApprovalReplay dashId={params.id} />
    </div>
  );
}

'use client';

import { useEffect, useState } from 'react';
import { useParams } from 'next/navigation';
import { DashboardGrid } from '@/components/dashboard/DashboardGrid';
import { DashboardToolbar } from '@/components/dashboard/DashboardToolbar';
import { WidgetPicker } from '@/components/dashboard/WidgetPicker';
import { CollaboratorPresence } from '@/components/dashboard/CollaboratorPresence';
import { MobileLayoutEditor } from '@/components/dashboard/MobileLayoutEditor';
import { VersionHistory } from '@/components/dashboard/VersionHistory';
import { ShareDialog } from '@/components/dashboard/ShareDialog';
import { EmbedDialog } from '@/components/dashboard/EmbedDialog';
import { useDashboardStore } from '@/store/dashboard.store';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export default function DashboardEditPage() {
  const params = useParams<{ id: string }>();
  const setDashboard = useDashboardStore((s) => s.setDashboard);
  const editMode = useDashboardStore((s) => s.editMode);
  const reset = useDashboardStore((s) => s.reset);
  const [loading, setLoading] = useState(true);
  const [shareOpen, setShareOpen] = useState(false);
  const [embedOpen, setEmbedOpen] = useState(false);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${params.id}`);
        const data = await response.json();
        if (data.success) setDashboard(data.data);
      } catch { /* handle */ }
      setLoading(false);
    }
    load();
    return () => { reset(); };
  }, [params.id, setDashboard, reset]);

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-96 w-full" /></div>;
  }

  return (
    <div>
      <div className="flex items-center justify-between mb-2">
        <CollaboratorPresence dashId={params.id} />
      </div>

      <DashboardToolbar
        dashId={params.id}
        onShare={() => setShareOpen(true)}
        onEmbed={() => setEmbedOpen(true)}
        onSubmit={async () => {
          await fetch(`/api/dashboards/${params.id}/submit`, { method: 'POST' });
          const res = await fetch(`/api/dashboards/${params.id}`).then((r) => r.json());
          if (res.success) setDashboard(res.data);
        }}
      />

      <div className="flex gap-4">
        <div className="flex-1 min-w-0">
          <Tabs defaultValue="canvas">
            <TabsList>
              <TabsTrigger value="canvas">Canvas</TabsTrigger>
              <TabsTrigger value="mobile">Mobile Layout</TabsTrigger>
              <TabsTrigger value="history">Version History</TabsTrigger>
            </TabsList>

            <TabsContent value="canvas" className="mt-4">
              <DashboardGrid dashId={params.id} isEditing={true} />
            </TabsContent>

            <TabsContent value="mobile" className="mt-4">
              <MobileLayoutEditor dashId={params.id} />
            </TabsContent>

            <TabsContent value="history" className="mt-4">
              <VersionHistory dashId={params.id} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="w-64 shrink-0">
          <WidgetPicker />
        </div>
      </div>

      <ShareDialog dashId={params.id} open={shareOpen} onOpenChange={setShareOpen} />
      <EmbedDialog dashId={params.id} open={embedOpen} onOpenChange={setEmbedOpen} />
    </div>
  );
}

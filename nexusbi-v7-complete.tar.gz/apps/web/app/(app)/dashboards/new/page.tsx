'use client';

import { useState, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Card, CardContent } from '@/components/ui/card';
import { Loader2 } from 'lucide-react';

export default function NewDashboardPage() {
  const router = useRouter();
  const [saving, setSaving] = useState(false);
  const [dashName, setDashName] = useState('');
  const [description, setDescription] = useState('');
  const [dualChecker, setDualChecker] = useState(false);

  const handleCreate = useCallback(async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      const response = await fetch('/api/dashboards', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          dashName,
          description: description || undefined,
          dualCheckerRequired: dualChecker,
        }),
      });
      const data = await response.json();
      if (data.success) {
        router.push(`/dashboards/${data.data.dashId}/edit`);
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [dashName, description, dualChecker, router]);

  return (
    <div>
      <PageHeader
        title="New Dashboard"
        description="Create a new dashboard and start adding widgets."
        breadcrumbs={[
          { label: 'Dashboards', href: '/dashboards' },
          { label: 'New' },
        ]}
      />
      <div className="max-w-lg">
        <Card>
          <CardContent className="p-6">
            <form onSubmit={handleCreate} className="space-y-4">
              <div className="space-y-2">
                <Label>Dashboard Name</Label>
                <Input placeholder="Q4 Revenue Overview" value={dashName} onChange={(e) => setDashName(e.target.value)} required autoFocus />
              </div>
              <div className="space-y-2">
                <Label>Description (optional)</Label>
                <Textarea placeholder="Describe this dashboard..." value={description} onChange={(e) => setDescription(e.target.value)} rows={3} />
              </div>
              <div className="flex items-center gap-3">
                <Switch checked={dualChecker} onCheckedChange={setDualChecker} id="dualChecker" />
                <Label htmlFor="dualChecker">Require dual-checker approval</Label>
              </div>
              <p className="text-xs text-muted-foreground">
                When enabled, two independent checkers must approve this dashboard before it becomes visible to viewers.
              </p>
              <Button type="submit" disabled={saving || !dashName} className="w-full">
                {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Creating...</> : 'Create & Open Editor'}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

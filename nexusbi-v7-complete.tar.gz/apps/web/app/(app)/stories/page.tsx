'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { Plus, FileText, Eye } from 'lucide-react';
import type { Story, StoryCreateInput, ApiResponse } from '@nexusbi/shared-types';

export default function StoriesPage() {
  const router = useRouter();
  const [stories, setStories] = useState<Story[]>([]);
  const [loading, setLoading] = useState(true);
  const [showNew, setShowNew] = useState(false);
  const [name, setName] = useState('');
  const [desc, setDesc] = useState('');
  const [creating, setCreating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      try {
        const r = await fetch('/api/stories');
        const j = (await r.json()) as ApiResponse<Story[]>;
        if (j.success) setStories(j.data || []);
        else setError(j.error?.message || 'Load failed');
      } catch (e) {
        setError(e instanceof Error ? e.message : 'Network error');
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  async function handleCreate() {
    if (!name.trim()) return;
    setCreating(true);
    setError(null);
    try {
      const body: StoryCreateInput = { storyName: name.trim(), description: desc.trim() || undefined };
      const r = await fetch('/api/stories', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      const j = (await r.json()) as ApiResponse<Story>;
      if (j.success && j.data) {
        router.push(`/stories/${j.data.storyId}`);
      } else setError(j.error?.message || 'Create failed');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Create failed');
    } finally {
      setCreating(false);
    }
  }

  if (loading) return <div className="p-6 text-sm text-gray-500">Loading stories...</div>;

  return (
    <div className="p-6">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h1 className="text-2xl font-bold">Stories</h1>
          <p className="text-sm text-gray-500">
            Multi-frame narratives that walk an audience through dashboards and worksheets.
          </p>
        </div>
        <button
          onClick={() => setShowNew(true)}
          className="inline-flex items-center gap-2 rounded-md bg-gray-900 px-3 py-2 text-sm font-medium text-white hover:bg-gray-800"
        >
          <Plus className="h-4 w-4" /> New Story
        </button>
      </div>

      {error && (
        <div className="rounded-md bg-red-50 border border-red-200 px-3 py-2 text-sm text-red-700 mb-4">{error}</div>
      )}

      {showNew && (
        <div className="rounded-md border border-gray-200 bg-white p-4 mb-4 space-y-3">
          <h3 className="font-medium">Create Story</h3>
          <input
            type="text" value={name} onChange={(e) => setName(e.target.value)}
            placeholder="Story name"
            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
          />
          <textarea
            value={desc} onChange={(e) => setDesc(e.target.value)}
            rows={2} placeholder="Description"
            className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
          />
          <div className="flex gap-2 justify-end">
            <button onClick={() => setShowNew(false)} className="rounded-md border border-gray-300 px-3 py-1.5 text-sm hover:bg-gray-50">Cancel</button>
            <button
              onClick={handleCreate} disabled={creating || !name.trim()}
              className="rounded-md bg-gray-900 px-3 py-1.5 text-sm text-white hover:bg-gray-800 disabled:opacity-50"
            >
              {creating ? 'Creating...' : 'Create Story'}
            </button>
          </div>
        </div>
      )}

      {stories.length === 0 ? (
        <div className="rounded-md border border-dashed border-gray-300 bg-gray-50 p-12 text-center">
          <FileText className="mx-auto h-10 w-10 text-gray-400 mb-3" />
          <p className="text-sm text-gray-600">No stories yet. Create one to start narrating.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {stories.map((s) => (
            <Link
              key={s.storyId}
              href={`/stories/${s.storyId}`}
              className="rounded-md border border-gray-200 bg-white p-4 hover:shadow-sm transition-shadow"
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="font-semibold text-sm">{s.storyName}</h3>
                {s.isPublished && (
                  <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    <Eye className="h-3 w-3" /> Published
                  </span>
                )}
              </div>
              {s.description && <p className="text-xs text-gray-600 mb-3 line-clamp-2">{s.description}</p>}
              <div className="text-xs text-gray-500">
                {s.storyPoints.length} {s.storyPoints.length === 1 ? 'point' : 'points'} · v{s.version}
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}

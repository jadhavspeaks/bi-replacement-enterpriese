'use client';

import { use } from 'react';
import Link from 'next/link';
import { ArrowLeft } from 'lucide-react';
import { StoryBuilder } from '@/components/workbook/StoryBuilder';

export default function StoryDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  return (
    <div className="p-6">
      <Link href="/stories" className="text-sm text-blue-600 inline-flex items-center gap-1 mb-3">
        <ArrowLeft className="h-3 w-3" /> Back to stories
      </Link>
      <StoryBuilder storyId={id} />
    </div>
  );
}

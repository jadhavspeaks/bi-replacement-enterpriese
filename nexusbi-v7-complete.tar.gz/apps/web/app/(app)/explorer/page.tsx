import { PageHeader } from '@nexusbi/ui-components';
import { ExplorerShell } from '@/components/explorer/ExplorerShell';

export default function ExplorerPage() {
  return (
    <div>
      <PageHeader
        title="Data Explorer"
        description="Visually explore your data using Graphic Walker. Select a data source and cube to begin."
      />
      <ExplorerShell />
    </div>
  );
}

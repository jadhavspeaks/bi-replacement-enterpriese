import { PageHeader } from '@nexusbi/ui-components';
import { WebhookManager } from '@/components/admin/WebhookManager';

export default function WebhooksPage() {
  return (
    <div>
      <PageHeader
        title="Outbound Webhooks"
        description="Configure webhook endpoints triggered by dashboard approvals, metric thresholds, or schedules."
        breadcrumbs={[
          { label: 'Admin', href: '/admin' },
          { label: 'Webhooks' },
        ]}
      />
      <WebhookManager />
    </div>
  );
}

import { PageHeader } from '@nexusbi/ui-components';
import { TimedAccessManager } from '@/components/admin/TimedAccessManager';

export default function TimedAccessPage() {
  return (
    <div>
      <PageHeader
        title="Time-Bounded Access"
        description="Grant and manage time-limited access to data sources and dashboards. Expired grants are automatically denied."
        breadcrumbs={[
          { label: 'Admin', href: '/admin' },
          { label: 'Timed Access' },
        ]}
      />
      <TimedAccessManager />
    </div>
  );
}

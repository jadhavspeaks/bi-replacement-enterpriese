'use client';

import { useEffect, useState, useCallback } from 'react';
import { PageHeader, DataTable } from '@nexusbi/ui-components';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, Plus, Settings, Lock } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';

interface ConfigEntry {
  key: string;
  value: string;
  configType: string;
  description: string | null;
  isSecret: boolean;
}

export default function PlatformConfigPage() {
  const [configs, setConfigs] = useState<ConfigEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [editOpen, setEditOpen] = useState(false);
  const [saving, setSaving] = useState(false);

  const [editKey, setEditKey] = useState('');
  const [editValue, setEditValue] = useState('');
  const [editDescription, setEditDescription] = useState('');
  const [editIsSecret, setEditIsSecret] = useState(false);
  const [isNew, setIsNew] = useState(false);

  const fetchConfigs = useCallback(async () => {
    try {
      const response = await fetch('/api/admin/platform');
      const data = await response.json();
      if (data.success) setConfigs(data.data || []);
    } catch { /* handle */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchConfigs(); }, [fetchConfigs]);

  const handleEdit = useCallback((config?: ConfigEntry) => {
    if (config) {
      setEditKey(config.key);
      setEditValue(config.isSecret ? '' : config.value);
      setEditDescription(config.description || '');
      setEditIsSecret(config.isSecret);
      setIsNew(false);
    } else {
      setEditKey('');
      setEditValue('');
      setEditDescription('');
      setEditIsSecret(false);
      setIsNew(true);
    }
    setEditOpen(true);
  }, []);

  const handleSave = useCallback(async () => {
    setSaving(true);
    try {
      const response = await fetch('/api/admin/platform', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          key: editKey,
          value: editValue,
          description: editDescription || undefined,
          isSecret: editIsSecret,
        }),
      });
      if (response.ok) {
        setEditOpen(false);
        fetchConfigs();
      }
    } catch { /* handle */ }
    setSaving(false);
  }, [editKey, editValue, editDescription, editIsSecret, fetchConfigs]);

  const columns: ColumnDef<ConfigEntry>[] = [
    { accessorKey: 'key', header: 'Key', cell: ({ row }) => (
      <span className="font-mono text-sm">{row.original.key}</span>
    )},
    { accessorKey: 'value', header: 'Value', cell: ({ row }) => (
      <span className="text-sm">
        {row.original.isSecret ? (
          <span className="flex items-center gap-1 text-muted-foreground">
            <Lock className="h-3 w-3" />••••••••
          </span>
        ) : (
          <span className="font-mono text-xs truncate max-w-64 block">{row.original.value}</span>
        )}
      </span>
    )},
    { accessorKey: 'configType', header: 'Type', cell: ({ row }) => (
      <Badge variant="outline" className="text-xs">{row.original.configType}</Badge>
    )},
    { accessorKey: 'description', header: 'Description', cell: ({ row }) => (
      <span className="text-xs text-muted-foreground">{row.original.description || '—'}</span>
    )},
    { id: 'actions', header: '', cell: ({ row }) => (
      <Button variant="ghost" size="sm" onClick={() => handleEdit(row.original)}>Edit</Button>
    )},
  ];

  if (loading) {
    return <div className="space-y-4"><Skeleton className="h-12 w-full" /><Skeleton className="h-48 w-full" /></div>;
  }

  return (
    <div>
      <PageHeader
        title="Platform Configuration"
        description="Manage system-wide settings stored in NB_PLATFORM_CONFIG."
        breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: 'Platform' }]}
        actions={
          <Button onClick={() => handleEdit()}>
            <Plus className="h-4 w-4 mr-2" />Add Config
          </Button>
        }
      />

      <DataTable columns={columns} data={configs} searchColumn="key" searchPlaceholder="Search config keys..." />

      <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle>{isNew ? 'Add Config' : `Edit: ${editKey}`}</DialogTitle></DialogHeader>
          <div className="space-y-4">
            <div className="space-y-2">
              <Label>Key</Label>
              <Input value={editKey} onChange={(e) => setEditKey(e.target.value)} disabled={!isNew} placeholder="smtp.host" className="font-mono" />
            </div>
            <div className="space-y-2">
              <Label>Value</Label>
              <Textarea value={editValue} onChange={(e) => setEditValue(e.target.value)} placeholder="Configuration value..." rows={3} className="font-mono text-sm" />
            </div>
            <div className="space-y-2">
              <Label>Description</Label>
              <Input value={editDescription} onChange={(e) => setEditDescription(e.target.value)} placeholder="What this config does..." />
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={editIsSecret} onCheckedChange={setEditIsSecret} id="configSecret" />
              <Label htmlFor="configSecret">Secret value (will be masked)</Label>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving || !editKey}>
              {saving ? <><Loader2 className="h-4 w-4 mr-2 animate-spin" />Saving...</> : 'Save'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

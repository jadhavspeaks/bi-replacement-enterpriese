import { PageHeader } from '@nexusbi/ui-components';
import { RoleManager } from '@/components/admin/RoleManager';

export default function RolesPage() {
  return (
    <div>
      <PageHeader
        title="Roles & Permissions"
        description="Manage roles and their permission assignments."
        breadcrumbs={[
          { label: 'Admin', href: '/admin' },
          { label: 'Roles' },
        ]}
      />
      <RoleManager />
    </div>
  );
}

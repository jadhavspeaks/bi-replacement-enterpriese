import { PageHeader } from '@nexusbi/ui-components';
import { UserManager } from '@/components/admin/UserManager';

export default function UsersPage() {
  return (
    <div>
      <PageHeader
        title="User Management"
        description="Create and manage user accounts with role assignments."
        breadcrumbs={[
          { label: 'Admin', href: '/admin' },
          { label: 'Users' },
        ]}
      />
      <UserManager />
    </div>
  );
}

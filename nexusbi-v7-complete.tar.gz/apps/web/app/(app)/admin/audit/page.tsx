'use client';

import { useEffect, useState, useCallback } from 'react';
import { PageHeader, DataTable } from '@nexusbi/ui-components';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Search, RefreshCw } from 'lucide-react';
import type { ColumnDef } from '@tanstack/react-table';
import type { AuditLogEntry } from '@nexusbi/shared-types';

export default function AuditLogPage() {
  const [logs, setLogs] = useState<AuditLogEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);

  const [filterAction, setFilterAction] = useState('');
  const [filterResourceType, setFilterResourceType] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');

  const fetchLogs = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams();
      params.set('page', String(page));
      params.set('pageSize', '50');
      if (filterAction) params.set('action', filterAction);
      if (filterResourceType) params.set('resourceType', filterResourceType);
      if (startDate) params.set('startDate', new Date(startDate).toISOString());
      if (endDate) params.set('endDate', new Date(endDate).toISOString());

      const response = await fetch(`/api/admin/audit?${params.toString()}`);
      const data = await response.json();
      if (data.success) {
        setLogs(data.data || []);
        setTotal(data.meta?.total || 0);
      }
    } catch { /* handle */ }
    setLoading(false);
  }, [page, filterAction, filterResourceType, startDate, endDate]);

  useEffect(() => { fetchLogs(); }, [fetchLogs]);

  const columns: ColumnDef<AuditLogEntry>[] = [
    { accessorKey: 'createdAt', header: 'Time', cell: ({ row }) => (
      <span className="text-xs whitespace-nowrap">{new Date(row.original.createdAt).toLocaleString()}</span>
    )},
    { accessorKey: 'userName', header: 'User', cell: ({ row }) => (
      <span className="text-sm font-medium">{row.original.userName || row.original.userId.substring(0, 8)}</span>
    )},
    { accessorKey: 'action', header: 'Action', cell: ({ row }) => (
      <Badge variant="outline" className="text-xs font-mono">{row.original.action}</Badge>
    )},
    { accessorKey: 'resourceType', header: 'Resource', cell: ({ row }) => (
      <span className="text-xs">{row.original.resourceType || '—'}</span>
    )},
    { accessorKey: 'resourceId', header: 'Resource ID', cell: ({ row }) => (
      <span className="font-mono text-xs truncate max-w-24 block">{row.original.resourceId?.substring(0, 12) || '—'}</span>
    )},
    { accessorKey: 'responseStatus', header: 'Status', cell: ({ row }) => {
      const status = row.original.responseStatus;
      if (!status) return <span className="text-xs text-muted-foreground">—</span>;
      return (
        <Badge variant={status >= 200 && status < 300 ? 'default' : status >= 400 ? 'destructive' : 'secondary'} className="text-xs">
          {status}
        </Badge>
      );
    }},
    { accessorKey: 'durationMs', header: 'Duration', cell: ({ row }) => (
      <span className="text-xs text-muted-foreground">{row.original.durationMs ? `${row.original.durationMs}ms` : '—'}</span>
    )},
    { accessorKey: 'ipAddress', header: 'IP', cell: ({ row }) => (
      <span className="font-mono text-xs">{row.original.ipAddress || '—'}</span>
    )},
  ];

  return (
    <div>
      <PageHeader
        title="Audit Log"
        description={`${total.toLocaleString()} events recorded.`}
        breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: 'Audit Log' }]}
        actions={
          <Button variant="outline" size="sm" onClick={fetchLogs}>
            <RefreshCw className="h-3.5 w-3.5 mr-1" />Refresh
          </Button>
        }
      />

      <div className="flex flex-wrap items-end gap-3 mb-4">
        <div className="space-y-1">
          <Label className="text-xs">Action</Label>
          <Input placeholder="e.g. dashboard.create" value={filterAction} onChange={(e) => setFilterAction(e.target.value)} className="w-44 h-8 text-sm" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Resource Type</Label>
          <Select value={filterResourceType} onValueChange={setFilterResourceType}>
            <SelectTrigger className="w-36 h-8 text-sm"><SelectValue placeholder="All" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="">All</SelectItem>
              <SelectItem value="datasource">Datasource</SelectItem>
              <SelectItem value="dashboard">Dashboard</SelectItem>
              <SelectItem value="schema">Schema</SelectItem>
              <SelectItem value="user">User</SelectItem>
              <SelectItem value="role">Role</SelectItem>
              <SelectItem value="template">Template</SelectItem>
              <SelectItem value="webhook_endpoint">Webhook</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <div className="space-y-1">
          <Label className="text-xs">Start Date</Label>
          <Input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} className="w-36 h-8 text-sm" />
        </div>
        <div className="space-y-1">
          <Label className="text-xs">End Date</Label>
          <Input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} className="w-36 h-8 text-sm" />
        </div>
      </div>

      {loading ? (
        <div className="space-y-2">{Array.from({ length: 10 }).map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
      ) : (
        <DataTable columns={columns} data={logs} showSearch={false} pageSize={50} emptyMessage="No audit log entries match your filters." />
      )}
    </div>
  );
}

import type { ReactNode } from 'react';

export default function AuthLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-br from-nexus-950 via-nexus-900 to-nexus-800">
      <div className="w-full max-w-md px-4">
        {children}
      </div>
    </div>
  );
}

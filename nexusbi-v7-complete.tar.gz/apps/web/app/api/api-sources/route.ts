export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { encryptJson } from '@/lib/encryption';
import type { ApiResponse, ApiSource, ApiSourceCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'datasource.view');
  if (denied) return denied;

  try {
    const sources = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT SOURCE_ID, SOURCE_NAME, API_TYPE, BASE_URL,
                REQUEST_CONFIG, RESPONSE_MAPPING, POLL_CRON,
                STAGING_TABLE, LAST_POLLED_AT, LAST_POLL_STATUS,
                LAST_ROW_COUNT, DS_ID, TENANT_ID, CREATED_BY,
                CREATED_AT, UPDATED_AT, IS_ACTIVE
         FROM NB_API_SOURCES
         WHERE TENANT_ID = :tenantId AND IS_ACTIVE = 1
         ORDER BY SOURCE_NAME`,
        { tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      const list: ApiSource[] = [];
      for (const row of result.rows || []) {
        list.push({
          sourceId: row.SOURCE_ID as string,
          sourceName: row.SOURCE_NAME as string,
          apiType: row.API_TYPE as ApiSource['apiType'],
          baseUrl: row.BASE_URL as string,
          authConfig: null, // Never expose auth config
          requestConfig: parseJsonClob(await clobToString(row.REQUEST_CONFIG)),
          responseMapping: parseJsonClob(await clobToString(row.RESPONSE_MAPPING)),
          pollCron: row.POLL_CRON as string | null,
          stagingTable: row.STAGING_TABLE as string | null,
          lastPolledAt: row.LAST_POLLED_AT ? String(row.LAST_POLLED_AT) : null,
          lastPollStatus: row.LAST_POLL_STATUS as string | null,
          lastRowCount: row.LAST_ROW_COUNT as number | null,
          dsId: row.DS_ID as string | null,
          tenantId: row.TENANT_ID as string,
          createdBy: row.CREATED_BY as string,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
          isActive: (row.IS_ACTIVE as number) === 1,
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<ApiSource[]>>({
      success: true,
      data: sources,
    });
  } catch (error) {
    console.error('GET /api/api-sources error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'api_source.create', resourceType: 'api_source' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'api.source.create');
    if (denied) return denied;

    let body: ApiSourceCreateInput;
    try {
      body = await request.json() as ApiSourceCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.sourceName || !body.apiType || !body.baseUrl) {
      return invalidInputResponse('sourceName, apiType, and baseUrl are required');
    }

    try {
      const sourceId = generateId();
      const authConfigEncrypted = body.authConfig
        ? encryptJson(body.authConfig as unknown as Record<string, unknown>)
        : null;

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_API_SOURCES
             (SOURCE_ID, SOURCE_NAME, API_TYPE, BASE_URL, AUTH_CONFIG,
              REQUEST_CONFIG, RESPONSE_MAPPING, POLL_CRON,
              TENANT_ID, CREATED_BY, CREATED_AT, UPDATED_AT, IS_ACTIVE)
           VALUES
             (:sourceId, :sourceName, :apiType, :baseUrl, :authConfig,
              :requestConfig, :responseMapping, :pollCron,
              :tenantId, :createdBy, SYSTIMESTAMP, SYSTIMESTAMP, 1)`,
          {
            sourceId,
            sourceName: body.sourceName,
            apiType: body.apiType,
            baseUrl: body.baseUrl,
            authConfig: authConfigEncrypted,
            requestConfig: body.requestConfig ? JSON.stringify(body.requestConfig) : null,
            responseMapping: body.responseMapping ? JSON.stringify(body.responseMapping) : null,
            pollCron: body.pollCron ?? null,
            tenantId: user.tenantId,
            createdBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ sourceId: string }>>(
        { success: true, data: { sourceId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/api-sources error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

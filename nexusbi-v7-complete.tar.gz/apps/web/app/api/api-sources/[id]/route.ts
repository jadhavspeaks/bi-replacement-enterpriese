export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { encryptJson } from '@/lib/encryption';
import type { ApiResponse, ApiSource, ApiSourceUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'datasource.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const source = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT SOURCE_ID, SOURCE_NAME, API_TYPE, BASE_URL,
                REQUEST_CONFIG, RESPONSE_MAPPING, POLL_CRON,
                STAGING_TABLE, LAST_POLLED_AT, LAST_POLL_STATUS,
                LAST_ROW_COUNT, DS_ID, TENANT_ID, CREATED_BY,
                CREATED_AT, UPDATED_AT, IS_ACTIVE
         FROM NB_API_SOURCES
         WHERE SOURCE_ID = :sourceId AND TENANT_ID = :tenantId`,
        { sourceId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        sourceId: row.SOURCE_ID as string,
        sourceName: row.SOURCE_NAME as string,
        apiType: row.API_TYPE as ApiSource['apiType'],
        baseUrl: row.BASE_URL as string,
        authConfig: null,
        requestConfig: parseJsonClob(await clobToString(row.REQUEST_CONFIG)),
        responseMapping: parseJsonClob(await clobToString(row.RESPONSE_MAPPING)),
        pollCron: row.POLL_CRON as string | null,
        stagingTable: row.STAGING_TABLE as string | null,
        lastPolledAt: row.LAST_POLLED_AT ? String(row.LAST_POLLED_AT) : null,
        lastPollStatus: row.LAST_POLL_STATUS as string | null,
        lastRowCount: row.LAST_ROW_COUNT as number | null,
        dsId: row.DS_ID as string | null,
        tenantId: row.TENANT_ID as string,
        createdBy: row.CREATED_BY as string,
        createdAt: String(row.CREATED_AT),
        updatedAt: String(row.UPDATED_AT),
        isActive: (row.IS_ACTIVE as number) === 1,
      } as ApiSource;
    });

    if (!source) return notFoundResponse('API source not found');

    return NextResponse.json<ApiResponse<ApiSource>>({ success: true, data: source });
  } catch (error) {
    console.error('GET /api/api-sources/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'api_source.update', resourceType: 'api_source', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'api.source.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: ApiSourceUpdateInput;
    try {
      body = await request.json() as ApiSourceUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ SOURCE_ID: string }>(
          `SELECT SOURCE_ID FROM NB_API_SOURCES
           WHERE SOURCE_ID = :sourceId AND TENANT_ID = :tenantId`,
          { sourceId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('API source not found');

      await withTransaction(async (conn) => {
        const setClauses: string[] = ['UPDATED_AT = SYSTIMESTAMP'];
        const binds: Record<string, unknown> = { sourceId: id, tenantId: user.tenantId };

        if (body.sourceName !== undefined) {
          setClauses.push('SOURCE_NAME = :sourceName');
          binds.sourceName = body.sourceName;
        }
        if (body.baseUrl !== undefined) {
          setClauses.push('BASE_URL = :baseUrl');
          binds.baseUrl = body.baseUrl;
        }
        if (body.authConfig !== undefined) {
          setClauses.push('AUTH_CONFIG = :authConfig');
          binds.authConfig = encryptJson(body.authConfig as unknown as Record<string, unknown>);
        }
        if (body.requestConfig !== undefined) {
          setClauses.push('REQUEST_CONFIG = :requestConfig');
          binds.requestConfig = JSON.stringify(body.requestConfig);
        }
        if (body.responseMapping !== undefined) {
          setClauses.push('RESPONSE_MAPPING = :responseMapping');
          binds.responseMapping = JSON.stringify(body.responseMapping);
        }
        if (body.pollCron !== undefined) {
          setClauses.push('POLL_CRON = :pollCron');
          binds.pollCron = body.pollCron;
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }

        await conn.execute(
          `UPDATE NB_API_SOURCES SET ${setClauses.join(', ')}
           WHERE SOURCE_ID = :sourceId AND TENANT_ID = :tenantId`,
          binds,
        );
      });

      return NextResponse.json<ApiResponse<{ sourceId: string }>>({
        success: true,
        data: { sourceId: id },
      });
    } catch (error) {
      console.error('PUT /api/api-sources/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'api_source.delete', resourceType: 'api_source', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'api.source.delete');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `UPDATE NB_API_SOURCES
           SET IS_ACTIVE = 0, UPDATED_AT = SYSTIMESTAMP
           WHERE SOURCE_ID = :sourceId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
          { sourceId: id, tenantId: user.tenantId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('API source not found');

      return NextResponse.json<ApiResponse<{ sourceId: string }>>({
        success: true,
        data: { sourceId: id },
      });
    } catch (error) {
      console.error('DELETE /api/api-sources/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { withConnection, clobToString } from '@/lib/oracle-pool';

export async function GET(): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const user = session.user;

  try {
    const rows = await withConnection(async (conn) => {
      const result = await conn.execute<{
        CUBE_NAME: string;
        DS_ID: string;
        SCHEMA_JSON: string;
      }>(
        `SELECT CUBE_NAME, DS_ID, SCHEMA_JSON
           FROM NB_CUBE_SCHEMAS
          WHERE TENANT_ID = :tenantId AND IS_ACTIVE = 1
          ORDER BY CUBE_NAME`,
        { tenantId: user.tenantId },
        { outFormat: 4002 },
      );
      return result.rows || [];
    });

    const cubes = await Promise.all(
      rows.map(async (row) => {
        const schemaJson = await clobToString(row.SCHEMA_JSON);
        let parsed: {
          measures?: Record<string, { sql: string; type: string; title?: string; description?: string }>;
          dimensions?: Record<string, { sql: string; type: string; title?: string; description?: string }>;
        } = {};
        try {
          parsed = JSON.parse(schemaJson);
        } catch {
          parsed = {};
        }

        const measures = Object.entries(parsed.measures || {}).map(([name, def]) => ({
          name: `${row.CUBE_NAME}.${name}`,
          shortTitle: name,
          title: def.title || name,
          type: def.type,
          description: def.description,
        }));
        const dimensions = Object.entries(parsed.dimensions || {}).map(([name, def]) => ({
          name: `${row.CUBE_NAME}.${name}`,
          shortTitle: name,
          title: def.title || name,
          type: def.type,
          description: def.description,
        }));

        return {
          name: row.CUBE_NAME,
          title: row.CUBE_NAME,
          measures,
          dimensions,
        };
      }),
    );

    return NextResponse.json({ cubes });
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

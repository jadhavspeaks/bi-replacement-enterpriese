export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { executeQuery, type Query } from '@/lib/query-engine';

interface RequestBody {
  query: Query;
  cubeName?: string;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }
  const user = session.user;

  let body: RequestBody;
  try {
    body = (await request.json()) as RequestBody;
  } catch {
    return NextResponse.json({ error: 'Invalid JSON body' }, { status: 400 });
  }

  // Infer cube name from the first measure/dimension if not supplied.
  // Members are namespaced like "CubeName.memberName".
  let cubeName = body.cubeName;
  if (!cubeName) {
    const firstRef = (body.query.measures || [])[0] || (body.query.dimensions || [])[0];
    if (firstRef && firstRef.includes('.')) cubeName = firstRef.split('.')[0];
  }
  if (!cubeName) {
    return NextResponse.json({ error: 'cubeName is required' }, { status: 400 });
  }

  try {
    const result = await executeQuery(user.tenantId, cubeName, body.query);
    return NextResponse.json(result);
  } catch (err) {
    const message = err instanceof Error ? err.message : 'Unknown error';
    return NextResponse.json({ error: message }, { status: 500 });
  }
}

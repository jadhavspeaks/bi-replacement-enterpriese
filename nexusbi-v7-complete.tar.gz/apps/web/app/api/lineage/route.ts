export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, internalErrorResponse } from '@/lib/rbac-middleware';
import { buildLineageGraph } from '@/lib/lineage';
import type { ApiResponse, LineageGraph } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'lineage.view');
  if (denied) return denied;

  try {
    const graph = await buildLineageGraph(session.user.tenantId);

    return NextResponse.json<ApiResponse<LineageGraph>>({
      success: true,
      data: graph,
    });
  } catch (error) {
    console.error('GET /api/lineage error:', error);
    return internalErrorResponse();
  }
}

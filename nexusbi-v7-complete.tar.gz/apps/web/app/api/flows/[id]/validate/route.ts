import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { validateNode } from '@/lib/flow-node-executors';

const Schema = z.object({ nodes: z.array(z.any()) });

export const POST = withAudit(
  (_, params) => ({ action: 'flow.validate', resourceType: 'flow', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'flow.view');
    const body = Schema.parse(await request.json());
    const results = body.nodes.map((n: any) => ({ nodeId: n.id, ...validateNode(n, []) }));
    return NextResponse.json({
      overallValid: results.every((r) => r.valid),
      results,
    });
  },
);

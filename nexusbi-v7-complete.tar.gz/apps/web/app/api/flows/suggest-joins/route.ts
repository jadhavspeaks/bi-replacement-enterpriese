import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { suggestJoins } from '@/lib/join-recommender';

const Schema = z.object({
  leftTable: z.string().min(1).max(128),
  rightTable: z.string().min(1).max(128),
  sampleSize: z.number().int().min(50).max(5000).optional(),
});

export const POST = withAudit(
  () => ({ action: 'flow.suggest_joins', resourceType: 'flow' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'flow.view');
    const body = Schema.parse(await request.json());
    const suggestions = await suggestJoins(body.leftTable, body.rightTable, body.sampleSize);
    return NextResponse.json({ suggestions });
  },
);

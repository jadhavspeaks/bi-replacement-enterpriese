import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';

const UpdateSchema = z.object({
  content: z.string().min(1).max(10_000).optional(),
  resolved: z.boolean().optional(),
});

export const PATCH = withAudit(
  (_, params) => ({ action: 'comment.update', resourceType: 'comment', resourceId: params.id }),
  async (request, { params }, user) => {
    const body = UpdateSchema.parse(await request.json());
    const row = await withConnection(async (conn) => {
      const r = await conn.execute<{ USER_ID: string }>(
        `SELECT USER_ID FROM NB_WIDGET_COMMENTS WHERE COMMENT_ID = :id`,
        { id: params.id }, { outFormat: 4002 },
      );
      return r.rows?.[0];
    });
    if (!row) return NextResponse.json({ error: 'Not found' }, { status: 404 });

    const isAuthor = row.USER_ID === user.userId;
    if (body.content !== undefined && !isAuthor) {
      return NextResponse.json({ error: 'Only the author can edit content' }, { status: 403 });
    }
    if (body.resolved !== undefined) await requireAuthAndPermission(user, 'comment.resolve');

    await withConnection(async (conn) => {
      const sets: string[] = [];
      const binds: Record<string, unknown> = { id: params.id };
      if (body.content !== undefined) { sets.push('CONTENT = :c'); binds.c = body.content; }
      if (body.resolved !== undefined) { sets.push('RESOLVED = :r'); binds.r = body.resolved ? 1 : 0; }
      sets.push('UPDATED_AT = SYSTIMESTAMP');
      await conn.execute(
        `UPDATE NB_WIDGET_COMMENTS SET ${sets.join(', ')} WHERE COMMENT_ID = :id`,
        binds,
      );
      await conn.commit();
    });

    return NextResponse.json({ ok: true });
  },
);

export const DELETE = withAudit(
  (_, params) => ({ action: 'comment.delete', resourceType: 'comment', resourceId: params.id }),
  async (request, { params }, user) => {
    const row = await withConnection(async (conn) => {
      const r = await conn.execute<{ USER_ID: string }>(
        `SELECT USER_ID FROM NB_WIDGET_COMMENTS WHERE COMMENT_ID = :id`,
        { id: params.id }, { outFormat: 4002 },
      );
      return r.rows?.[0];
    });
    if (!row) return NextResponse.json({ error: 'Not found' }, { status: 404 });
    if (row.USER_ID !== user.userId && !user.permissions.includes('comment.resolve')) {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }
    await withConnection(async (conn) => {
      await conn.execute(`DELETE FROM NB_WIDGET_COMMENTS WHERE COMMENT_ID = :id`, { id: params.id });
      await conn.commit();
    });
    return NextResponse.json({ ok: true });
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { deliverWebhook } from '@/lib/webhook-out';
import type { ApiResponse, WebhookEndpoint } from '@nexusbi/shared-types';

const INTERNAL_API_SECRET = process.env.INTERNAL_API_SECRET || '';

export async function POST(request: NextRequest): Promise<NextResponse> {
  const secret = request.headers.get('x-internal-secret');
  if (secret !== INTERNAL_API_SECRET || INTERNAL_API_SECRET.length === 0) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Invalid internal secret' } },
      { status: 403 },
    );
  }

  let body: {
    endpointId: string;
    event: string;
    data: Record<string, unknown>;
    tenantId: string;
  };

  try {
    body = await request.json() as typeof body;
  } catch {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INVALID_INPUT', message: 'Invalid JSON body' } },
      { status: 400 },
    );
  }

  if (!body.endpointId || !body.event || !body.tenantId) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INVALID_INPUT', message: 'endpointId, event, and tenantId are required' } },
      { status: 400 },
    );
  }

  try {
    const endpoint = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT ENDPOINT_ID, ENDPOINT_NAME, URL, SECRET_HASH,
                TRIGGER_TYPE, TRIGGER_CONFIG, IS_ACTIVE,
                TENANT_ID, CREATED_BY, CREATED_AT
         FROM NB_WEBHOOK_ENDPOINTS
         WHERE ENDPOINT_ID = :endpointId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
        { endpointId: body.endpointId, tenantId: body.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        endpointId: row.ENDPOINT_ID as string,
        endpointName: row.ENDPOINT_NAME as string,
        url: row.URL as string,
        secretHash: row.SECRET_HASH as string,
        triggerType: row.TRIGGER_TYPE as WebhookEndpoint['triggerType'],
        triggerConfig: parseJsonClob(await clobToString(row.TRIGGER_CONFIG)),
        isActive: true,
        tenantId: row.TENANT_ID as string,
        createdBy: row.CREATED_BY as string,
        createdAt: String(row.CREATED_AT),
      } as WebhookEndpoint;
    });

    if (!endpoint) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { code: 'NOT_FOUND', message: 'Endpoint not found or inactive' } },
        { status: 404 },
      );
    }

    const deliveryLog = await deliverWebhook(
      endpoint,
      body.event,
      body.data,
      body.tenantId,
    );

    return NextResponse.json<ApiResponse<typeof deliveryLog>>({
      success: true,
      data: deliveryLog,
    });
  } catch (error) {
    console.error('POST /api/internal/webhook-deliver error:', error);
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INTERNAL_ERROR', message: 'Webhook delivery failed' } },
      { status: 500 },
    );
  }
}

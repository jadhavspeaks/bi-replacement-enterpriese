export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction } from '@/lib/oracle-pool';
import { hashPassword, validatePasswordStrength } from '@/lib/password';
import { invalidateAllPermissionCaches } from '@/lib/rbac';
import type { ApiResponse } from '@nexusbi/shared-types';

interface UserDetail {
  userId: string;
  email: string;
  username: string;
  displayName: string | null;
  tenantId: string;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  updatedAt: string;
  roles: Array<{ roleId: string; roleName: string; assignedAt: string }>;
}

interface UserUpdateInput {
  email?: string;
  displayName?: string;
  isActive?: boolean;
  password?: string;
  roleIds?: string[];
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'admin.users');
  if (denied) return denied;

  const { id } = await params;

  try {
    const user = await withConnection(async (conn) => {
      const result = await conn.execute<{
        USER_ID: string;
        EMAIL: string;
        USERNAME: string;
        DISPLAY_NAME: string | null;
        TENANT_ID: string;
        IS_ACTIVE: number;
        LAST_LOGIN_AT: string | null;
        CREATED_AT: string;
        UPDATED_AT: string;
      }>(
        `SELECT USER_ID, EMAIL, USERNAME, DISPLAY_NAME, TENANT_ID,
                IS_ACTIVE, LAST_LOGIN_AT, CREATED_AT, UPDATED_AT
         FROM NB_USERS
         WHERE USER_ID = :userId AND TENANT_ID = :tenantId`,
        { userId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      const rolesResult = await conn.execute<{
        ROLE_ID: string;
        ROLE_NAME: string;
        ASSIGNED_AT: string;
      }>(
        `SELECT R.ROLE_ID, R.ROLE_NAME, UR.ASSIGNED_AT
         FROM NB_USER_ROLES UR
         JOIN NB_ROLES R ON R.ROLE_ID = UR.ROLE_ID
         WHERE UR.USER_ID = :userId AND UR.TENANT_ID = :tenantId
         ORDER BY R.ROLE_NAME`,
        { userId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      return {
        userId: row.USER_ID,
        email: row.EMAIL,
        username: row.USERNAME,
        displayName: row.DISPLAY_NAME,
        tenantId: row.TENANT_ID,
        isActive: row.IS_ACTIVE === 1,
        lastLoginAt: row.LAST_LOGIN_AT ? String(row.LAST_LOGIN_AT) : null,
        createdAt: String(row.CREATED_AT),
        updatedAt: String(row.UPDATED_AT),
        roles: (rolesResult.rows || []).map((r) => ({
          roleId: r.ROLE_ID,
          roleName: r.ROLE_NAME,
          assignedAt: String(r.ASSIGNED_AT),
        })),
      } as UserDetail;
    });

    if (!user) return notFoundResponse('User not found');

    return NextResponse.json<ApiResponse<UserDetail>>({ success: true, data: user });
  } catch (error) {
    console.error('GET /api/admin/users/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'user.update', resourceType: 'user', resourceId: p.id }),
  async (request, { params }, adminUser) => {
    const denied = await requirePermission(adminUser, 'admin.users');
    if (denied) return denied;

    const { id } = await params;
    let body: UserUpdateInput;
    try {
      body = await request.json() as UserUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      await withTransaction(async (conn) => {
        const setClauses: string[] = ['UPDATED_AT = SYSTIMESTAMP'];
        const binds: Record<string, unknown> = { userId: id, tenantId: adminUser.tenantId };

        if (body.email !== undefined) {
          setClauses.push('EMAIL = :email');
          binds.email = body.email;
        }
        if (body.displayName !== undefined) {
          setClauses.push('DISPLAY_NAME = :displayName');
          binds.displayName = body.displayName;
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }
        if (body.password !== undefined) {
          const check = validatePasswordStrength(body.password);
          if (!check.valid) {
            throw new Error(`Password validation failed: ${check.errors.join(', ')}`);
          }
          const hash = await hashPassword(body.password);
          setClauses.push('PASSWORD_HASH = :passwordHash');
          binds.passwordHash = hash;
        }

        await conn.execute(
          `UPDATE NB_USERS SET ${setClauses.join(', ')}
           WHERE USER_ID = :userId AND TENANT_ID = :tenantId`,
          binds,
        );

        // Replace roles if provided
        if (body.roleIds !== undefined) {
          await conn.execute(
            `DELETE FROM NB_USER_ROLES WHERE USER_ID = :userId AND TENANT_ID = :tenantId`,
            { userId: id, tenantId: adminUser.tenantId },
          );

          for (const roleId of body.roleIds) {
            await conn.execute(
              `INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, TENANT_ID, ASSIGNED_AT, ASSIGNED_BY)
               VALUES (:userId, :roleId, :tenantId, SYSTIMESTAMP, :assignedBy)`,
              { userId: id, roleId, tenantId: adminUser.tenantId, assignedBy: adminUser.id },
            );
          }

          await invalidateAllPermissionCaches(adminUser.tenantId);
        }
      });

      return NextResponse.json<ApiResponse<{ userId: string }>>({
        success: true,
        data: { userId: id },
      });
    } catch (error) {
      if (error instanceof Error && error.message.startsWith('Password validation')) {
        return invalidInputResponse(error.message);
      }
      console.error('PUT /api/admin/users/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'user.deactivate', resourceType: 'user', resourceId: p.id }),
  async (request, { params }, adminUser) => {
    const denied = await requirePermission(adminUser, 'admin.users');
    if (denied) return denied;

    const { id } = await params;

    // Prevent self-deactivation
    if (id === adminUser.id) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { code: 'RBAC_DENIED', message: 'Cannot deactivate your own account' } },
        { status: 403 },
      );
    }

    try {
      const deactivated = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `UPDATE NB_USERS SET IS_ACTIVE = 0, UPDATED_AT = SYSTIMESTAMP
           WHERE USER_ID = :userId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
          { userId: id, tenantId: adminUser.tenantId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deactivated) return notFoundResponse('User not found or already inactive');

      return NextResponse.json<ApiResponse<{ userId: string }>>({
        success: true,
        data: { userId: id },
      });
    } catch (error) {
      console.error('DELETE /api/admin/users/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

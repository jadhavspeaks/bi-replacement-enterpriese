export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { getAllConfigs, setConfigValue } from '@/lib/oracle-config';
import type { ApiResponse } from '@nexusbi/shared-types';
import type { PlatformConfig } from '@/lib/oracle-config';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'admin.platform');
  if (denied) return denied;

  try {
    const configs = await getAllConfigs(true);

    return NextResponse.json<ApiResponse<PlatformConfig[]>>({
      success: true,
      data: configs,
    });
  } catch (error) {
    console.error('GET /api/admin/platform error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  { action: 'platform.config.update', resourceType: 'platform_config' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'admin.platform');
    if (denied) return denied;

    let body: {
      key: string;
      value: string;
      configType?: string;
      description?: string;
      isSecret?: boolean;
    };
    try {
      body = await request.json() as typeof body;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.key || body.value === undefined) {
      return invalidInputResponse('key and value are required');
    }

    try {
      await setConfigValue(body.key, body.value, user.id, {
        configType: body.configType,
        description: body.description,
        isSecret: body.isSecret,
      });

      return NextResponse.json<ApiResponse<{ key: string }>>({
        success: true,
        data: { key: body.key },
      });
    } catch (error) {
      console.error('PUT /api/admin/platform error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

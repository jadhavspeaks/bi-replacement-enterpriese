export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, AuditLogEntry, AuditLogFilter } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'audit.view');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const filters: AuditLogFilter = {
    userId: searchParams.get('userId') ?? undefined,
    action: searchParams.get('action') ?? undefined,
    resourceType: searchParams.get('resourceType') ?? undefined,
    resourceId: searchParams.get('resourceId') ?? undefined,
    startDate: searchParams.get('startDate') ?? undefined,
    endDate: searchParams.get('endDate') ?? undefined,
    page: parseInt(searchParams.get('page') || '1', 10),
    pageSize: parseInt(searchParams.get('pageSize') || '50', 10),
  };

  const pageSize = Math.min(filters.pageSize || 50, 200);
  const offset = ((filters.page || 1) - 1) * pageSize;

  try {
    const result = await withConnection(async (conn) => {
      let whereClauses = ['L.TENANT_ID = :tenantId'];
      const binds: Record<string, unknown> = { tenantId: session.user.tenantId };

      if (filters.userId) {
        whereClauses.push('L.USER_ID = :filterUserId');
        binds.filterUserId = filters.userId;
      }
      if (filters.action) {
        whereClauses.push('L.ACTION = :filterAction');
        binds.filterAction = filters.action;
      }
      if (filters.resourceType) {
        whereClauses.push('L.RESOURCE_TYPE = :filterResourceType');
        binds.filterResourceType = filters.resourceType;
      }
      if (filters.resourceId) {
        whereClauses.push('L.RESOURCE_ID = :filterResourceId');
        binds.filterResourceId = filters.resourceId;
      }
      if (filters.startDate) {
        whereClauses.push("L.CREATED_AT >= TO_TIMESTAMP(:startDate, 'YYYY-MM-DD\"T\"HH24:MI:SS.FF3\"Z\"')");
        binds.startDate = filters.startDate;
      }
      if (filters.endDate) {
        whereClauses.push("L.CREATED_AT <= TO_TIMESTAMP(:endDate, 'YYYY-MM-DD\"T\"HH24:MI:SS.FF3\"Z\"')");
        binds.endDate = filters.endDate;
      }

      const whereStr = whereClauses.join(' AND ');

      // Get total count
      const countResult = await conn.execute<{ CNT: number }>(
        `SELECT COUNT(*) AS CNT FROM NB_AUDIT_LOG L WHERE ${whereStr}`,
        binds,
        { outFormat: 4002 },
      );
      const total = countResult.rows?.[0]?.CNT || 0;

      // Get page
      const dataResult = await conn.execute<{
        LOG_ID: string;
        USER_ID: string;
        TENANT_ID: string | null;
        ACTION: string;
        RESOURCE_TYPE: string | null;
        RESOURCE_ID: string | null;
        REQUEST_PAYLOAD: string;
        RESPONSE_STATUS: number | null;
        IP_ADDRESS: string | null;
        DURATION_MS: number | null;
        CREATED_AT: string;
        DISPLAY_NAME: string | null;
      }>(
        `SELECT L.LOG_ID, L.USER_ID, L.TENANT_ID, L.ACTION,
                L.RESOURCE_TYPE, L.RESOURCE_ID, L.REQUEST_PAYLOAD,
                L.RESPONSE_STATUS, L.IP_ADDRESS, L.DURATION_MS,
                L.CREATED_AT, U.DISPLAY_NAME
         FROM NB_AUDIT_LOG L
         LEFT JOIN NB_USERS U ON U.USER_ID = L.USER_ID
         WHERE ${whereStr}
         ORDER BY L.CREATED_AT DESC
         OFFSET :offset ROWS FETCH NEXT :pageSize ROWS ONLY`,
        { ...binds, offset, pageSize },
        { outFormat: 4002 },
      );

      const entries: AuditLogEntry[] = [];
      for (const row of dataResult.rows || []) {
        entries.push({
          logId: row.LOG_ID,
          userId: row.USER_ID,
          userName: row.DISPLAY_NAME ?? undefined,
          tenantId: row.TENANT_ID,
          action: row.ACTION,
          resourceType: row.RESOURCE_TYPE,
          resourceId: row.RESOURCE_ID,
          requestPayload: parseJsonClob(await clobToString(row.REQUEST_PAYLOAD)),
          responseStatus: row.RESPONSE_STATUS,
          ipAddress: row.IP_ADDRESS,
          durationMs: row.DURATION_MS,
          createdAt: String(row.CREATED_AT),
        });
      }

      return { entries, total };
    });

    return NextResponse.json<ApiResponse<AuditLogEntry[]>>({
      success: true,
      data: result.entries,
      meta: {
        total: result.total,
        page: filters.page || 1,
        pageSize,
      },
    });
  } catch (error) {
    console.error('GET /api/admin/audit error:', error);
    return internalErrorResponse();
  }
}

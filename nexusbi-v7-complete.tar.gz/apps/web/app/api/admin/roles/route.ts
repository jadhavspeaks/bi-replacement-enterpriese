export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import { invalidateAllPermissionCaches } from '@/lib/rbac';
import type { ApiResponse, Role, RoleWithPermissions, Permission } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'admin.roles');
  if (denied) return denied;

  try {
    const roles = await withConnection(async (conn) => {
      const rolesResult = await conn.execute<{
        ROLE_ID: string;
        ROLE_NAME: string;
        ROLE_DESCRIPTION: string | null;
        IS_SYSTEM_ROLE: number;
        CREATED_AT: string;
      }>(
        `SELECT ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE, CREATED_AT
         FROM NB_ROLES ORDER BY ROLE_NAME`,
        {},
        { outFormat: 4002 },
      );

      const list: RoleWithPermissions[] = [];
      for (const role of rolesResult.rows || []) {
        const permsResult = await conn.execute<{
          PERM_ID: string;
          PERM_CODE: string;
          PERM_CATEGORY: string;
          DESCRIPTION: string;
        }>(
          `SELECT P.PERM_ID, P.PERM_CODE, P.PERM_CATEGORY, P.DESCRIPTION
           FROM NB_ROLE_PERMISSIONS RP
           JOIN NB_PERMISSIONS P ON P.PERM_ID = RP.PERM_ID
           WHERE RP.ROLE_ID = :roleId
           ORDER BY P.PERM_CATEGORY, P.PERM_CODE`,
          { roleId: role.ROLE_ID },
          { outFormat: 4002 },
        );

        list.push({
          roleId: role.ROLE_ID,
          roleName: role.ROLE_NAME,
          roleDescription: role.ROLE_DESCRIPTION,
          isSystemRole: role.IS_SYSTEM_ROLE === 1,
          createdAt: String(role.CREATED_AT),
          permissions: (permsResult.rows || []).map((p) => ({
            permId: p.PERM_ID,
            permCode: p.PERM_CODE as Permission['permCode'],
            permCategory: p.PERM_CATEGORY,
            description: p.DESCRIPTION,
          })),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<RoleWithPermissions[]>>({
      success: true,
      data: roles,
    });
  } catch (error) {
    console.error('GET /api/admin/roles error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'role.create', resourceType: 'role' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'admin.roles');
    if (denied) return denied;

    let body: { roleName: string; roleDescription?: string; permissionIds?: string[] };
    try {
      body = await request.json() as typeof body;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.roleName) {
      return invalidInputResponse('roleName is required');
    }

    try {
      const roleId = generateId();

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE, CREATED_AT)
           VALUES (:roleId, :roleName, :roleDescription, 0, SYSTIMESTAMP)`,
          {
            roleId,
            roleName: body.roleName,
            roleDescription: body.roleDescription ?? null,
          },
        );

        if (body.permissionIds && body.permissionIds.length > 0) {
          for (const permId of body.permissionIds) {
            await conn.execute(
              `INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_AT, GRANTED_BY)
               VALUES (:roleId, :permId, SYSTIMESTAMP, :grantedBy)`,
              { roleId, permId, grantedBy: user.id },
            );
          }
        }
      });

      await invalidateAllPermissionCaches(user.tenantId);

      return NextResponse.json<ApiResponse<{ roleId: string }>>(
        { success: true, data: { roleId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/admin/roles error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { deliverWebhook } from '@/lib/webhook-out';
import type { ApiResponse, WebhookEndpoint, WebhookDeliveryLog } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'webhook.deliver', resourceType: 'webhook_endpoint', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'webhook.manage');
    if (denied) return denied;

    const { id } = await params;

    try {
      const endpoint = await withConnection(async (conn) => {
        const result = await conn.execute<Record<string, unknown>>(
          `SELECT ENDPOINT_ID, ENDPOINT_NAME, URL, SECRET_HASH,
                  TRIGGER_TYPE, TRIGGER_CONFIG, IS_ACTIVE,
                  TENANT_ID, CREATED_BY, CREATED_AT
           FROM NB_WEBHOOK_ENDPOINTS
           WHERE ENDPOINT_ID = :endpointId AND TENANT_ID = :tenantId`,
          { endpointId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );

        if (!result.rows || result.rows.length === 0) return null;
        const row = result.rows[0];

        return {
          endpointId: row.ENDPOINT_ID as string,
          endpointName: row.ENDPOINT_NAME as string,
          url: row.URL as string,
          secretHash: row.SECRET_HASH as string,
          triggerType: row.TRIGGER_TYPE as WebhookEndpoint['triggerType'],
          triggerConfig: parseJsonClob(await clobToString(row.TRIGGER_CONFIG)),
          isActive: (row.IS_ACTIVE as number) === 1,
          tenantId: row.TENANT_ID as string,
          createdBy: row.CREATED_BY as string,
          createdAt: String(row.CREATED_AT),
        } as WebhookEndpoint;
      });

      if (!endpoint) return notFoundResponse('Webhook endpoint not found');

      const deliveryLog = await deliverWebhook(
        endpoint,
        'test',
        {
          message: 'This is a test webhook delivery from NexusBI',
          triggeredBy: user.displayName,
          timestamp: new Date().toISOString(),
        },
        user.tenantId,
      );

      return NextResponse.json<ApiResponse<WebhookDeliveryLog>>({
        success: true,
        data: deliveryLog,
      });
    } catch (error) {
      console.error('POST /api/webhooks/[id]/test error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

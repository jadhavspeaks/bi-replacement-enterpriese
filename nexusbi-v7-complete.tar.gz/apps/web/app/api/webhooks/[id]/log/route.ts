export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { getDeliveryLog } from '@/lib/webhook-out';
import { withConnection } from '@/lib/oracle-pool';
import type { ApiResponse, WebhookDeliveryLog } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'webhook.manage');
  if (denied) return denied;

  const { id } = await params;

  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get('limit') || '50', 10);

  try {
    // Verify endpoint exists in org
    const exists = await withConnection(async (conn) => {
      const result = await conn.execute<{ ENDPOINT_ID: string }>(
        `SELECT ENDPOINT_ID FROM NB_WEBHOOK_ENDPOINTS
         WHERE ENDPOINT_ID = :endpointId AND TENANT_ID = :tenantId`,
        { endpointId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );
      return (result.rows?.length ?? 0) > 0;
    });

    if (!exists) return notFoundResponse('Webhook endpoint not found');

    const logs = await getDeliveryLog(id, session.user.tenantId, Math.min(limit, 200));

    return NextResponse.json<ApiResponse<WebhookDeliveryLog[]>>({
      success: true,
      data: logs,
    });
  } catch (error) {
    console.error('GET /api/webhooks/[id]/log error:', error);
    return internalErrorResponse();
  }
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { hashPassword } from '@/lib/password';
import type { ApiResponse, WebhookEndpoint, WebhookEndpointCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'webhook.manage');
  if (denied) return denied;

  try {
    const endpoints = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT ENDPOINT_ID, ENDPOINT_NAME, URL, TRIGGER_TYPE,
                TRIGGER_CONFIG, IS_ACTIVE, TENANT_ID, CREATED_BY, CREATED_AT
         FROM NB_WEBHOOK_ENDPOINTS
         WHERE TENANT_ID = :tenantId
         ORDER BY ENDPOINT_NAME`,
        { tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      const list: Omit<WebhookEndpoint, 'secretHash'>[] = [];
      for (const row of result.rows || []) {
        list.push({
          endpointId: row.ENDPOINT_ID as string,
          endpointName: row.ENDPOINT_NAME as string,
          url: row.URL as string,
          secretHash: '********',
          triggerType: row.TRIGGER_TYPE as WebhookEndpoint['triggerType'],
          triggerConfig: parseJsonClob(await clobToString(row.TRIGGER_CONFIG)),
          isActive: (row.IS_ACTIVE as number) === 1,
          tenantId: row.TENANT_ID as string,
          createdBy: row.CREATED_BY as string,
          createdAt: String(row.CREATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<typeof endpoints>>({ success: true, data: endpoints });
  } catch (error) {
    console.error('GET /api/webhooks error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'webhook_endpoint.create', resourceType: 'webhook_endpoint' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'webhook.manage');
    if (denied) return denied;

    let body: WebhookEndpointCreateInput;
    try {
      body = await request.json() as WebhookEndpointCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.endpointName || !body.url || !body.secret || !body.triggerType) {
      return invalidInputResponse('endpointName, url, secret, and triggerType are required');
    }

    try {
      const endpointId = generateId();
      const secretHash = await hashPassword(body.secret);

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_WEBHOOK_ENDPOINTS
             (ENDPOINT_ID, ENDPOINT_NAME, URL, SECRET_HASH,
              TRIGGER_TYPE, TRIGGER_CONFIG, IS_ACTIVE,
              TENANT_ID, CREATED_BY, CREATED_AT)
           VALUES
             (:endpointId, :endpointName, :url, :secretHash,
              :triggerType, :triggerConfig, 1,
              :tenantId, :createdBy, SYSTIMESTAMP)`,
          {
            endpointId,
            endpointName: body.endpointName,
            url: body.url,
            secretHash,
            triggerType: body.triggerType,
            triggerConfig: body.triggerConfig ? JSON.stringify(body.triggerConfig) : null,
            tenantId: user.tenantId,
            createdBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ endpointId: string }>>(
        { success: true, data: { endpointId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/webhooks error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

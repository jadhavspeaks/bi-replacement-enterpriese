export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, Workbook, WorkbookUpdateInput } from '@nexusbi/shared-types';

async function loadWorkbook(id: string, tenantId: string, userId: string): Promise<Workbook | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<Record<string, unknown>>(
      `SELECT WORKBOOK_ID, WORKBOOK_NAME, DESCRIPTION, OWNER_ID, TENANT_ID, DS_ID,
              TAGS, IS_PUBLISHED, PUBLISHED_DASH_ID, THUMBNAIL_URL, VERSION,
              CREATED_AT, UPDATED_AT
       FROM NB_WORKBOOKS
       WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
      { id, tenantId, userId },
      { outFormat: 4002 },
    );
    if (!result.rows || result.rows.length === 0) return null;
    const row = result.rows[0];
    return {
      workbookId: row.WORKBOOK_ID as string,
      workbookName: row.WORKBOOK_NAME as string,
      description: await clobToString(row.DESCRIPTION) || null,
      ownerId: row.OWNER_ID as string,
      tenantId: row.TENANT_ID as string,
      dsId: (row.DS_ID as string) || null,
      tags: (row.TAGS as string) || null,
      isPublished: (row.IS_PUBLISHED as number) === 1,
      publishedDashId: (row.PUBLISHED_DASH_ID as string) || null,
      thumbnailUrl: (row.THUMBNAIL_URL as string) || null,
      version: row.VERSION as number,
      createdAt: String(row.CREATED_AT),
      updatedAt: String(row.UPDATED_AT),
    };
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { id } = await params;
  try {
    const wb = await loadWorkbook(id, session.user.tenantId, session.user.id);
    if (!wb) return notFoundResponse('Workbook not found');
    return NextResponse.json<ApiResponse<Workbook>>({ success: true, data: wb });
  } catch (error) {
    console.error('GET /api/workbooks/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (_req, p) => ({ action: 'workbook.update', resourceType: 'workbook', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: WorkbookUpdateInput;
    try {
      body = await request.json() as WorkbookUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await loadWorkbook(id, user.tenantId, user.id);
      if (!existing) return notFoundResponse('Workbook not found');

      await withTransaction(async (conn) => {
        const sets: string[] = ['UPDATED_AT = SYSTIMESTAMP', 'VERSION = VERSION + 1'];
        const binds: Record<string, unknown> = { id, tenantId: user.tenantId, userId: user.id };
        if (body.workbookName !== undefined) { sets.push('WORKBOOK_NAME = :name'); binds.name = body.workbookName.trim(); }
        if (body.description !== undefined) { sets.push('DESCRIPTION = :desc'); binds.desc = body.description; }
        if (body.dsId !== undefined) { sets.push('DS_ID = :dsId'); binds.dsId = body.dsId; }
        if (body.tags !== undefined) { sets.push('TAGS = :tags'); binds.tags = body.tags; }
        await conn.execute(
          `UPDATE NB_WORKBOOKS SET ${sets.join(', ')} WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
          binds,
        );
      });

      const updated = await loadWorkbook(id, user.tenantId, user.id);
      return NextResponse.json<ApiResponse<Workbook>>({ success: true, data: updated! });
    } catch (error) {
      console.error('PUT /api/workbooks/[id] error:', error);
      return internalErrorResponse();
    }
  },
);

export const DELETE = withAudit(
  (_req, p) => ({ action: 'workbook.delete', resourceType: 'workbook', resourceId: p.id }),
  async (_request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.delete');
    if (denied) return denied;

    const { id } = await params;
    try {
      const existing = await loadWorkbook(id, user.tenantId, user.id);
      if (!existing) return notFoundResponse('Workbook not found');

      await withConnection(async (conn) => {
        await conn.execute(
          `DELETE FROM NB_WORKBOOKS WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
          { id, tenantId: user.tenantId, userId: user.id },
        );
        await conn.commit();
      });

      return NextResponse.json<ApiResponse<{ deleted: boolean }>>({ success: true, data: { deleted: true } });
    } catch (error) {
      console.error('DELETE /api/workbooks/[id] error:', error);
      return internalErrorResponse();
    }
  },
);

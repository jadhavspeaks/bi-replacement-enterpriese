import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { parseLOD } from '@/lib/lod-parser';
import { generateId } from '@nexusbi/shared-types';

const CreateSchema = z.object({
  fieldName: z.string().min(1).max(200),
  lodExpression: z.string().min(1),
  description: z.string().optional(),
});

export const POST = withAudit(
  (_, params) => ({ action: 'lod.create', resourceType: 'workbook', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'workbook.edit');
    const body = CreateSchema.parse(await request.json());
    const parsed = parseLOD(body.lodExpression, body.fieldName);
    if (parsed.errors.length > 0) {
      return NextResponse.json({ errors: parsed.errors, raw: parsed.raw }, { status: 422 });
    }

    const calcId = generateId('CF');
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_CALCULATED_FIELDS (CALC_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION,
          FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID, VALIDATION_ERROR,
          LOD_TYPE, LOD_DIMENSIONS, LOD_AGGREGATION, LOD_FILTER)
         VALUES (:id, :wb, :n, :e, 'measure', 'number', :desc, 1, NULL,
           :lt, :ld, :la, :lf)`,
        {
          id: calcId, wb: params.id, n: body.fieldName, e: body.lodExpression,
          desc: body.description ?? null,
          lt: parsed.expr.type, ld: JSON.stringify(parsed.expr.dimensions),
          la: parsed.expr.aggregation, lf: parsed.expr.filter ?? null,
        },
      );
      await conn.commit();
    });

    return NextResponse.json({ calcId, parsed: parsed.expr }, { status: 201 });
  },
);

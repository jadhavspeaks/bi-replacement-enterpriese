export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, Worksheet, WorksheetShelf } from '@nexusbi/shared-types';

interface PublishResult {
  workbookId: string;
  dashId: string;
  widgetCount: number;
  status: 'DRAFT';
}

export const POST = withAudit(
  (_req, p) => ({ action: 'workbook.publish', resourceType: 'workbook', resourceId: p.id }),
  async (_request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.publish');
    if (denied) return denied;

    const { id } = await params;

    try {
      // Verify workbook ownership and get name
      const workbookInfo = await withConnection(async (conn) => {
        const r = await conn.execute<{ WORKBOOK_NAME: string; DESCRIPTION: unknown; TAGS: string }>(
          `SELECT WORKBOOK_NAME, DESCRIPTION, TAGS FROM NB_WORKBOOKS
           WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
          { id, tenantId: user.tenantId, userId: user.id },
          { outFormat: 4002 },
        );
        if (!r.rows || r.rows.length === 0) return null;
        return {
          name: r.rows[0].WORKBOOK_NAME,
          description: await clobToString(r.rows[0].DESCRIPTION) || '',
          tags: r.rows[0].TAGS || '',
        };
      });

      if (!workbookInfo) return notFoundResponse('Workbook not found');

      // Load all worksheets
      const sheets = await withConnection(async (conn) => {
        const r = await conn.execute<Record<string, unknown>>(
          `SELECT WORKSHEET_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME
           FROM NB_WORKSHEETS WHERE WORKBOOK_ID = :id ORDER BY SORT_ORDER`,
          { id }, { outFormat: 4002 },
        );
        const list: Array<{ id: string; name: string; chartType: string; shelves: WorksheetShelf; cube: string | null }> = [];
        for (const row of r.rows || []) {
          list.push({
            id: row.WORKSHEET_ID as string,
            name: row.WORKSHEET_NAME as string,
            chartType: row.CHART_TYPE as string,
            shelves: parseJsonClob(await clobToString(row.SHELVES_JSON)) as WorksheetShelf,
            cube: (row.CUBE_NAME as string) || null,
          });
        }
        return list;
      });

      if (sheets.length === 0) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'INVALID_INPUT', message: 'Workbook has no worksheets to publish' } },
          { status: 422 },
        );
      }

      // Build dashboard widgets layout: 2 columns, 3 rows of 4 grid units each
      const widgets = sheets.map((s, i) => {
        const col = i % 2;
        const row = Math.floor(i / 2);
        return {
          widgetId: `w_${s.id}`,
          widgetType: s.chartType === 'table' || s.chartType === 'pivot' || s.chartType === 'crosstab' ? 'table' : 'chart',
          title: s.name,
          x: col * 6, y: row * 4, w: 6, h: 4,
          chartType: s.chartType,
          cubeName: s.cube,
          shelves: s.shelves,
        };
      });

      const layout = {
        cols: 12, rowHeight: 40,
        margin: [10, 10], containerPadding: [10, 10],
        compactType: 'vertical',
      };

      const dashId = generateId();

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON,
                                      OWNER_ID, TENANT_ID, VERSION, TAGS, APPROVAL_STATUS, SOURCE)
           VALUES (:dashId, :name, :desc, :layout, :widgets, :owner, :org, 1, :tags, 'DRAFT', 'WORKBOOK')`,
          {
            dashId,
            name: workbookInfo.name,
            desc: workbookInfo.description,
            layout: JSON.stringify(layout),
            widgets: JSON.stringify(widgets),
            owner: user.id,
            org: user.tenantId,
            tags: workbookInfo.tags,
          },
        );

        await conn.execute(
          `INSERT INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
           VALUES (SYS_GUID(), :dashId, 1, :userId, :summary)`,
          { dashId, userId: user.id, summary: `Published from workbook ${id}` },
        );

        await conn.execute(
          `UPDATE NB_WORKBOOKS SET IS_PUBLISHED = 1, PUBLISHED_DASH_ID = :dashId, UPDATED_AT = SYSTIMESTAMP
           WHERE WORKBOOK_ID = :id`,
          { dashId, id },
        );
      });

      const result: PublishResult = {
        workbookId: id, dashId, widgetCount: widgets.length, status: 'DRAFT',
      };

      return NextResponse.json<ApiResponse<PublishResult>>({ success: true, data: result }, { status: 201 });
    } catch (error) {
      console.error('POST /api/workbooks/[id]/publish error:', error);
      return internalErrorResponse();
    }
  },
);

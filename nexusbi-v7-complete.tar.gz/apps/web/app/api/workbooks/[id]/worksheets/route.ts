export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, Worksheet, WorksheetCreateInput, WorksheetShelf } from '@nexusbi/shared-types';

const DEFAULT_SHELVES: WorksheetShelf = {
  columns: [], rows: [], color: null, size: null, label: null,
  detail: [], tooltip: [], filters: [], pages: [],
};

async function workbookOwnedBy(workbookId: string, tenantId: string, userId: string): Promise<boolean> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ CNT: number }>(
      `SELECT COUNT(*) AS CNT FROM NB_WORKBOOKS
       WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
      { id: workbookId, tenantId, userId },
      { outFormat: 4002 },
    );
    return ((r.rows?.[0]?.CNT ?? 0) as number) > 0;
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { id } = await params;
  try {
    if (!(await workbookOwnedBy(id, session.user.tenantId, session.user.id))) {
      return notFoundResponse('Workbook not found');
    }

    const sheets = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE,
                SHELVES_JSON, CUBE_QUERY_JSON, CUBE_NAME, SORT_SPECS_JSON,
                MARK_TYPE, COLOR_PALETTE, AXIS_CONFIG, TOOLTIP_CONFIG,
                REF_LINES_JSON, ANNOTATIONS_JSON, CREATED_AT, UPDATED_AT
         FROM NB_WORKSHEETS WHERE WORKBOOK_ID = :id ORDER BY SORT_ORDER`,
        { id }, { outFormat: 4002 },
      );
      const list: Worksheet[] = [];
      for (const row of result.rows || []) {
        list.push({
          worksheetId: row.WORKSHEET_ID as string,
          workbookId: row.WORKBOOK_ID as string,
          worksheetName: row.WORKSHEET_NAME as string,
          sortOrder: row.SORT_ORDER as number,
          chartType: row.CHART_TYPE as Worksheet['chartType'],
          shelves: (parseJsonClob(await clobToString(row.SHELVES_JSON)) as WorksheetShelf) || DEFAULT_SHELVES,
          cubeQuery: parseJsonClob(await clobToString(row.CUBE_QUERY_JSON)) as Record<string, unknown> | null,
          cubeName: (row.CUBE_NAME as string) || null,
          sortSpecs: (parseJsonClob(await clobToString(row.SORT_SPECS_JSON)) as Worksheet['sortSpecs']) || [],
          markType: (row.MARK_TYPE as string) || null,
          colorPalette: (row.COLOR_PALETTE as string) || null,
          axisConfig: parseJsonClob(await clobToString(row.AXIS_CONFIG)) as Record<string, unknown> | null,
          tooltipConfig: parseJsonClob(await clobToString(row.TOOLTIP_CONFIG)) as Record<string, unknown> | null,
          referenceLines: (parseJsonClob(await clobToString(row.REF_LINES_JSON)) as Worksheet['referenceLines']) || [],
          annotations: (parseJsonClob(await clobToString(row.ANNOTATIONS_JSON)) as Worksheet['annotations']) || [],
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<Worksheet[]>>({ success: true, data: sheets });
  } catch (error) {
    console.error('GET /api/workbooks/[id]/worksheets error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  (_req, p) => ({ action: 'worksheet.create', resourceType: 'workbook', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: WorksheetCreateInput;
    try {
      body = await request.json() as WorksheetCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.worksheetName || !body.chartType) {
      return invalidInputResponse('worksheetName and chartType are required');
    }

    try {
      if (!(await workbookOwnedBy(id, user.tenantId, user.id))) {
        return notFoundResponse('Workbook not found');
      }

      const worksheetId = generateId();
      const shelves: WorksheetShelf = { ...DEFAULT_SHELVES, ...(body.shelves || {}) };

      await withConnection(async (conn) => {
        const orderResult = await conn.execute<{ MX: number }>(
          `SELECT NVL(MAX(SORT_ORDER), -1) AS MX FROM NB_WORKSHEETS WHERE WORKBOOK_ID = :id`,
          { id }, { outFormat: 4002 },
        );
        const newOrder = ((orderResult.rows?.[0]?.MX ?? -1) as number) + 1;

        await conn.execute(
          `INSERT INTO NB_WORKSHEETS (WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME)
           VALUES (:wsId, :wbId, :name, :ord, :ct, :shelves, :cube)`,
          {
            wsId: worksheetId, wbId: id,
            name: body.worksheetName.trim(),
            ord: newOrder, ct: body.chartType,
            shelves: JSON.stringify(shelves),
            cube: body.cubeName || null,
          },
        );
        await conn.commit();
      });

      const created: Worksheet = {
        worksheetId, workbookId: id,
        worksheetName: body.worksheetName.trim(),
        sortOrder: 0, chartType: body.chartType,
        shelves, cubeQuery: null, cubeName: body.cubeName || null,
        sortSpecs: [], markType: null, colorPalette: null,
        axisConfig: null, tooltipConfig: null,
        referenceLines: [], annotations: [],
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<Worksheet>>({ success: true, data: created }, { status: 201 });
    } catch (error) {
      console.error('POST /api/workbooks/[id]/worksheets error:', error);
      return internalErrorResponse();
    }
  },
);

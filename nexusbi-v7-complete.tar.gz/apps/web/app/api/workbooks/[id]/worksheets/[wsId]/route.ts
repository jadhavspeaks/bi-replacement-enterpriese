export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, Worksheet, WorksheetUpdateInput, WorksheetShelf } from '@nexusbi/shared-types';

const DEFAULT_SHELVES: WorksheetShelf = {
  columns: [], rows: [], color: null, size: null, label: null,
  detail: [], tooltip: [], filters: [], pages: [],
};

async function loadSheet(workbookId: string, wsId: string, tenantId: string, userId: string): Promise<Worksheet | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<Record<string, unknown>>(
      `SELECT WS.WORKSHEET_ID, WS.WORKBOOK_ID, WS.WORKSHEET_NAME, WS.SORT_ORDER, WS.CHART_TYPE,
              WS.SHELVES_JSON, WS.CUBE_QUERY_JSON, WS.CUBE_NAME, WS.SORT_SPECS_JSON,
              WS.MARK_TYPE, WS.COLOR_PALETTE, WS.AXIS_CONFIG, WS.TOOLTIP_CONFIG,
              WS.REF_LINES_JSON, WS.ANNOTATIONS_JSON, WS.CREATED_AT, WS.UPDATED_AT
       FROM NB_WORKSHEETS WS
       JOIN NB_WORKBOOKS WB ON WB.WORKBOOK_ID = WS.WORKBOOK_ID
       WHERE WS.WORKSHEET_ID = :wsId AND WS.WORKBOOK_ID = :wbId
         AND WB.TENANT_ID = :tenantId AND WB.OWNER_ID = :userId`,
      { wsId, wbId: workbookId, tenantId, userId },
      { outFormat: 4002 },
    );
    if (!result.rows || result.rows.length === 0) return null;
    const row = result.rows[0];
    return {
      worksheetId: row.WORKSHEET_ID as string,
      workbookId: row.WORKBOOK_ID as string,
      worksheetName: row.WORKSHEET_NAME as string,
      sortOrder: row.SORT_ORDER as number,
      chartType: row.CHART_TYPE as Worksheet['chartType'],
      shelves: (parseJsonClob(await clobToString(row.SHELVES_JSON)) as WorksheetShelf) || DEFAULT_SHELVES,
      cubeQuery: parseJsonClob(await clobToString(row.CUBE_QUERY_JSON)) as Record<string, unknown> | null,
      cubeName: (row.CUBE_NAME as string) || null,
      sortSpecs: (parseJsonClob(await clobToString(row.SORT_SPECS_JSON)) as Worksheet['sortSpecs']) || [],
      markType: (row.MARK_TYPE as string) || null,
      colorPalette: (row.COLOR_PALETTE as string) || null,
      axisConfig: parseJsonClob(await clobToString(row.AXIS_CONFIG)) as Record<string, unknown> | null,
      tooltipConfig: parseJsonClob(await clobToString(row.TOOLTIP_CONFIG)) as Record<string, unknown> | null,
      referenceLines: (parseJsonClob(await clobToString(row.REF_LINES_JSON)) as Worksheet['referenceLines']) || [],
      annotations: (parseJsonClob(await clobToString(row.ANNOTATIONS_JSON)) as Worksheet['annotations']) || [],
      createdAt: String(row.CREATED_AT),
      updatedAt: String(row.UPDATED_AT),
    };
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string; wsId: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { id, wsId } = await params;
  try {
    const sheet = await loadSheet(id, wsId, session.user.tenantId, session.user.id);
    if (!sheet) return notFoundResponse('Worksheet not found');
    return NextResponse.json<ApiResponse<Worksheet>>({ success: true, data: sheet });
  } catch (error) {
    console.error('GET /api/workbooks/[id]/worksheets/[wsId] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (_req, p) => ({ action: 'worksheet.update', resourceType: 'worksheet', resourceId: p.wsId }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id, wsId } = await params;
    let body: WorksheetUpdateInput;
    try {
      body = await request.json() as WorksheetUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await loadSheet(id, wsId, user.tenantId, user.id);
      if (!existing) return notFoundResponse('Worksheet not found');

      await withTransaction(async (conn) => {
        const sets: string[] = ['UPDATED_AT = SYSTIMESTAMP'];
        const binds: Record<string, unknown> = { wsId, wbId: id };
        if (body.worksheetName !== undefined) { sets.push('WORKSHEET_NAME = :name'); binds.name = body.worksheetName.trim(); }
        if (body.sortOrder !== undefined) { sets.push('SORT_ORDER = :ord'); binds.ord = body.sortOrder; }
        if (body.chartType !== undefined) { sets.push('CHART_TYPE = :ct'); binds.ct = body.chartType; }
        if (body.shelves !== undefined) { sets.push('SHELVES_JSON = :shelves'); binds.shelves = JSON.stringify(body.shelves); }
        if (body.cubeQuery !== undefined) { sets.push('CUBE_QUERY_JSON = :cq'); binds.cq = JSON.stringify(body.cubeQuery); }
        if (body.cubeName !== undefined) { sets.push('CUBE_NAME = :cube'); binds.cube = body.cubeName; }
        if (body.sortSpecs !== undefined) { sets.push('SORT_SPECS_JSON = :ss'); binds.ss = JSON.stringify(body.sortSpecs); }
        if (body.markType !== undefined) { sets.push('MARK_TYPE = :mt'); binds.mt = body.markType; }
        if (body.colorPalette !== undefined) { sets.push('COLOR_PALETTE = :cp'); binds.cp = body.colorPalette; }
        if (body.axisConfig !== undefined) { sets.push('AXIS_CONFIG = :ac'); binds.ac = JSON.stringify(body.axisConfig); }
        if (body.tooltipConfig !== undefined) { sets.push('TOOLTIP_CONFIG = :tc'); binds.tc = JSON.stringify(body.tooltipConfig); }
        if (body.referenceLines !== undefined) { sets.push('REF_LINES_JSON = :rl'); binds.rl = JSON.stringify(body.referenceLines); }
        if (body.annotations !== undefined) { sets.push('ANNOTATIONS_JSON = :an'); binds.an = JSON.stringify(body.annotations); }
        await conn.execute(
          `UPDATE NB_WORKSHEETS SET ${sets.join(', ')} WHERE WORKSHEET_ID = :wsId AND WORKBOOK_ID = :wbId`,
          binds,
        );
      });

      const updated = await loadSheet(id, wsId, user.tenantId, user.id);
      return NextResponse.json<ApiResponse<Worksheet>>({ success: true, data: updated! });
    } catch (error) {
      console.error('PUT /api/workbooks/[id]/worksheets/[wsId] error:', error);
      return internalErrorResponse();
    }
  },
);

export const DELETE = withAudit(
  (_req, p) => ({ action: 'worksheet.delete', resourceType: 'worksheet', resourceId: p.wsId }),
  async (_request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id, wsId } = await params;
    try {
      const existing = await loadSheet(id, wsId, user.tenantId, user.id);
      if (!existing) return notFoundResponse('Worksheet not found');

      await withConnection(async (conn) => {
        await conn.execute(
          `DELETE FROM NB_WORKSHEETS WHERE WORKSHEET_ID = :wsId AND WORKBOOK_ID = :wbId`,
          { wsId, wbId: id },
        );
        await conn.commit();
      });

      return NextResponse.json<ApiResponse<{ deleted: boolean }>>({ success: true, data: { deleted: true } });
    } catch (error) {
      console.error('DELETE /api/workbooks/[id]/worksheets/[wsId] error:', error);
      return internalErrorResponse();
    }
  },
);

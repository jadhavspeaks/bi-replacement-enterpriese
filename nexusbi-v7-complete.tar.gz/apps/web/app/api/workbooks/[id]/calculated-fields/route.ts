export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, CalculatedField, CalculatedFieldCreateInput } from '@nexusbi/shared-types';

async function workbookOwnedBy(workbookId: string, tenantId: string, userId: string): Promise<boolean> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ CNT: number }>(
      `SELECT COUNT(*) AS CNT FROM NB_WORKBOOKS
       WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
      { id: workbookId, tenantId, userId },
      { outFormat: 4002 },
    );
    return ((r.rows?.[0]?.CNT ?? 0) as number) > 0;
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { id } = await params;
  try {
    if (!(await workbookOwnedBy(id, session.user.tenantId, session.user.id))) {
      return notFoundResponse('Workbook not found');
    }

    const fields = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE,
                DESCRIPTION, IS_VALID, VALIDATION_ERROR, CREATED_AT, UPDATED_AT
         FROM NB_CALCULATED_FIELDS WHERE WORKBOOK_ID = :id ORDER BY FIELD_NAME`,
        { id }, { outFormat: 4002 },
      );
      const list: CalculatedField[] = [];
      for (const row of result.rows || []) {
        list.push({
          fieldId: row.FIELD_ID as string,
          workbookId: row.WORKBOOK_ID as string,
          fieldName: row.FIELD_NAME as string,
          expression: await clobToString(row.EXPRESSION) || '',
          fieldType: row.FIELD_TYPE as CalculatedField['fieldType'],
          dataType: row.DATA_TYPE as CalculatedField['dataType'],
          description: (row.DESCRIPTION as string) || null,
          isValid: (row.IS_VALID as number) === 1,
          validationError: (row.VALIDATION_ERROR as string) || null,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<CalculatedField[]>>({ success: true, data: fields });
  } catch (error) {
    console.error('GET /api/workbooks/[id]/calculated-fields error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  (_req, p) => ({ action: 'calc_field.create', resourceType: 'workbook', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: CalculatedFieldCreateInput;
    try {
      body = await request.json() as CalculatedFieldCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.fieldName || !body.expression || !body.fieldType || !body.dataType) {
      return invalidInputResponse('fieldName, expression, fieldType, dataType are required');
    }

    try {
      if (!(await workbookOwnedBy(id, user.tenantId, user.id))) {
        return notFoundResponse('Workbook not found');
      }

      const fieldId = generateId();

      await withConnection(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_CALCULATED_FIELDS (FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID)
           VALUES (:fid, :wbId, :name, :expr, :ft, :dt, :desc, 1)`,
          {
            fid: fieldId, wbId: id,
            name: body.fieldName.trim(),
            expr: body.expression.trim(),
            ft: body.fieldType, dt: body.dataType,
            desc: body.description || null,
          },
        );
        await conn.commit();
      });

      const created: CalculatedField = {
        fieldId, workbookId: id,
        fieldName: body.fieldName.trim(),
        expression: body.expression.trim(),
        fieldType: body.fieldType, dataType: body.dataType,
        description: body.description || null,
        isValid: true, validationError: null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<CalculatedField>>({ success: true, data: created }, { status: 201 });
    } catch (error) {
      console.error('POST /api/workbooks/[id]/calculated-fields error:', error);
      return internalErrorResponse();
    }
  },
);

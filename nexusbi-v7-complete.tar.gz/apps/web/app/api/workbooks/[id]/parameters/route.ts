export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, Parameter, ParameterCreateInput } from '@nexusbi/shared-types';

async function workbookOwnedBy(workbookId: string, tenantId: string, userId: string): Promise<boolean> {
  return withConnection(async (conn) => {
    const r = await conn.execute<{ CNT: number }>(
      `SELECT COUNT(*) AS CNT FROM NB_WORKBOOKS
       WHERE WORKBOOK_ID = :id AND TENANT_ID = :tenantId AND OWNER_ID = :userId`,
      { id: workbookId, tenantId, userId },
      { outFormat: 4002 },
    );
    return ((r.rows?.[0]?.CNT ?? 0) as number) > 0;
  });
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { id } = await params;
  try {
    if (!(await workbookOwnedBy(id, session.user.tenantId, session.user.id))) {
      return notFoundResponse('Workbook not found');
    }

    const params_list = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE,
                CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, ALLOWABLE_VALUES,
                RANGE_MIN, RANGE_MAX, RANGE_STEP, CREATED_AT, UPDATED_AT
         FROM NB_PARAMETERS WHERE WORKBOOK_ID = :id ORDER BY PARAMETER_NAME`,
        { id }, { outFormat: 4002 },
      );
      const list: Parameter[] = [];
      for (const row of result.rows || []) {
        list.push({
          parameterId: row.PARAMETER_ID as string,
          workbookId: row.WORKBOOK_ID as string,
          parameterName: row.PARAMETER_NAME as string,
          displayName: row.DISPLAY_NAME as string,
          dataType: row.DATA_TYPE as Parameter['dataType'],
          currentValue: row.CURRENT_VALUE as string,
          defaultValue: row.DEFAULT_VALUE as string,
          allowableType: row.ALLOWABLE_TYPE as Parameter['allowableType'],
          allowableValues: parseJsonClob(await clobToString(row.ALLOWABLE_VALUES)) as string[] | null,
          rangeMin: (row.RANGE_MIN as string) || null,
          rangeMax: (row.RANGE_MAX as string) || null,
          rangeStep: (row.RANGE_STEP as string) || null,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<Parameter[]>>({ success: true, data: params_list });
  } catch (error) {
    console.error('GET /api/workbooks/[id]/parameters error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  (_req, p) => ({ action: 'parameter.create', resourceType: 'workbook', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'workbook.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: ParameterCreateInput;
    try {
      body = await request.json() as ParameterCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.parameterName || !body.displayName || !body.dataType || !body.allowableType || body.defaultValue === undefined) {
      return invalidInputResponse('parameterName, displayName, dataType, allowableType, defaultValue are required');
    }

    try {
      if (!(await workbookOwnedBy(id, user.tenantId, user.id))) {
        return notFoundResponse('Workbook not found');
      }

      const parameterId = generateId();

      await withConnection(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_PARAMETERS (PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE,
                                     CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, ALLOWABLE_VALUES,
                                     RANGE_MIN, RANGE_MAX, RANGE_STEP)
           VALUES (:pid, :wbId, :name, :disp, :dt, :curr, :def, :at, :av, :rmin, :rmax, :rstep)`,
          {
            pid: parameterId, wbId: id,
            name: body.parameterName.trim(),
            disp: body.displayName.trim(),
            dt: body.dataType,
            curr: body.defaultValue,
            def: body.defaultValue,
            at: body.allowableType,
            av: body.allowableValues ? JSON.stringify(body.allowableValues) : null,
            rmin: body.rangeMin || null,
            rmax: body.rangeMax || null,
            rstep: body.rangeStep || null,
          },
        );
        await conn.commit();
      });

      const created: Parameter = {
        parameterId, workbookId: id,
        parameterName: body.parameterName.trim(),
        displayName: body.displayName.trim(),
        dataType: body.dataType,
        currentValue: body.defaultValue,
        defaultValue: body.defaultValue,
        allowableType: body.allowableType,
        allowableValues: body.allowableValues || null,
        rangeMin: body.rangeMin || null,
        rangeMax: body.rangeMax || null,
        rangeStep: body.rangeStep || null,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<Parameter>>({ success: true, data: created }, { status: 201 });
    } catch (error) {
      console.error('POST /api/workbooks/[id]/parameters error:', error);
      return internalErrorResponse();
    }
  },
);

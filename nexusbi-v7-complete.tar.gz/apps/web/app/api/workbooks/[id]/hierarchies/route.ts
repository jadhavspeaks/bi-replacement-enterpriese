import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { generateId } from '@nexusbi/shared-types';

const CreateSchema = z.object({
  hierName: z.string().min(1).max(200),
  levels: z.array(z.string()).min(2).max(10),
});

export const GET = withAudit(
  (_, params) => ({ action: 'hierarchy.list', resourceType: 'workbook', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'hierarchy.manage');
    const rows = await withConnection(async (conn) => {
      const r = await conn.execute<{
        HIER_ID: string; HIER_NAME: string; LEVELS_JSON: string; CREATED_AT: Date;
      }>(
        `SELECT HIER_ID, HIER_NAME, LEVELS_JSON, CREATED_AT FROM NB_HIERARCHIES
         WHERE WORKBOOK_ID = :wb ORDER BY HIER_NAME`,
        { wb: params.id }, { outFormat: 4002 },
      );
      return r.rows ?? [];
    });
    return NextResponse.json({
      hierarchies: rows.map((r) => ({
        hierId: r.HIER_ID, workbookId: params.id, hierName: r.HIER_NAME,
        levels: JSON.parse(r.LEVELS_JSON),
        createdAt: r.CREATED_AT.toISOString(),
      })),
    });
  },
);

export const POST = withAudit(
  (_, params) => ({ action: 'hierarchy.create', resourceType: 'workbook', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'hierarchy.manage');
    const body = CreateSchema.parse(await request.json());
    const hierId = generateId('HIER');
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_HIERARCHIES (HIER_ID, WORKBOOK_ID, HIER_NAME, LEVELS_JSON)
         VALUES (:id, :wb, :n, :lv)`,
        { id: hierId, wb: params.id, n: body.hierName, lv: JSON.stringify(body.levels) },
      );
      await conn.commit();
    });
    return NextResponse.json({ hierId }, { status: 201 });
  },
);

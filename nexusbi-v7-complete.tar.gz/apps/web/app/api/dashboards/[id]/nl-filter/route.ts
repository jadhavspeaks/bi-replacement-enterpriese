export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { parseNLFilter } from '@/lib/nl-filter-parser';
import type { ApiResponse, NLFilterParseResult, NLFilterInput } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'nl_filter.apply', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.view');
    if (denied) return denied;

    const { id } = await params;

    let body: NLFilterInput;
    try {
      body = await request.json() as NLFilterInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.text || body.text.trim().length === 0) {
      return invalidInputResponse('text is required');
    }

    try {
      // Verify dashboard exists and get cube metadata
      const dashData = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          WIDGETS_JSON: string;
        }>(
          `SELECT DASH_ID, WIDGETS_JSON
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dashData) return notFoundResponse('Dashboard not found');

      // Extract available dimensions and measures from widgets
      const widgetsStr = await clobToString(dashData.WIDGETS_JSON);
      const widgets = parseJsonClob<Array<{
        cubeQuery?: {
          measures?: string[];
          dimensions?: string[];
        };
        cubeName?: string;
      }>>(widgetsStr) || [];

      const availableDimensions = new Set<string>();
      const availableMeasures = new Set<string>();
      let cubeName = body.cubeName || '';

      for (const widget of widgets) {
        if (widget.cubeQuery?.measures) {
          widget.cubeQuery.measures.forEach((m) => availableMeasures.add(m));
        }
        if (widget.cubeQuery?.dimensions) {
          widget.cubeQuery.dimensions.forEach((d) => availableDimensions.add(d));
        }
        if (widget.cubeName && !cubeName) {
          cubeName = widget.cubeName;
        }
      }

      // Parse NL filter
      const parseResult = parseNLFilter(body.text, {
        cubeName,
        availableDimensions: body.availableDimensions || Array.from(availableDimensions),
        availableMeasures: body.availableMeasures || Array.from(availableMeasures),
      });

      // Log to NB_NL_FILTER_HISTORY
      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_NL_FILTER_HISTORY
             (HISTORY_ID, DASH_ID, USER_ID, RAW_INPUT,
              PARSED_FILTERS, PARSE_SUCCESS, PARSE_CONFIDENCE,
              APPLIED_AT, TENANT_ID)
           VALUES
             (:historyId, :dashId, :userId, :rawInput,
              :parsedFilters, :parseSuccess, :parseConfidence,
              SYSTIMESTAMP, :tenantId)`,
          {
            historyId: generateId(),
            dashId: id,
            userId: user.id,
            rawInput: body.text.substring(0, 1000),
            parsedFilters: JSON.stringify(parseResult.filters),
            parseSuccess: parseResult.filters.length > 0 ? 1 : 0,
            parseConfidence: parseResult.confidence,
            tenantId: user.tenantId,
          },
        );
      });

      return NextResponse.json<ApiResponse<NLFilterParseResult>>({
        success: true,
        data: parseResult,
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/nl-filter error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

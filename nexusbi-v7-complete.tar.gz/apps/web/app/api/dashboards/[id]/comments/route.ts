import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { buildCommentTree, extractMentions, notifyMentioned, notifyParentCommenter } from '@/lib/comment-notifier';
import { generateId } from '@nexusbi/shared-types';

const CreateSchema = z.object({
  widgetId: z.string().min(1),
  parentId: z.string().optional(),
  content: z.string().min(1).max(10_000),
  markContext: z.record(z.any()).optional(),
});

export const GET = withAudit(
  (_, params) => ({ action: 'comment.list', resourceType: 'dashboard', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'comment.view');
    const { searchParams } = new URL(request.url);
    const widgetId = searchParams.get('widgetId');
    if (!widgetId) return NextResponse.json({ error: 'widgetId required' }, { status: 400 });
    const tree = await buildCommentTree(params.id, widgetId);
    return NextResponse.json({ comments: tree });
  },
);

export const POST = withAudit(
  (_, params) => ({ action: 'comment.create', resourceType: 'dashboard', resourceId: params.id }),
  async (request, { params }, user) => {
    await requireAuthAndPermission(user, 'comment.create');
    const body = CreateSchema.parse(await request.json());
    const mentions = extractMentions(body.content);
    const commentId = generateId('CMT');

    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_WIDGET_COMMENTS
          (COMMENT_ID, DASH_ID, WIDGET_ID, PARENT_ID, USER_ID, CONTENT, MARK_CONTEXT, MENTIONED_USERS)
         VALUES (:id, :d, :w, :p, :u, :c, :mc, :mu)`,
        {
          id: commentId, d: params.id, w: body.widgetId, p: body.parentId ?? null, u: user.userId,
          c: body.content,
          mc: body.markContext ? JSON.stringify(body.markContext) : null,
          mu: JSON.stringify(mentions),
        },
      );
      await conn.commit();
    });

    const comment = {
      commentId, dashId: params.id, widgetId: body.widgetId,
      parentId: body.parentId ?? null, userId: user.userId, userName: user.fullName ?? user.username,
      content: body.content, markContext: body.markContext ?? null,
      mentionedUsers: mentions, resolved: false,
      createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    };

    if (mentions.length > 0) await notifyMentioned(comment as never, mentions);
    if (body.parentId) await notifyParentCommenter(comment as never, body.parentId);

    return NextResponse.json(comment, { status: 201 });
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { logWidgetPerf } from '@/lib/perf-tracker';
import type { ApiResponse, PerfMetricLogInput } from '@nexusbi/shared-types';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const { id } = await params;

  let body: PerfMetricLogInput;
  try {
    body = await request.json() as PerfMetricLogInput;
  } catch {
    return invalidInputResponse('Invalid JSON body');
  }

  if (!body.widgetId || body.loadMs === undefined) {
    return invalidInputResponse('widgetId and loadMs are required');
  }

  try {
    await logWidgetPerf(
      id,
      session.user.id,
      session.user.tenantId,
      {
        widgetId: body.widgetId,
        loadMs: Math.max(0, Math.round(body.loadMs)),
        cubeQueryMs: Math.max(0, Math.round(body.cubeQueryMs || 0)),
        renderMs: Math.max(0, Math.round(body.renderMs || 0)),
      },
    );

    return NextResponse.json<ApiResponse<{ logged: boolean }>>({
      success: true,
      data: { logged: true },
    });
  } catch (error) {
    console.error('POST /api/dashboards/[id]/perf/log error:', error);
    return internalErrorResponse();
  }
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, requireAnyPermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { checkTimedAccess } from '@/lib/timed-access';
import { checkPermission } from '@/lib/rbac';
import type { ApiResponse, Dashboard, DashboardUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    // LAW-15: Check timed access
    const hasAccess = await checkTimedAccess('dashboard', id, session.user.id, session.user.tenantId);
    if (!hasAccess) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { code: 'RBAC_DENIED', message: 'Timed access expired' } },
        { status: 403 },
      );
    }

    const dash = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON,
                FILTERS_JSON, OWNER_ID, TENANT_ID, IS_PUBLIC, IS_EMBEDDED,
                EMBED_TOKEN, VERSION, THUMBNAIL_URL, TAGS,
                APPROVAL_STATUS, APPROVED_BY, APPROVED_AT,
                REJECTED_BY, REJECTED_AT, REJECTION_REASON,
                SOURCE, DUAL_CHECKER_REQUIRED, CREATED_AT, UPDATED_AT
         FROM NB_DASHBOARDS
         WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
        { dashId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        dashId: row.DASH_ID as string,
        dashName: row.DASH_NAME as string,
        description: await clobToString(row.DESCRIPTION) || null,
        layoutJson: parseJsonClob(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob(await clobToString(row.WIDGETS_JSON)),
        filtersJson: parseJsonClob(await clobToString(row.FILTERS_JSON)),
        ownerId: row.OWNER_ID as string,
        tenantId: row.TENANT_ID as string,
        isPublic: (row.IS_PUBLIC as number) === 1,
        isEmbedded: (row.IS_EMBEDDED as number) === 1,
        embedToken: row.EMBED_TOKEN as string | null,
        version: row.VERSION as number,
        thumbnailUrl: row.THUMBNAIL_URL as string | null,
        tags: row.TAGS as string | null,
        approvalStatus: row.APPROVAL_STATUS as Dashboard['approvalStatus'],
        approvedBy: row.APPROVED_BY as string | null,
        approvedAt: row.APPROVED_AT ? String(row.APPROVED_AT) : null,
        rejectedBy: row.REJECTED_BY as string | null,
        rejectedAt: row.REJECTED_AT ? String(row.REJECTED_AT) : null,
        rejectionReason: await clobToString(row.REJECTION_REASON) || null,
        source: row.SOURCE as Dashboard['source'],
        dualCheckerRequired: (row.DUAL_CHECKER_REQUIRED as number) === 1,
        createdAt: String(row.CREATED_AT),
        updatedAt: String(row.UPDATED_AT),
      } as Dashboard;
    });

    if (!dash) return notFoundResponse('Dashboard not found');

    // Viewer access: if user cannot create dashboards, they must be the owner OR have an explicit share
    const canSeeAll = await checkPermission(session.user.id, session.user.tenantId, session.user.roles, 'dashboard.create');
    if (!canSeeAll) {
      const isOwner = dash.ownerId === session.user.id;
      const isApproved = dash.approvalStatus === 'APPROVED';
      let isShared = false;
      if (!isOwner) {
        const shareCheck = await withConnection(async (conn) => {
          const r = await conn.execute<{ CNT: number }>(
            `SELECT COUNT(*) AS CNT FROM NB_DASHBOARD_SHARES S
             WHERE S.DASH_ID = :dashId
               AND (S.USER_ID = :userId
                    OR S.ROLE_ID IN (
                      SELECT UR.ROLE_ID FROM NB_USER_ROLES UR
                      WHERE UR.USER_ID = :userId AND UR.TENANT_ID = :tenantId))`,
            { dashId: id, userId: session.user.id, tenantId: session.user.tenantId },
            { outFormat: 4002 },
          );
          return ((r.rows?.[0]?.CNT ?? 0) as number) > 0;
        });
        isShared = shareCheck;
      }
      if (!isOwner && !(isShared && isApproved)) {
        return notFoundResponse('Dashboard not found');
      }
    }

    return NextResponse.json<ApiResponse<Dashboard>>({ success: true, data: dash });
  } catch (error) {
    console.error('GET /api/dashboards/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'dashboard.update', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requireAnyPermission(user, ['dashboard.edit', 'dashboard.edit.any']);
    if (denied) return denied;

    const { id } = await params;
    let body: DashboardUpdateInput;
    try {
      body = await request.json() as DashboardUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          OWNER_ID: string;
          VERSION: number;
          APPROVAL_STATUS: string;
        }>(
          `SELECT DASH_ID, OWNER_ID, VERSION, APPROVAL_STATUS
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!existing) return notFoundResponse('Dashboard not found');

      // Check ownership unless has edit.any
      const canEditAny = await requirePermission(user, 'dashboard.edit.any');
      if (canEditAny && existing.OWNER_ID !== user.id) {
        return canEditAny;
      }

      await withTransaction(async (conn) => {
        const newVersion = existing.VERSION + 1;
        const setClauses: string[] = [
          'UPDATED_AT = SYSTIMESTAMP',
          'VERSION = :newVersion',
        ];
        const binds: Record<string, unknown> = {
          dashId: id,
          tenantId: user.tenantId,
          newVersion,
        };

        // A14: Re-editing an APPROVED dashboard resets to DRAFT
        if (existing.APPROVAL_STATUS === 'APPROVED' || existing.APPROVAL_STATUS === 'REJECTED') {
          setClauses.push("APPROVAL_STATUS = 'DRAFT'");
          setClauses.push('APPROVED_BY = NULL');
          setClauses.push('APPROVED_AT = NULL');
          setClauses.push('REJECTED_BY = NULL');
          setClauses.push('REJECTED_AT = NULL');
          setClauses.push('REJECTION_REASON = NULL');
        }

        if (body.dashName !== undefined) {
          setClauses.push('DASH_NAME = :dashName');
          binds.dashName = body.dashName;
        }
        if (body.description !== undefined) {
          setClauses.push('DESCRIPTION = :description');
          binds.description = body.description;
        }
        if (body.layoutJson !== undefined) {
          setClauses.push('LAYOUT_JSON = :layoutJson');
          binds.layoutJson = JSON.stringify(body.layoutJson);
        }
        if (body.widgetsJson !== undefined) {
          setClauses.push('WIDGETS_JSON = :widgetsJson');
          binds.widgetsJson = JSON.stringify(body.widgetsJson);
        }
        if (body.filtersJson !== undefined) {
          setClauses.push('FILTERS_JSON = :filtersJson');
          binds.filtersJson = JSON.stringify(body.filtersJson);
        }
        if (body.isPublic !== undefined) {
          setClauses.push('IS_PUBLIC = :isPublic');
          binds.isPublic = body.isPublic ? 1 : 0;
        }
        if (body.tags !== undefined) {
          setClauses.push('TAGS = :tags');
          binds.tags = body.tags;
        }
        if (body.dualCheckerRequired !== undefined) {
          setClauses.push('DUAL_CHECKER_REQUIRED = :dualChecker');
          binds.dualChecker = body.dualCheckerRequired ? 1 : 0;
        }

        await conn.execute(
          `UPDATE NB_DASHBOARDS SET ${setClauses.join(', ')}
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          binds,
        );

        // Save version snapshot
        await conn.execute(
          `INSERT INTO NB_DASHBOARD_VERSIONS
             (VERSION_ID, DASH_ID, VERSION, LAYOUT_JSON, WIDGETS_JSON,
              FILTERS_JSON, SAVED_BY, SAVED_AT, CHANGE_SUMMARY)
           VALUES
             (:versionId, :dashId, :version, :layoutJson, :widgetsJson,
              :filtersJson, :savedBy, SYSTIMESTAMP, :summary)`,
          {
            versionId: generateId(),
            dashId: id,
            version: newVersion,
            layoutJson: body.layoutJson ? JSON.stringify(body.layoutJson) : null,
            widgetsJson: body.widgetsJson ? JSON.stringify(body.widgetsJson) : null,
            filtersJson: body.filtersJson ? JSON.stringify(body.filtersJson) : null,
            savedBy: user.id,
            summary: `Updated by ${user.displayName}`,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ dashId: string; version: number }>>({
        success: true,
        data: { dashId: id, version: existing.VERSION + 1 },
      });
    } catch (error) {
      console.error('PUT /api/dashboards/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'dashboard.delete', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requireAnyPermission(user, ['dashboard.delete', 'dashboard.delete.any']);
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `DELETE FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Dashboard not found');

      return NextResponse.json<ApiResponse<{ dashId: string }>>({
        success: true,
        data: { dashId: id },
      });
    } catch (error) {
      console.error('DELETE /api/dashboards/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

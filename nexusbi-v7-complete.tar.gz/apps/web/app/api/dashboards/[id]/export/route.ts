export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection } from '@/lib/oracle-pool';
import type { DashboardExportOptions } from '@nexusbi/shared-types';

/**
 * Dashboard export — produces a JSON bundle of widget data and a printable HTML
 * representation. PDF/PNG image rendering is deferred; users can use browser
 * "Print to PDF" on the HTML output. This avoids pulling in headless-Chromium
 * (puppeteer) which is blocked by most corporate proxies.
 */
export const POST = withAudit(
  (_req, p) => ({ action: 'dashboard.export', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.view');
    if (denied) return denied;

    const { id } = await params;

    let body: DashboardExportOptions = { format: 'html' };
    try {
      body = (await request.json()) as DashboardExportOptions;
    } catch {
      // defaults
    }

    if (!['html', 'csv', 'json'].includes(body.format)) {
      return invalidInputResponse('format must be html, csv, or json');
    }

    try {
      const dash = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          DASH_NAME: string;
          LAYOUT_JSON: string | null;
        }>(
          `SELECT DASH_ID, DASH_NAME, LAYOUT_JSON
             FROM NB_DASHBOARDS
            WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dash) return notFoundResponse('Dashboard not found');

      const dashName = dash.DASH_NAME || 'dashboard';

      if (body.format === 'json') {
        return NextResponse.json({
          dashId: dash.DASH_ID,
          dashName,
          layout: dash.LAYOUT_JSON ? JSON.parse(dash.LAYOUT_JSON) : null,
          exportedAt: new Date().toISOString(),
          exportedBy: user.userId,
        });
      }

      if (body.format === 'csv') {
        const csvLines = ['widget_id,widget_type,title'];
        const layout = dash.LAYOUT_JSON ? JSON.parse(dash.LAYOUT_JSON) : { widgets: [] };
        for (const w of layout.widgets || []) {
          csvLines.push(
            `"${w.widgetId || ''}","${w.chartType || ''}","${(w.title || '').replace(/"/g, '""')}"`,
          );
        }
        const body_ = csvLines.join('\n');
        return new NextResponse(body_, {
          status: 200,
          headers: {
            'Content-Type': 'text/csv',
            'Content-Disposition': `attachment; filename="${dashName}.csv"`,
          },
        });
      }

      // HTML — printable, self-contained
      const html = `<!DOCTYPE html><html><head><meta charset="utf-8"><title>${dashName}</title>
<style>body{font-family:Arial,sans-serif;max-width:1200px;margin:2em auto;padding:1em}
h1{color:#1E40AF}table{border-collapse:collapse;width:100%}th,td{border:1px solid #ccc;padding:8px;text-align:left}
th{background:#F3F4F6}.hint{color:#6B7280;font-size:0.9em;margin-top:2em}</style></head>
<body><h1>${dashName}</h1>
<p>Exported by user <b>${user.userId}</b> on ${new Date().toISOString().slice(0, 10)}</p>
<p>Use your browser's <b>Print to PDF</b> feature to save this as a PDF.</p>
<pre style="background:#F9FAFB;padding:1em;border-radius:6px">${dash.LAYOUT_JSON || '{}'}</pre>
<p class="hint">For rendered-screenshot export (PNG/PDF), install <code>puppeteer-core</code> and configure <code>PUPPETEER_EXECUTABLE_PATH</code>.</p>
</body></html>`;

      return new NextResponse(html, {
        status: 200,
        headers: {
          'Content-Type': 'text/html; charset=utf-8',
          'Content-Disposition': `attachment; filename="${dashName}.html"`,
        },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/export error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

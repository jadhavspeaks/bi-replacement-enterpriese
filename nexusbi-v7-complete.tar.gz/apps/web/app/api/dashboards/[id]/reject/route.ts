export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import type { ApiResponse } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.reject', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.reject');
    if (denied) return denied;

    const { id } = await params;

    let body: { comments: string };
    try {
      body = await request.json() as { comments: string };
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.comments || body.comments.trim().length === 0) {
      return invalidInputResponse('Comments are required when rejecting a dashboard');
    }

    try {
      const dash = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          APPROVAL_STATUS: string;
          DUAL_CHECKER_REQUIRED: number;
        }>(
          `SELECT DASH_ID, APPROVAL_STATUS, DUAL_CHECKER_REQUIRED
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dash) return notFoundResponse('Dashboard not found');

      if (dash.APPROVAL_STATUS !== 'PENDING_REVIEW') {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'CONFLICT', message: 'Dashboard is not pending review' } },
          { status: 409 },
        );
      }

      const review = await withConnection(async (conn) => {
        const result = await conn.execute<{
          REVIEW_ID: string;
          SUBMITTED_BY: string;
        }>(
          `SELECT REVIEW_ID, SUBMITTED_BY
           FROM NB_DASHBOARD_REVIEWS
           WHERE DASH_ID = :dashId AND REVIEW_STATUS = 'PENDING'
           ORDER BY SUBMITTED_AT DESC
           FETCH FIRST 1 ROW ONLY`,
          { dashId: id },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!review) {
        return notFoundResponse('No pending review found');
      }

      // Self-rejection blocked
      if (review.SUBMITTED_BY === user.id) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'RBAC_DENIED', message: 'Cannot reject your own submission' } },
          { status: 403 },
        );
      }

      await withTransaction(async (conn) => {
        // Reject immediately (even in dual-checker mode, one reject = REJECTED)
        await conn.execute(
          `UPDATE NB_DASHBOARDS
           SET APPROVAL_STATUS = 'REJECTED',
               REJECTED_BY = :rejectedBy,
               REJECTED_AT = SYSTIMESTAMP,
               REJECTION_REASON = :reason,
               UPDATED_AT = SYSTIMESTAMP
           WHERE DASH_ID = :dashId`,
          { dashId: id, rejectedBy: user.id, reason: body.comments },
        );

        await conn.execute(
          `UPDATE NB_DASHBOARD_REVIEWS
           SET REVIEWED_BY = :reviewedBy,
               REVIEWED_AT = SYSTIMESTAMP,
               REVIEW_STATUS = 'REJECTED',
               REVIEW_COMMENTS = :comments
           WHERE REVIEW_ID = :reviewId`,
          { reviewId: review.REVIEW_ID, reviewedBy: user.id, comments: body.comments },
        );

        // If dual-checker, record the rejection in checker assignments
        if (dash.DUAL_CHECKER_REQUIRED === 1) {
          // Find next available slot
          const existingSlots = await conn.execute<{ CHECKER_SLOT: number }>(
            `SELECT CHECKER_SLOT FROM NB_CHECKER_ASSIGNMENTS
             WHERE REVIEW_ID = :reviewId ORDER BY CHECKER_SLOT`,
            { reviewId: review.REVIEW_ID },
            { outFormat: 4002 },
          );

          const usedSlots = (existingSlots.rows || []).map((r) => r.CHECKER_SLOT);
          const slot = usedSlots.includes(1) ? 2 : 1;

          await conn.execute(
            `INSERT INTO NB_CHECKER_ASSIGNMENTS
               (ASSIGNMENT_ID, REVIEW_ID, CHECKER_SLOT, CHECKER_ID,
                ASSIGNED_AT, DECISION, DECIDED_AT, COMMENTS)
             VALUES
               (:assignmentId, :reviewId, :slot, :checkerId,
                SYSTIMESTAMP, 'REJECTED', SYSTIMESTAMP, :comments)`,
            {
              assignmentId: generateId(),
              reviewId: review.REVIEW_ID,
              slot,
              checkerId: user.id,
              comments: body.comments,
            },
          );
        }
      });

      return NextResponse.json<ApiResponse<{ dashId: string; status: string }>>({
        success: true,
        data: { dashId: id, status: 'REJECTED' },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/reject error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

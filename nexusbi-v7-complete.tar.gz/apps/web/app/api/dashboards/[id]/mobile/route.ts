export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, MobileLayout, MobileLayoutInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const layout = await withConnection(async (conn) => {
      // Verify dashboard belongs to org
      const dashCheck = await conn.execute<{ DASH_ID: string }>(
        `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
        { dashId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );
      if (!dashCheck.rows || dashCheck.rows.length === 0) return 'NOT_FOUND';

      const result = await conn.execute<{
        LAYOUT_ID: string;
        DASH_ID: string;
        LAYOUT_JSON: string;
        WIDGETS_JSON: string;
        LAST_EDITED_BY: string | null;
        UPDATED_AT: string;
        TENANT_ID: string;
      }>(
        `SELECT LAYOUT_ID, DASH_ID, LAYOUT_JSON, WIDGETS_JSON,
                LAST_EDITED_BY, UPDATED_AT, TENANT_ID
         FROM NB_MOBILE_LAYOUTS
         WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
        { dashId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        layoutId: row.LAYOUT_ID,
        dashId: row.DASH_ID,
        layoutJson: parseJsonClob(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob(await clobToString(row.WIDGETS_JSON)),
        lastEditedBy: row.LAST_EDITED_BY,
        updatedAt: String(row.UPDATED_AT),
        tenantId: row.TENANT_ID,
      } as MobileLayout;
    });

    if (layout === 'NOT_FOUND') return notFoundResponse('Dashboard not found');

    return NextResponse.json<ApiResponse<MobileLayout | null>>({
      success: true,
      data: layout,
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/mobile error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'mobile_layout.update', resourceType: 'mobile_layout', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.edit');
    if (denied) return denied;

    const { id } = await params;

    let body: MobileLayoutInput;
    try {
      body = await request.json() as MobileLayoutInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.layoutJson || !body.widgetsJson) {
      return invalidInputResponse('layoutJson and widgetsJson are required');
    }

    try {
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DASH_ID: string }>(
          `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('Dashboard not found');

      await withTransaction(async (conn) => {
        const existing = await conn.execute<{ LAYOUT_ID: string }>(
          `SELECT LAYOUT_ID FROM NB_MOBILE_LAYOUTS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );

        if (existing.rows && existing.rows.length > 0) {
          await conn.execute(
            `UPDATE NB_MOBILE_LAYOUTS
             SET LAYOUT_JSON = :layoutJson,
                 WIDGETS_JSON = :widgetsJson,
                 LAST_EDITED_BY = :editedBy,
                 UPDATED_AT = SYSTIMESTAMP
             WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
            {
              dashId: id,
              tenantId: user.tenantId,
              layoutJson: JSON.stringify(body.layoutJson),
              widgetsJson: JSON.stringify(body.widgetsJson),
              editedBy: user.id,
            },
          );
        } else {
          await conn.execute(
            `INSERT INTO NB_MOBILE_LAYOUTS
               (LAYOUT_ID, DASH_ID, LAYOUT_JSON, WIDGETS_JSON,
                LAST_EDITED_BY, UPDATED_AT, TENANT_ID)
             VALUES
               (:layoutId, :dashId, :layoutJson, :widgetsJson,
                :editedBy, SYSTIMESTAMP, :tenantId)`,
            {
              layoutId: generateId(),
              dashId: id,
              layoutJson: JSON.stringify(body.layoutJson),
              widgetsJson: JSON.stringify(body.widgetsJson),
              editedBy: user.id,
              tenantId: user.tenantId,
            },
          );
        }
      });

      return NextResponse.json<ApiResponse<{ dashId: string }>>({
        success: true,
        data: { dashId: id },
      });
    } catch (error) {
      console.error('PUT /api/dashboards/[id]/mobile error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

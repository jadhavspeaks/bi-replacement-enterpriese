export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, DashboardReview, CheckerAssignmentWithUser } from '@nexusbi/shared-types';

interface ReviewWithCheckers extends DashboardReview {
  submittedByDisplayName?: string;
  reviewedByDisplayName?: string;
  checkerAssignments: CheckerAssignmentWithUser[];
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    // Verify dashboard exists in org
    const dashExists = await withConnection(async (conn) => {
      const result = await conn.execute<{ DASH_ID: string }>(
        `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
        { dashId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );
      return (result.rows?.length ?? 0) > 0;
    });

    if (!dashExists) return notFoundResponse('Dashboard not found');

    const reviews = await withConnection(async (conn) => {
      const reviewResult = await conn.execute<{
        REVIEW_ID: string;
        DASH_ID: string;
        DASH_VERSION: number;
        SUBMITTED_BY: string;
        SUBMITTED_AT: string;
        REVIEWED_BY: string | null;
        REVIEWED_AT: string | null;
        REVIEW_STATUS: string;
        REVIEW_COMMENTS: string;
        TENANT_ID: string;
        SUBMITTED_DISPLAY: string | null;
        REVIEWED_DISPLAY: string | null;
      }>(
        `SELECT R.REVIEW_ID, R.DASH_ID, R.DASH_VERSION,
                R.SUBMITTED_BY, R.SUBMITTED_AT,
                R.REVIEWED_BY, R.REVIEWED_AT,
                R.REVIEW_STATUS, R.REVIEW_COMMENTS, R.TENANT_ID,
                US.DISPLAY_NAME AS SUBMITTED_DISPLAY,
                UR.DISPLAY_NAME AS REVIEWED_DISPLAY
         FROM NB_DASHBOARD_REVIEWS R
         LEFT JOIN NB_USERS US ON US.USER_ID = R.SUBMITTED_BY
         LEFT JOIN NB_USERS UR ON UR.USER_ID = R.REVIEWED_BY
         WHERE R.DASH_ID = :dashId AND R.TENANT_ID = :tenantId
         ORDER BY R.SUBMITTED_AT DESC`,
        { dashId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      const list: ReviewWithCheckers[] = [];
      for (const row of reviewResult.rows || []) {
        // Get checker assignments for this review
        const assignResult = await conn.execute<{
          ASSIGNMENT_ID: string;
          REVIEW_ID: string;
          CHECKER_SLOT: number;
          CHECKER_ID: string;
          ASSIGNED_AT: string;
          DECISION: string;
          DECIDED_AT: string | null;
          COMMENTS: string;
          CHECKER_DISPLAY: string | null;
          CHECKER_EMAIL: string | null;
        }>(
          `SELECT CA.ASSIGNMENT_ID, CA.REVIEW_ID, CA.CHECKER_SLOT,
                  CA.CHECKER_ID, CA.ASSIGNED_AT, CA.DECISION,
                  CA.DECIDED_AT, CA.COMMENTS,
                  U.DISPLAY_NAME AS CHECKER_DISPLAY,
                  U.EMAIL AS CHECKER_EMAIL
           FROM NB_CHECKER_ASSIGNMENTS CA
           LEFT JOIN NB_USERS U ON U.USER_ID = CA.CHECKER_ID
           WHERE CA.REVIEW_ID = :reviewId
           ORDER BY CA.CHECKER_SLOT`,
          { reviewId: row.REVIEW_ID },
          { outFormat: 4002 },
        );

        const checkerAssignments: CheckerAssignmentWithUser[] = [];
        for (const ca of assignResult.rows || []) {
          checkerAssignments.push({
            assignmentId: ca.ASSIGNMENT_ID,
            reviewId: ca.REVIEW_ID,
            checkerSlot: ca.CHECKER_SLOT as 1 | 2,
            checkerId: ca.CHECKER_ID,
            assignedAt: String(ca.ASSIGNED_AT),
            decision: ca.DECISION as CheckerAssignmentWithUser['decision'],
            decidedAt: ca.DECIDED_AT ? String(ca.DECIDED_AT) : null,
            comments: await clobToString(ca.COMMENTS) || null,
            checkerDisplayName: ca.CHECKER_DISPLAY ?? undefined,
            checkerEmail: ca.CHECKER_EMAIL ?? undefined,
          });
        }

        list.push({
          reviewId: row.REVIEW_ID,
          dashId: row.DASH_ID,
          dashVersion: row.DASH_VERSION,
          submittedBy: row.SUBMITTED_BY,
          submittedAt: String(row.SUBMITTED_AT),
          reviewedBy: row.REVIEWED_BY,
          reviewedAt: row.REVIEWED_AT ? String(row.REVIEWED_AT) : null,
          reviewStatus: row.REVIEW_STATUS as DashboardReview['reviewStatus'],
          reviewComments: await clobToString(row.REVIEW_COMMENTS) || null,
          tenantId: row.TENANT_ID,
          submittedByDisplayName: row.SUBMITTED_DISPLAY ?? undefined,
          reviewedByDisplayName: row.REVIEWED_DISPLAY ?? undefined,
          checkerAssignments,
        });
      }

      return list;
    });

    return NextResponse.json<ApiResponse<ReviewWithCheckers[]>>({
      success: true,
      data: reviews,
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/reviews error:', error);
    return internalErrorResponse();
  }
}

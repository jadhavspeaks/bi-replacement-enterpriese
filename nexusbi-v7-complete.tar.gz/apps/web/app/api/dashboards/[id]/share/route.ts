export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import type { ApiResponse, DashboardShare, DashboardShareInput } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.share', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.share');
    if (denied) return denied;

    const { id } = await params;
    let body: DashboardShareInput;
    try {
      body = await request.json() as DashboardShareInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.roleId && !body.userId) {
      return invalidInputResponse('Either roleId or userId is required');
    }

    try {
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DASH_ID: string }>(
          `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('Dashboard not found');

      const shareId = generateId();

      await withTransaction(async (conn) => {
        // Remove existing share for same target
        if (body.roleId) {
          await conn.execute(
            `DELETE FROM NB_DASHBOARD_SHARES WHERE DASH_ID = :dashId AND ROLE_ID = :roleId`,
            { dashId: id, roleId: body.roleId },
          );
        }
        if (body.userId) {
          await conn.execute(
            `DELETE FROM NB_DASHBOARD_SHARES WHERE DASH_ID = :dashId AND USER_ID = :userId`,
            { dashId: id, userId: body.userId },
          );
        }

        await conn.execute(
          `INSERT INTO NB_DASHBOARD_SHARES
             (SHARE_ID, DASH_ID, ROLE_ID, USER_ID, CAN_EDIT, CAN_SHARE,
              SHARED_AT, SHARED_BY)
           VALUES
             (:shareId, :dashId, :roleId, :userId, :canEdit, :canShare,
              SYSTIMESTAMP, :sharedBy)`,
          {
            shareId,
            dashId: id,
            roleId: body.roleId ?? null,
            userId: body.userId ?? null,
            canEdit: body.canEdit ? 1 : 0,
            canShare: body.canShare ? 1 : 0,
            sharedBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ shareId: string }>>(
        { success: true, data: { shareId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/dashboards/[id]/share error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'dashboard.unshare', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.share');
    if (denied) return denied;

    const { id } = await params;
    const { searchParams } = new URL(request.url);
    const shareId = searchParams.get('shareId');

    if (!shareId) {
      return invalidInputResponse('shareId query parameter is required');
    }

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `DELETE FROM NB_DASHBOARD_SHARES
           WHERE SHARE_ID = :shareId AND DASH_ID = :dashId`,
          { shareId, dashId: id },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Share not found');

      return NextResponse.json<ApiResponse<{ deleted: boolean }>>({
        success: true,
        data: { deleted: true },
      });
    } catch (error) {
      console.error('DELETE /api/dashboards/[id]/share error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

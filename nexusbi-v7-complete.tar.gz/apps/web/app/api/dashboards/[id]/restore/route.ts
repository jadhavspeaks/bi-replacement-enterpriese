export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.restore', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.edit');
    if (denied) return denied;

    const { id } = await params;

    let body: { versionId: string };
    try {
      body = await request.json() as { versionId: string };
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.versionId) {
      return invalidInputResponse('versionId is required');
    }

    try {
      const version = await withConnection(async (conn) => {
        const result = await conn.execute<{
          VERSION_ID: string;
          VERSION: number;
          LAYOUT_JSON: string;
          WIDGETS_JSON: string;
          FILTERS_JSON: string;
        }>(
          `SELECT V.VERSION_ID, V.VERSION, V.LAYOUT_JSON, V.WIDGETS_JSON, V.FILTERS_JSON
           FROM NB_DASHBOARD_VERSIONS V
           JOIN NB_DASHBOARDS D ON D.DASH_ID = V.DASH_ID
           WHERE V.VERSION_ID = :versionId
             AND V.DASH_ID = :dashId
             AND D.TENANT_ID = :tenantId`,
          { versionId: body.versionId, dashId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!version) return notFoundResponse('Version not found');

      const layoutJson = await clobToString(version.LAYOUT_JSON);
      const widgetsJson = await clobToString(version.WIDGETS_JSON);
      const filtersJson = await clobToString(version.FILTERS_JSON);

      await withTransaction(async (conn) => {
        // Get current version number
        const current = await conn.execute<{ VERSION: number }>(
          `SELECT VERSION FROM NB_DASHBOARDS WHERE DASH_ID = :dashId`,
          { dashId: id },
          { outFormat: 4002 },
        );
        const newVersion = (current.rows?.[0]?.VERSION || 0) + 1;

        // Update dashboard with restored version data
        await conn.execute(
          `UPDATE NB_DASHBOARDS
           SET LAYOUT_JSON = :layoutJson,
               WIDGETS_JSON = :widgetsJson,
               FILTERS_JSON = :filtersJson,
               VERSION = :newVersion,
               APPROVAL_STATUS = 'DRAFT',
               APPROVED_BY = NULL,
               APPROVED_AT = NULL,
               REJECTED_BY = NULL,
               REJECTED_AT = NULL,
               REJECTION_REASON = NULL,
               UPDATED_AT = SYSTIMESTAMP
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          {
            dashId: id,
            tenantId: user.tenantId,
            layoutJson: layoutJson || null,
            widgetsJson: widgetsJson || '[]',
            filtersJson: filtersJson || null,
            newVersion,
          },
        );

        // Save restore as new version
        await conn.execute(
          `INSERT INTO NB_DASHBOARD_VERSIONS
             (VERSION_ID, DASH_ID, VERSION, LAYOUT_JSON, WIDGETS_JSON,
              FILTERS_JSON, SAVED_BY, SAVED_AT, CHANGE_SUMMARY)
           VALUES
             (:versionId, :dashId, :version, :layoutJson, :widgetsJson,
              :filtersJson, :savedBy, SYSTIMESTAMP, :summary)`,
          {
            versionId: generateId(),
            dashId: id,
            version: newVersion,
            layoutJson: layoutJson || null,
            widgetsJson: widgetsJson || '[]',
            filtersJson: filtersJson || null,
            savedBy: user.id,
            summary: `Restored from version ${version.VERSION}`,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ dashId: string; restoredFromVersion: number }>>({
        success: true,
        data: { dashId: id, restoredFromVersion: version.VERSION },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/restore error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

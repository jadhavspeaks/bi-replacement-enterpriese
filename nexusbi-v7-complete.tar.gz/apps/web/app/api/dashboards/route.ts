export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { checkPermission } from '@/lib/rbac';
import type { ApiResponse, Dashboard, DashboardCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { user } = session;

  try {
    // VIEWER role: only see APPROVED dashboards (A14)
    const canSeeAll = await checkPermission(user.id, user.tenantId, user.roles, 'dashboard.create');

    const dashboards = await withConnection(async (conn) => {
      let sql = `SELECT D.DASH_ID, D.DASH_NAME, D.DESCRIPTION, D.OWNER_ID, D.TENANT_ID,
                        D.IS_PUBLIC, D.VERSION, D.THUMBNAIL_URL, D.TAGS,
                        D.APPROVAL_STATUS, D.APPROVED_BY, D.APPROVED_AT,
                        D.REJECTED_BY, D.REJECTED_AT, D.SOURCE,
                        D.DUAL_CHECKER_REQUIRED, D.CREATED_AT, D.UPDATED_AT
                 FROM NB_DASHBOARDS D
                 WHERE D.TENANT_ID = :tenantId`;
      const binds: Record<string, unknown> = { tenantId: user.tenantId };

      if (!canSeeAll) {
        // VIEWER: ONLY dashboards explicitly shared with their user_id or one of their roles.
        // Approved status alone does NOT grant access. Owners always see their own.
        sql += ` AND (
                   D.OWNER_ID = :userId
                   OR D.DASH_ID IN (
                     SELECT S.DASH_ID FROM NB_DASHBOARD_SHARES S
                     WHERE S.USER_ID = :userId
                        OR S.ROLE_ID IN (
                          SELECT UR.ROLE_ID FROM NB_USER_ROLES UR
                          WHERE UR.USER_ID = :userId AND UR.TENANT_ID = :tenantId
                        )
                   )
                 )
                 AND D.APPROVAL_STATUS = 'APPROVED'`;
        binds.userId = user.id;
      }

      sql += ` ORDER BY D.UPDATED_AT DESC`;

      const result = await conn.execute<Record<string, unknown>>(sql, binds, { outFormat: 4002 });

      const list: Dashboard[] = [];
      for (const row of result.rows || []) {
        list.push({
          dashId: row.DASH_ID as string,
          dashName: row.DASH_NAME as string,
          description: await clobToString(row.DESCRIPTION) || null,
          layoutJson: null,
          widgetsJson: null,
          filtersJson: null,
          ownerId: row.OWNER_ID as string,
          tenantId: row.TENANT_ID as string,
          isPublic: (row.IS_PUBLIC as number) === 1,
          isEmbedded: false,
          embedToken: null,
          version: row.VERSION as number,
          thumbnailUrl: row.THUMBNAIL_URL as string | null,
          tags: row.TAGS as string | null,
          approvalStatus: row.APPROVAL_STATUS as Dashboard['approvalStatus'],
          approvedBy: row.APPROVED_BY as string | null,
          approvedAt: row.APPROVED_AT ? String(row.APPROVED_AT) : null,
          rejectedBy: row.REJECTED_BY as string | null,
          rejectedAt: row.REJECTED_AT ? String(row.REJECTED_AT) : null,
          rejectionReason: null,
          source: row.SOURCE as Dashboard['source'],
          dualCheckerRequired: (row.DUAL_CHECKER_REQUIRED as number) === 1,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<Dashboard[]>>({
      success: true,
      data: dashboards,
    });
  } catch (error) {
    console.error('GET /api/dashboards error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'dashboard.create', resourceType: 'dashboard' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'dashboard.create');
    if (denied) return denied;

    let body: DashboardCreateInput;
    try {
      body = await request.json() as DashboardCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dashName) {
      return invalidInputResponse('dashName is required');
    }

    try {
      const dashId = generateId();

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_DASHBOARDS
             (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON,
              FILTERS_JSON, OWNER_ID, TENANT_ID, IS_PUBLIC, VERSION,
              TAGS, APPROVAL_STATUS, SOURCE, DUAL_CHECKER_REQUIRED,
              CREATED_AT, UPDATED_AT)
           VALUES
             (:dashId, :dashName, :description, :layoutJson, :widgetsJson,
              :filtersJson, :ownerId, :tenantId, :isPublic, 1,
              :tags, 'DRAFT', 'MANUAL', :dualChecker,
              SYSTIMESTAMP, SYSTIMESTAMP)`,
          {
            dashId,
            dashName: body.dashName,
            description: body.description ?? null,
            layoutJson: body.layoutJson ? JSON.stringify(body.layoutJson) : JSON.stringify({
              cols: 12, rowHeight: 40, margin: [10, 10],
              containerPadding: [10, 10], compactType: 'vertical',
            }),
            widgetsJson: body.widgetsJson ? JSON.stringify(body.widgetsJson) : '[]',
            filtersJson: body.filtersJson ? JSON.stringify(body.filtersJson) : null,
            ownerId: user.id,
            tenantId: user.tenantId,
            isPublic: body.isPublic ? 1 : 0,
            tags: body.tags ?? null,
            dualChecker: body.dualCheckerRequired ? 1 : 0,
          },
        );

        // Save initial version
        await conn.execute(
          `INSERT INTO NB_DASHBOARD_VERSIONS
             (VERSION_ID, DASH_ID, VERSION, LAYOUT_JSON, WIDGETS_JSON,
              FILTERS_JSON, SAVED_BY, SAVED_AT, CHANGE_SUMMARY)
           VALUES
             (:versionId, :dashId, 1, :layoutJson, :widgetsJson,
              :filtersJson, :savedBy, SYSTIMESTAMP, 'Initial creation')`,
          {
            versionId: generateId(),
            dashId,
            layoutJson: body.layoutJson ? JSON.stringify(body.layoutJson) : null,
            widgetsJson: body.widgetsJson ? JSON.stringify(body.widgetsJson) : '[]',
            filtersJson: body.filtersJson ? JSON.stringify(body.filtersJson) : null,
            savedBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ dashId: string }>>(
        { success: true, data: { dashId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/dashboards error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

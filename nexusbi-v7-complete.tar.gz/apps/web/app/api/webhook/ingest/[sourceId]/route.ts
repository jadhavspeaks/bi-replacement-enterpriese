export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { withConnection, clobToString, parseJsonClob, generateId } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse } from '@nexusbi/shared-types';

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ sourceId: string }> },
): Promise<NextResponse> {
  const { sourceId } = await params;

  try {
    // Load API source config
    const source = await withConnection(async (conn) => {
      const result = await conn.execute<{
        SOURCE_ID: string;
        API_TYPE: string;
        AUTH_CONFIG: string;
        RESPONSE_MAPPING: string;
        STAGING_TABLE: string | null;
        TENANT_ID: string;
      }>(
        `SELECT SOURCE_ID, API_TYPE, AUTH_CONFIG, RESPONSE_MAPPING,
                STAGING_TABLE, TENANT_ID
         FROM NB_API_SOURCES
         WHERE SOURCE_ID = :sourceId AND IS_ACTIVE = 1 AND API_TYPE = 'WEBHOOK_PUSH'`,
        { sourceId },
        { outFormat: 4002 },
      );
      return result.rows?.[0] || null;
    });

    if (!source) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { code: 'NOT_FOUND', message: 'Webhook source not found' } },
        { status: 404 },
      );
    }

    // Validate webhook secret
    const authConfigStr = await clobToString(source.AUTH_CONFIG);
    if (authConfigStr) {
      try {
        const authConfig = JSON.parse(decrypt(authConfigStr)) as {
          method: string;
          secretHeader?: string;
          secretValue?: string;
        };

        if (authConfig.secretHeader && authConfig.secretValue) {
          const providedSecret = request.headers.get(authConfig.secretHeader);
          if (providedSecret !== authConfig.secretValue) {
            return NextResponse.json<ApiResponse<never>>(
              { success: false, error: { code: 'RBAC_DENIED', message: 'Invalid webhook secret' } },
              { status: 403 },
            );
          }
        }
      } catch {
        console.error('Failed to validate webhook secret for source:', sourceId);
      }
    }

    // Parse payload
    let payload: unknown;
    const contentType = request.headers.get('content-type') || '';

    if (contentType.includes('application/json')) {
      payload = await request.json();
    } else {
      payload = await request.text();
    }

    // Get response mapping for data extraction
    const mappingStr = await clobToString(source.RESPONSE_MAPPING);
    const mapping = parseJsonClob<{
      dataPath: string;
      columnMappings: Array<{
        sourcePath: string;
        targetColumn: string;
        dataType: string;
      }>;
    }>(mappingStr);

    // Log the inbound webhook
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_AUDIT_LOG
           (LOG_ID, USER_ID, TENANT_ID, ACTION, RESOURCE_TYPE, RESOURCE_ID,
            REQUEST_PAYLOAD, RESPONSE_STATUS, CREATED_AT)
         VALUES
           (:logId, 'WEBHOOK', :tenantId, 'webhook.ingest', 'api_source', :sourceId,
            :payload, 200, SYSTIMESTAMP)`,
        {
          logId: generateId(),
          tenantId: source.TENANT_ID,
          sourceId,
          payload: typeof payload === 'string' ? payload : JSON.stringify(payload),
        },
      );

      // Update last poll status
      await conn.execute(
        `UPDATE NB_API_SOURCES
         SET LAST_POLLED_AT = SYSTIMESTAMP,
             LAST_POLL_STATUS = 'SUCCESS',
             LAST_ROW_COUNT = 1
         WHERE SOURCE_ID = :sourceId`,
        { sourceId },
      );

      await conn.commit();
    });

    return NextResponse.json<ApiResponse<{ received: boolean }>>({
      success: true,
      data: { received: true },
    });
  } catch (error) {
    console.error('POST /api/webhook/ingest/[sourceId] error:', error);
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INGEST_FAILED', message: 'Webhook processing failed' } },
      { status: 500 },
    );
  }
}

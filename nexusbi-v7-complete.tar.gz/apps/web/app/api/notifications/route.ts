export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { sendNotification } from '@/lib/notifications';
import type { ApiResponse, DeliveryType, DeliveryConfig } from '@nexusbi/shared-types';

interface SendNotificationInput {
  deliveryType: DeliveryType;
  deliveryConfig: DeliveryConfig;
  subject: string;
  body: string;
  htmlBody?: string;
}

export async function POST(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  let input: SendNotificationInput;
  try {
    input = await request.json() as SendNotificationInput;
  } catch {
    return invalidInputResponse('Invalid JSON body');
  }

  if (!input.deliveryType || !input.deliveryConfig || !input.subject || !input.body) {
    return invalidInputResponse('deliveryType, deliveryConfig, subject, and body are required');
  }

  try {
    await sendNotification({
      deliveryType: input.deliveryType,
      deliveryConfig: input.deliveryConfig,
      subject: input.subject,
      body: input.body,
      htmlBody: input.htmlBody,
    });

    return NextResponse.json<ApiResponse<{ sent: boolean }>>({
      success: true,
      data: { sent: true },
    });
  } catch (error) {
    console.error('POST /api/notifications error:', error);
    return internalErrorResponse();
  }
}

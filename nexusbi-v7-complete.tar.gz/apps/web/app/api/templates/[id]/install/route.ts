export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, TemplateInstallInput, WidgetConfig } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'template.install', resourceType: 'template', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'template.install');
    if (denied) return denied;

    const { id } = await params;

    let body: TemplateInstallInput;
    try {
      body = await request.json() as TemplateInstallInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsMapping || Object.keys(body.dsMapping).length === 0) {
      return invalidInputResponse('dsMapping is required');
    }

    try {
      const template = await withConnection(async (conn) => {
        const result = await conn.execute<{
          TEMPLATE_ID: string;
          TEMPLATE_NAME: string;
          LAYOUT_JSON: string;
          WIDGETS_JSON: string;
        }>(
          `SELECT TEMPLATE_ID, TEMPLATE_NAME, LAYOUT_JSON, WIDGETS_JSON
           FROM NB_DASH_TEMPLATES
           WHERE TEMPLATE_ID = :templateId
             AND (TENANT_ID = :tenantId OR IS_GLOBAL = 1)`,
          { templateId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!template) return notFoundResponse('Template not found');

      const layoutJson = await clobToString(template.LAYOUT_JSON);
      const widgetsJsonStr = await clobToString(template.WIDGETS_JSON);
      const widgets = parseJsonClob<WidgetConfig[]>(widgetsJsonStr) || [];

      // Remap datasource references in widgets
      const remappedWidgets = widgets.map((widget) => {
        const newWidget = { ...widget, widgetId: generateId() };
        if (newWidget.dsId && body.dsMapping[newWidget.dsId]) {
          newWidget.dsId = body.dsMapping[newWidget.dsId];
        }
        return newWidget;
      });

      const dashId = generateId();
      const dashName = body.dashName || `${template.TEMPLATE_NAME} (installed)`;
      const installId = generateId();

      await withTransaction(async (conn) => {
        // Create new dashboard
        await conn.execute(
          `INSERT INTO NB_DASHBOARDS
             (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON,
              OWNER_ID, TENANT_ID, VERSION, APPROVAL_STATUS, SOURCE,
              CREATED_AT, UPDATED_AT)
           VALUES
             (:dashId, :dashName, :description, :layoutJson, :widgetsJson,
              :ownerId, :tenantId, 1, 'DRAFT', 'MANUAL',
              SYSTIMESTAMP, SYSTIMESTAMP)`,
          {
            dashId,
            dashName,
            description: `Installed from template: ${template.TEMPLATE_NAME}`,
            layoutJson,
            widgetsJson: JSON.stringify(remappedWidgets),
            ownerId: user.id,
            tenantId: user.tenantId,
          },
        );

        // Save initial version
        await conn.execute(
          `INSERT INTO NB_DASHBOARD_VERSIONS
             (VERSION_ID, DASH_ID, VERSION, LAYOUT_JSON, WIDGETS_JSON,
              SAVED_BY, SAVED_AT, CHANGE_SUMMARY)
           VALUES
             (:versionId, :dashId, 1, :layoutJson, :widgetsJson,
              :savedBy, SYSTIMESTAMP, :summary)`,
          {
            versionId: generateId(),
            dashId,
            layoutJson,
            widgetsJson: JSON.stringify(remappedWidgets),
            savedBy: user.id,
            summary: `Installed from template: ${template.TEMPLATE_NAME}`,
          },
        );

        // Record install
        await conn.execute(
          `INSERT INTO NB_TEMPLATE_INSTALLS
             (INSTALL_ID, TEMPLATE_ID, DASH_ID, DS_MAPPING,
              INSTALLED_BY, TENANT_ID, INSTALLED_AT)
           VALUES
             (:installId, :templateId, :dashId, :dsMapping,
              :installedBy, :tenantId, SYSTIMESTAMP)`,
          {
            installId,
            templateId: id,
            dashId,
            dsMapping: JSON.stringify(body.dsMapping),
            installedBy: user.id,
            tenantId: user.tenantId,
          },
        );

        // Increment install count
        await conn.execute(
          `UPDATE NB_DASH_TEMPLATES
           SET INSTALL_COUNT = INSTALL_COUNT + 1
           WHERE TEMPLATE_ID = :templateId`,
          { templateId: id },
        );
      });

      return NextResponse.json<ApiResponse<{ dashId: string; installId: string }>>(
        { success: true, data: { dashId, installId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/templates/[id]/install error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, DashTemplate } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'template.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const template = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT TEMPLATE_ID, TEMPLATE_NAME, DESCRIPTION, CATEGORY,
                TAGS, LAYOUT_JSON, WIDGETS_JSON, REQUIRED_DS_TYPES,
                THUMBNAIL_URL, IS_GLOBAL, PUBLISHED_BY, TENANT_ID,
                CREATED_AT, INSTALL_COUNT
         FROM NB_DASH_TEMPLATES
         WHERE TEMPLATE_ID = :templateId
           AND (TENANT_ID = :tenantId OR IS_GLOBAL = 1)`,
        { templateId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        templateId: row.TEMPLATE_ID as string,
        templateName: row.TEMPLATE_NAME as string,
        description: await clobToString(row.DESCRIPTION) || null,
        category: row.CATEGORY as string | null,
        tags: row.TAGS as string | null,
        layoutJson: parseJsonClob(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob(await clobToString(row.WIDGETS_JSON)),
        requiredDsTypes: parseJsonClob<string[]>(await clobToString(row.REQUIRED_DS_TYPES)),
        thumbnailUrl: row.THUMBNAIL_URL as string | null,
        isGlobal: (row.IS_GLOBAL as number) === 1,
        publishedBy: row.PUBLISHED_BY as string,
        tenantId: row.TENANT_ID as string,
        createdAt: String(row.CREATED_AT),
        installCount: row.INSTALL_COUNT as number,
      } as DashTemplate;
    });

    if (!template) return notFoundResponse('Template not found');

    return NextResponse.json<ApiResponse<DashTemplate>>({ success: true, data: template });
  } catch (error) {
    console.error('GET /api/templates/[id] error:', error);
    return internalErrorResponse();
  }
}

export const DELETE = withAudit(
  (req, p) => ({ action: 'template.delete', resourceType: 'template', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'template.publish');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `DELETE FROM NB_DASH_TEMPLATES
           WHERE TEMPLATE_ID = :templateId AND TENANT_ID = :tenantId`,
          { templateId: id, tenantId: user.tenantId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Template not found');

      return NextResponse.json<ApiResponse<{ templateId: string }>>({
        success: true,
        data: { templateId: id },
      });
    } catch (error) {
      console.error('DELETE /api/templates/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

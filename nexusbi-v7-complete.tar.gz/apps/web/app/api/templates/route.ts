export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, DashTemplate, DashTemplateCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'template.view');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const category = searchParams.get('category');
  const search = searchParams.get('search');

  try {
    const templates = await withConnection(async (conn) => {
      let sql = `SELECT TEMPLATE_ID, TEMPLATE_NAME, DESCRIPTION, CATEGORY,
                        TAGS, REQUIRED_DS_TYPES, THUMBNAIL_URL, IS_GLOBAL,
                        PUBLISHED_BY, TENANT_ID, CREATED_AT, INSTALL_COUNT
                 FROM NB_DASH_TEMPLATES
                 WHERE (TENANT_ID = :tenantId OR IS_GLOBAL = 1)`;
      const binds: Record<string, unknown> = { tenantId: session.user.tenantId };

      if (category) {
        sql += ` AND CATEGORY = :category`;
        binds.category = category;
      }
      if (search) {
        sql += ` AND (UPPER(TEMPLATE_NAME) LIKE UPPER(:search) OR UPPER(TAGS) LIKE UPPER(:search))`;
        binds.search = `%${search}%`;
      }

      sql += ` ORDER BY INSTALL_COUNT DESC, TEMPLATE_NAME`;

      const result = await conn.execute<Record<string, unknown>>(sql, binds, { outFormat: 4002 });

      const list: Omit<DashTemplate, 'layoutJson' | 'widgetsJson'>[] = [];
      for (const row of result.rows || []) {
        list.push({
          templateId: row.TEMPLATE_ID as string,
          templateName: row.TEMPLATE_NAME as string,
          description: await clobToString(row.DESCRIPTION) || null,
          category: row.CATEGORY as string | null,
          tags: row.TAGS as string | null,
          requiredDsTypes: parseJsonClob<string[]>(await clobToString(row.REQUIRED_DS_TYPES)),
          thumbnailUrl: row.THUMBNAIL_URL as string | null,
          isGlobal: (row.IS_GLOBAL as number) === 1,
          publishedBy: row.PUBLISHED_BY as string,
          tenantId: row.TENANT_ID as string,
          createdAt: String(row.CREATED_AT),
          installCount: row.INSTALL_COUNT as number,
        } as any);
      }
      return list;
    });

    return NextResponse.json<ApiResponse<typeof templates>>({ success: true, data: templates });
  } catch (error) {
    console.error('GET /api/templates error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'template.publish', resourceType: 'template' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'template.publish');
    if (denied) return denied;

    let body: DashTemplateCreateInput;
    try {
      body = await request.json() as DashTemplateCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dashId || !body.templateName) {
      return invalidInputResponse('dashId and templateName are required');
    }

    try {
      // Load dashboard data
      const dash = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          LAYOUT_JSON: string;
          WIDGETS_JSON: string;
          APPROVAL_STATUS: string;
        }>(
          `SELECT DASH_ID, LAYOUT_JSON, WIDGETS_JSON, APPROVAL_STATUS
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND TENANT_ID = :tenantId`,
          { dashId: body.dashId, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dash) {
        return invalidInputResponse('Dashboard not found');
      }

      if (dash.APPROVAL_STATUS !== 'APPROVED') {
        return invalidInputResponse('Only APPROVED dashboards can be published as templates');
      }

      const templateId = generateId();
      const layoutJson = await clobToString(dash.LAYOUT_JSON);
      const widgetsJson = await clobToString(dash.WIDGETS_JSON);

      // Extract required DS types from widgets
      const widgets = parseJsonClob<Array<{ dsId?: string }>>(widgetsJson) || [];
      const dsIds = [...new Set(widgets.filter((w) => w.dsId).map((w) => w.dsId!))];

      let requiredDsTypes: string[] = [];
      if (dsIds.length > 0) {
        const dsTypes = await withConnection(async (conn) => {
          const result = await conn.execute<{ DS_TYPE: string }>(
            `SELECT DISTINCT DS_TYPE FROM NB_DATA_SOURCES
             WHERE DS_ID IN (${dsIds.map((_, i) => `:ds${i}`).join(',')})`,
            Object.fromEntries(dsIds.map((id, i) => [`ds${i}`, id])),
            { outFormat: 4002 },
          );
          return (result.rows || []).map((r) => r.DS_TYPE);
        });
        requiredDsTypes = dsTypes;
      }

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_DASH_TEMPLATES
             (TEMPLATE_ID, TEMPLATE_NAME, DESCRIPTION, CATEGORY, TAGS,
              LAYOUT_JSON, WIDGETS_JSON, REQUIRED_DS_TYPES,
              IS_GLOBAL, PUBLISHED_BY, TENANT_ID, CREATED_AT, INSTALL_COUNT)
           VALUES
             (:templateId, :templateName, :description, :category, :tags,
              :layoutJson, :widgetsJson, :requiredDsTypes,
              :isGlobal, :publishedBy, :tenantId, SYSTIMESTAMP, 0)`,
          {
            templateId,
            templateName: body.templateName,
            description: body.description ?? null,
            category: body.category ?? null,
            tags: body.tags ?? null,
            layoutJson: layoutJson || '{}',
            widgetsJson: widgetsJson || '[]',
            requiredDsTypes: requiredDsTypes.length > 0 ? JSON.stringify(requiredDsTypes) : null,
            isGlobal: body.isGlobal ? 1 : 0,
            publishedBy: user.id,
            tenantId: user.tenantId,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ templateId: string }>>(
        { success: true, data: { templateId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/templates error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

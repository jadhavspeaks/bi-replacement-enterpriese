export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, DsAccess, DsAccessInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'datasource.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const accessList = await withConnection(async (conn) => {
      const result = await conn.execute<{
        ACCESS_ID: string;
        DS_ID: string;
        ROLE_ID: string;
        CAN_QUERY: number;
        CAN_EXPORT: number;
        CAN_MANAGE: number;
        ROW_FILTER_SQL: string;
        COLUMN_BLACKLIST: string;
        GRANTED_AT: string;
        GRANTED_BY: string;
        EXPIRES_AT: string | null;
        ROLE_NAME: string;
      }>(
        `SELECT A.ACCESS_ID, A.DS_ID, A.ROLE_ID, A.CAN_QUERY, A.CAN_EXPORT,
                A.CAN_MANAGE, A.ROW_FILTER_SQL, A.COLUMN_BLACKLIST,
                A.GRANTED_AT, A.GRANTED_BY, A.EXPIRES_AT, R.ROLE_NAME
         FROM NB_DS_ACCESS A
         JOIN NB_ROLES R ON R.ROLE_ID = A.ROLE_ID
         JOIN NB_DATA_SOURCES D ON D.DS_ID = A.DS_ID
         WHERE A.DS_ID = :dsId AND D.TENANT_ID = :tenantId
         ORDER BY R.ROLE_NAME`,
        { dsId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      const list: (DsAccess & { roleName: string })[] = [];
      for (const row of result.rows || []) {
        list.push({
          accessId: row.ACCESS_ID,
          dsId: row.DS_ID,
          roleId: row.ROLE_ID,
          canQuery: row.CAN_QUERY === 1,
          canExport: row.CAN_EXPORT === 1,
          canManage: row.CAN_MANAGE === 1,
          rowFilterSql: await clobToString(row.ROW_FILTER_SQL) || null,
          columnBlacklist: await clobToString(row.COLUMN_BLACKLIST) || null,
          grantedAt: String(row.GRANTED_AT),
          grantedBy: row.GRANTED_BY,
          expiresAt: row.EXPIRES_AT ? String(row.EXPIRES_AT) : null,
          roleName: row.ROLE_NAME,
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<typeof accessList>>({
      success: true,
      data: accessList,
    });
  } catch (error) {
    console.error('GET /api/datasources/[id]/access error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'datasource.access.update', resourceType: 'datasource', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'datasource.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: DsAccessInput;
    try {
      body = await request.json() as DsAccessInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.roleId) {
      return invalidInputResponse('roleId is required');
    }

    try {
      // Verify datasource exists in org
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DS_ID: string }>(
          `SELECT DS_ID FROM NB_DATA_SOURCES WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
          { dsId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('Data source not found');

      await withTransaction(async (conn) => {
        // Upsert access record
        const existing = await conn.execute<{ ACCESS_ID: string }>(
          `SELECT ACCESS_ID FROM NB_DS_ACCESS
           WHERE DS_ID = :dsId AND ROLE_ID = :roleId`,
          { dsId: id, roleId: body.roleId },
          { outFormat: 4002 },
        );

        if (existing.rows && existing.rows.length > 0) {
          await conn.execute(
            `UPDATE NB_DS_ACCESS
             SET CAN_QUERY = :canQuery,
                 CAN_EXPORT = :canExport,
                 CAN_MANAGE = :canManage,
                 ROW_FILTER_SQL = :rowFilterSql,
                 COLUMN_BLACKLIST = :columnBlacklist,
                 EXPIRES_AT = :expiresAt,
                 GRANTED_BY = :grantedBy
             WHERE DS_ID = :dsId AND ROLE_ID = :roleId`,
            {
              dsId: id,
              roleId: body.roleId,
              canQuery: body.canQuery !== undefined ? (body.canQuery ? 1 : 0) : 1,
              canExport: body.canExport !== undefined ? (body.canExport ? 1 : 0) : 0,
              canManage: body.canManage !== undefined ? (body.canManage ? 1 : 0) : 0,
              rowFilterSql: body.rowFilterSql ?? null,
              columnBlacklist: body.columnBlacklist ? JSON.stringify(body.columnBlacklist) : null,
              expiresAt: body.expiresAt ?? null,
              grantedBy: user.id,
            },
          );
        } else {
          await conn.execute(
            `INSERT INTO NB_DS_ACCESS
               (ACCESS_ID, DS_ID, ROLE_ID, CAN_QUERY, CAN_EXPORT, CAN_MANAGE,
                ROW_FILTER_SQL, COLUMN_BLACKLIST, GRANTED_AT, GRANTED_BY, EXPIRES_AT)
             VALUES
               (:accessId, :dsId, :roleId, :canQuery, :canExport, :canManage,
                :rowFilterSql, :columnBlacklist, SYSTIMESTAMP, :grantedBy, :expiresAt)`,
            {
              accessId: generateId(),
              dsId: id,
              roleId: body.roleId,
              canQuery: body.canQuery !== undefined ? (body.canQuery ? 1 : 0) : 1,
              canExport: body.canExport !== undefined ? (body.canExport ? 1 : 0) : 0,
              canManage: body.canManage !== undefined ? (body.canManage ? 1 : 0) : 0,
              rowFilterSql: body.rowFilterSql ?? null,
              columnBlacklist: body.columnBlacklist ? JSON.stringify(body.columnBlacklist) : null,
              grantedBy: user.id,
              expiresAt: body.expiresAt ?? null,
            },
          );
        }
      });

      return NextResponse.json<ApiResponse<{ dsId: string; roleId: string }>>({
        success: true,
        data: { dsId: id, roleId: body.roleId },
      });
    } catch (error) {
      console.error('PUT /api/datasources/[id]/access error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

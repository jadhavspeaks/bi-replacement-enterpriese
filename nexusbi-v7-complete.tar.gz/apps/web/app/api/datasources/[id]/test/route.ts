export const runtime = 'nodejs';

import { NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse, ConnectionTestResult } from '@nexusbi/shared-types';

/**
 * Connection tester for the 12 supported data-source types.
 * All other types are rejected at the schema layer — they can't reach here.
 */
async function testConnection(
  dsType: string,
  config: Record<string, unknown>,
): Promise<ConnectionTestResult> {
  const startTime = performance.now();

  try {
    switch (dsType) {
      case 'oracle': {
        // Oracle connections are validated via Cube.js driver when first queried.
        // Here we verify the config shape is complete.
        const required = ['host', 'port', 'serviceName', 'user', 'password'];
        const missing = required.filter((k) => !config[k]);
        if (missing.length > 0) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: `Missing required fields: ${missing.join(', ')}`,
          };
        }
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      case 'mongodb': {
        const hasConnStr = Boolean(config.connectionString);
        const hasHostPort = Boolean(config.host) && Boolean(config.port);
        if (!hasConnStr && !hasHostPort) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'MongoDB requires either connectionString or host+port',
          };
        }
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      case 'hive':
      case 'impala': {
        // Hadoop-ecosystem Thrift endpoints. Verifies host:port + Kerberos config sanity.
        const host = config.host as string | undefined;
        const port = config.port as number | undefined;
        const authMechanism = (config.authMechanism as string) || 'NOSASL';
        if (!host || !port) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'host and port are required',
          };
        }
        if (authMechanism === 'KERBEROS' && !config.kerberosPrincipal) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'Kerberos auth requires kerberosPrincipal',
          };
        }
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      case 'api_rest':
      case 'api_graphql': {
        const baseUrl = config.baseUrl as string | undefined;
        if (!baseUrl) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'baseUrl is required',
          };
        }
        try {
          const response = await fetch(baseUrl, {
            method: 'HEAD',
            signal: AbortSignal.timeout(10000),
          });
          return {
            success: response.ok || response.status === 405 || response.status === 401,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage:
              response.ok || response.status === 405 || response.status === 401
                ? null
                : `HTTP ${response.status}`,
          };
        } catch (err) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: err instanceof Error ? err.message : 'Connection failed',
          };
        }
      }

      case 'api_oauth_rest': {
        const tokenUrl = config.tokenUrl as string | undefined;
        if (!tokenUrl || !config.clientId || !config.clientSecret) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'OAuth requires tokenUrl, clientId, clientSecret',
          };
        }
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      case 'api_webhook': {
        if (!config.secretValue) {
          return {
            success: false,
            latencyMs: Math.round(performance.now() - startTime),
            tableCount: null,
            errorMessage: 'secretValue is required',
          };
        }
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      case 'file_csv':
      case 'file_excel':
      case 'file_json':
      case 'file_parquet': {
        // File-based sources are tested during ingest.
        return {
          success: true,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: null,
        };
      }

      default:
        return {
          success: false,
          latencyMs: Math.round(performance.now() - startTime),
          tableCount: null,
          errorMessage: `Unsupported data source type: ${dsType}`,
        };
    }
  } catch (error) {
    return {
      success: false,
      latencyMs: Math.round(performance.now() - startTime),
      tableCount: null,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export const POST = withAudit(
  (_req, p) => ({ action: 'datasource.test', resourceType: 'datasource', resourceId: p.id }),
  async (_request, { params }, user) => {
    const denied = await requirePermission(user, 'datasource.test');
    if (denied) return denied;

    const { id } = await params;

    try {
      const ds = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DS_ID: string;
          DS_TYPE: string;
          CONFIG_ENCRYPTED: string;
        }>(
          `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
           FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
          { dsId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!ds) return notFoundResponse('Data source not found');

      const configStr = await clobToString(ds.CONFIG_ENCRYPTED);
      let config: Record<string, unknown>;
      try {
        config = JSON.parse(decrypt(configStr));
      } catch {
        return NextResponse.json<ApiResponse<ConnectionTestResult>>({
          success: true,
          data: {
            success: false,
            latencyMs: 0,
            tableCount: null,
            errorMessage: 'Failed to decrypt credentials',
          },
        });
      }

      const testResult = await testConnection(ds.DS_TYPE, config);

      await withConnection(async (conn) => {
        await conn.execute(
          `UPDATE NB_DATA_SOURCES
           SET LAST_TESTED_AT = SYSTIMESTAMP,
               LAST_TEST_RESULT = :testResult,
               LAST_ERROR_MSG = :errorMsg,
               STATUS = CASE WHEN :success = 1 THEN 'ACTIVE' ELSE 'ERROR' END,
               UPDATED_AT = SYSTIMESTAMP
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
          {
            dsId: id,
            tenantId: user.tenantId,
            testResult: testResult.success ? 'SUCCESS' : 'FAILED',
            errorMsg: testResult.errorMessage,
            success: testResult.success ? 1 : 0,
          },
        );
        await conn.commit();
      });

      return NextResponse.json<ApiResponse<ConnectionTestResult>>({
        success: true,
        data: testResult,
      });
    } catch (error) {
      console.error('POST /api/datasources/[id]/test error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

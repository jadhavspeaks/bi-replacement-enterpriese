export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString } from '@/lib/oracle-pool';
import { encryptJson, maskConfig } from '@/lib/encryption';
import { validateDsConfig } from '@/lib/datasource-schemas';
import type { ApiResponse, DataSource, DataSourceUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'datasource.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const ds = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT DS_ID, DS_NAME, DS_TYPE, DESCRIPTION, CONFIG_MASKED,
                STATUS, LAST_TESTED_AT, LAST_TEST_RESULT, LAST_ERROR_MSG,
                CUBE_DS_ID, TENANT_ID, CREATED_BY, CREATED_AT, UPDATED_AT, IS_ACTIVE
         FROM NB_DATA_SOURCES
         WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
        { dsId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        dsId: row.DS_ID as string,
        dsName: row.DS_NAME as string,
        dsType: row.DS_TYPE as string,
        description: await clobToString(row.DESCRIPTION) || null,
        configEncrypted: '',
        configMasked: await clobToString(row.CONFIG_MASKED) || null,
        status: row.STATUS as string,
        lastTestedAt: row.LAST_TESTED_AT ? String(row.LAST_TESTED_AT) : null,
        lastTestResult: row.LAST_TEST_RESULT as string | null,
        lastErrorMsg: await clobToString(row.LAST_ERROR_MSG) || null,
        cubeDsId: row.CUBE_DS_ID as string | null,
        tenantId: row.TENANT_ID as string,
        createdBy: row.CREATED_BY as string,
        createdAt: String(row.CREATED_AT),
        updatedAt: String(row.UPDATED_AT),
        isActive: (row.IS_ACTIVE as number) === 1,
      } as DataSource;
    });

    if (!ds) return notFoundResponse('Data source not found');

    return NextResponse.json<ApiResponse<DataSource>>({ success: true, data: ds });
  } catch (error) {
    console.error('GET /api/datasources/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'datasource.update', resourceType: 'datasource', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'datasource.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: DataSourceUpdateInput;
    try {
      body = await request.json() as DataSourceUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await withConnection(async (conn) => {
        const result = await conn.execute<{ DS_ID: string; DS_TYPE: string }>(
          `SELECT DS_ID, DS_TYPE FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
          { dsId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!existing) return notFoundResponse('Data source not found');

      if (body.config) {
        const validation = validateDsConfig(existing.DS_TYPE as any, body.config);
        if (!validation.success) {
          return invalidInputResponse('Invalid configuration', {
            errors: (validation as any).error.errors,
          });
        }
      }

      await withTransaction(async (conn) => {
        const setClauses: string[] = ['UPDATED_AT = SYSTIMESTAMP'];
        const binds: Record<string, unknown> = { dsId: id, tenantId: user.tenantId };

        if (body.dsName !== undefined) {
          setClauses.push('DS_NAME = :dsName');
          binds.dsName = body.dsName;
        }
        if (body.description !== undefined) {
          setClauses.push('DESCRIPTION = :description');
          binds.description = body.description;
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }
        if (body.config) {
          setClauses.push('CONFIG_ENCRYPTED = :configEncrypted');
          setClauses.push('CONFIG_MASKED = :configMasked');
          binds.configEncrypted = encryptJson(body.config as Record<string, unknown>);
          binds.configMasked = JSON.stringify(maskConfig(body.config as Record<string, unknown>));
        }

        await conn.execute(
          `UPDATE NB_DATA_SOURCES SET ${setClauses.join(', ')}
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId`,
          binds,
        );
      });

      return NextResponse.json<ApiResponse<{ dsId: string }>>({
        success: true,
        data: { dsId: id },
      });
    } catch (error) {
      console.error('PUT /api/datasources/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'datasource.delete', resourceType: 'datasource', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'datasource.delete');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `UPDATE NB_DATA_SOURCES
           SET IS_ACTIVE = 0, STATUS = 'INACTIVE', UPDATED_AT = SYSTIMESTAMP
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
          { dsId: id, tenantId: user.tenantId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Data source not found');

      return NextResponse.json<ApiResponse<{ dsId: string }>>({
        success: true,
        data: { dsId: id },
      });
    } catch (error) {
      console.error('DELETE /api/datasources/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

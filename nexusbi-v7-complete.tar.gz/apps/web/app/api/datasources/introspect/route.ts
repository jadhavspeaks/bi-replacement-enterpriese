export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse, IntrospectionResult, IntrospectedTable, IntrospectedColumn } from '@nexusbi/shared-types';

async function introspectOracle(config: Record<string, unknown>): Promise<IntrospectedTable[]> {
  const oracledb = await import('oracledb');
  let conn;

  try {
    conn = await oracledb.default.getConnection({
      user: config.user as string,
      password: config.password as string,
      connectString: `${config.host}:${config.port}/${config.serviceName}`,
    });

    const tablesResult = await conn.execute<{
      TABLE_NAME: string;
      NUM_ROWS: number | null;
    }>(
      `SELECT TABLE_NAME, NUM_ROWS
       FROM ALL_TABLES
       WHERE OWNER = UPPER(:schema)
       ORDER BY TABLE_NAME`,
      { schema: config.schema || config.user },
      { outFormat: 4002 },
    );

    const tables: IntrospectedTable[] = [];

    for (const tableRow of tablesResult.rows || []) {
      const colsResult = await conn.execute<{
        COLUMN_NAME: string;
        DATA_TYPE: string;
        NULLABLE: string;
        DATA_LENGTH: number;
        DATA_PRECISION: number | null;
        DATA_SCALE: number | null;
        DATA_DEFAULT: string | null;
      }>(
        `SELECT COLUMN_NAME, DATA_TYPE, NULLABLE, DATA_LENGTH,
                DATA_PRECISION, DATA_SCALE, DATA_DEFAULT
         FROM ALL_TAB_COLUMNS
         WHERE TABLE_NAME = :tableName
           AND OWNER = UPPER(:schema)
         ORDER BY COLUMN_ID`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      // Get primary keys
      const pkResult = await conn.execute<{ COLUMN_NAME: string }>(
        `SELECT CC.COLUMN_NAME
         FROM ALL_CONSTRAINTS C
         JOIN ALL_CONS_COLUMNS CC ON CC.CONSTRAINT_NAME = C.CONSTRAINT_NAME
           AND CC.OWNER = C.OWNER
         WHERE C.TABLE_NAME = :tableName
           AND C.OWNER = UPPER(:schema)
           AND C.CONSTRAINT_TYPE = 'P'`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      const pkColumns = new Set((pkResult.rows || []).map((r) => r.COLUMN_NAME));

      // Get foreign keys
      const fkResult = await conn.execute<{
        COLUMN_NAME: string;
        R_TABLE_NAME: string;
        R_COLUMN_NAME: string;
      }>(
        `SELECT CC.COLUMN_NAME, RC.TABLE_NAME AS R_TABLE_NAME, RCC.COLUMN_NAME AS R_COLUMN_NAME
         FROM ALL_CONSTRAINTS C
         JOIN ALL_CONS_COLUMNS CC ON CC.CONSTRAINT_NAME = C.CONSTRAINT_NAME AND CC.OWNER = C.OWNER
         JOIN ALL_CONSTRAINTS RC ON RC.CONSTRAINT_NAME = C.R_CONSTRAINT_NAME AND RC.OWNER = C.R_OWNER
         JOIN ALL_CONS_COLUMNS RCC ON RCC.CONSTRAINT_NAME = RC.CONSTRAINT_NAME AND RCC.OWNER = RC.OWNER
         WHERE C.TABLE_NAME = :tableName
           AND C.OWNER = UPPER(:schema)
           AND C.CONSTRAINT_TYPE = 'R'`,
        {
          tableName: tableRow.TABLE_NAME,
          schema: config.schema || config.user,
        },
        { outFormat: 4002 },
      );

      const fkMap = new Map<string, { table: string; column: string }>();
      for (const fk of fkResult.rows || []) {
        fkMap.set(fk.COLUMN_NAME, {
          table: fk.R_TABLE_NAME,
          column: fk.R_COLUMN_NAME,
        });
      }

      const columns: IntrospectedColumn[] = (colsResult.rows || []).map((col) => {
        const fk = fkMap.get(col.COLUMN_NAME);
        return {
          columnName: col.COLUMN_NAME,
          dataType: col.DATA_TYPE,
          nullable: col.NULLABLE === 'Y',
          isPrimaryKey: pkColumns.has(col.COLUMN_NAME),
          isForeignKey: fkMap.has(col.COLUMN_NAME),
          referencedTable: fk?.table,
          referencedColumn: fk?.column,
          defaultValue: col.DATA_DEFAULT ?? undefined,
          characterMaxLength: col.DATA_LENGTH,
          numericPrecision: col.DATA_PRECISION ?? undefined,
          numericScale: col.DATA_SCALE ?? undefined,
        };
      });

      tables.push({
        tableName: tableRow.TABLE_NAME,
        schemaName: (config.schema || config.user) as string,
        estimatedRowCount: tableRow.NUM_ROWS,
        columns,
      });
    }

    return tables;
  } finally {
    if (conn) {
      try { await conn.close(); } catch { /* ignore */ }
    }
  }
}

export const POST = withAudit(
  { action: 'schema.autogenerate', resourceType: 'datasource' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'schema.autogenerate');
    if (denied) return denied;

    let body: { dsId: string };
    try {
      body = await request.json() as { dsId: string };
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsId) {
      return invalidInputResponse('dsId is required');
    }

    try {
      const ds = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DS_ID: string;
          DS_TYPE: string;
          CONFIG_ENCRYPTED: string;
        }>(
          `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
           FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND TENANT_ID = :tenantId AND IS_ACTIVE = 1`,
          { dsId: body.dsId, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!ds) return invalidInputResponse('Data source not found');

      const configStr = await clobToString(ds.CONFIG_ENCRYPTED);
      const config = JSON.parse(decrypt(configStr));

      let tables: IntrospectedTable[];

      switch (ds.DS_TYPE) {
        case 'oracle':
          tables = await introspectOracle(config);
          break;
        default:
          // For other types, return empty introspection with guidance
          tables = [];
          break;
      }

      const result: IntrospectionResult = {
        dsId: body.dsId,
        tables,
        introspectedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<IntrospectionResult>>({
        success: true,
        data: result,
      });
    } catch (error) {
      console.error('POST /api/datasources/introspect error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

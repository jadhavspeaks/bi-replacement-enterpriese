export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, ScheduledReport, ScheduledReportCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'report.schedule');
  if (denied) return denied;

  try {
    const reports = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT R.REPORT_ID, R.DASH_ID, R.REPORT_NAME, R.CRON_EXPRESSION,
                R.DELIVERY_TYPE, R.DELIVERY_CONFIG, R.IS_ACTIVE,
                R.LAST_RUN_AT, R.LAST_RUN_STATUS, R.NEXT_RUN_AT,
                R.CREATED_BY, R.CREATED_AT, D.DASH_NAME
         FROM NB_SCHEDULED_REPORTS R
         JOIN NB_DASHBOARDS D ON D.DASH_ID = R.DASH_ID
         WHERE D.TENANT_ID = :tenantId
         ORDER BY R.REPORT_NAME`,
        { tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      const list: (ScheduledReport & { dashName: string })[] = [];
      for (const row of result.rows || []) {
        list.push({
          reportId: row.REPORT_ID as string,
          dashId: row.DASH_ID as string,
          reportName: row.REPORT_NAME as string,
          cronExpression: row.CRON_EXPRESSION as string,
          deliveryType: row.DELIVERY_TYPE as ScheduledReport['deliveryType'],
          deliveryConfig: parseJsonClob(await clobToString(row.DELIVERY_CONFIG)) as ScheduledReport['deliveryConfig'],
          isActive: (row.IS_ACTIVE as number) === 1,
          lastRunAt: row.LAST_RUN_AT ? String(row.LAST_RUN_AT) : null,
          lastRunStatus: row.LAST_RUN_STATUS as string | null,
          nextRunAt: row.NEXT_RUN_AT ? String(row.NEXT_RUN_AT) : null,
          createdBy: row.CREATED_BY as string,
          createdAt: String(row.CREATED_AT),
          dashName: row.DASH_NAME as string,
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<typeof reports>>({ success: true, data: reports });
  } catch (error) {
    console.error('GET /api/reports error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'report.create', resourceType: 'report' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'report.schedule');
    if (denied) return denied;

    let body: ScheduledReportCreateInput;
    try {
      body = await request.json() as ScheduledReportCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dashId || !body.reportName || !body.cronExpression || !body.deliveryType || !body.deliveryConfig) {
      return invalidInputResponse('dashId, reportName, cronExpression, deliveryType, and deliveryConfig are required');
    }

    try {
      const reportId = generateId();

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_SCHEDULED_REPORTS
             (REPORT_ID, DASH_ID, REPORT_NAME, CRON_EXPRESSION,
              DELIVERY_TYPE, DELIVERY_CONFIG, IS_ACTIVE,
              CREATED_BY, CREATED_AT)
           VALUES
             (:reportId, :dashId, :reportName, :cronExpression,
              :deliveryType, :deliveryConfig, 1,
              :createdBy, SYSTIMESTAMP)`,
          {
            reportId,
            dashId: body.dashId,
            reportName: body.reportName,
            cronExpression: body.cronExpression,
            deliveryType: body.deliveryType,
            deliveryConfig: JSON.stringify(body.deliveryConfig),
            createdBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ reportId: string }>>(
        { success: true, data: { reportId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/reports error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withTransaction, generateId } from '@/lib/oracle-pool';
import { uploadFile, buildObjectName, BUCKETS } from '@/lib/storage';
import type { ApiResponse, FileUploadResult } from '@nexusbi/shared-types';

const MAX_FILE_SIZE = 500 * 1024 * 1024; // 500MB

const MIME_TO_TYPE: Record<string, string> = {
  'text/csv': 'csv',
  'application/vnd.ms-excel': 'excel',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': 'excel',
  'application/parquet': 'parquet',
  'application/x-parquet': 'parquet',
  'application/json': 'json',
  'text/plain': 'csv',
};

function detectFileType(filename: string, mimeType: string): string {
  const ext = filename.split('.').pop()?.toLowerCase();
  if (ext === 'csv') return 'csv';
  if (ext === 'xlsx' || ext === 'xls') return 'excel';
  if (ext === 'parquet') return 'parquet';
  if (ext === 'json') return 'json';
  return MIME_TO_TYPE[mimeType] || 'csv';
}

export const POST = withAudit(
  { action: 'file.upload', resourceType: 'file' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'file.upload');
    if (denied) return denied;

    try {
      const formData = await request.formData();
      const file = formData.get('file') as File | null;

      if (!file) {
        return invalidInputResponse('No file provided');
      }

      if (file.size > MAX_FILE_SIZE) {
        return invalidInputResponse(`File size exceeds maximum of ${MAX_FILE_SIZE / (1024 * 1024)}MB`);
      }

      const fileType = detectFileType(file.name, file.type);
      const fileId = generateId();
      const objectName = buildObjectName(user.tenantId, 'uploads', `${fileId}_${file.name}`);

      const buffer = Buffer.from(await file.arrayBuffer());
      const minioPath = await uploadFile(
        BUCKETS.files,
        objectName,
        buffer,
        buffer.length,
        file.type,
      );

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_FILE_INGESTIONS
             (FILE_ID, ORIGINAL_NAME, FILE_TYPE, FILE_SIZE_BYTES,
              MINIO_PATH, INGEST_STATUS, UPLOADED_BY, TENANT_ID, CREATED_AT)
           VALUES
             (:fileId, :originalName, :fileType, :fileSizeBytes,
              :minioPath, 'UPLOADED', :uploadedBy, :tenantId, SYSTIMESTAMP)`,
          {
            fileId,
            originalName: file.name,
            fileType,
            fileSizeBytes: file.size,
            minioPath,
            uploadedBy: user.id,
            tenantId: user.tenantId,
          },
        );
      });

      const result: FileUploadResult = {
        fileId,
        originalName: file.name,
        fileType,
        fileSizeBytes: file.size,
        minioPath,
        ingestStatus: 'UPLOADED',
      };

      return NextResponse.json<ApiResponse<FileUploadResult>>(
        { success: true, data: result },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/files/upload error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

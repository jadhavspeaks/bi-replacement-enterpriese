export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection } from '@/lib/oracle-pool';
import { ingestFile } from '@/lib/file-ingest';
import type { ApiResponse, IngestResult, IngestOptions } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'file.ingest', resourceType: 'file', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'file.upload');
    if (denied) return denied;

    const { id } = await params;

    let options: IngestOptions = {};
    try {
      const body = await request.json();
      options = body as IngestOptions;
    } catch {
      // No options provided, use defaults
    }

    try {
      const file = await withConnection(async (conn) => {
        const result = await conn.execute<{
          FILE_ID: string;
          FILE_TYPE: string;
          MINIO_PATH: string | null;
          INGEST_STATUS: string;
        }>(
          `SELECT FILE_ID, FILE_TYPE, MINIO_PATH, INGEST_STATUS
           FROM NB_FILE_INGESTIONS
           WHERE FILE_ID = :fileId AND TENANT_ID = :tenantId`,
          { fileId: id, tenantId: user.tenantId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!file) return notFoundResponse('File not found');

      if (!file.MINIO_PATH) {
        return invalidInputResponse('File has not been uploaded to storage');
      }

      if (file.INGEST_STATUS === 'INGESTING') {
        return invalidInputResponse('File is already being ingested');
      }

      const result = await ingestFile(
        id,
        file.MINIO_PATH,
        file.FILE_TYPE,
        user.tenantId,
        options,
      );

      return NextResponse.json<ApiResponse<IngestResult>>({
        success: true,
        data: result,
      });
    } catch (error) {
      console.error('POST /api/files/[id]/ingest error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, FileIngestion } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const { id } = await params;

  try {
    const ingestion = await withConnection(async (conn) => {
      const result = await conn.execute<{
        FILE_ID: string;
        ORIGINAL_NAME: string;
        FILE_TYPE: string;
        FILE_SIZE_BYTES: number | null;
        MINIO_PATH: string | null;
        STAGING_TABLE: string | null;
        INGEST_STATUS: string;
        ROW_COUNT: number | null;
        COLUMN_SCHEMA: string;
        ERROR_MESSAGE: string;
        UPLOADED_BY: string;
        TENANT_ID: string;
        CREATED_AT: string;
        COMPLETED_AT: string | null;
      }>(
        `SELECT FILE_ID, ORIGINAL_NAME, FILE_TYPE, FILE_SIZE_BYTES,
                MINIO_PATH, STAGING_TABLE, INGEST_STATUS, ROW_COUNT,
                COLUMN_SCHEMA, ERROR_MESSAGE, UPLOADED_BY, TENANT_ID,
                CREATED_AT, COMPLETED_AT
         FROM NB_FILE_INGESTIONS
         WHERE FILE_ID = :fileId AND TENANT_ID = :tenantId`,
        { fileId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      const columnSchemaStr = await clobToString(row.COLUMN_SCHEMA);
      const errorMessageStr = await clobToString(row.ERROR_MESSAGE);

      return {
        fileId: row.FILE_ID,
        originalName: row.ORIGINAL_NAME,
        fileType: row.FILE_TYPE,
        fileSizeBytes: row.FILE_SIZE_BYTES,
        minioPath: row.MINIO_PATH,
        stagingTable: row.STAGING_TABLE,
        ingestStatus: row.INGEST_STATUS as FileIngestion['ingestStatus'],
        rowCount: row.ROW_COUNT,
        columnSchema: parseJsonClob(columnSchemaStr),
        errorMessage: errorMessageStr || null,
        uploadedBy: row.UPLOADED_BY,
        tenantId: row.TENANT_ID,
        createdAt: String(row.CREATED_AT),
        completedAt: row.COMPLETED_AT ? String(row.COMPLETED_AT) : null,
      } as FileIngestion;
    });

    if (!ingestion) return notFoundResponse('File not found');

    return NextResponse.json<ApiResponse<FileIngestion>>({
      success: true,
      data: ingestion,
    });
  } catch (error) {
    console.error('GET /api/files/[id] error:', error);
    return internalErrorResponse();
  }
}

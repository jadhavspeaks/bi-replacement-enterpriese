import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withConnection } from '@/lib/oracle-pool';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { generateId } from '@nexusbi/shared-types';

const CreateSchema = z.object({
  subscriptionType: z.enum(['dashboard','widget','story']),
  targetId: z.string().min(1),
  name: z.string().min(1).max(300),
  cronExpression: z.string().min(1),
  timezone: z.string().optional(),
  deliveryChannels: z.array(z.enum(['email','webhook','slack','teams'])),
  recipients: z.array(z.string()),
  renderFormat: z.enum(['png','pdf','csv','xlsx','html']),
  filterOverrides: z.record(z.any()).optional(),
  emailSubject: z.string().optional(),
  emailBody: z.string().optional(),
});

export const GET = withAudit(
  () => ({ action: 'subscription.list', resourceType: 'subscription' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'subscription.manage');
    const rows = await withConnection(async (conn) => {
      const r = await conn.execute<{
        SUBSCRIPTION_ID: string; SUBSCRIPTION_TYPE: string; TARGET_ID: string;
        SUB_NAME: string; CRON_EXPRESSION: string; RENDER_FORMAT: string;
        DELIVERY_CHANNELS: string; RECIPIENTS: string; IS_ENABLED: number;
        LAST_DELIVERED_AT: Date | null; LAST_STATUS: string | null;
      }>(
        `SELECT SUBSCRIPTION_ID, SUBSCRIPTION_TYPE, TARGET_ID, SUB_NAME, CRON_EXPRESSION,
                RENDER_FORMAT, DELIVERY_CHANNELS, RECIPIENTS, IS_ENABLED,
                LAST_DELIVERED_AT, LAST_STATUS
         FROM NB_SUBSCRIPTIONS WHERE OWNER_ID = :o AND TENANT_ID = :org
         ORDER BY CREATED_AT DESC`,
        { o: user.userId, org: user.tenantId }, { outFormat: 4002 },
      );
      return r.rows ?? [];
    });
    return NextResponse.json({
      subscriptions: rows.map((r) => ({
        subscriptionId: r.SUBSCRIPTION_ID, subscriptionType: r.SUBSCRIPTION_TYPE,
        targetId: r.TARGET_ID, name: r.SUB_NAME, cronExpression: r.CRON_EXPRESSION,
        renderFormat: r.RENDER_FORMAT,
        deliveryChannels: JSON.parse(r.DELIVERY_CHANNELS),
        recipients: JSON.parse(r.RECIPIENTS),
        isEnabled: r.IS_ENABLED === 1,
        lastDeliveredAt: r.LAST_DELIVERED_AT?.toISOString() ?? null,
        lastStatus: r.LAST_STATUS,
      })),
    });
  },
);

export const POST = withAudit(
  () => ({ action: 'subscription.create', resourceType: 'subscription' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'subscription.manage');
    const body = CreateSchema.parse(await request.json());
    const id = generateId('SUB');
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_SUBSCRIPTIONS (SUBSCRIPTION_ID, SUBSCRIPTION_TYPE, TARGET_ID,
          OWNER_ID, TENANT_ID, SUB_NAME, CRON_EXPRESSION, TIMEZONE, DELIVERY_CHANNELS,
          RECIPIENTS, RENDER_FORMAT, FILTER_OVERRIDES, EMAIL_SUBJECT, EMAIL_BODY, IS_ENABLED)
         VALUES (:id, :t, :tgt, :o, :org, :n, :cron, :tz, :dc, :r, :rf, :fo, :es, :eb, 1)`,
        {
          id, t: body.subscriptionType, tgt: body.targetId,
          o: user.userId, org: user.tenantId,
          n: body.name, cron: body.cronExpression, tz: body.timezone ?? 'UTC',
          dc: JSON.stringify(body.deliveryChannels), r: JSON.stringify(body.recipients),
          rf: body.renderFormat, fo: body.filterOverrides ? JSON.stringify(body.filterOverrides) : null,
          es: body.emailSubject ?? null, eb: body.emailBody ?? null,
        },
      );
      await conn.commit();
    });
    return NextResponse.json({ subscriptionId: id }, { status: 201 });
  },
);

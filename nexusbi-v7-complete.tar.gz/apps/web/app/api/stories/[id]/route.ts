export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, Story, StoryPoint, StoryPointCreateInput } from '@nexusbi/shared-types';

async function loadStoryPoints(storyId: string): Promise<StoryPoint[]> {
  return withConnection(async (conn) => {
    const r = await conn.execute<Record<string, unknown>>(
      `SELECT POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE,
              DASH_ID, WORKSHEET_ID, CONTENT_JSON, FILTER_OVERRIDES
       FROM NB_STORY_POINTS WHERE STORY_ID = :sid ORDER BY SORT_ORDER`,
      { sid: storyId }, { outFormat: 4002 },
    );
    const list: StoryPoint[] = [];
    for (const row of r.rows || []) {
      const contentStr = await clobToString(row.CONTENT_JSON);
      const filterStr = await clobToString(row.FILTER_OVERRIDES);
      list.push({
        pointId: row.POINT_ID as string,
        storyId: row.STORY_ID as string,
        sortOrder: row.SORT_ORDER as number,
        pointType: row.POINT_TYPE as StoryPoint['pointType'],
        title: row.TITLE as string,
        narrative: await clobToString(row.NARRATIVE) || null,
        dashId: (row.DASH_ID as string) || null,
        worksheetId: (row.WORKSHEET_ID as string) || null,
        contentJson: contentStr ? (JSON.parse(contentStr) as Record<string, unknown>) : null,
        filterOverrides: filterStr ? (JSON.parse(filterStr) as Record<string, unknown>) : null,
      });
    }
    return list;
  });
}

async function loadStory(storyId: string, tenantId: string): Promise<Story | null> {
  const story = await withConnection(async (conn) => {
    const r = await conn.execute<Record<string, unknown>>(
      `SELECT STORY_ID, STORY_NAME, DESCRIPTION, OWNER_ID, TENANT_ID, IS_PUBLISHED, VERSION, CREATED_AT, UPDATED_AT
       FROM NB_STORIES WHERE STORY_ID = :id AND TENANT_ID = :tenantId`,
      { id: storyId, tenantId }, { outFormat: 4002 },
    );
    if (!r.rows || r.rows.length === 0) return null;
    const row = r.rows[0];
    return {
      storyId: row.STORY_ID as string,
      storyName: row.STORY_NAME as string,
      description: await clobToString(row.DESCRIPTION) || null,
      ownerId: row.OWNER_ID as string,
      tenantId: row.TENANT_ID as string,
      isPublished: (row.IS_PUBLISHED as number) === 1,
      version: row.VERSION as number,
      storyPoints: [] as StoryPoint[],
      createdAt: String(row.CREATED_AT),
      updatedAt: String(row.UPDATED_AT),
    } as Story;
  });
  if (!story) return null;
  story.storyPoints = await loadStoryPoints(storyId);
  return story;
}

export async function GET(
  _request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'story.view');
  if (denied) return denied;

  const { id } = await params;
  try {
    const story = await loadStory(id, session.user.tenantId);
    if (!story) return notFoundResponse('Story not found');
    if (!story.isPublished && story.ownerId !== session.user.id) {
      return notFoundResponse('Story not found');
    }
    return NextResponse.json<ApiResponse<Story>>({ success: true, data: story });
  } catch (error) {
    console.error('GET /api/stories/[id] error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  (_req, p) => ({ action: 'story.add_point', resourceType: 'story', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'story.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: StoryPointCreateInput;
    try {
      body = await request.json() as StoryPointCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.pointType || !body.title) {
      return invalidInputResponse('pointType and title are required');
    }

    try {
      const story = await loadStory(id, user.tenantId);
      if (!story) return notFoundResponse('Story not found');
      if (story.ownerId !== user.id) return notFoundResponse('Story not found');

      const pointId = generateId();

      await withTransaction(async (conn) => {
        const orderResult = await conn.execute<{ MX: number }>(
          `SELECT NVL(MAX(SORT_ORDER), -1) AS MX FROM NB_STORY_POINTS WHERE STORY_ID = :id`,
          { id }, { outFormat: 4002 },
        );
        const newOrder = ((orderResult.rows?.[0]?.MX ?? -1) as number) + 1;

        await conn.execute(
          `INSERT INTO NB_STORY_POINTS (POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE, DASH_ID, WORKSHEET_ID, CONTENT_JSON, FILTER_OVERRIDES)
           VALUES (:pid, :sid, :ord, :pt, :title, :narr, :dash, :wsid, :content, :filters)`,
          {
            pid: pointId, sid: id, ord: newOrder,
            pt: body.pointType, title: body.title.trim(),
            narr: body.narrative || null,
            dash: body.dashId || null, wsid: body.worksheetId || null,
            content: body.contentJson ? JSON.stringify(body.contentJson) : null,
            filters: body.filterOverrides ? JSON.stringify(body.filterOverrides) : null,
          },
        );
        await conn.execute(`UPDATE NB_STORIES SET UPDATED_AT = SYSTIMESTAMP, VERSION = VERSION + 1 WHERE STORY_ID = :id`, { id });
      });

      const updated = await loadStory(id, user.tenantId);
      return NextResponse.json<ApiResponse<Story>>({ success: true, data: updated! }, { status: 201 });
    } catch (error) {
      console.error('POST /api/stories/[id] error:', error);
      return internalErrorResponse();
    }
  },
);

export const PUT = withAudit(
  (_req, p) => ({ action: 'story.update', resourceType: 'story', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'story.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: { storyName?: string; description?: string; isPublished?: boolean };
    try {
      body = await request.json() as typeof body;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await loadStory(id, user.tenantId);
      if (!existing) return notFoundResponse('Story not found');
      if (existing.ownerId !== user.id) return notFoundResponse('Story not found');

      await withConnection(async (conn) => {
        const sets: string[] = ['UPDATED_AT = SYSTIMESTAMP', 'VERSION = VERSION + 1'];
        const binds: Record<string, unknown> = { id };
        if (body.storyName !== undefined) { sets.push('STORY_NAME = :name'); binds.name = body.storyName.trim(); }
        if (body.description !== undefined) { sets.push('DESCRIPTION = :desc'); binds.desc = body.description; }
        if (body.isPublished !== undefined) { sets.push('IS_PUBLISHED = :pub'); binds.pub = body.isPublished ? 1 : 0; }
        await conn.execute(`UPDATE NB_STORIES SET ${sets.join(', ')} WHERE STORY_ID = :id`, binds);
        await conn.commit();
      });

      const updated = await loadStory(id, user.tenantId);
      return NextResponse.json<ApiResponse<Story>>({ success: true, data: updated! });
    } catch (error) {
      console.error('PUT /api/stories/[id] error:', error);
      return internalErrorResponse();
    }
  },
);

export const DELETE = withAudit(
  (_req, p) => ({ action: 'story.delete', resourceType: 'story', resourceId: p.id }),
  async (_request, { params }, user) => {
    const denied = await requirePermission(user, 'story.edit');
    if (denied) return denied;

    const { id } = await params;
    try {
      const existing = await loadStory(id, user.tenantId);
      if (!existing) return notFoundResponse('Story not found');
      if (existing.ownerId !== user.id) return notFoundResponse('Story not found');

      await withConnection(async (conn) => {
        await conn.execute(`DELETE FROM NB_STORIES WHERE STORY_ID = :id AND OWNER_ID = :userId`, { id, userId: user.id });
        await conn.commit();
      });

      return NextResponse.json<ApiResponse<{ deleted: boolean }>>({ success: true, data: { deleted: true } });
    } catch (error) {
      console.error('DELETE /api/stories/[id] error:', error);
      return internalErrorResponse();
    }
  },
);

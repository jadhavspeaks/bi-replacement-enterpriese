export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withTransaction, generateId } from '@/lib/oracle-pool';
import { uploadFile, buildObjectName, BUCKETS } from '@/lib/storage';
import { importTwbx, convertWorksheetsToWidgets } from '@/lib/tableau-import';
import type { ApiResponse, TableauImport } from '@nexusbi/shared-types';

export const POST = withAudit(
  { action: 'tableau.import', resourceType: 'tableau_import' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'tableau.import');
    if (denied) return denied;

    try {
      const formData = await request.formData();
      const file = formData.get('file') as File | null;

      if (!file) {
        return invalidInputResponse('No file provided');
      }

      if (!file.name.endsWith('.twbx')) {
        return invalidInputResponse('File must be a .twbx Tableau workbook');
      }

      const importId = generateId();
      const objectName = buildObjectName(user.tenantId, 'tableau', `${importId}_${file.name}`);
      const buffer = Buffer.from(await file.arrayBuffer());

      // Upload to MinIO
      const minioPath = await uploadFile(
        BUCKETS.tableau,
        objectName,
        buffer,
        buffer.length,
        'application/octet-stream',
      );

      // Create import record
      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_TABLEAU_IMPORTS
             (IMPORT_ID, ORIGINAL_NAME, MINIO_PATH, IMPORT_STATUS,
              IMPORTED_BY, TENANT_ID, CREATED_AT)
           VALUES
             (:importId, :originalName, :minioPath, 'PROCESSING',
              :importedBy, :tenantId, SYSTIMESTAMP)`,
          {
            importId,
            originalName: file.name,
            minioPath,
            importedBy: user.id,
            tenantId: user.tenantId,
          },
        );
      });

      // Parse the .twbx file
      try {
        const parseResult = await importTwbx(minioPath);
        const widgets = convertWorksheetsToWidgets(
          parseResult.worksheets,
          parseResult.dashboardLayout,
        );

        // Create dashboard from imported worksheets
        const dashId = generateId();
        const warnings: string[] = [];
        const unmapped = parseResult.worksheets
          .filter((ws) => ws.measures.length === 0 && ws.dimensions.length === 0)
          .map((ws) => ({
            worksheetName: ws.worksheetName,
            fieldName: '',
            reason: 'No measures or dimensions detected',
          }));

        if (unmapped.length > 0) {
          warnings.push(`${unmapped.length} worksheets had no detectable fields`);
        }

        await withTransaction(async (conn) => {
          // Create dashboard
          await conn.execute(
            `INSERT INTO NB_DASHBOARDS
               (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON,
                OWNER_ID, TENANT_ID, SOURCE, CREATED_AT, UPDATED_AT)
             VALUES
               (:dashId, :dashName, :description, :layoutJson, :widgetsJson,
                :ownerId, :tenantId, 'TABLEAU_IMPORT', SYSTIMESTAMP, SYSTIMESTAMP)`,
            {
              dashId,
              dashName: `Imported: ${file.name.replace('.twbx', '')}`,
              description: `Imported from Tableau workbook ${file.name}`,
              layoutJson: JSON.stringify({
                cols: 12,
                rowHeight: 40,
                margin: [10, 10],
                containerPadding: [10, 10],
                compactType: 'vertical',
              }),
              widgetsJson: JSON.stringify(widgets),
              ownerId: user.id,
              tenantId: user.tenantId,
            },
          );

          // Update import record
          await conn.execute(
            `UPDATE NB_TABLEAU_IMPORTS
             SET IMPORT_STATUS = 'COMPLETE',
                 DASH_ID = :dashId,
                 WIDGETS_CREATED = :widgetsCreated,
                 WARNINGS = :warnings,
                 UNMAPPED_ITEMS = :unmappedItems,
                 COMPLETED_AT = SYSTIMESTAMP
             WHERE IMPORT_ID = :importId`,
            {
              importId,
              dashId,
              widgetsCreated: widgets.length,
              warnings: warnings.length > 0 ? JSON.stringify(warnings) : null,
              unmappedItems: unmapped.length > 0 ? JSON.stringify(unmapped) : null,
            },
          );
        });

        const result: TableauImport = {
          importId,
          originalName: file.name,
          minioPath,
          dashId,
          importStatus: 'COMPLETE',
          widgetsCreated: widgets.length,
          warnings: warnings.length > 0 ? warnings : null,
          unmappedItems: unmapped.length > 0 ? unmapped : null,
          importedBy: user.id,
          tenantId: user.tenantId,
          createdAt: new Date().toISOString(),
          completedAt: new Date().toISOString(),
        };

        return NextResponse.json<ApiResponse<TableauImport>>(
          { success: true, data: result },
          { status: 201 },
        );
      } catch (parseError) {
        const errMsg = parseError instanceof Error ? parseError.message : 'Parse error';

        await withTransaction(async (conn) => {
          await conn.execute(
            `UPDATE NB_TABLEAU_IMPORTS
             SET IMPORT_STATUS = 'ERROR',
                 WARNINGS = :errorMsg,
                 COMPLETED_AT = SYSTIMESTAMP
             WHERE IMPORT_ID = :importId`,
            { importId, errorMsg: JSON.stringify([errMsg]) },
          );
        });

        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'INGEST_FAILED', message: errMsg } },
          { status: 400 },
        );
      }
    } catch (error) {
      console.error('POST /api/tableau/import error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

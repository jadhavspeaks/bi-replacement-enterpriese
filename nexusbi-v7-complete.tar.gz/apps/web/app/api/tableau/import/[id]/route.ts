export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, TableauImport } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const { id } = await params;

  try {
    const imp = await withConnection(async (conn) => {
      const result = await conn.execute<{
        IMPORT_ID: string;
        ORIGINAL_NAME: string;
        MINIO_PATH: string | null;
        DASH_ID: string | null;
        IMPORT_STATUS: string;
        WIDGETS_CREATED: number | null;
        WARNINGS: string;
        UNMAPPED_ITEMS: string;
        IMPORTED_BY: string;
        TENANT_ID: string;
        CREATED_AT: string;
        COMPLETED_AT: string | null;
      }>(
        `SELECT IMPORT_ID, ORIGINAL_NAME, MINIO_PATH, DASH_ID,
                IMPORT_STATUS, WIDGETS_CREATED, WARNINGS,
                UNMAPPED_ITEMS, IMPORTED_BY, TENANT_ID,
                CREATED_AT, COMPLETED_AT
         FROM NB_TABLEAU_IMPORTS
         WHERE IMPORT_ID = :importId AND TENANT_ID = :tenantId`,
        { importId: id, tenantId: session.user.tenantId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      const warningsStr = await clobToString(row.WARNINGS);
      const unmappedStr = await clobToString(row.UNMAPPED_ITEMS);

      return {
        importId: row.IMPORT_ID,
        originalName: row.ORIGINAL_NAME,
        minioPath: row.MINIO_PATH,
        dashId: row.DASH_ID,
        importStatus: row.IMPORT_STATUS as TableauImport['importStatus'],
        widgetsCreated: row.WIDGETS_CREATED,
        warnings: parseJsonClob<string[]>(warningsStr),
        unmappedItems: parseJsonClob(unmappedStr),
        importedBy: row.IMPORTED_BY,
        tenantId: row.TENANT_ID,
        createdAt: String(row.CREATED_AT),
        completedAt: row.COMPLETED_AT ? String(row.COMPLETED_AT) : null,
      } as TableauImport;
    });

    if (!imp) return notFoundResponse('Import not found');

    return NextResponse.json<ApiResponse<TableauImport>>({
      success: true,
      data: imp,
    });
  } catch (error) {
    console.error('GET /api/tableau/import/[id] error:', error);
    return internalErrorResponse();
  }
}

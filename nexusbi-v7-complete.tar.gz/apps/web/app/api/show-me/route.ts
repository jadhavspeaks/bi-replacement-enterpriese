import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { withAudit } from '@/lib/audit';
import { requireAuthAndPermission } from '@/lib/rbac-middleware';
import { recommend, autoMapShelves } from '@/lib/show-me-rules';

const Schema = z.object({
  shelves: z.object({
    columns: z.array(z.string()),
    rows: z.array(z.string()),
    color: z.string().nullable(),
    size: z.string().nullable(),
  }),
  schemas: z.array(z.object({
    name: z.string(),
    fieldClass: z.enum(['dimension','measure']),
    dataType: z.enum(['string','number','date','boolean','geo']),
    cardinality: z.number().optional(),
  })),
});

export const POST = withAudit(
  () => ({ action: 'show_me.recommend', resourceType: 'worksheet' }),
  async (request, _params, user) => {
    await requireAuthAndPermission(user, 'workbook.view');
    const body = Schema.parse(await request.json());
    const recommendations = recommend(body);
    const dims = body.schemas.filter((s) => s.fieldClass === 'dimension').map((s) => s.name);
    const measures = body.schemas.filter((s) => s.fieldClass === 'measure').map((s) => s.name);
    const withMappings = recommendations.map((rec) => ({
      ...rec,
      autoMap: autoMapShelves(rec.chartType, dims, measures),
    }));
    return NextResponse.json({ recommendations: withMappings });
  },
);

#!/usr/bin/env node
/*
 * NexusBI login diagnostic
 * ========================
 *
 * Reads apps/web/data/nexusbi.db directly and reports, step by step, what an
 * authorize() implementation would see for a given username + password:
 *
 *   1. Is the DB present and does it have the expected schema?
 *   2. Does the user row exist? With what columns/values?
 *   3. Does the stored PASSWORD_HASH look like a valid bcrypt string?
 *   4. Does bcrypt.compare(password, hash) return true?
 *   5. What roles and permissions would be loaded for this user?
 *
 * Usage (from project root on Windows):
 *   node apps\web\scripts\diag-login.js
 *   node apps\web\scripts\diag-login.js admin "Admin@123!"
 *   node apps\web\scripts\diag-login.js author1 "Test@123!"
 *
 * Self-re-spawns with --experimental-sqlite on Node 22 so no flag is required.
 * Uses only node:sqlite (builtin) + bcryptjs (already in apps/web deps).
 */
'use strict';

// ---------------------------------------------------------------------------
// Boot: re-spawn with --experimental-sqlite on Node 22 if not already set.
// On Node >= 23 the flag is no-op and we skip the re-spawn.
// ---------------------------------------------------------------------------
(function boot() {
  const major = parseInt(process.versions.node.split('.')[0], 10);
  if (major !== 22) return;
  if (process.execArgv.indexOf('--experimental-sqlite') !== -1) return;
  const { spawnSync } = require('child_process');
  const args = ['--experimental-sqlite', '--no-warnings', __filename].concat(
    process.argv.slice(2),
  );
  const res = spawnSync(process.execPath, args, { stdio: 'inherit' });
  process.exit(typeof res.status === 'number' ? res.status : 1);
})();

const fs = require('fs');
const path = require('path');

// ---------------------------------------------------------------------------
// Args + constants
// ---------------------------------------------------------------------------
const USERNAME = process.argv[2] || 'admin';
const PASSWORD = process.argv[3] || 'Admin@123!';

const USE_COLOR =
  process.stdout.isTTY && process.env.NO_COLOR !== '1' && process.platform !== 'win32' ? true : !!process.stdout.isTTY;
const paint = (code, s) => (USE_COLOR ? `\x1b[${code}m${s}\x1b[0m` : s);
const green = (s) => paint('32', s);
const red = (s) => paint('31', s);
const blue = (s) => paint('34', s);
const bold = (s) => paint('1', s);

const OK = (s) => console.log(`${green('[OK]')}   ${s}`);
const BAD = (s) => console.log(`${red('[FAIL]')} ${s}`);
const I = (s) => console.log(`${blue('[info]')} ${s}`);
const BAR = () => console.log('-'.repeat(74));

BAR();
console.log(
  `NexusBI login diagnostic  |  username=${JSON.stringify(USERNAME)}  password=${JSON.stringify(
    PASSWORD,
  )}`,
);
BAR();

// ---------------------------------------------------------------------------
// 1. Locate SQLite database file
// ---------------------------------------------------------------------------
const candidates = [
  path.resolve(__dirname, '..', 'data', 'nexusbi.db'),
  path.resolve(process.cwd(), 'apps', 'web', 'data', 'nexusbi.db'),
  path.resolve(process.cwd(), 'data', 'nexusbi.db'),
];
const dbPath = candidates.find((p) => {
  try {
    return fs.statSync(p).isFile();
  } catch {
    return false;
  }
});
if (!dbPath) {
  BAD('SQLite database file not found. Tried:');
  candidates.forEach((c) => console.log(`       - ${c}`));
  I('Run `npm run dev` once in apps/web to auto-create the DB from sqlite-seed.sql.');
  process.exit(2);
}
OK(`DB located: ${dbPath}`);

// ---------------------------------------------------------------------------
// 2. Open DB (node:sqlite is builtin on Node 22 with --experimental-sqlite)
// ---------------------------------------------------------------------------
let db;
try {
  const sqlite = require('node:sqlite');
  db = new sqlite.DatabaseSync(dbPath);
} catch (err) {
  BAD(`Cannot open SQLite DB: ${err && err.message ? err.message : String(err)}`);
  I('Ensure you are on Node 22+ (node --version).');
  process.exit(2);
}

// ---------------------------------------------------------------------------
// 3. Load bcryptjs (resolved from apps/web/node_modules preferentially)
// ---------------------------------------------------------------------------
let bcrypt;
const bcryptCandidates = [
  path.resolve(__dirname, '..', 'node_modules', 'bcryptjs'),
  'bcryptjs',
];
for (const c of bcryptCandidates) {
  try {
    bcrypt = require(c);
    break;
  } catch {
    /* try next */
  }
}
if (!bcrypt) {
  BAD('bcryptjs module not found.');
  I('Run: cd apps/web && npm install');
  process.exit(2);
}
OK('bcryptjs loaded');

// ---------------------------------------------------------------------------
// 4. Confirm schema is installed
// ---------------------------------------------------------------------------
let nbTableCount = 0;
try {
  const r = db
    .prepare(`SELECT COUNT(*) AS c FROM sqlite_master WHERE type='table' AND name LIKE 'NB_%'`)
    .get();
  nbTableCount = Number(r && r.c);
} catch (err) {
  BAD(`Failed to query sqlite_master: ${err.message}`);
  process.exit(2);
}
I(`NB_* tables in database: ${nbTableCount}`);
if (nbTableCount < 5) {
  BAD('Schema looks uninstalled. Delete apps/web/data/nexusbi.db and restart dev server to re-seed.');
  process.exit(2);
}

// ---------------------------------------------------------------------------
// 5. Look up user row
// ---------------------------------------------------------------------------
let user = null;
try {
  user = db
    .prepare(
      `SELECT USER_ID, USERNAME, EMAIL, DISPLAY_NAME, PASSWORD_HASH, TENANT_ID,
              COALESCE(IS_ACTIVE, 1) AS IS_ACTIVE
         FROM NB_USERS
        WHERE LOWER(USERNAME) = LOWER(?) OR LOWER(EMAIL) = LOWER(?)
        LIMIT 1`,
    )
    .get(USERNAME, USERNAME);
} catch (err) {
  BAD(`SELECT on NB_USERS failed: ${err.message}`);
  I('Columns in NB_USERS:');
  try {
    const cols = db.prepare(`PRAGMA table_info(NB_USERS)`).all();
    cols.forEach((c) => console.log(`       - ${c.name} (${c.type})`));
  } catch {
    /* ignore */
  }
  process.exit(3);
}

if (!user) {
  BAD(`No row in NB_USERS matches username/email = ${JSON.stringify(USERNAME)}`);
  I('Users present (up to 20):');
  try {
    const all = db
      .prepare('SELECT USERNAME, EMAIL, COALESCE(IS_ACTIVE, 1) AS IS_ACTIVE FROM NB_USERS LIMIT 20')
      .all();
    all.forEach((u) =>
      console.log(`       - ${u.USERNAME.padEnd(16)} ${String(u.EMAIL).padEnd(32)} IS_ACTIVE=${u.IS_ACTIVE}`),
    );
  } catch (err) {
    console.log(`       (listing failed: ${err.message})`);
  }
  process.exit(3);
}

OK(`User row loaded`);
console.log(`       USER_ID      = ${user.USER_ID}`);
console.log(`       USERNAME     = ${user.USERNAME}`);
console.log(`       EMAIL        = ${user.EMAIL}`);
console.log(`       DISPLAY_NAME = ${user.DISPLAY_NAME}`);
console.log(`       TENANT_ID    = ${user.TENANT_ID}`);
console.log(`       IS_ACTIVE    = ${user.IS_ACTIVE}`);

const isActive = Number(user.IS_ACTIVE) === 1;
if (!isActive) {
  BAD(`IS_ACTIVE is ${user.IS_ACTIVE} (expected 1) — authorize() will reject this login.`);
}

// ---------------------------------------------------------------------------
// 6. Inspect stored password hash
// ---------------------------------------------------------------------------
const hash = user.PASSWORD_HASH == null ? '' : String(user.PASSWORD_HASH);
const looksLikeBcrypt = /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/.test(hash);

console.log(`       PASSWORD_HASH length = ${hash.length}`);
console.log(`       PASSWORD_HASH prefix = ${hash.slice(0, 7)}`);
console.log(`       PASSWORD_HASH tail   = ${hash.slice(-10)}`);

if (!looksLikeBcrypt) {
  BAD('Stored PASSWORD_HASH is NOT a well-formed bcrypt string.');
  I('Expected form: $2a$10$<53 chars>   or   $2b$10$<53 chars>');
  I(`Actual value:  ${JSON.stringify(hash)}`);
} else {
  OK('PASSWORD_HASH is a well-formed bcrypt string');
}

// ---------------------------------------------------------------------------
// 7. bcrypt.compare
// ---------------------------------------------------------------------------
let matched = false;
let compareErr = null;
try {
  matched = bcrypt.compareSync(PASSWORD, hash);
} catch (err) {
  compareErr = err;
}

if (compareErr) {
  BAD(`bcrypt.compare threw: ${compareErr.message}`);
} else if (matched) {
  OK(bold('bcrypt.compare SUCCEEDED — password matches the stored hash'));
} else {
  BAD(bold('bcrypt.compare FAILED — supplied password does NOT match the stored hash'));
  try {
    const fresh = bcrypt.hashSync(PASSWORD, 10);
    I(`To reset this account's password to ${JSON.stringify(PASSWORD)}, run these two commands:`);
    console.log('');
    console.log(`       # from apps/web/ directory`);
    console.log(
      `       node --experimental-sqlite --no-warnings -e "const s=require('node:sqlite');const db=new s.DatabaseSync('./data/nexusbi.db');db.prepare('UPDATE NB_USERS SET PASSWORD_HASH = ? WHERE USERNAME = ?').run('${fresh}', '${USERNAME}');console.log('updated rows:',db.prepare('SELECT changes() AS c').get().c);db.close();"`,
    );
    console.log('');
    I('Or open the DB with any SQLite client and run:');
    console.log(`       UPDATE NB_USERS SET PASSWORD_HASH = '${fresh}' WHERE USERNAME = '${USERNAME}';`);
  } catch (err) {
    console.log(`       (could not generate replacement hash: ${err.message})`);
  }
}

// ---------------------------------------------------------------------------
// 8. Roles + 9. Permissions — what would be loaded post-auth
// ---------------------------------------------------------------------------
let roles = [];
try {
  roles = db
    .prepare(
      `SELECT r.ROLE_ID, r.ROLE_NAME
         FROM NB_ROLES r
         JOIN NB_USER_ROLES ur ON ur.ROLE_ID = r.ROLE_ID
        WHERE ur.USER_ID = ?`,
    )
    .all(user.USER_ID);
} catch (err) {
  BAD(`Role join failed: ${err.message}`);
}
I(
  `Roles assigned: ${roles.length}${
    roles.length ? ` — ${roles.map((r) => r.ROLE_NAME).join(', ')}` : ' (none)'
  }`,
);

let perms = [];
if (roles.length > 0) {
  try {
    const placeholders = roles.map(() => '?').join(',');
    const stmt = db.prepare(
      `SELECT DISTINCT P.PERM_CODE
         FROM NB_ROLE_PERMISSIONS RP
         JOIN NB_PERMISSIONS P ON P.PERM_ID = RP.PERM_ID
        WHERE RP.ROLE_ID IN (${placeholders})`,
    );
    perms = stmt.all.apply(stmt, roles.map((r) => r.ROLE_ID));
  } catch (err) {
    BAD(`Permission join failed: ${err.message}`);
  }
}
I(`Permissions resolved: ${perms.length}`);
if (perms.length > 0) {
  const sample = perms
    .slice(0, 8)
    .map((p) => p.PERM_CODE)
    .join(', ');
  console.log(`       sample: ${sample}${perms.length > 8 ? ', …' : ''}`);
}

db.close();

// ---------------------------------------------------------------------------
// Verdict
// ---------------------------------------------------------------------------
BAR();
if (matched && isActive && looksLikeBcrypt) {
  console.log(green(bold('DIAGNOSIS: credentials are VALID at the database level.')));
  console.log('');
  console.log('If login is still failing in the browser:');
  console.log('  - Check the dev-server terminal for "[auth][error] CredentialsSignin"');
  console.log('    and any line logged by authorize() above it');
  console.log('  - Confirm NEXTAUTH_URL matches the origin you are visiting');
  console.log('  - Clear browser cookies for localhost and retry');
} else {
  console.log(red(bold('DIAGNOSIS: login would be rejected because of the failure(s) marked above.')));
  console.log('');
  if (!matched && looksLikeBcrypt) {
    console.log('Most likely cause: the seed committed a hash for a different password than');
    console.log(`${JSON.stringify(PASSWORD)}. Use the UPDATE statement printed above to reset it,`);
    console.log('or delete apps/web/data/nexusbi.db and restart dev server to re-seed cleanly.');
  } else if (!looksLikeBcrypt) {
    console.log('Most likely cause: the seed PASSWORD_HASH value is a placeholder, got truncated,');
    console.log('or was generated by an incompatible tool. Reset with the generated hash above.');
  } else if (!isActive) {
    console.log("Fix with:  UPDATE NB_USERS SET IS_ACTIVE = 1 WHERE USERNAME = '" + USERNAME + "';");
  }
}
BAR();
process.exit(0);

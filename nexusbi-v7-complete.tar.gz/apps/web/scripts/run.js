#!/usr/bin/env node
/**
 * Cross-platform launcher for the Next.js CLI.
 *
 * Earlier versions of this script spawned `next.cmd` through a shell, which
 * broke on Windows whenever the project path contained spaces, parentheses,
 * or ampersands (very common — "C:\Project - Codes\NexusBI" for example).
 * The current approach is to require Next's CLI entrypoint *inside this same
 * Node process*. There is no shell involved, so paths cannot be misparsed.
 *
 * It also handles the SQLite flag transition:
 *   - Node 22: needs --experimental-sqlite (added below to the current process)
 *   - Node 23+: node:sqlite is stable; flag would be rejected, so it's omitted
 *
 * Usage:
 *   node scripts/run.js dev
 *   node scripts/run.js build
 *   node scripts/run.js start
 *   node scripts/run.js dev -- --port 4000     (extra args forwarded to Next)
 */

'use strict';

const path = require('node:path');
const { spawn } = require('node:child_process');

const target = process.argv[2];
if (!target || !['dev', 'build', 'start', 'lint'].includes(target)) {
  console.error('Usage: node scripts/run.js <dev|build|start|lint> [...extra args]');
  process.exit(1);
}

// Forward any extra args to Next (after `--` or simply trailing).
const passthrough = process.argv.slice(3).filter((a) => a !== '--');

// Detect Node version. Node 22 still has node:sqlite gated behind a flag;
// 23+ ships it stable. Adding the flag on >=23 would make Node abort at startup
// because it doesn't recognise the option.
const nodeMajor = parseInt(process.versions.node.split('.')[0], 10);
const needsSqliteFlag = nodeMajor === 22;

// Where is the Next CLI?
let nextCliPath;
try {
  nextCliPath = require.resolve('next/dist/bin/next', { paths: [path.resolve(__dirname, '..')] });
} catch (err) {
  console.error('Could not locate Next.js CLI. Did you run `npm install`?');
  console.error('  resolve error:', (err && err.message) || err);
  process.exit(1);
}

// Strategy: re-spawn the *current Node binary* with the right flags + the Next
// CLI script path. We use the explicit args array (not a shell) so spaces and
// special characters in the project path are handled by Node, not by cmd.exe.
const nodeBin = process.execPath; // absolute path to current node, no quoting issues
const nodeArgs = ['--no-warnings'];
if (needsSqliteFlag) nodeArgs.push('--experimental-sqlite');
nodeArgs.push(nextCliPath, target, ...passthrough);

const child = spawn(nodeBin, nodeArgs, {
  stdio: 'inherit',
  // No shell, no windowsVerbatimArguments — Node passes argv as-is.
  shell: false,
  env: process.env,
});

child.on('exit', (code, signal) => {
  if (signal) process.kill(process.pid, signal);
  else process.exit(code ?? 0);
});

child.on('error', (err) => {
  console.error('Failed to launch Next.js:', err.message);
  process.exit(1);
});

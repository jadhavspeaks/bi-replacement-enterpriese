#!/usr/bin/env node
/**
 * Cross-platform launcher that sets --experimental-sqlite only when needed.
 *
 * - Node 22: needs the flag (node:sqlite is behind --experimental-sqlite)
 * - Node 23+: node:sqlite is stable, flag is no longer accepted
 * - Windows/Mac/Linux: works the same because we spawn a child process
 *
 * Usage:  node scripts/run.js dev
 *         node scripts/run.js start
 *         node scripts/run.js build
 */
const { spawn } = require('node:child_process');
const path = require('node:path');

const target = process.argv[2];
if (!target) {
  console.error('Usage: node scripts/run.js <dev|start|build>');
  process.exit(1);
}

const majorVersion = parseInt(process.versions.node.split('.')[0], 10);
const needsFlag = majorVersion === 22;

const nodeOptions = [process.env.NODE_OPTIONS || '', '--no-warnings'];
if (needsFlag) nodeOptions.push('--experimental-sqlite');

const env = {
  ...process.env,
  NODE_OPTIONS: nodeOptions.filter(Boolean).join(' '),
};

const nextBin = path.resolve(__dirname, '..', 'node_modules', '.bin', process.platform === 'win32' ? 'next.cmd' : 'next');
const child = spawn(nextBin, [target, ...process.argv.slice(3)], {
  stdio: 'inherit',
  env,
  shell: process.platform === 'win32',
});

child.on('exit', (code) => process.exit(code ?? 1));

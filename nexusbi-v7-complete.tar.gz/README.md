# NexusBI v7

Enterprise BI platform — 12 connectors, multi-tenant, SQLite/Oracle-backed, built on Next.js 15 + React 19.

## What's in this release

- **Database: SQLite by default** — zero credentials, zero setup, auto-creates its schema on first run using Node 22's built-in `node:sqlite` module (no native compilation, no npm download).
- **Oracle stays available behind a feature flag** — set `DB_BACKEND=oracle` with the usual `ORACLE_*` env vars and everything works unchanged.
- **Zero Cube.js dependency** — replaced with an in-app TypeScript query engine.
- **12 connectors only** — Oracle, MongoDB, Hive, Impala, CSV/Excel/JSON/Parquet files, REST/GraphQL/OAuth/Webhook APIs.
- **Multi-tenant** — Organization renamed to Tenant throughout.
- **No monorepo workspaces**, **no Puppeteer**, **no Cubestore binary**, **no better-sqlite3 native compile**. Installs cleanly behind any corporate proxy.

## Supported connectors

| Category | Connectors |
|---|---|
| Databases | Oracle, MongoDB |
| Hadoop ecosystem | Hive, Impala |
| File uploads | CSV, Excel, JSON, Parquet |
| APIs | REST, GraphQL, OAuth2 REST, Inbound Webhook |

## Requirements

- **Node.js 22 or newer** (the built-in `node:sqlite` module needs 22+)
- Nothing else. No Oracle client, no Python, no native compilers.

## Install (SQLite — zero credentials, zero secrets config)

```bash
tar -xzf nexusbi-v7-complete.tar.gz
cd nexusbi

npm run install:all        # ~60s, zero errors
npm run dev                # http://localhost:3000
```

That's it. On first run the app:
- Generates and persists a `NEXTAUTH_SECRET` to `apps/web/data/.auth-secret` (gitignored, 0600 perms)
- Creates `apps/web/data/nexusbi.db` with 52 tables and seed data (6 users, 61 permissions, 6 roles, 1 default tenant)

Login with `admin` / `Admin@123!`.

To rotate the auth secret: delete `apps/web/data/.auth-secret` (forces new generation on next boot) or set `NEXTAUTH_SECRET` explicitly in `apps/web/.env.local`.

## Switch to Oracle (when DB access is available)

```bash
# In apps/web/.env.local
DB_BACKEND=oracle
ORACLE_HOST=your-oracle-host
ORACLE_PORT=1521
ORACLE_SERVICE=XEPDB1
ORACLE_USER=your_existing_user
ORACLE_PASSWORD=your_password

# Install Oracle driver (optional dep — only pulled when you need it)
cd apps/web && npm install oracledb && cd ..

# Install schema using your existing user (no CREATE USER, no sqlplus)
npm run install:schema:oracle
```

No other code changes. The adapter layer makes the backend a single env flag.

## Architecture

```
┌──────────────────────────────────────────────────────────────┐
│  apps/web  (Next.js 15 · React 19 · NextAuth v5)             │
│                                                              │
│  lib/db/ — DB adapter facade (DB_BACKEND=sqlite|oracle)      │
│   ├── sqlite-adapter.ts   uses node:sqlite  (Node 22+)       │
│   └── oracle-adapter.ts   uses oracledb     (optional dep)   │
│                                                              │
│  lib/query-engine.ts — in-app semantic layer                 │
│   ├── compiles Query → SQL (Oracle/Hive) or Mongo pipeline   │
│   └── dispatches to native connectors                        │
│                                                              │
│  lib/connectors/                                             │
│   ├── oracle-connector.ts  uses oracledb                     │
│   ├── mongo-connector.ts   uses mongodb (optional dep)       │
│   └── hive-connector.ts    uses hive-driver (optional dep)   │
└──────────────────────────────────────────────────────────────┘
```

## Corporate-proxy friendly

This release has been hardened for installs behind restrictive artifactories:

- **No native compilation** — `better-sqlite3` rejected in favor of built-in `node:sqlite` because the former needs to download Node headers through node-gyp (often 403'd).
- **No Cube.js server** — no `@cubejs-backend/*` packages, no Cubestore binary download.
- **No Puppeteer** — no chrome-headless-shell download.
- **Drivers for MongoDB, Hive, Oracle are `optionalDependencies`** — if your artifactory doesn't mirror them, `npm install` still succeeds; queries against those sources will throw a clear error at runtime.

## Test accounts (seeded)

| Username | Password | Role |
|---|---|---|
| admin | Admin@123! | PLATFORM_ADMIN |
| author1 | Test@123! | AUTHOR |
| checker1 | Test@123! | CHECKER |
| viewer1 | Test@123! | VIEWER |
| embed_user | Test@123! | EMBED_ONLY |

## Known issues

See `KNOWN_ISSUES.md` for inherited pre-existing TS errors in API routes (the app installs, builds, and boots; individual routes have categorized fixes documented).

## Documentation

- `docs/NexusBI-User-Guide.docx` — 50-chapter user guide
- `nexusbi-v7-app.html` — self-contained browser demo
- `KNOWN_ISSUES.md` — pre-existing bugs with one-line fixes

'use client';

import { useEffect, useState, useCallback } from 'react';
import { useDashboardStore } from '@/store/dashboard.store';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { X, Database, ChevronDown, ChevronRight, Loader2 } from 'lucide-react';
import type { CubeSchema, WidgetConfig } from '@nexusbi/shared-types';

interface ParsedSchema {
  cubeName: string;
  measures: Array<{ name: string; type: string }>;
  dimensions: Array<{ name: string; type: string }>;
}

function parseSchemaJs(schemaJs: string, fallbackName: string): ParsedSchema | null {
  try {
    const parsed = JSON.parse(schemaJs);
    return {
      cubeName: parsed.cubeName || parsed.name || fallbackName,
      measures: Object.entries<{ type?: string }>(parsed.measures || {}).map(([name, def]) => ({
        name,
        type: def.type || 'unknown',
      })),
      dimensions: Object.entries<{ type?: string }>(parsed.dimensions || {}).map(([name, def]) => ({
        name,
        type: def.type || 'unknown',
      })),
    };
  } catch {
    return null;
  }
}

/**
 * Side panel shown when a widget is selected in the dashboard editor.
 *
 * Lets the user:
 *   1. Set the widget title
 *   2. Pick a cube from the semantic layer
 *   3. Pick measures + dimensions to query
 *   4. Save the binding (writes cubeQuery to the widget config)
 *
 * The widget then renders real data via /api/cube/v1/load on its next paint.
 *
 * Closes via the X button (which deselects the widget) or by clicking elsewhere.
 */
export function WidgetInspector() {
  const selectedWidgetId = useDashboardStore((s) => s.selectedWidgetId);
  const widgets = useDashboardStore((s) => s.widgets);
  const updateWidget = useDashboardStore((s) => s.updateWidget);
  const removeWidget = useDashboardStore((s) => s.removeWidget);
  const selectWidget = useDashboardStore((s) => s.selectWidget);

  const widget = widgets.find((w) => w.widgetId === selectedWidgetId);

  const [cubes, setCubes] = useState<CubeSchema[]>([]);
  const [parsed, setParsed] = useState<Map<string, ParsedSchema>>(new Map());
  const [loading, setLoading] = useState(true);
  const [savedAt, setSavedAt] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    fetch('/api/schemas')
      .then((r) => r.json())
      .then((d) => {
        if (!active) return;
        const list = (d.data || []) as CubeSchema[];
        setCubes(list);
        const m = new Map<string, ParsedSchema>();
        for (const cs of list) {
          const p = parseSchemaJs(cs.schemaJs || '', cs.cubeName);
          if (p) m.set(cs.schemaId, p);
        }
        setParsed(m);
        setLoading(false);
      })
      .catch(() => setLoading(false));
    return () => {
      active = false;
    };
  }, []);

  const apply = useCallback(
    (patch: Partial<WidgetConfig>) => {
      if (!widget) return;
      updateWidget(widget.widgetId, patch);
      setSavedAt(Date.now());
    },
    [widget, updateWidget],
  );

  if (!widget) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-sm">Widget Inspector</CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-xs text-muted-foreground">
            Click a widget on the canvas to edit its title and bind it to data.
          </p>
        </CardContent>
      </Card>
    );
  }

  const currentCubeName = widget.cubeName || '';
  const currentSchema = cubes.find((c) => c.cubeName === currentCubeName);
  const currentParsed = currentSchema ? parsed.get(currentSchema.schemaId) : null;
  const cubeQuery = widget.cubeQuery || { measures: [], dimensions: [] };
  const measures = cubeQuery.measures || [];
  const dimensions = cubeQuery.dimensions || [];

  function toggleMeasure(name: string) {
    if (!currentParsed) return;
    const fullName = `${currentParsed.cubeName}.${name}`;
    const next = measures.includes(fullName)
      ? measures.filter((m) => m !== fullName)
      : [...measures, fullName];
    apply({
      cubeQuery: { ...cubeQuery, measures: next },
      cubeName: currentParsed.cubeName,
    });
  }

  function toggleDimension(name: string) {
    if (!currentParsed) return;
    const fullName = `${currentParsed.cubeName}.${name}`;
    const next = dimensions.includes(fullName)
      ? dimensions.filter((d) => d !== fullName)
      : [...dimensions, fullName];
    apply({
      cubeQuery: { ...cubeQuery, dimensions: next },
      cubeName: currentParsed.cubeName,
    });
  }

  function setCube(schemaId: string) {
    const cube = cubes.find((c) => c.schemaId === schemaId);
    if (!cube) return;
    apply({
      cubeName: cube.cubeName,
      cubeQuery: { measures: [], dimensions: [] },
    });
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between gap-2">
          <div className="min-w-0 flex-1">
            <CardTitle className="text-sm">Widget Inspector</CardTitle>
            <Badge variant="outline" className="mt-1 text-xs">{widget.widgetType}</Badge>
          </div>
          <Button variant="ghost" size="icon" className="h-6 w-6 shrink-0" onClick={() => selectWidget(null)}>
            <X className="h-3 w-3" />
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-1">
          <Label htmlFor="title" className="text-xs">Title</Label>
          <Input
            id="title"
            value={widget.title}
            onChange={(e) => apply({ title: e.target.value })}
            className="h-8 text-sm"
          />
        </div>

        <div className="space-y-1">
          <Label className="text-xs">Cube</Label>
          {loading ? (
            <Skeleton className="h-8 w-full" />
          ) : cubes.length === 0 ? (
            <div className="rounded border border-dashed p-2 text-xs text-muted-foreground">
              No cubes yet.{' '}
              <a className="underline" href="/semantic/new">Create one</a>
              {' '}then refresh.
            </div>
          ) : (
            <Select value={currentSchema?.schemaId || ''} onValueChange={setCube}>
              <SelectTrigger className="h-8 text-sm">
                <SelectValue placeholder="Pick a cube…" />
              </SelectTrigger>
              <SelectContent>
                {cubes.map((c) => (
                  <SelectItem key={c.schemaId} value={c.schemaId}>
                    <Database className="mr-1 inline h-3 w-3" />
                    {c.cubeName}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {currentParsed && (
          <>
            <div className="space-y-1">
              <Label className="text-xs">
                Measures ({measures.length}/{currentParsed.measures.length})
              </Label>
              <div className="max-h-40 space-y-1 overflow-auto rounded border p-2">
                {currentParsed.measures.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No measures defined in this cube.</p>
                ) : (
                  currentParsed.measures.map((m) => {
                    const full = `${currentParsed.cubeName}.${m.name}`;
                    const checked = measures.includes(full);
                    return (
                      <label key={m.name} className="flex cursor-pointer items-center gap-2 text-xs">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleMeasure(m.name)}
                          className="h-3 w-3"
                        />
                        <span className="flex-1 font-mono">{m.name}</span>
                        <Badge variant="secondary" className="text-[10px]">{m.type}</Badge>
                      </label>
                    );
                  })
                )}
              </div>
            </div>

            <div className="space-y-1">
              <Label className="text-xs">
                Dimensions ({dimensions.length}/{currentParsed.dimensions.length})
              </Label>
              <div className="max-h-40 space-y-1 overflow-auto rounded border p-2">
                {currentParsed.dimensions.length === 0 ? (
                  <p className="text-xs text-muted-foreground">No dimensions defined in this cube.</p>
                ) : (
                  currentParsed.dimensions.map((d) => {
                    const full = `${currentParsed.cubeName}.${d.name}`;
                    const checked = dimensions.includes(full);
                    return (
                      <label key={d.name} className="flex cursor-pointer items-center gap-2 text-xs">
                        <input
                          type="checkbox"
                          checked={checked}
                          onChange={() => toggleDimension(d.name)}
                          className="h-3 w-3"
                        />
                        <span className="flex-1 font-mono">{d.name}</span>
                        <Badge variant="secondary" className="text-[10px]">{d.type}</Badge>
                      </label>
                    );
                  })
                )}
              </div>
            </div>
          </>
        )}

        {savedAt && (
          <p className="text-xs text-muted-foreground">
            Auto-saved at {new Date(savedAt).toLocaleTimeString()}. Changes apply on next save.
          </p>
        )}

        <div className="border-t pt-3">
          <Button
            variant="destructive"
            size="sm"
            className="w-full"
            onClick={() => {
              removeWidget(widget.widgetId);
              selectWidget(null);
            }}
          >
            Delete widget
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

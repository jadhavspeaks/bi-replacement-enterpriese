'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';

/**
 * Base Input component (shadcn/ui style).
 *
 * `suppressHydrationWarning` is intentionally set on the underlying <input>.
 * Enterprise browsers and password managers (Island Enterprise Browser, 1Password,
 * LastPass, Dashlane, Bitwarden, etc.) inject DOM attributes into form fields
 * after the server-rendered HTML arrives but before React hydrates. Example:
 *
 *   island_form_infra_autocomplete="username"
 *   island_form_infra_field_type="USERNAME"
 *   island_field_signature="text||username|username||parsed|0"
 *
 * React then reports a hydration mismatch because the client DOM has attributes
 * the server never emitted. This is harmless — the extension's attributes are
 * additive and don't affect React's virtual DOM diff for subsequent renders —
 * but the dev-mode error overlay is disruptive.
 *
 * `suppressHydrationWarning` on the <input> tells React to skip the attribute
 * diff for this one element only (it does NOT propagate to children, which is
 * fine because <input> is a void element).
 *
 * Reference:
 *   https://react.dev/reference/react-dom/client/hydrateRoot#suppressing-unavoidable-hydration-mismatch-errors
 */
export type InputProps = React.InputHTMLAttributes<HTMLInputElement>;

const Input = React.forwardRef<HTMLInputElement, InputProps>(
  ({ className, type, ...props }, ref) => {
    return (
      <input
        type={type}
        ref={ref}
        suppressHydrationWarning
        className={cn(
          'flex h-9 w-full rounded-md border border-input bg-transparent px-3 py-1 text-sm shadow-sm transition-colors',
          'file:border-0 file:bg-transparent file:text-sm file:font-medium file:text-foreground',
          'placeholder:text-muted-foreground',
          'focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring',
          'disabled:cursor-not-allowed disabled:opacity-50',
          className,
        )}
        {...props}
      />
    );
  },
);
Input.displayName = 'Input';

export { Input };

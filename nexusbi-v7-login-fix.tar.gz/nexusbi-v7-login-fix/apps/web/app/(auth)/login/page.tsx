'use client';

import * as React from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { signIn } from 'next-auth/react';
import { Input } from '@/components/ui/input';

/**
 * /login
 *
 * Credentials sign-in page for NexusBI.
 *
 * Notes for maintainers:
 * - `suppressHydrationWarning` on <form> is defensive: enterprise browsers and
 *   password managers (Island, 1Password, LastPass, Bitwarden, Dashlane) inject
 *   form-level attributes in addition to the per-field ones already handled in
 *   components/ui/input.tsx. This prevents the dev-mode hydration overlay from
 *   showing for those attributes.
 * - `redirect: false` on signIn() is deliberate so we can show inline errors
 *   rather than landing on the default NextAuth error page.
 * - On success, we call router.push() + router.refresh() so middleware-protected
 *   routes re-evaluate the new session immediately.
 */

type ErrorKey =
  | 'CredentialsSignin'
  | 'Configuration'
  | 'AccessDenied'
  | 'Verification'
  | 'Default'
  | (string & {});

const ERROR_MESSAGES: Record<string, string> = {
  CredentialsSignin: 'Invalid username or password.',
  Configuration: 'Authentication is misconfigured. Check server logs.',
  AccessDenied: 'Your account does not have access to this workspace.',
  Verification: 'The sign-in link is invalid or has expired.',
  Default: 'Something went wrong signing you in. Please try again.',
};

function messageFor(key: ErrorKey | null | undefined): string | null {
  if (!key) return null;
  return ERROR_MESSAGES[key] ?? ERROR_MESSAGES.Default;
}

export default function LoginPage(): React.JSX.Element {
  const router = useRouter();
  const search = useSearchParams();

  const callbackUrl = search.get('callbackUrl') || '/';
  const initialError = search.get('error');

  const [username, setUsername] = React.useState('');
  const [password, setPassword] = React.useState('');
  const [showPassword, setShowPassword] = React.useState(false);
  const [error, setError] = React.useState<string | null>(messageFor(initialError));
  const [pending, setPending] = React.useState(false);

  const onSubmit = React.useCallback(
    async (e: React.FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      setError(null);
      setPending(true);
      try {
        const result = await signIn('credentials', {
          username: username.trim(),
          password,
          redirect: false,
          callbackUrl,
        });

        if (!result) {
          setError('Network error — server did not respond.');
          return;
        }
        if (result.error) {
          setError(messageFor(result.error) ?? result.error);
          return;
        }
        router.push(result.url ?? callbackUrl);
        router.refresh();
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Unexpected error.');
      } finally {
        setPending(false);
      }
    },
    [username, password, callbackUrl, router],
  );

  const canSubmit = !pending && username.trim().length > 0 && password.length > 0;

  return (
    <div className="relative flex min-h-screen items-center justify-center overflow-hidden bg-slate-50 px-4 py-12 dark:bg-slate-950">
      {/* Decorative background — soft gradient blobs */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 -z-10 overflow-hidden"
      >
        <div className="absolute -top-24 -left-24 h-96 w-96 rounded-full bg-indigo-200/40 blur-3xl dark:bg-indigo-500/10" />
        <div className="absolute -bottom-32 -right-20 h-96 w-96 rounded-full bg-violet-200/50 blur-3xl dark:bg-violet-500/10" />
        <div className="absolute top-1/3 right-1/3 h-64 w-64 rounded-full bg-sky-200/30 blur-3xl dark:bg-sky-500/10" />
      </div>

      <div className="w-full max-w-md">
        <div className="rounded-2xl border border-slate-200 bg-white/95 shadow-2xl backdrop-blur-sm dark:border-slate-800 dark:bg-slate-900/80">
          <div className="p-8 sm:p-10">
            {/* Logo + heading */}
            <div className="mb-8 text-center">
              <div className="mx-auto mb-4 flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 via-violet-500 to-fuchsia-500 shadow-lg shadow-indigo-500/25">
                <svg
                  viewBox="0 0 24 24"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="2.25"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  className="h-7 w-7 text-white"
                  aria-hidden="true"
                >
                  <path d="M3 3v18h18" />
                  <path d="M7 14l3-3 3 3 4-5" />
                  <circle cx="7" cy="14" r="1.25" fill="currentColor" />
                  <circle cx="10" cy="11" r="1.25" fill="currentColor" />
                  <circle cx="13" cy="14" r="1.25" fill="currentColor" />
                  <circle cx="17" cy="9" r="1.25" fill="currentColor" />
                </svg>
              </div>
              <h1 className="text-2xl font-semibold tracking-tight text-slate-900 dark:text-slate-50">
                Welcome to NexusBI
              </h1>
              <p className="mt-1.5 text-sm text-slate-500 dark:text-slate-400">
                Sign in to access your workspace
              </p>
            </div>

            {/* Form */}
            <form onSubmit={onSubmit} className="space-y-4" suppressHydrationWarning>
              <div className="space-y-1.5">
                <label
                  htmlFor="username"
                  className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                >
                  Username or email
                </label>
                <Input
                  id="username"
                  name="username"
                  type="text"
                  autoComplete="username"
                  autoFocus
                  required
                  disabled={pending}
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  aria-invalid={error ? 'true' : 'false'}
                  className="h-10"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <label
                    htmlFor="password"
                    className="block text-sm font-medium text-slate-700 dark:text-slate-300"
                  >
                    Password
                  </label>
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="text-xs font-medium text-indigo-600 hover:text-indigo-500 dark:text-indigo-400 dark:hover:text-indigo-300"
                    tabIndex={-1}
                  >
                    {showPassword ? 'Hide' : 'Show'}
                  </button>
                </div>
                <Input
                  id="password"
                  name="password"
                  type={showPassword ? 'text' : 'password'}
                  autoComplete="current-password"
                  required
                  disabled={pending}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  aria-invalid={error ? 'true' : 'false'}
                  className="h-10"
                />
              </div>

              {error ? (
                <div
                  className="flex items-start gap-2 rounded-md border border-red-200 bg-red-50 px-3 py-2.5 text-sm text-red-800 dark:border-red-900/50 dark:bg-red-950/40 dark:text-red-300"
                  role="alert"
                >
                  <svg
                    viewBox="0 0 20 20"
                    fill="currentColor"
                    className="mt-0.5 h-4 w-4 flex-shrink-0"
                    aria-hidden="true"
                  >
                    <path
                      fillRule="evenodd"
                      d="M10 18a8 8 0 100-16 8 8 0 000 16zm-.75-5.25a.75.75 0 001.5 0V8.75a.75.75 0 00-1.5 0v4zM10 15a1 1 0 100-2 1 1 0 000 2z"
                      clipRule="evenodd"
                    />
                  </svg>
                  <span>{error}</span>
                </div>
              ) : null}

              <button
                type="submit"
                disabled={!canSubmit}
                className="inline-flex w-full items-center justify-center gap-2 rounded-md bg-gradient-to-r from-indigo-600 to-violet-600 px-4 py-2.5 text-sm font-medium text-white shadow-sm shadow-indigo-500/20 transition hover:from-indigo-500 hover:to-violet-500 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600 disabled:cursor-not-allowed disabled:opacity-60"
              >
                {pending ? (
                  <>
                    <svg
                      viewBox="0 0 24 24"
                      fill="none"
                      className="h-4 w-4 animate-spin"
                      aria-hidden="true"
                    >
                      <circle
                        cx="12"
                        cy="12"
                        r="10"
                        stroke="currentColor"
                        strokeOpacity="0.25"
                        strokeWidth="4"
                      />
                      <path
                        d="M4 12a8 8 0 018-8"
                        stroke="currentColor"
                        strokeWidth="4"
                        strokeLinecap="round"
                      />
                    </svg>
                    <span>Signing in…</span>
                  </>
                ) : (
                  <span>Sign in</span>
                )}
              </button>
            </form>
          </div>

          {/* Footer with dev hint */}
          <div className="rounded-b-2xl border-t border-slate-200 bg-slate-50/70 px-8 py-4 text-xs dark:border-slate-800 dark:bg-slate-900/60 sm:px-10">
            <div className="flex items-center justify-between gap-2 text-slate-500 dark:text-slate-400">
              <span className="font-medium">Development credentials</span>
              <code className="rounded bg-slate-200/70 px-1.5 py-0.5 font-mono text-[11px] text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                admin / Admin@123!
              </code>
            </div>
          </div>
        </div>

        <p className="mt-6 text-center text-xs text-slate-400 dark:text-slate-600">
          NexusBI v7 · Secure analytics for the enterprise
        </p>
      </div>
    </div>
  );
}

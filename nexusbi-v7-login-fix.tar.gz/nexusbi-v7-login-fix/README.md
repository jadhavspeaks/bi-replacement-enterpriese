# NexusBI v7 — login-flow fix pack

Three files, three fixes, applied in any order.

```
apps/web/components/ui/input.tsx          # HYDRATION — fixes Island Browser mismatch
apps/web/scripts/diag-login.js            # DIAGNOSTIC — tells you why CredentialsSignin fires
apps/web/app/(auth)/login/page.tsx        # UI        — replaces the plain login page
```

Copy each into the matching path in your project (overwriting the existing file). No dependency
changes required; uses only what is already in `apps/web/package.json`.

---

## 1. `components/ui/input.tsx` — fixes the hydration error in Image 1

**Symptom:**

> A tree hydrated but some attributes of the server rendered HTML didn't match the client properties.
> ```
> island_form_infra_autocomplete="username"
> island_form_infra_field_type="USERNAME"
> island_field_signature="text||username|username||parsed|0"
> ```

**Root cause:** Island Enterprise Browser (your corporate browser at Citigroup) injects
form-recognition attributes into every `<input>` element *after* the server-rendered HTML arrives
but *before* React hydrates. React sees the client DOM has attributes the SSR output doesn't, and
warns loudly in dev mode. The attributes are additive and harmless — they don't affect any
subsequent React diff — but the error overlay is disruptive.

**Fix:** `suppressHydrationWarning` on the underlying `<input>` tells React to skip attribute
diffing for that one element. Official React escape hatch, designed for exactly this scenario.
See https://react.dev/reference/react-dom/client/hydrateRoot#suppressing-unavoidable-hydration-mismatch-errors

The new login page also sets `suppressHydrationWarning` on the `<form>` element as defense in
depth — some password managers inject form-level attributes too.

---

## 2. `scripts/diag-login.js` — identifies why CredentialsSignin fires in Image 2

`[auth][error] CredentialsSignin` from `@auth/core` means the `authorize()` function returned
`null`. The HTTP 200 on `POST /api/auth/callback/credentials` is not a contradiction — NextAuth
always returns 200 and communicates failure via a redirect with `?error=CredentialsSignin`.

The common root causes, each of which this script distinguishes:

| Cause                                     | What diag-login prints                                         |
|-------------------------------------------|----------------------------------------------------------------|
| User row doesn't exist                    | `[FAIL] No row in NB_USERS matches username/email = "admin"`   |
| Seed committed hash for different password| `[FAIL] bcrypt.compare FAILED` + a ready-to-paste UPDATE        |
| Hash is a placeholder / truncated         | `[FAIL] Stored PASSWORD_HASH is NOT a well-formed bcrypt string`|
| STATUS is not `'ACTIVE'`                  | `[FAIL] STATUS is "SUSPENDED" …`                                |
| Everything below auth layer is fine       | `DIAGNOSIS: credentials are VALID at the database level.`       |

**Run it** (from project root on Windows):

```
node apps\web\scripts\diag-login.js
node apps\web\scripts\diag-login.js admin "Admin@123!"
node apps\web\scripts\diag-login.js author1 "Test@123!"
```

The script:
- Auto-locates `apps/web/data/nexusbi.db`
- Self-re-spawns with `--experimental-sqlite` on Node 22 — no flags needed at invocation
- Uses only `node:sqlite` (builtin) + `bcryptjs` (already installed)
- If the password doesn't match, prints a ready-to-paste SQL UPDATE with a correct hash

**If the script says credentials are VALID at the DB level** and you still get `CredentialsSignin`
in the browser, the bug is in `apps/web/lib/auth.ts` (column name typo, silent exception, or a
rejecting callback). Share `auth.ts` in your next message and I'll pinpoint the line.

---

## 3. `app/(auth)/login/page.tsx` — the "UI not dynamic" fix

The previous login page looked like unstyled HTML. The replacement is a proper shadcn/Tailwind
form: gradient background, glass-effect card, logo, loading spinner on submit, show/hide password
toggle, styled error banner, dev-account hint in the footer.

Compatible with your existing stack — imports only from `@/components/ui/input`, `next/navigation`,
and `next-auth/react`. No new dependencies.

One behavioural note: submit uses `redirect: false` so the page shows inline errors instead of
landing on the default NextAuth error route. After success it calls `router.push()` +
`router.refresh()` so middleware-protected routes re-evaluate the fresh session immediately.

---

## Apply order

1. Drop in `input.tsx` → the Island hydration overlay disappears on next page load.
2. Drop in `login/page.tsx` → login page renders styled.
3. Run `diag-login.js` with `admin` / `Admin@123!` → read the verdict → act on it.
4. If diag says "VALID at DB level," share `lib/auth.ts` in the next turn.

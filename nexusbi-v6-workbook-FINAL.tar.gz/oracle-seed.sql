-- ============================================================================
-- NexusBI v6 — Oracle Seed SQL
-- 31 Tables · 38 Permissions · 6 Roles · 6 Dummy Users · Sample Data
-- Run with: sqlplus nexusbi/password@host:port/service @oracle-seed.sql
-- ============================================================================

-- ─── 1. ORGANIZATIONS ───────────────────────────────────────────────────────
CREATE TABLE NB_ORGANIZATIONS (
  ORG_ID           VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ORG_NAME         VARCHAR2(200)  NOT NULL,
  ORG_SLUG         VARCHAR2(100)  NOT NULL UNIQUE,
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 2. USERS ───────────────────────────────────────────────────────────────
CREATE TABLE NB_USERS (
  USER_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  EMAIL            VARCHAR2(320)  NOT NULL UNIQUE,
  USERNAME         VARCHAR2(100)  NOT NULL UNIQUE,
  PASSWORD_HASH    VARCHAR2(200)  NOT NULL,
  DISPLAY_NAME     VARCHAR2(200),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  LAST_LOGIN_AT    TIMESTAMP,
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 3. ROLES ───────────────────────────────────────────────────────────────
CREATE TABLE NB_ROLES (
  ROLE_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ROLE_NAME        VARCHAR2(100)  NOT NULL UNIQUE,
  ROLE_DESCRIPTION VARCHAR2(500),
  IS_SYSTEM_ROLE   NUMBER(1)      DEFAULT 0,
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 4. PERMISSIONS ─────────────────────────────────────────────────────────
CREATE TABLE NB_PERMISSIONS (
  PERM_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  PERM_CODE        VARCHAR2(100)  NOT NULL UNIQUE,
  PERM_CATEGORY    VARCHAR2(50)   NOT NULL,
  DESCRIPTION      VARCHAR2(500)
);

-- ─── 5. ROLE_PERMISSIONS ────────────────────────────────────────────────────
CREATE TABLE NB_ROLE_PERMISSIONS (
  ROLE_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  PERM_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_PERMISSIONS(PERM_ID),
  GRANTED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  GRANTED_BY       VARCHAR2(36),
  PRIMARY KEY (ROLE_ID, PERM_ID)
);

-- ─── 6. USER_ROLES ──────────────────────────────────────────────────────────
CREATE TABLE NB_USER_ROLES (
  USER_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ROLE_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  ASSIGNED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  ASSIGNED_BY      VARCHAR2(36),
  PRIMARY KEY (USER_ID, ROLE_ID, ORG_ID)
);

-- ─── 7. DATA_SOURCES ────────────────────────────────────────────────────────
CREATE TABLE NB_DATA_SOURCES (
  DS_ID            VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DS_NAME          VARCHAR2(200)  NOT NULL,
  DS_TYPE          VARCHAR2(50)   NOT NULL,
  DESCRIPTION      VARCHAR2(2000),
  CONFIG_ENCRYPTED CLOB,
  STATUS           VARCHAR2(20)   DEFAULT 'INACTIVE',
  LAST_TESTED_AT   TIMESTAMP,
  LAST_TEST_RESULT VARCHAR2(20),
  CUBE_DS_ID       VARCHAR2(100),
  OWNER_ID         VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 8. DS_ACCESS ───────────────────────────────────────────────────────────
CREATE TABLE NB_DS_ACCESS (
  ACCESS_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DS_ID            VARCHAR2(36)   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  ROLE_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_ROLES(ROLE_ID),
  CAN_QUERY        NUMBER(1)      DEFAULT 1,
  CAN_EXPORT       NUMBER(1)      DEFAULT 0,
  CAN_MANAGE       NUMBER(1)      DEFAULT 0,
  ROW_FILTER_SQL   VARCHAR2(4000),
  EXPIRES_AT       TIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 9. CUBE_SCHEMAS ────────────────────────────────────────────────────────
CREATE TABLE NB_CUBE_SCHEMAS (
  SCHEMA_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DS_ID            VARCHAR2(36)   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  CUBE_NAME        VARCHAR2(200)  NOT NULL,
  SCHEMA_JS        CLOB           NOT NULL,
  VERSION          NUMBER         DEFAULT 1,
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  CREATED_BY       VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 10. COLUMN_TAGS ────────────────────────────────────────────────────────
CREATE TABLE NB_COLUMN_TAGS (
  TAG_ID           VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  SCHEMA_ID        VARCHAR2(36)   NOT NULL REFERENCES NB_CUBE_SCHEMAS(SCHEMA_ID),
  COLUMN_NAME      VARCHAR2(200)  NOT NULL,
  TAG_KEY          VARCHAR2(100)  NOT NULL,
  TAG_VALUE        VARCHAR2(500),
  CREATED_BY       VARCHAR2(36),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 11. FILE_UPLOADS ───────────────────────────────────────────────────────
CREATE TABLE NB_FILE_UPLOADS (
  FILE_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  FILE_NAME        VARCHAR2(500)  NOT NULL,
  ORIGINAL_NAME    VARCHAR2(500)  NOT NULL,
  MIME_TYPE        VARCHAR2(100),
  FILE_SIZE        NUMBER,
  MINIO_BUCKET     VARCHAR2(100)  NOT NULL,
  MINIO_KEY        VARCHAR2(500)  NOT NULL,
  UPLOAD_STATUS    VARCHAR2(20)   DEFAULT 'UPLOADED',
  INGEST_STATUS    VARCHAR2(20),
  DUCKDB_TABLE     VARCHAR2(200),
  UPLOADED_BY      VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 12. API_SOURCES ────────────────────────────────────────────────────────
CREATE TABLE NB_API_SOURCES (
  SOURCE_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  SOURCE_NAME      VARCHAR2(200)  NOT NULL,
  API_TYPE         VARCHAR2(30)   NOT NULL,
  BASE_URL         VARCHAR2(2000) NOT NULL,
  AUTH_CONFIG      CLOB,
  POLL_CRON        VARCHAR2(100),
  JQ_EXPRESSION    VARCHAR2(2000),
  PAGINATION_TYPE  VARCHAR2(30),
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  LAST_POLL_AT     TIMESTAMP,
  LAST_POLL_STATUS VARCHAR2(20),
  LAST_ROW_COUNT   NUMBER,
  DUCKDB_TABLE     VARCHAR2(200),
  OWNER_ID         VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 13. DASHBOARDS ─────────────────────────────────────────────────────────
CREATE TABLE NB_DASHBOARDS (
  DASH_ID              VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_NAME            VARCHAR2(300)  NOT NULL,
  DESCRIPTION          VARCHAR2(2000),
  LAYOUT_JSON          CLOB,
  WIDGETS_JSON         CLOB,
  FILTERS_JSON         CLOB,
  OWNER_ID             VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID               VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  IS_PUBLIC            NUMBER(1)      DEFAULT 0,
  IS_EMBEDDED          NUMBER(1)      DEFAULT 0,
  EMBED_TOKEN          VARCHAR2(2000),
  VERSION              NUMBER         DEFAULT 1,
  THUMBNAIL_URL        VARCHAR2(1000),
  TAGS                 VARCHAR2(1000),
  APPROVAL_STATUS      VARCHAR2(20)   DEFAULT 'DRAFT',
  APPROVED_BY          VARCHAR2(36),
  APPROVED_AT          TIMESTAMP,
  REJECTED_BY          VARCHAR2(36),
  REJECTED_AT          TIMESTAMP,
  REJECTION_REASON     VARCHAR2(2000),
  SOURCE               VARCHAR2(30)   DEFAULT 'MANUAL',
  DUAL_CHECKER_REQUIRED NUMBER(1)     DEFAULT 0,
  CREATED_AT           TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT           TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 14. DASHBOARD_VERSIONS ─────────────────────────────────────────────────
CREATE TABLE NB_DASHBOARD_VERSIONS (
  VERSION_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  VERSION          NUMBER         NOT NULL,
  LAYOUT_JSON      CLOB,
  WIDGETS_JSON     CLOB,
  SAVED_BY         VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  SAVED_AT         TIMESTAMP      DEFAULT SYSTIMESTAMP,
  CHANGE_SUMMARY   VARCHAR2(500)
);

-- ─── 15. DASHBOARD_SHARES ───────────────────────────────────────────────────
CREATE TABLE NB_DASHBOARD_SHARES (
  SHARE_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  ROLE_ID          VARCHAR2(36)   REFERENCES NB_ROLES(ROLE_ID),
  USER_ID          VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  CAN_EDIT         NUMBER(1)      DEFAULT 0,
  CAN_SHARE        NUMBER(1)      DEFAULT 0,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 16. DASHBOARD_REVIEWS ──────────────────────────────────────────────────
CREATE TABLE NB_DASHBOARD_REVIEWS (
  REVIEW_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  DASH_VERSION     NUMBER         NOT NULL,
  SUBMITTED_BY     VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  SUBMITTED_AT     TIMESTAMP      DEFAULT SYSTIMESTAMP,
  REVIEWED_BY      VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  REVIEWED_AT      TIMESTAMP,
  REVIEW_STATUS    VARCHAR2(20)   DEFAULT 'PENDING',
  REVIEW_COMMENTS  CLOB,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID)
);

-- ─── 17. CHECKER_ASSIGNMENTS ────────────────────────────────────────────────
CREATE TABLE NB_CHECKER_ASSIGNMENTS (
  ASSIGNMENT_ID    VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  REVIEW_ID        VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARD_REVIEWS(REVIEW_ID),
  CHECKER_SLOT     NUMBER(1)      NOT NULL CHECK (CHECKER_SLOT IN (1, 2)),
  CHECKER_ID       VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ASSIGNED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  DECISION         VARCHAR2(20),
  DECIDED_AT       TIMESTAMP,
  COMMENTS         CLOB
);

-- ─── 18. APPROVAL_SNAPSHOTS ─────────────────────────────────────────────────
CREATE TABLE NB_APPROVAL_SNAPSHOTS (
  SNAPSHOT_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  REVIEW_ID        VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARD_REVIEWS(REVIEW_ID),
  VERSION          NUMBER         NOT NULL,
  LAYOUT_JSON      CLOB,
  WIDGETS_JSON     CLOB,
  FILTERS_JSON     CLOB,
  SNAPPED_BY       VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  SNAPPED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID)
);

-- ─── 19. PERF_METRICS ───────────────────────────────────────────────────────
CREATE TABLE NB_PERF_METRICS (
  METRIC_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  WIDGET_ID        VARCHAR2(36)   NOT NULL,
  USER_ID          VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  LOAD_MS          NUMBER         NOT NULL,
  CUBE_QUERY_MS    NUMBER,
  RENDER_MS        NUMBER,
  RECORDED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID)
);
CREATE INDEX IDX_PERF_DASH_WIDGET ON NB_PERF_METRICS(DASH_ID, WIDGET_ID);

-- ─── 20. MOBILE_LAYOUTS ─────────────────────────────────────────────────────
CREATE TABLE NB_MOBILE_LAYOUTS (
  LAYOUT_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  LAYOUT_JSON      CLOB,
  WIDGETS_JSON     CLOB,
  LAST_EDITED_BY   VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CONSTRAINT UK_MOBILE_DASH UNIQUE (DASH_ID, ORG_ID)
);

-- ─── 21. NL_FILTER_HISTORY ──────────────────────────────────────────────────
CREATE TABLE NB_NL_FILTER_HISTORY (
  HISTORY_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  USER_ID          VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  RAW_INPUT        VARCHAR2(1000) NOT NULL,
  PARSED_FILTERS   CLOB,
  PARSE_SUCCESS    NUMBER(1)      DEFAULT 0,
  PARSE_CONFIDENCE NUMBER,
  APPLIED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID)
);

-- ─── 22. PREAGG_RECOMMENDATIONS ─────────────────────────────────────────────
CREATE TABLE NB_PREAGG_RECOMMENDATIONS (
  REC_ID           VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  CUBE_NAME        VARCHAR2(200)  NOT NULL,
  DS_ID            VARCHAR2(36)   REFERENCES NB_DATA_SOURCES(DS_ID),
  REASON           VARCHAR2(1000),
  QUERY_COUNT      NUMBER         DEFAULT 0,
  AVG_QUERY_MS     NUMBER,
  PREAGG_DEF       CLOB,
  SMART_REFRESH_CRON VARCHAR2(100),
  CONFIDENCE_SCORE NUMBER,
  STATUS           VARCHAR2(20)   DEFAULT 'PENDING',
  APPLIED_AT       TIMESTAMP,
  APPLIED_BY       VARCHAR2(36),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 23. WEBHOOK_ENDPOINTS ──────────────────────────────────────────────────
CREATE TABLE NB_WEBHOOK_ENDPOINTS (
  ENDPOINT_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ENDPOINT_NAME    VARCHAR2(200)  NOT NULL,
  URL              VARCHAR2(2000) NOT NULL,
  SECRET_HASH      VARCHAR2(200)  NOT NULL,
  TRIGGER_TYPE     VARCHAR2(30)   NOT NULL,
  TRIGGER_CONFIG   CLOB,
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_BY       VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 24. WEBHOOK_DELIVERY_LOG ───────────────────────────────────────────────
CREATE TABLE NB_WEBHOOK_DELIVERY_LOG (
  DELIVERY_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ENDPOINT_ID      VARCHAR2(36)   NOT NULL REFERENCES NB_WEBHOOK_ENDPOINTS(ENDPOINT_ID),
  TRIGGER_EVENT    VARCHAR2(100)  NOT NULL,
  PAYLOAD          CLOB,
  STATUS           VARCHAR2(20)   DEFAULT 'PENDING',
  HTTP_STATUS      NUMBER,
  RESPONSE_BODY    CLOB,
  ATTEMPT_COUNT    NUMBER         DEFAULT 0,
  DELIVERED_AT     TIMESTAMP,
  NEXT_RETRY_AT    TIMESTAMP,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 25. DASH_TEMPLATES ─────────────────────────────────────────────────────
CREATE TABLE NB_DASH_TEMPLATES (
  TEMPLATE_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  TEMPLATE_NAME    VARCHAR2(300)  NOT NULL,
  DESCRIPTION      CLOB,
  CATEGORY         VARCHAR2(100),
  TAGS             VARCHAR2(1000),
  LAYOUT_JSON      CLOB,
  WIDGETS_JSON     CLOB,
  REQUIRED_DS_TYPES CLOB,
  THUMBNAIL_URL    VARCHAR2(1000),
  IS_GLOBAL        NUMBER(1)      DEFAULT 0,
  PUBLISHED_BY     VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  INSTALL_COUNT    NUMBER         DEFAULT 0
);

-- ─── 26. TEMPLATE_INSTALLS ──────────────────────────────────────────────────
CREATE TABLE NB_TEMPLATE_INSTALLS (
  INSTALL_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  TEMPLATE_ID      VARCHAR2(36)   NOT NULL REFERENCES NB_DASH_TEMPLATES(TEMPLATE_ID),
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  DS_MAPPING       CLOB,
  INSTALLED_BY     VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  INSTALLED_AT     TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 27. TIMED_ACCESS ───────────────────────────────────────────────────────
CREATE TABLE NB_TIMED_ACCESS (
  ACCESS_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  RESOURCE_TYPE    VARCHAR2(30)   NOT NULL,
  RESOURCE_ID      VARCHAR2(36)   NOT NULL,
  ROLE_ID          VARCHAR2(36)   REFERENCES NB_ROLES(ROLE_ID),
  USER_ID          VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  GRANTED_BY       VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  EXPIRES_AT       TIMESTAMP      NOT NULL,
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 28. TABLEAU_IMPORTS ────────────────────────────────────────────────────
CREATE TABLE NB_TABLEAU_IMPORTS (
  IMPORT_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  ORIGINAL_NAME    VARCHAR2(500)  NOT NULL,
  MINIO_KEY        VARCHAR2(500),
  IMPORT_STATUS    VARCHAR2(20)   DEFAULT 'PROCESSING',
  DASH_ID          VARCHAR2(36)   REFERENCES NB_DASHBOARDS(DASH_ID),
  WIDGETS_CREATED  NUMBER,
  WARNINGS         CLOB,
  UNMAPPED_ITEMS   CLOB,
  IMPORTED_BY      VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  ORG_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  COMPLETED_AT     TIMESTAMP
);

-- ─── 29. SCHEDULED_REPORTS ──────────────────────────────────────────────────
CREATE TABLE NB_SCHEDULED_REPORTS (
  REPORT_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID),
  REPORT_NAME      VARCHAR2(200)  NOT NULL,
  CRON_EXPRESSION  VARCHAR2(100)  NOT NULL,
  DELIVERY_TYPE    VARCHAR2(30)   NOT NULL,
  DELIVERY_CONFIG  CLOB,
  IS_ACTIVE        NUMBER(1)      DEFAULT 1,
  LAST_RUN_AT      TIMESTAMP,
  LAST_RUN_STATUS  VARCHAR2(20),
  NEXT_RUN_AT      TIMESTAMP,
  CREATED_BY       VARCHAR2(36)   REFERENCES NB_USERS(USER_ID),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ─── 30. AUDIT_LOG ──────────────────────────────────────────────────────────
CREATE TABLE NB_AUDIT_LOG (
  LOG_ID           VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  USER_ID          VARCHAR2(36)   NOT NULL,
  ORG_ID           VARCHAR2(36),
  ACTION           VARCHAR2(100)  NOT NULL,
  RESOURCE_TYPE    VARCHAR2(50),
  RESOURCE_ID      VARCHAR2(36),
  REQUEST_PAYLOAD  CLOB,
  RESPONSE_STATUS  NUMBER,
  IP_ADDRESS       VARCHAR2(45),
  DURATION_MS      NUMBER,
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_AUDIT_ORG_DATE ON NB_AUDIT_LOG(ORG_ID, CREATED_AT DESC);
CREATE INDEX IDX_AUDIT_USER     ON NB_AUDIT_LOG(USER_ID, CREATED_AT DESC);

-- ─── 31. PLATFORM_CONFIG ────────────────────────────────────────────────────
CREATE TABLE NB_PLATFORM_CONFIG (
  CONFIG_KEY       VARCHAR2(200)  PRIMARY KEY,
  CONFIG_VALUE     CLOB           NOT NULL,
  CONFIG_TYPE      VARCHAR2(30)   DEFAULT 'STRING',
  DESCRIPTION      VARCHAR2(500),
  IS_SECRET        NUMBER(1)      DEFAULT 0,
  UPDATED_BY       VARCHAR2(36),
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP
);


-- ════════════════════════════════════════════════════════════════════
-- SEED: 38 Permissions
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.view',       'datasource',  'View data sources');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.create',     'datasource',  'Create data sources');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.edit',       'datasource',  'Edit data sources');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.delete',     'datasource',  'Delete data sources');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.test',       'datasource',  'Test data source connections');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'datasource.manage_acl', 'datasource',  'Manage data source access controls');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'schema.view',           'schema',      'View cube schemas');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'schema.edit',           'schema',      'Edit cube schemas');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'schema.create',         'schema',      'Create cube schemas');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'schema.delete',         'schema',      'Delete cube schemas');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'explorer.use',          'explorer',    'Use the data explorer');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.view',        'dashboard',   'View dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.create',      'dashboard',   'Create dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.edit',        'dashboard',   'Edit dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.delete',      'dashboard',   'Delete dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.submit',      'dashboard',   'Submit dashboards for review');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.approve',     'dashboard',   'Approve pending dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.reject',      'dashboard',   'Reject pending dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.share',       'dashboard',   'Share dashboards with roles/users');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.embed',       'dashboard',   'Generate embed tokens');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.export',      'dashboard',   'Export dashboards to PDF/image');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'dashboard.replay',      'dashboard',   'View approval replay history');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'lineage.view',          'lineage',     'View data lineage graph');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'report.schedule',       'report',      'Create and manage scheduled reports');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'tableau.import',        'tableau',     'Import Tableau workbooks');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'perf.view',             'performance', 'View performance scorecards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'preagg.manage',         'performance', 'Manage pre-aggregation recommendations');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'webhook.manage',        'webhook',     'Manage outbound webhook endpoints');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'template.view',         'template',    'Browse template marketplace');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'template.install',      'template',    'Install templates as dashboards');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'template.publish',      'template',    'Publish dashboards as templates');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'admin.roles',           'admin',       'Manage roles and permissions');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'admin.users',           'admin',       'Manage user accounts');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'admin.platform',        'admin',       'Manage platform configuration');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'audit.view',            'admin',       'View audit log');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'file.upload',           'file',        'Upload files');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'file.manage',           'file',        'Manage uploaded files');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'api_source.manage',     'api_source',  'Manage API data sources');

-- ════════════════════════════════════════════════════════════════════
-- SEED: 6 Roles
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_PADMIN',  'PLATFORM_ADMIN',  'Full platform administration',  1);
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_DSADMIN', 'DS_ADMIN',        'Data source administration',    1);
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_AUTHOR',  'AUTHOR',          'Dashboard creation and editing',1);
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_CHECKER', 'CHECKER',         'Dashboard approval workflow',   1);
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_VIEWER',  'VIEWER',          'Dashboard viewing only',        1);
INSERT INTO NB_ROLES (ROLE_ID, ROLE_NAME, ROLE_DESCRIPTION, IS_SYSTEM_ROLE) VALUES ('R_EMBED',   'EMBED_ONLY',      'Embedded dashboard access',     1);

-- ════════════════════════════════════════════════════════════════════
-- SEED: Role → Permission Map
-- ════════════════════════════════════════════════════════════════════

-- PLATFORM_ADMIN → ALL 38 permissions
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS;

-- DS_ADMIN → 18 permissions
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_DSADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('datasource.view','datasource.create','datasource.edit','datasource.delete','datasource.test','datasource.manage_acl',
                      'schema.view','schema.edit','schema.create','schema.delete',
                      'explorer.use','lineage.view','file.upload','file.manage','api_source.manage',
                      'perf.view','preagg.manage','tableau.import');

-- AUTHOR → 19 permissions
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('datasource.view','schema.view','explorer.use','lineage.view',
                      'dashboard.view','dashboard.create','dashboard.edit','dashboard.delete','dashboard.submit',
                      'dashboard.share','dashboard.embed','dashboard.export','dashboard.replay',
                      'report.schedule','template.view','template.install','template.publish',
                      'perf.view','file.upload');

-- CHECKER → 6 permissions
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_CHECKER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('dashboard.view','dashboard.approve','dashboard.reject','dashboard.replay','lineage.view','perf.view');

-- VIEWER → 4 permissions
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('dashboard.view','template.view','explorer.use','lineage.view');

-- EMBED_ONLY → 1 permission
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_EMBED', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE = 'dashboard.view';


-- ════════════════════════════════════════════════════════════════════
-- SEED: Default Organization
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_ORGANIZATIONS (ORG_ID, ORG_NAME, ORG_SLUG) VALUES ('ORG_DEFAULT', 'Default Organization', 'default');


-- ════════════════════════════════════════════════════════════════════
-- SEED: 6 Dummy Users (for testing)
--
-- ALL PASSWORDS: Test@123!
-- bcrypt 12 rounds hash of "Test@123!" = $2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6
-- (admin uses Admin@123! = $2b$12$LJ3kV0TbY1s9Y5K7T0n8ZeQxHf0W5U5FZ9Qr8Y5P1M7N3X2Z4A6Oi)
-- ════════════════════════════════════════════════════════════════════

-- 1. admin (PLATFORM_ADMIN) — password: Admin@123!
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_ADMIN', 'admin@nexusbi.local', 'admin',
          '$2b$12$LJ3kV0TbY1s9Y5K7T0n8ZeQxHf0W5U5FZ9Qr8Y5P1M7N3X2Z4A6Oi',
          'Platform Administrator', 'ORG_DEFAULT');

-- 2. author1 (AUTHOR) — password: Test@123!
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_AUTHOR1', 'sarah.chen@acme.local', 'author1',
          '$2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6',
          'Sarah Chen', 'ORG_DEFAULT');

-- 3. checker1 (CHECKER) — password: Test@123!
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_CHECKER1', 'michael.kim@acme.local', 'checker1',
          '$2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6',
          'Michael Kim', 'ORG_DEFAULT');

-- 4. checker2 (CHECKER) — password: Test@123! (needed for dual-checker testing)
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_CHECKER2', 'emma.wilson@acme.local', 'checker2',
          '$2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6',
          'Emma Wilson', 'ORG_DEFAULT');

-- 5. viewer1 (VIEWER) — password: Test@123!
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_VIEWER1', 'david.lee@acme.local', 'viewer1',
          '$2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6',
          'David Lee', 'ORG_DEFAULT');

-- 6. embed_user (EMBED_ONLY) — password: Test@123!
INSERT INTO NB_USERS (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID)
  VALUES ('USR_EMBED', 'embed@nexusbi.local', 'embed_user',
          '$2b$12$rZm7rOaSvgLrPJxVq5H3/.RVzA8gE5L2W0QGV6xN4fjFm1jN5G8q6',
          'Embed Service Account', 'ORG_DEFAULT');


-- ════════════════════════════════════════════════════════════════════
-- SEED: User → Role Assignments
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_ADMIN',    'R_PADMIN',  'ORG_DEFAULT', 'SYSTEM');
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_AUTHOR1',  'R_AUTHOR',  'ORG_DEFAULT', 'SYSTEM');
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_CHECKER1', 'R_CHECKER', 'ORG_DEFAULT', 'SYSTEM');
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_CHECKER2', 'R_CHECKER', 'ORG_DEFAULT', 'SYSTEM');
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_VIEWER1',  'R_VIEWER',  'ORG_DEFAULT', 'SYSTEM');
INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_BY) VALUES ('USR_EMBED',    'R_EMBED',   'ORG_DEFAULT', 'SYSTEM');


-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Dashboards (3 dashboards in different states)
-- ════════════════════════════════════════════════════════════════════

-- Dashboard 1: APPROVED (visible to VIEWER)
INSERT INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, ORG_ID, VERSION, TAGS, APPROVAL_STATUS, APPROVED_BY, APPROVED_AT, SOURCE)
  VALUES ('DASH_REVENUE', 'Q4 Revenue Overview',
          'Quarterly revenue performance across all regions with product breakdown.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"Total Revenue","staticValue":"$4.28M","subtitle":"↑ 14.2% vs Q3","x":0,"y":0,"w":3,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"Orders","staticValue":"12,847","subtitle":"↑ 8.1%","x":3,"y":0,"w":3,"h":3},{"widgetId":"w3","widgetType":"kpi","title":"AOV","staticValue":"$333","subtitle":"↓ 2.1%","x":6,"y":0,"w":3,"h":3},{"widgetId":"w4","widgetType":"chart","title":"Revenue by Region","echartsOption":{"xAxis":{"type":"category","data":["APAC","EMEA","Americas","ANZ"]},"yAxis":{"type":"value"},"series":[{"data":[1420000,980000,1560000,320000],"type":"bar","itemStyle":{"color":"#1e40af"}}],"grid":{"left":60,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":8,"h":6},{"widgetId":"w5","widgetType":"table","title":"Top Products","columns":["Product","Revenue","Growth"],"rows":[["Enterprise Plan","$1.2M","+18%"],["Pro Plan","$847K","+12%"],["Team Plan","$562K","+5%"],["Starter","$231K","-3%"]],"x":8,"y":3,"w":4,"h":6}]',
          'USR_AUTHOR1', 'ORG_DEFAULT', 3, 'revenue,quarterly,q4', 'APPROVED', 'USR_CHECKER1', SYSTIMESTAMP, 'MANUAL');

INSERT INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (SYS_GUID(), 'DASH_REVENUE', 3, 'USR_AUTHOR1', 'Q4 final numbers updated');

-- Dashboard 2: DRAFT (only visible to AUTHOR and above)
INSERT INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, ORG_ID, VERSION, TAGS, APPROVAL_STATUS, SOURCE)
  VALUES ('DASH_CHURN', 'Customer Churn Analysis',
          'Monthly churn rates, cohort retention curves, and at-risk account identification.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"Monthly Churn Rate","staticValue":"2.4%","subtitle":"↓ 0.3pp","x":0,"y":0,"w":4,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"At-Risk Accounts","staticValue":"47","subtitle":"Need attention","x":4,"y":0,"w":4,"h":3},{"widgetId":"w3","widgetType":"chart","title":"Churn Trend","echartsOption":{"xAxis":{"type":"category","data":["Jan","Feb","Mar","Apr","May","Jun"]},"yAxis":{"type":"value","axisLabel":{"formatter":"{value}%"}},"series":[{"data":[3.2,2.9,2.7,2.8,2.5,2.4],"type":"line","smooth":true,"itemStyle":{"color":"#c2410c"}}],"grid":{"left":50,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":12,"h":6}]',
          'USR_AUTHOR1', 'ORG_DEFAULT', 1, 'churn,retention', 'DRAFT', 'MANUAL');

INSERT INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (SYS_GUID(), 'DASH_CHURN', 1, 'USR_AUTHOR1', 'Initial creation');

-- Dashboard 3: PENDING_REVIEW with dual-checker (testing approval workflow)
INSERT INTO NB_DASHBOARDS (DASH_ID, DASH_NAME, DESCRIPTION, LAYOUT_JSON, WIDGETS_JSON, OWNER_ID, ORG_ID, VERSION, TAGS, APPROVAL_STATUS, SOURCE, DUAL_CHECKER_REQUIRED)
  VALUES ('DASH_APAC', 'APAC Sales Performance',
          'Regional sales metrics for Asia-Pacific with country-level breakdown.',
          '{"cols":12,"rowHeight":40,"margin":[10,10],"containerPadding":[10,10],"compactType":"vertical"}',
          '[{"widgetId":"w1","widgetType":"kpi","title":"APAC Revenue","staticValue":"$1.42M","subtitle":"↑ 22.7%","x":0,"y":0,"w":4,"h":3},{"widgetId":"w2","widgetType":"kpi","title":"New Customers","staticValue":"284","subtitle":"↑ 18%","x":4,"y":0,"w":4,"h":3},{"widgetId":"w3","widgetType":"chart","title":"Revenue by Country","echartsOption":{"xAxis":{"type":"category","data":["Japan","Australia","India","Singapore","Korea"]},"yAxis":{"type":"value"},"series":[{"data":[480000,320000,280000,190000,150000],"type":"bar","itemStyle":{"color":"#047857"}}],"grid":{"left":60,"right":20,"top":20,"bottom":30}},"x":0,"y":3,"w":12,"h":6}]',
          'USR_AUTHOR1', 'ORG_DEFAULT', 2, 'apac,sales,regional', 'PENDING_REVIEW', 'MANUAL', 1);

INSERT INTO NB_DASHBOARD_VERSIONS (VERSION_ID, DASH_ID, VERSION, SAVED_BY, CHANGE_SUMMARY)
  VALUES (SYS_GUID(), 'DASH_APAC', 2, 'USR_AUTHOR1', 'Added country breakdown chart');

-- Review record for the pending dashboard
INSERT INTO NB_DASHBOARD_REVIEWS (REVIEW_ID, DASH_ID, DASH_VERSION, SUBMITTED_BY, REVIEW_STATUS, ORG_ID)
  VALUES ('REV_APAC_01', 'DASH_APAC', 2, 'USR_AUTHOR1', 'PENDING', 'ORG_DEFAULT');


-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Platform Config
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('app.name', 'NexusBI', 'STRING', 'Application display name', 0);
INSERT INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('app.version', '6.0.0', 'STRING', 'Application version', 0);
INSERT INTO NB_PLATFORM_CONFIG (CONFIG_KEY, CONFIG_VALUE, CONFIG_TYPE, DESCRIPTION, IS_SECRET)
  VALUES ('approval.dual_checker_default', 'false', 'BOOLEAN', 'Default dual-checker requirement for new dashboards', 0);


-- ════════════════════════════════════════════════════════════════════
-- WORKBOOK SYSTEM (Tableau replacement: workbooks, worksheets,
-- calculated fields, parameters, stories, dashboard actions)
-- ════════════════════════════════════════════════════════════════════

-- 32. WORKBOOKS — Author's personal workspace (Tableau .twbx equivalent)
CREATE TABLE NB_WORKBOOKS (
  WORKBOOK_ID       VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_NAME     VARCHAR2(300)  NOT NULL,
  DESCRIPTION       CLOB,
  OWNER_ID          VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ORG_ID            VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  DS_ID             VARCHAR2(36)   REFERENCES NB_DATA_SOURCES(DS_ID),
  TAGS              VARCHAR2(1000),
  IS_PUBLISHED      NUMBER(1)      DEFAULT 0,
  PUBLISHED_DASH_ID VARCHAR2(36)   REFERENCES NB_DASHBOARDS(DASH_ID),
  THUMBNAIL_URL     VARCHAR2(1000),
  VERSION           NUMBER         DEFAULT 1,
  CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_WB_OWNER ON NB_WORKBOOKS(OWNER_ID, ORG_ID);

-- 33. WORKSHEETS — Single analysis view inside a workbook (one chart/table)
CREATE TABLE NB_WORKSHEETS (
  WORKSHEET_ID    VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID     VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  WORKSHEET_NAME  VARCHAR2(300)  NOT NULL,
  SORT_ORDER      NUMBER         DEFAULT 0,
  CHART_TYPE      VARCHAR2(50)   NOT NULL,
  SHELVES_JSON    CLOB           NOT NULL,
  CUBE_QUERY_JSON CLOB,
  CUBE_NAME       VARCHAR2(200),
  SORT_SPECS_JSON CLOB,
  MARK_TYPE       VARCHAR2(50),
  COLOR_PALETTE   VARCHAR2(100),
  AXIS_CONFIG     CLOB,
  TOOLTIP_CONFIG  CLOB,
  REF_LINES_JSON  CLOB,
  ANNOTATIONS_JSON CLOB,
  CREATED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP
);
CREATE INDEX IDX_WS_WORKBOOK ON NB_WORKSHEETS(WORKBOOK_ID, SORT_ORDER);

-- 34. CALCULATED FIELDS — Custom dimensions/measures defined per workbook
CREATE TABLE NB_CALCULATED_FIELDS (
  FIELD_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID      VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  FIELD_NAME       VARCHAR2(200)  NOT NULL,
  EXPRESSION       CLOB           NOT NULL,
  FIELD_TYPE       VARCHAR2(20)   NOT NULL CHECK (FIELD_TYPE IN ('dimension', 'measure')),
  DATA_TYPE        VARCHAR2(20)   NOT NULL CHECK (DATA_TYPE IN ('string', 'number', 'date', 'boolean')),
  DESCRIPTION      VARCHAR2(2000),
  IS_VALID         NUMBER(1)      DEFAULT 1,
  VALIDATION_ERROR VARCHAR2(2000),
  CREATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT       TIMESTAMP      DEFAULT SYSTIMESTAMP,
  CONSTRAINT UK_CF_WB_NAME UNIQUE (WORKBOOK_ID, FIELD_NAME)
);

-- 35. PARAMETERS — User-configurable variables (Tableau parameters)
CREATE TABLE NB_PARAMETERS (
  PARAMETER_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID       VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  PARAMETER_NAME    VARCHAR2(200)  NOT NULL,
  DISPLAY_NAME      VARCHAR2(300)  NOT NULL,
  DATA_TYPE         VARCHAR2(20)   NOT NULL CHECK (DATA_TYPE IN ('string','integer','float','date','boolean')),
  CURRENT_VALUE     VARCHAR2(2000) NOT NULL,
  DEFAULT_VALUE     VARCHAR2(2000) NOT NULL,
  ALLOWABLE_TYPE    VARCHAR2(20)   NOT NULL CHECK (ALLOWABLE_TYPE IN ('all','list','range')),
  ALLOWABLE_VALUES  CLOB,
  RANGE_MIN         VARCHAR2(200),
  RANGE_MAX         VARCHAR2(200),
  RANGE_STEP        VARCHAR2(200),
  CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP,
  CONSTRAINT UK_PARAM_WB_NAME UNIQUE (WORKBOOK_ID, PARAMETER_NAME)
);

-- 36. STORIES — Multi-dashboard narrative sequences (Tableau Story)
CREATE TABLE NB_STORIES (
  STORY_ID      VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  STORY_NAME    VARCHAR2(300)  NOT NULL,
  DESCRIPTION   CLOB,
  OWNER_ID      VARCHAR2(36)   NOT NULL REFERENCES NB_USERS(USER_ID),
  ORG_ID        VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  IS_PUBLISHED  NUMBER(1)      DEFAULT 0,
  VERSION       NUMBER         DEFAULT 1,
  CREATED_AT    TIMESTAMP      DEFAULT SYSTIMESTAMP,
  UPDATED_AT    TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- 37. STORY POINTS — Individual frames within a story
CREATE TABLE NB_STORY_POINTS (
  POINT_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  STORY_ID         VARCHAR2(36)   NOT NULL REFERENCES NB_STORIES(STORY_ID) ON DELETE CASCADE,
  SORT_ORDER       NUMBER         NOT NULL,
  POINT_TYPE       VARCHAR2(20)   NOT NULL CHECK (POINT_TYPE IN ('dashboard','worksheet','text','image')),
  TITLE            VARCHAR2(300)  NOT NULL,
  NARRATIVE        CLOB,
  DASH_ID          VARCHAR2(36)   REFERENCES NB_DASHBOARDS(DASH_ID),
  WORKSHEET_ID     VARCHAR2(36)   REFERENCES NB_WORKSHEETS(WORKSHEET_ID),
  CONTENT_JSON     CLOB,
  FILTER_OVERRIDES CLOB
);
CREATE INDEX IDX_SP_STORY ON NB_STORY_POINTS(STORY_ID, SORT_ORDER);

-- 38. DASHBOARD ACTIONS — Inter-widget filter/highlight/URL actions
CREATE TABLE NB_DASHBOARD_ACTIONS (
  ACTION_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DASH_ID           VARCHAR2(36)   NOT NULL REFERENCES NB_DASHBOARDS(DASH_ID) ON DELETE CASCADE,
  ACTION_NAME       VARCHAR2(200)  NOT NULL,
  ACTION_TYPE       VARCHAR2(20)   NOT NULL CHECK (ACTION_TYPE IN ('filter','highlight','url','parameter')),
  TRIGGER_TYPE      VARCHAR2(20)   NOT NULL CHECK (TRIGGER_TYPE IN ('select','hover','menu')),
  SOURCE_WIDGET_ID  VARCHAR2(36)   NOT NULL,
  TARGET_WIDGETS    CLOB           NOT NULL,
  SOURCE_FIELD      VARCHAR2(200),
  TARGET_FIELD      VARCHAR2(200),
  URL_TEMPLATE      VARCHAR2(2000),
  PARAMETER_NAME    VARCHAR2(200),
  IS_ENABLED        NUMBER(1)      DEFAULT 1,
  CREATED_AT        TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- 39. DATA EXTRACTS — Scheduled snapshots into Oracle staging
CREATE TABLE NB_DATA_EXTRACTS (
  EXTRACT_ID         VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  DS_ID              VARCHAR2(36)   NOT NULL REFERENCES NB_DATA_SOURCES(DS_ID),
  EXTRACT_NAME       VARCHAR2(300)  NOT NULL,
  QUERY_EXPRESSION   CLOB           NOT NULL,
  REFRESH_SCHEDULE   VARCHAR2(100),
  LAST_REFRESHED_AT  TIMESTAMP,
  ROW_COUNT          NUMBER         DEFAULT 0,
  STAGING_TABLE      VARCHAR2(128)  NOT NULL,
  IS_INCREMENTAL     NUMBER(1)      DEFAULT 0,
  INCREMENTAL_COLUMN VARCHAR2(200),
  ORG_ID             VARCHAR2(36)   NOT NULL REFERENCES NB_ORGANIZATIONS(ORG_ID),
  CREATED_AT         TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- 40. DATA SETS — Static or computed groups of dimension members
CREATE TABLE NB_DATA_SETS (
  SET_ID          VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID     VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  SET_NAME        VARCHAR2(200)  NOT NULL,
  SET_TYPE        VARCHAR2(20)   NOT NULL CHECK (SET_TYPE IN ('static','computed')),
  BASE_DIMENSION  VARCHAR2(200)  NOT NULL,
  STATIC_MEMBERS  CLOB,
  CONDITION_JSON  CLOB,
  TOP_N_JSON      CLOB,
  CREATED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- 41. DATA GROUPS — Bucketing dimension members into named groups
CREATE TABLE NB_DATA_GROUPS (
  GROUP_ID        VARCHAR2(36)   DEFAULT SYS_GUID() PRIMARY KEY,
  WORKBOOK_ID     VARCHAR2(36)   NOT NULL REFERENCES NB_WORKBOOKS(WORKBOOK_ID) ON DELETE CASCADE,
  GROUP_NAME      VARCHAR2(200)  NOT NULL,
  BASE_DIMENSION  VARCHAR2(200)  NOT NULL,
  GROUP_MEMBERS   CLOB           NOT NULL,
  INCLUDE_OTHER   NUMBER(1)      DEFAULT 1,
  OTHER_LABEL     VARCHAR2(200)  DEFAULT 'Other',
  CREATED_AT      TIMESTAMP      DEFAULT SYSTIMESTAMP
);

-- ════════════════════════════════════════════════════════════════════
-- WORKBOOK PERMISSIONS — Add to NB_PERMISSIONS
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'workbook.view',     'workbook', 'View own workbooks');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'workbook.create',   'workbook', 'Create new workbooks');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'workbook.edit',     'workbook', 'Edit workbooks');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'workbook.delete',   'workbook', 'Delete workbooks');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'workbook.publish',  'workbook', 'Publish workbook to dashboard');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'story.view',        'story',    'View stories');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'story.create',      'story',    'Create stories');
INSERT INTO NB_PERMISSIONS (PERM_ID, PERM_CODE, PERM_CATEGORY, DESCRIPTION) VALUES (SYS_GUID(), 'story.edit',        'story',    'Edit stories');

-- Grant workbook + story perms to PLATFORM_ADMIN
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_PADMIN', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('workbook.view','workbook.create','workbook.edit','workbook.delete','workbook.publish','story.view','story.create','story.edit');

-- Grant workbook + story perms to AUTHOR (the Maker role)
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_AUTHOR', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS
  WHERE PERM_CODE IN ('workbook.view','workbook.create','workbook.edit','workbook.delete','workbook.publish','story.view','story.create','story.edit');

-- Grant story.view to VIEWER
INSERT INTO NB_ROLE_PERMISSIONS (ROLE_ID, PERM_ID, GRANTED_BY)
  SELECT 'R_VIEWER', PERM_ID, 'SYSTEM' FROM NB_PERMISSIONS WHERE PERM_CODE = 'story.view';

-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Workbook (so AUTHOR has something to start with)
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_WORKBOOKS (WORKBOOK_ID, WORKBOOK_NAME, DESCRIPTION, OWNER_ID, ORG_ID, TAGS, VERSION)
  VALUES ('WB_REVENUE', 'Revenue Analysis Workbook',
          'Personal workspace for exploring quarterly revenue across regions and products.',
          'USR_AUTHOR1', 'ORG_DEFAULT', 'revenue,exploratory', 1);

INSERT INTO NB_WORKSHEETS (WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME)
  VALUES ('WS_REGION', 'WB_REVENUE', 'Revenue by Region', 0, 'bar',
          '{"columns":["region"],"rows":["total_revenue"],"color":"region","size":null,"label":null,"detail":[],"tooltip":[],"filters":[],"pages":[]}',
          'Orders');

INSERT INTO NB_WORKSHEETS (WORKSHEET_ID, WORKBOOK_ID, WORKSHEET_NAME, SORT_ORDER, CHART_TYPE, SHELVES_JSON, CUBE_NAME)
  VALUES ('WS_TREND', 'WB_REVENUE', 'Revenue Trend', 1, 'line',
          '{"columns":["order_date.month"],"rows":["total_revenue"],"color":null,"size":null,"label":null,"detail":[],"tooltip":[],"filters":[],"pages":[]}',
          'Orders');

INSERT INTO NB_CALCULATED_FIELDS (FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID)
  VALUES (SYS_GUID(), 'WB_REVENUE', 'profit_margin', '(total_revenue - total_cost) / NULLIF(total_revenue, 0)', 'measure', 'number',
          'Profit margin as a percentage of revenue', 1);

INSERT INTO NB_CALCULATED_FIELDS (FIELD_ID, WORKBOOK_ID, FIELD_NAME, EXPRESSION, FIELD_TYPE, DATA_TYPE, DESCRIPTION, IS_VALID)
  VALUES (SYS_GUID(), 'WB_REVENUE', 'revenue_bucket', 'CASE WHEN total_revenue > 1000000 THEN ''High'' WHEN total_revenue > 100000 THEN ''Mid'' ELSE ''Low'' END', 'dimension', 'string',
          'Bucket revenue into High/Mid/Low tiers', 1);

INSERT INTO NB_PARAMETERS (PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE, CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, ALLOWABLE_VALUES)
  VALUES (SYS_GUID(), 'WB_REVENUE', 'target_region', 'Target Region', 'string', 'APAC', 'APAC', 'list',
          '["APAC","EMEA","Americas","ANZ","LATAM"]');

INSERT INTO NB_PARAMETERS (PARAMETER_ID, WORKBOOK_ID, PARAMETER_NAME, DISPLAY_NAME, DATA_TYPE, CURRENT_VALUE, DEFAULT_VALUE, ALLOWABLE_TYPE, RANGE_MIN, RANGE_MAX, RANGE_STEP)
  VALUES (SYS_GUID(), 'WB_REVENUE', 'min_revenue', 'Minimum Revenue', 'integer', '100000', '100000', 'range',
          '0', '10000000', '50000');

-- ════════════════════════════════════════════════════════════════════
-- SEED: Sample Story
-- ════════════════════════════════════════════════════════════════════
INSERT INTO NB_STORIES (STORY_ID, STORY_NAME, DESCRIPTION, OWNER_ID, ORG_ID, IS_PUBLISHED, VERSION)
  VALUES ('STORY_Q4', 'Q4 Performance Story',
          'Walkthrough of Q4 results across regions, products, and trends.',
          'USR_AUTHOR1', 'ORG_DEFAULT', 1, 1);

INSERT INTO NB_STORY_POINTS (POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE, DASH_ID)
  VALUES (SYS_GUID(), 'STORY_Q4', 0, 'dashboard', 'Q4 Revenue Overview',
          'We exceeded Q3 revenue by 14.2%, driven primarily by APAC and Americas.', 'DASH_REVENUE');

INSERT INTO NB_STORY_POINTS (POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE)
  VALUES (SYS_GUID(), 'STORY_Q4', 1, 'text', 'Key Takeaways',
          'Three things stood out this quarter: (1) APAC growth of 22.7%, (2) AOV decline of 2.1% needs attention, (3) Enterprise Plan continues to be our top revenue driver at $1.2M.');

-- ════════════════════════════════════════════════════════════════════
-- SEED: Dashboard Shares (so VIEWER role sees ONLY shared dashboards)
-- ════════════════════════════════════════════════════════════════════
-- Share Q4 Revenue dashboard with viewer1 specifically
INSERT INTO NB_DASHBOARD_SHARES (SHARE_ID, DASH_ID, USER_ID, CAN_EDIT, CAN_SHARE, ORG_ID)
  VALUES (SYS_GUID(), 'DASH_REVENUE', 'USR_VIEWER1', 0, 0, 'ORG_DEFAULT');

-- Share Q4 Revenue dashboard with the entire VIEWER role
INSERT INTO NB_DASHBOARD_SHARES (SHARE_ID, DASH_ID, ROLE_ID, CAN_EDIT, CAN_SHARE, ORG_ID)
  VALUES (SYS_GUID(), 'DASH_REVENUE', 'R_VIEWER', 0, 0, 'ORG_DEFAULT');

COMMIT;

import type {
  IntrospectedTable,
  IntrospectedColumn,
  AutoGenerateOptions,
  MeasureType,
  DimensionType,
} from '@nexusbi/shared-types';

interface GeneratedSchema {
  cubeName: string;
  schemaJs: string;
}

const NUMERIC_DB_TYPES = [
  'NUMBER', 'NUMERIC', 'DECIMAL', 'INT', 'INTEGER', 'BIGINT', 'SMALLINT', 'TINYINT',
  'FLOAT', 'DOUBLE', 'REAL', 'DOUBLE PRECISION', 'MONEY', 'SMALLMONEY',
  'INT2', 'INT4', 'INT8', 'FLOAT4', 'FLOAT8', 'SERIAL', 'BIGSERIAL',
];

const DATE_DB_TYPES = [
  'DATE', 'DATETIME', 'DATETIME2', 'TIMESTAMP', 'TIMESTAMP WITH TIME ZONE',
  'TIMESTAMP WITHOUT TIME ZONE', 'TIMESTAMPTZ', 'SMALLDATETIME',
];

const BOOLEAN_DB_TYPES = ['BOOLEAN', 'BOOL', 'BIT'];

function toCamelCase(str: string): string {
  return str
    .toLowerCase()
    .replace(/[^a-zA-Z0-9]+(.)/g, (_match, chr: string) => chr.toUpperCase());
}

function toPascalCase(str: string): string {
  const camel = toCamelCase(str);
  return camel.charAt(0).toUpperCase() + camel.slice(1);
}

function toSnakeCase(str: string): string {
  return str.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
}

function inferDimensionType(column: IntrospectedColumn): DimensionType {
  const upperType = column.dataType.toUpperCase().split('(')[0].trim();

  if (DATE_DB_TYPES.some((dt) => upperType.includes(dt))) {
    return 'time';
  }
  if (NUMERIC_DB_TYPES.some((nt) => upperType === nt || upperType.startsWith(nt + '('))) {
    return 'number';
  }
  if (BOOLEAN_DB_TYPES.some((bt) => upperType === bt)) {
    return 'boolean';
  }
  return 'string';
}

function shouldBeMeasure(column: IntrospectedColumn, inferMeasures: boolean): boolean {
  if (!inferMeasures) return false;
  if (column.isPrimaryKey || column.isForeignKey) return false;
  const upperType = column.dataType.toUpperCase().split('(')[0].trim();
  if (!NUMERIC_DB_TYPES.some((nt) => upperType === nt || upperType.startsWith(nt + '('))) {
    return false;
  }
  const lowerName = column.columnName.toLowerCase();
  const measureHints = [
    'amount', 'total', 'sum', 'count', 'qty', 'quantity',
    'price', 'cost', 'revenue', 'sales', 'profit', 'margin',
    'balance', 'rate', 'score', 'value', 'weight', 'size',
    'duration', 'latency', 'fee', 'tax', 'discount',
  ];
  return measureHints.some((hint) => lowerName.includes(hint));
}

function inferMeasureType(column: IntrospectedColumn): MeasureType {
  const lowerName = column.columnName.toLowerCase();
  if (lowerName.includes('count') || lowerName.includes('qty') || lowerName.includes('quantity')) {
    return 'sum';
  }
  if (lowerName.includes('avg') || lowerName.includes('rate') || lowerName.includes('score')) {
    return 'avg';
  }
  return 'sum';
}

function formatName(name: string, convention: 'camelCase' | 'snake_case'): string {
  return convention === 'camelCase' ? toCamelCase(name) : toSnakeCase(name);
}

function generateSchemaForTable(
  table: IntrospectedTable,
  options: AutoGenerateOptions,
  allTables: IntrospectedTable[],
): GeneratedSchema {
  const convention = options.namingConvention ?? 'camelCase';
  const inferMeasuresFlag = options.inferMeasures ?? true;
  const cubeName = toPascalCase(table.tableName);
  const sqlTable = table.schemaName
    ? `${table.schemaName}.${table.tableName}`
    : table.tableName;

  const primaryKeyCol = table.columns.find((c) => c.isPrimaryKey);
  const measures: string[] = [];
  const dimensions: string[] = [];
  const joins: string[] = [];

  // Count measure always
  measures.push(`    ${formatName('count', convention)}: {
      type: \`count\`,
      drillMembers: [${primaryKeyCol ? formatName(primaryKeyCol.columnName, convention) : ''}]
    }`);

  for (const col of table.columns) {
    if (shouldBeMeasure(col, inferMeasuresFlag)) {
      const mType = inferMeasureType(col);
      const mName = formatName(col.columnName, convention);
      measures.push(`    ${mName}: {
      sql: \`\${CUBE}.\${col.columnName}\`,
      type: \`${mType}\`,
      title: \`${col.columnName.replace(/_/g, ' ')}\`
    }`);
    } else {
      const dType = inferDimensionType(col);
      const dName = formatName(col.columnName, convention);
      const dimDef: string[] = [
        `      sql: \`\${CUBE}.${col.columnName}\``,
        `      type: \`${dType}\``,
      ];
      if (col.isPrimaryKey) {
        dimDef.push(`      primaryKey: true`);
      }
      dimensions.push(`    ${dName}: {\n${dimDef.join(',\n')}\n    }`);
    }
  }

  if (options.includeJoins) {
    for (const col of table.columns) {
      if (col.isForeignKey && col.referencedTable) {
        const refTable = allTables.find(
          (t) => t.tableName === col.referencedTable,
        );
        if (refTable && options.tables.includes(refTable.tableName)) {
          const joinName = toPascalCase(col.referencedTable);
          const refPk = refTable.columns.find((c) => c.isPrimaryKey);
          if (refPk) {
            joins.push(`    ${joinName}: {
      sql: \`\${CUBE}.${col.columnName} = \${${joinName}}.${refPk.columnName}\`,
      relationship: \`many_to_one\`
    }`);
          }
        }
      }
    }
  }

  const parts: string[] = [
    `cube(\`${cubeName}\`, {`,
    `  sql: \`SELECT * FROM ${sqlTable}\`,`,
    '',
  ];

  if (joins.length > 0) {
    parts.push(`  joins: {`);
    parts.push(joins.join(',\n\n'));
    parts.push(`  },`);
    parts.push('');
  }

  parts.push(`  measures: {`);
  parts.push(measures.join(',\n\n'));
  parts.push(`  },`);
  parts.push('');
  parts.push(`  dimensions: {`);
  parts.push(dimensions.join(',\n\n'));
  parts.push(`  }`);
  parts.push(`});`);

  return {
    cubeName,
    schemaJs: parts.join('\n'),
  };
}

export function generateCubeSchemas(
  tables: IntrospectedTable[],
  options: AutoGenerateOptions,
): GeneratedSchema[] {
  const selectedTables = tables.filter((t) => options.tables.includes(t.tableName));
  return selectedTables.map((table) => generateSchemaForTable(table, options, tables));
}

export function generateSingleCubeSchema(
  table: IntrospectedTable,
  options: Omit<AutoGenerateOptions, 'tables'>,
): GeneratedSchema {
  return generateSchemaForTable(
    table,
    { ...options, tables: [table.tableName] },
    [table],
  );
}

export interface ValidationError {
  line: number | null;
  message: string;
  severity: 'error' | 'warning';
}

export interface ValidationResult {
  valid: boolean;
  errors: ValidationError[];
  warnings: ValidationError[];
  cubeName: string | null;
  measuresCount: number;
  dimensionsCount: number;
}

const REQUIRED_SECTIONS = ['measures', 'dimensions'] as const;
const VALID_MEASURE_TYPES = [
  'count', 'countDistinct', 'countDistinctApprox',
  'sum', 'avg', 'min', 'max', 'number', 'runningTotal',
];
const VALID_DIMENSION_TYPES = ['string', 'number', 'boolean', 'time', 'geo'];
const VALID_RELATIONSHIP_TYPES = ['one_to_one', 'one_to_many', 'many_to_one'];
const DANGEROUS_PATTERNS = [
  /require\s*\(/,
  /import\s+/,
  /process\./,
  /global\./,
  /eval\s*\(/,
  /Function\s*\(/,
  /child_process/,
  /fs\./,
  /\bexec\s*\(/,
  /\bspawn\s*\(/,
];

function extractCubeName(schemaJs: string): string | null {
  const match = schemaJs.match(/cube\s*\(\s*[`'"]([\w]+)[`'"]/);
  return match ? match[1] : null;
}

function countMembers(schemaJs: string, section: string): number {
  const sectionRegex = new RegExp(`${section}\\s*:\\s*\\{`, 'g');
  const match = sectionRegex.exec(schemaJs);
  if (!match) return 0;

  let braceCount = 1;
  let pos = match.index + match[0].length;
  let memberCount = 0;
  let depth = 1;

  while (pos < schemaJs.length && braceCount > 0) {
    const char = schemaJs[pos];
    if (char === '{') {
      braceCount++;
      if (braceCount === 2) {
        memberCount++;
      }
    } else if (char === '}') {
      braceCount--;
    }
    pos++;
  }

  return memberCount;
}

function checkDangerousPatterns(schemaJs: string): ValidationError[] {
  const errors: ValidationError[] = [];
  const lines = schemaJs.split('\n');

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    for (const pattern of DANGEROUS_PATTERNS) {
      if (pattern.test(line)) {
        errors.push({
          line: i + 1,
          message: `Potentially dangerous pattern detected: ${pattern.source}`,
          severity: 'error',
        });
      }
    }
  }

  return errors;
}

function checkSyntax(schemaJs: string): ValidationError[] {
  const errors: ValidationError[] = [];

  // Check balanced braces
  let braceCount = 0;
  let parenCount = 0;
  const lines = schemaJs.split('\n');

  for (let i = 0; i < lines.length; i++) {
    for (const char of lines[i]) {
      if (char === '{') braceCount++;
      if (char === '}') braceCount--;
      if (char === '(') parenCount++;
      if (char === ')') parenCount--;

      if (braceCount < 0) {
        errors.push({
          line: i + 1,
          message: 'Unexpected closing brace',
          severity: 'error',
        });
        braceCount = 0;
      }
      if (parenCount < 0) {
        errors.push({
          line: i + 1,
          message: 'Unexpected closing parenthesis',
          severity: 'error',
        });
        parenCount = 0;
      }
    }
  }

  if (braceCount !== 0) {
    errors.push({
      line: null,
      message: `Unbalanced braces: ${braceCount > 0 ? 'missing closing' : 'extra closing'} brace(s)`,
      severity: 'error',
    });
  }

  if (parenCount !== 0) {
    errors.push({
      line: null,
      message: `Unbalanced parentheses: ${parenCount > 0 ? 'missing closing' : 'extra closing'} parenthesis`,
      severity: 'error',
    });
  }

  return errors;
}

function checkStructure(schemaJs: string): ValidationError[] {
  const errors: ValidationError[] = [];
  const warnings: ValidationError[] = [];

  // Check cube() wrapper
  if (!schemaJs.match(/cube\s*\(/)) {
    errors.push({
      line: null,
      message: 'Schema must be wrapped in a cube() call',
      severity: 'error',
    });
    return errors;
  }

  // Check sql property
  if (!schemaJs.match(/sql\s*:/)) {
    errors.push({
      line: null,
      message: 'Missing required "sql" property',
      severity: 'error',
    });
  }

  // Check required sections
  for (const section of REQUIRED_SECTIONS) {
    if (!schemaJs.match(new RegExp(`${section}\\s*:\\s*\\{`))) {
      errors.push({
        line: null,
        message: `Missing required section: "${section}"`,
        severity: 'error',
      });
    }
  }

  // Validate measure types
  const measureTypeMatches = schemaJs.matchAll(/type\s*:\s*[`'"]([\w]+)[`'"]/g);
  for (const match of measureTypeMatches) {
    const typeValue = match[1];
    if (
      !VALID_MEASURE_TYPES.includes(typeValue) &&
      !VALID_DIMENSION_TYPES.includes(typeValue) &&
      !VALID_RELATIONSHIP_TYPES.includes(typeValue)
    ) {
      warnings.push({
        line: null,
        message: `Unknown type "${typeValue}" — verify it is a valid Cube.js type`,
        severity: 'warning',
      });
    }
  }

  // Check for primaryKey dimension
  if (!schemaJs.match(/primaryKey\s*:\s*true/)) {
    warnings.push({
      line: null,
      message: 'No dimension marked as primaryKey — count measures may be inaccurate',
      severity: 'warning',
    });
  }

  return [...errors, ...warnings];
}

export function validateCubeSchema(schemaJs: string): ValidationResult {
  const allErrors: ValidationError[] = [];
  const allWarnings: ValidationError[] = [];

  if (!schemaJs || schemaJs.trim().length === 0) {
    return {
      valid: false,
      errors: [{ line: null, message: 'Schema is empty', severity: 'error' }],
      warnings: [],
      cubeName: null,
      measuresCount: 0,
      dimensionsCount: 0,
    };
  }

  const dangerousErrors = checkDangerousPatterns(schemaJs);
  allErrors.push(...dangerousErrors.filter((e) => e.severity === 'error'));

  const syntaxErrors = checkSyntax(schemaJs);
  allErrors.push(...syntaxErrors.filter((e) => e.severity === 'error'));

  const structureResults = checkStructure(schemaJs);
  allErrors.push(...structureResults.filter((e) => e.severity === 'error'));
  allWarnings.push(...structureResults.filter((e) => e.severity === 'warning'));

  const cubeName = extractCubeName(schemaJs);
  if (!cubeName) {
    allErrors.push({
      line: null,
      message: 'Could not extract cube name from schema',
      severity: 'error',
    });
  }

  const measuresCount = countMembers(schemaJs, 'measures');
  const dimensionsCount = countMembers(schemaJs, 'dimensions');

  if (measuresCount === 0) {
    allWarnings.push({
      line: null,
      message: 'No measures defined — cube will have limited query capabilities',
      severity: 'warning',
    });
  }

  if (dimensionsCount === 0) {
    allWarnings.push({
      line: null,
      message: 'No dimensions defined — cube will have limited query capabilities',
      severity: 'warning',
    });
  }

  return {
    valid: allErrors.length === 0,
    errors: allErrors,
    warnings: allWarnings,
    cubeName,
    measuresCount,
    dimensionsCount,
  };
}

export function sanitizeSchemaJs(schemaJs: string): string {
  let sanitized = schemaJs.trim();

  // Remove any BOM
  if (sanitized.charCodeAt(0) === 0xfeff) {
    sanitized = sanitized.slice(1);
  }

  // Normalize line endings
  sanitized = sanitized.replace(/\r\n/g, '\n').replace(/\r/g, '\n');

  return sanitized;
}

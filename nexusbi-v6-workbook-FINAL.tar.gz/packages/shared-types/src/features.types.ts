import type { LayoutConfig, WidgetConfig, CubeFilter } from './dashboard.types';

// ── Performance Metrics ──────────────────────────────────

export interface PerfMetric {
  metricId: string;
  dashId: string;
  widgetId: string;
  userId: string;
  loadMs: number;
  cubeQueryMs: number;
  renderMs: number;
  viewedAt: string;
  orgId: string;
}

export interface PerfMetricLogInput {
  widgetId: string;
  loadMs: number;
  cubeQueryMs: number;
  renderMs: number;
}

export interface PerfAggregation {
  widgetId: string;
  widgetTitle: string;
  p50LoadMs: number;
  p95LoadMs: number;
  p99LoadMs: number;
  p50CubeQueryMs: number;
  p95CubeQueryMs: number;
  p99CubeQueryMs: number;
  p50RenderMs: number;
  p95RenderMs: number;
  p99RenderMs: number;
  sampleCount: number;
}

export interface PerfScorecard {
  dashId: string;
  dashName: string;
  widgets: PerfAggregation[];
  overallP50Ms: number;
  overallP95Ms: number;
  preaggCoveragePct: number;
  recommendations: PerfRecommendation[];
  generatedAt: string;
}

export interface PerfRecommendation {
  widgetId: string;
  widgetTitle: string;
  reason: string;
  suggestedAction: string;
  preaggRecId?: string;
  estimatedImprovement?: string;
}

// ── Webhook-Out ──────────────────────────────────────────

export const WEBHOOK_TRIGGER_TYPES = ['approval', 'threshold', 'schedule', 'manual'] as const;
export type WebhookTriggerType = (typeof WEBHOOK_TRIGGER_TYPES)[number];

export const WEBHOOK_DELIVERY_STATUSES = ['PENDING', 'SUCCESS', 'FAILED', 'RETRYING'] as const;
export type WebhookDeliveryStatus = (typeof WEBHOOK_DELIVERY_STATUSES)[number];

export interface WebhookEndpoint {
  endpointId: string;
  endpointName: string;
  url: string;
  secretHash: string;
  triggerType: WebhookTriggerType;
  triggerConfig: WebhookTriggerConfig | null;
  isActive: boolean;
  orgId: string;
  createdBy: string;
  createdAt: string;
}

export interface WebhookTriggerConfig {
  dashId?: string;
  metricThreshold?: {
    measure: string;
    operator: 'gt' | 'gte' | 'lt' | 'lte';
    value: number;
  };
  cronExpression?: string;
}

export interface WebhookEndpointCreateInput {
  endpointName: string;
  url: string;
  secret: string;
  triggerType: WebhookTriggerType;
  triggerConfig?: WebhookTriggerConfig;
}

export interface WebhookEndpointUpdateInput {
  endpointName?: string;
  url?: string;
  secret?: string;
  triggerType?: WebhookTriggerType;
  triggerConfig?: WebhookTriggerConfig;
  isActive?: boolean;
}

export interface WebhookDeliveryLog {
  deliveryId: string;
  endpointId: string;
  triggerEvent: string;
  payload: Record<string, unknown> | null;
  httpStatus: number | null;
  responseBody: string | null;
  attemptCount: number;
  deliveredAt: string | null;
  nextRetryAt: string | null;
  status: WebhookDeliveryStatus;
}

export interface WebhookPayload {
  event: string;
  dashId?: string;
  triggeredAt: string;
  data: Record<string, unknown>;
  orgId: string;
}

// ── Dashboard Templates ──────────────────────────────────

export interface DashTemplate {
  templateId: string;
  templateName: string;
  description: string | null;
  category: string | null;
  tags: string | null;
  layoutJson: LayoutConfig;
  widgetsJson: WidgetConfig[];
  requiredDsTypes: string[] | null;
  thumbnailUrl: string | null;
  isGlobal: boolean;
  publishedBy: string;
  orgId: string;
  createdAt: string;
  installCount: number;
}

export interface DashTemplateCreateInput {
  dashId: string;
  templateName: string;
  description?: string;
  category?: string;
  tags?: string;
  isGlobal?: boolean;
}

export interface TemplateInstall {
  installId: string;
  templateId: string;
  dashId: string;
  dsMapping: Record<string, string>;
  installedBy: string;
  orgId: string;
  installedAt: string;
}

export interface TemplateInstallInput {
  dsMapping: Record<string, string>;
  dashName?: string;
}

// ── Natural Language Filter ──────────────────────────────

export interface NLFilterHistory {
  historyId: string;
  dashId: string;
  userId: string;
  rawInput: string;
  parsedFilters: CubeFilter[] | null;
  parseSuccess: boolean;
  parseConfidence: number | null;
  appliedAt: string;
  orgId: string;
}

export interface NLFilterParseResult {
  filters: CubeFilter[];
  confidence: number;
  unmatched: string[];
}

export interface NLFilterInput {
  text: string;
  cubeName?: string;
  availableDimensions?: string[];
  availableMeasures?: string[];
}

// ── Mobile Layout ────────────────────────────────────────

export interface MobileLayout {
  layoutId: string;
  dashId: string;
  layoutJson: LayoutConfig;
  widgetsJson: WidgetConfig[];
  lastEditedBy: string | null;
  updatedAt: string;
  orgId: string;
}

export interface MobileLayoutInput {
  layoutJson: LayoutConfig;
  widgetsJson: WidgetConfig[];
}

// ── Smart Refresh ────────────────────────────────────────

export interface RefreshScheduleLog {
  logId: string;
  dsId: string;
  cubeName: string;
  measureNames: string[] | null;
  queryCount: number;
  avgDurationMs: number;
  hourOfDay: number;
  dayOfWeek: number;
  weekStart: string;
  orgId: string;
}

export interface SmartRefreshSuggestion {
  recId: string;
  dsId: string;
  cubeName: string;
  suggestedPreagg: string;
  reason: string;
  smartRefreshCron: string | null;
  confidenceScore: number | null;
  avgQueryMs: number;
  queryCount: number;
}

export interface PreAggRecommendation {
  recId: string;
  dsId: string;
  cubeName: string;
  suggestedPreagg: string;
  reason: string;
  avgQueryMs: number;
  queryCount: number;
  status: 'PENDING' | 'APPLIED' | 'DISMISSED';
  smartRefreshCron: string | null;
  confidenceScore: number | null;
  appliedAt: string | null;
  appliedBy: string | null;
  createdAt: string;
}

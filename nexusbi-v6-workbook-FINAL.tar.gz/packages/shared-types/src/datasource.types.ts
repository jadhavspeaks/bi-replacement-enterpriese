export const DATA_SOURCE_TYPES = [
  'postgres',
  'mysql',
  'mssql',
  'oracle',
  'sqlite',
  'snowflake',
  'bigquery',
  'redshift',
  'databricks',
  'athena',
  'hive',
  'sparksql',
  'impala',
  'presto',
  'trino',
  'clickhouse',
  'mongodb',
  'duckdb',
  'file_csv',
  'file_excel',
  'file_parquet',
  'file_json',
  'api_rest',
  'api_graphql',
  'api_webhook',
  'api_oauth_rest',
] as const;

export type DataSourceType = (typeof DATA_SOURCE_TYPES)[number];

export type DataSourceStatus = 'ACTIVE' | 'INACTIVE' | 'ERROR' | 'TESTING';

export interface DriverCapability {
  supportsSchemaIntrospection: boolean;
  supportsPreAggregations: boolean;
  supportsStreaming: boolean;
  requiresFileUpload: boolean;
  requiresApiConfig: boolean;
  cubeDriverPackage: string | null;
  defaultPort: number | null;
}

export const DRIVER_CAPABILITIES: Record<DataSourceType, DriverCapability> = {
  postgres: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/postgres-driver',
    defaultPort: 5432,
  },
  mysql: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/mysql-driver',
    defaultPort: 3306,
  },
  mssql: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/mssql-driver',
    defaultPort: 1433,
  },
  oracle: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: 1521,
  },
  sqlite: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/sqlite-driver',
    defaultPort: null,
  },
  snowflake: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/snowflake-driver',
    defaultPort: 443,
  },
  bigquery: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/bigquery-driver',
    defaultPort: null,
  },
  redshift: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/redshift-driver',
    defaultPort: 5439,
  },
  databricks: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/databricks-jdbc-driver',
    defaultPort: 443,
  },
  athena: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/athena-driver',
    defaultPort: null,
  },
  hive: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/hive-driver',
    defaultPort: 10000,
  },
  sparksql: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/hive-driver',
    defaultPort: 10000,
  },
  impala: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/hive-driver',
    defaultPort: 21050,
  },
  presto: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/prestodb-driver',
    defaultPort: 8080,
  },
  trino: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/prestodb-driver',
    defaultPort: 8080,
  },
  clickhouse: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: true,
    supportsStreaming: true,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/clickhouse-driver',
    defaultPort: 8123,
  },
  mongodb: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/mongobi-driver',
    defaultPort: 3307,
  },
  duckdb: {
    supportsSchemaIntrospection: true,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  file_csv: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  file_excel: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  file_parquet: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  file_json: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: true,
    requiresApiConfig: false,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  api_rest: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  api_graphql: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  api_webhook: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
  api_oauth_rest: {
    supportsSchemaIntrospection: false,
    supportsPreAggregations: false,
    supportsStreaming: false,
    requiresFileUpload: false,
    requiresApiConfig: true,
    cubeDriverPackage: '@cubejs-backend/oracle-driver',
    defaultPort: null,
  },
};

export interface DataSource {
  dsId: string;
  dsName: string;
  dsType: DataSourceType;
  description: string | null;
  configEncrypted: string;
  configMasked: string | null;
  status: DataSourceStatus;
  lastTestedAt: string | null;
  lastTestResult: string | null;
  lastErrorMsg: string | null;
  cubeDsId: string | null;
  orgId: string;
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  isActive: boolean;
}

export interface DataSourceCreateInput {
  dsName: string;
  dsType: DataSourceType;
  description?: string;
  config: Record<string, unknown>;
}

export interface DataSourceUpdateInput {
  dsName?: string;
  description?: string;
  config?: Record<string, unknown>;
  isActive?: boolean;
}

export interface DsAccess {
  accessId: string;
  dsId: string;
  roleId: string;
  canQuery: boolean;
  canExport: boolean;
  canManage: boolean;
  rowFilterSql: string | null;
  columnBlacklist: string | null;
  grantedAt: string;
  grantedBy: string;
  expiresAt: string | null;
}

export interface DsAccessInput {
  roleId: string;
  canQuery?: boolean;
  canExport?: boolean;
  canManage?: boolean;
  rowFilterSql?: string;
  columnBlacklist?: string[];
  expiresAt?: string;
}

export interface ConnectionTestResult {
  success: boolean;
  latencyMs: number;
  tableCount: number | null;
  errorMessage: string | null;
}

export const DS_TYPE_LABELS: Record<DataSourceType, string> = {
  postgres: 'PostgreSQL',
  mysql: 'MySQL',
  mssql: 'Microsoft SQL Server',
  oracle: 'Oracle Database',
  sqlite: 'SQLite',
  snowflake: 'Snowflake',
  bigquery: 'Google BigQuery',
  redshift: 'Amazon Redshift',
  databricks: 'Databricks',
  athena: 'Amazon Athena',
  hive: 'Apache Hive',
  sparksql: 'Spark SQL',
  impala: 'Apache Impala',
  presto: 'Presto',
  trino: 'Trino',
  clickhouse: 'ClickHouse',
  mongodb: 'MongoDB (BI Connector)',
  duckdb: 'DuckDB',
  file_csv: 'CSV File',
  file_excel: 'Excel File',
  file_parquet: 'Parquet File',
  file_json: 'JSON File',
  api_rest: 'REST API',
  api_graphql: 'GraphQL API',
  api_webhook: 'Inbound Webhook',
  api_oauth_rest: 'OAuth REST API',
};

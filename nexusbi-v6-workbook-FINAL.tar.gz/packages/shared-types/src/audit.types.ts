export const AUDIT_ACTIONS = [
  'datasource.create',
  'datasource.update',
  'datasource.delete',
  'datasource.test',
  'datasource.access.update',
  'schema.create',
  'schema.update',
  'schema.delete',
  'schema.autogenerate',
  'dashboard.create',
  'dashboard.update',
  'dashboard.delete',
  'dashboard.share',
  'dashboard.unshare',
  'dashboard.embed',
  'dashboard.export',
  'dashboard.submit',
  'dashboard.approve',
  'dashboard.reject',
  'dashboard.restore',
  'file.upload',
  'file.ingest',
  'api_source.create',
  'api_source.update',
  'api_source.delete',
  'api_source.poll',
  'webhook.ingest',
  'tableau.import',
  'report.create',
  'report.update',
  'report.delete',
  'report.run',
  'role.create',
  'role.update',
  'role.permission.update',
  'user.create',
  'user.update',
  'user.role.assign',
  'user.role.remove',
  'platform.config.update',
  'column.tag',
  'preagg.apply',
  'preagg.dismiss',
  'timed_access.grant',
  'timed_access.renew',
  'timed_access.expire',
  'webhook_endpoint.create',
  'webhook_endpoint.update',
  'webhook_endpoint.delete',
  'webhook.deliver',
  'template.publish',
  'template.install',
  'template.delete',
  'nl_filter.apply',
  'mobile_layout.update',
  'user.login',
  'user.logout',
] as const;

export type AuditAction = (typeof AUDIT_ACTIONS)[number];

export const AUDIT_RESOURCE_TYPES = [
  'datasource',
  'schema',
  'dashboard',
  'file',
  'api_source',
  'webhook',
  'tableau_import',
  'report',
  'role',
  'user',
  'platform_config',
  'column_tag',
  'preagg',
  'timed_access',
  'webhook_endpoint',
  'template',
  'nl_filter',
  'mobile_layout',
] as const;

export type AuditResourceType = (typeof AUDIT_RESOURCE_TYPES)[number];

export interface AuditLog {
  logId: string;
  userId: string;
  orgId: string | null;
  action: string;
  resourceType: string | null;
  resourceId: string | null;
  requestPayload: Record<string, unknown> | null;
  responseStatus: number | null;
  ipAddress: string | null;
  userAgent: string | null;
  durationMs: number | null;
  createdAt: string;
}

export interface AuditLogFilter {
  userId?: string;
  action?: string;
  resourceType?: string;
  resourceId?: string;
  startDate?: string;
  endDate?: string;
  page?: number;
  pageSize?: number;
}

export interface AuditLogEntry {
  logId: string;
  userId: string;
  userName?: string;
  orgId: string | null;
  action: string;
  resourceType: string | null;
  resourceId: string | null;
  requestPayload: Record<string, unknown> | null;
  responseStatus: number | null;
  ipAddress: string | null;
  durationMs: number | null;
  createdAt: string;
}

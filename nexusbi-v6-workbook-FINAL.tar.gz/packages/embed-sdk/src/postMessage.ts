export const NEXUSBI_MESSAGE_PREFIX = 'nexusbi:';

export type NexusBIMessageType =
  | 'nexusbi:ready'
  | 'nexusbi:resize'
  | 'nexusbi:filter:update'
  | 'nexusbi:filter:clear'
  | 'nexusbi:navigate'
  | 'nexusbi:error'
  | 'nexusbi:theme:set';

export interface NexusBIMessage {
  type: NexusBIMessageType;
  payload: Record<string, unknown>;
}

export interface ResizePayload {
  width: number;
  height: number;
}

export interface FilterUpdatePayload {
  filters: Array<{
    member: string;
    operator: string;
    values?: string[];
  }>;
}

export interface ThemePayload {
  theme: 'light' | 'dark';
}

export interface NavigatePayload {
  dashId: string;
}

export interface ErrorPayload {
  code: string;
  message: string;
}

export function createMessage(type: NexusBIMessageType, payload: Record<string, unknown>): NexusBIMessage {
  return { type, payload };
}

export function isNexusBIMessage(event: MessageEvent): boolean {
  if (!event.data || typeof event.data !== 'object') return false;
  return typeof event.data.type === 'string' && event.data.type.startsWith(NEXUSBI_MESSAGE_PREFIX);
}

export function parseMessage(event: MessageEvent): NexusBIMessage | null {
  if (!isNexusBIMessage(event)) return null;
  return event.data as NexusBIMessage;
}

export function postToParent(type: NexusBIMessageType, payload: Record<string, unknown>): void {
  if (typeof window === 'undefined') return;
  if (window.parent === window) return;

  window.parent.postMessage(createMessage(type, payload), '*');
}

export function postToIframe(
  iframe: HTMLIFrameElement,
  type: NexusBIMessageType,
  payload: Record<string, unknown>,
  targetOrigin: string = '*',
): void {
  if (!iframe.contentWindow) return;
  iframe.contentWindow.postMessage(createMessage(type, payload), targetOrigin);
}

export type MessageHandler = (message: NexusBIMessage) => void;

export function onNexusBIMessage(handler: MessageHandler): () => void {
  function listener(event: MessageEvent) {
    const message = parseMessage(event);
    if (message) handler(message);
  }

  window.addEventListener('message', listener);
  return () => window.removeEventListener('message', listener);
}

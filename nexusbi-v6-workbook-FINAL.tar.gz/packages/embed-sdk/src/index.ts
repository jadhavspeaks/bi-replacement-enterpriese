export { NexusBIEmbed, type NexusBIEmbedProps } from './NexusBIEmbed';
export {
  createMessage,
  isNexusBIMessage,
  parseMessage,
  postToParent,
  postToIframe,
  onNexusBIMessage,
  type NexusBIMessage,
  type NexusBIMessageType,
  type MessageHandler,
  type ResizePayload,
  type FilterUpdatePayload,
  type ThemePayload,
  type NavigatePayload,
  type ErrorPayload,
} from './postMessage';

import { useRef, useEffect, useCallback, useState } from 'react';
import { onNexusBIMessage, postToIframe, type NexusBIMessage } from './postMessage';

export interface UseNexusBIOptions {
  onReady?: () => void;
  onError?: (error: { code: string; message: string }) => void;
  onFilterUpdate?: (filters: Array<{ member: string; operator: string; values?: string[] }>) => void;
}

export interface UseNexusBIReturn {
  iframeRef: React.RefObject<HTMLIFrameElement | null>;
  isReady: boolean;
  setTheme: (theme: 'light' | 'dark') => void;
  updateFilters: (filters: Array<{ member: string; operator: string; values?: string[] }>) => void;
  clearFilters: () => void;
}

export function useNexusBI(options: UseNexusBIOptions = {}): UseNexusBIReturn {
  const iframeRef = useRef<HTMLIFrameElement | null>(null);
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    const cleanup = onNexusBIMessage((message: NexusBIMessage) => {
      switch (message.type) {
        case 'nexusbi:ready':
          setIsReady(true);
          options.onReady?.();
          break;
        case 'nexusbi:error':
          options.onError?.(message.payload as { code: string; message: string });
          break;
        case 'nexusbi:filter:update':
          options.onFilterUpdate?.(
            message.payload.filters as Array<{ member: string; operator: string; values?: string[] }>,
          );
          break;
      }
    });

    return cleanup;
  }, [options]);

  const setTheme = useCallback((theme: 'light' | 'dark') => {
    if (iframeRef.current) {
      postToIframe(iframeRef.current, 'nexusbi:theme:set', { theme });
    }
  }, []);

  const updateFilters = useCallback(
    (filters: Array<{ member: string; operator: string; values?: string[] }>) => {
      if (iframeRef.current) {
        postToIframe(iframeRef.current, 'nexusbi:filter:update', { filters });
      }
    },
    [],
  );

  const clearFilters = useCallback(() => {
    if (iframeRef.current) {
      postToIframe(iframeRef.current, 'nexusbi:filter:clear', {});
    }
  }, []);

  return { iframeRef, isReady, setTheme, updateFilters, clearFilters };
}

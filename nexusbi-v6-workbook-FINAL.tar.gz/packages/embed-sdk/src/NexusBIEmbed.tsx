'use client';

import { useRef, useEffect, useState, useCallback } from 'react';
import {
  onNexusBIMessage,
  postToIframe,
  type NexusBIMessage,
  type NexusBIMessageType,
} from './postMessage';

export interface NexusBIEmbedProps {
  url: string;
  token: string;
  width?: string | number;
  height?: string | number;
  theme?: 'light' | 'dark';
  hideToolbar?: boolean;
  className?: string;
  style?: React.CSSProperties;
  onReady?: () => void;
  onError?: (error: { code: string; message: string }) => void;
  onFilterUpdate?: (filters: Array<{ member: string; operator: string; values?: string[] }>) => void;
  onResize?: (size: { width: number; height: number }) => void;
}

export function NexusBIEmbed({
  url,
  token,
  width = '100%',
  height = '600px',
  theme = 'light',
  hideToolbar = false,
  className,
  style,
  onReady,
  onError,
  onFilterUpdate,
  onResize,
}: NexusBIEmbedProps) {
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [loaded, setLoaded] = useState(false);

  const embedUrl = `${url}/embed?token=${encodeURIComponent(token)}&theme=${theme}${hideToolbar ? '&hideToolbar=1' : ''}`;

  useEffect(() => {
    const cleanup = onNexusBIMessage((message: NexusBIMessage) => {
      switch (message.type) {
        case 'nexusbi:ready':
          setLoaded(true);
          onReady?.();
          break;
        case 'nexusbi:error':
          onError?.(message.payload as { code: string; message: string });
          break;
        case 'nexusbi:filter:update':
          onFilterUpdate?.(message.payload.filters as Array<{ member: string; operator: string; values?: string[] }>);
          break;
        case 'nexusbi:resize':
          onResize?.(message.payload as { width: number; height: number });
          break;
      }
    });

    return cleanup;
  }, [onReady, onError, onFilterUpdate, onResize]);

  const setTheme = useCallback((newTheme: 'light' | 'dark') => {
    if (iframeRef.current) {
      postToIframe(iframeRef.current, 'nexusbi:theme:set', { theme: newTheme });
    }
  }, []);

  const updateFilters = useCallback((filters: Array<{ member: string; operator: string; values?: string[] }>) => {
    if (iframeRef.current) {
      postToIframe(iframeRef.current, 'nexusbi:filter:update', { filters });
    }
  }, []);

  const clearFilters = useCallback(() => {
    if (iframeRef.current) {
      postToIframe(iframeRef.current, 'nexusbi:filter:clear', {});
    }
  }, []);

  return (
    <div
      className={className}
      style={{
        position: 'relative',
        width: typeof width === 'number' ? `${width}px` : width,
        height: typeof height === 'number' ? `${height}px` : height,
        ...style,
      }}
    >
      {!loaded && (
        <div
          style={{
            position: 'absolute',
            inset: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            backgroundColor: '#f8fafc',
            borderRadius: '8px',
            border: '1px solid #e2e8f0',
          }}
        >
          <div style={{ textAlign: 'center' }}>
            <div
              style={{
                width: '32px',
                height: '32px',
                border: '3px solid #e2e8f0',
                borderTopColor: '#3b82f6',
                borderRadius: '50%',
                animation: 'spin 1s linear infinite',
                margin: '0 auto 8px',
              }}
            />
            <p style={{ color: '#64748b', fontSize: '14px' }}>Loading NexusBI...</p>
          </div>
        </div>
      )}
      <iframe
        ref={iframeRef}
        src={embedUrl}
        style={{
          width: '100%',
          height: '100%',
          border: 'none',
          borderRadius: '8px',
          opacity: loaded ? 1 : 0,
          transition: 'opacity 0.3s ease',
        }}
        allow="fullscreen"
        title="NexusBI Dashboard"
      />
      <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>
    </div>
  );
}

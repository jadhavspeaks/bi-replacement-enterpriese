const fetch = require('node-fetch');

const INTERNAL_API_URL = process.env.INTERNAL_API_URL || 'http://localhost:3000';
const INTERNAL_API_SECRET = process.env.INTERNAL_API_SECRET || '';
const CUBEJS_API_SECRET = process.env.CUBEJS_API_SECRET || 'change-me';

const DRIVER_MAP = {
  postgres: '@cubejs-backend/postgres-driver',
  mysql: '@cubejs-backend/mysql-driver',
  mssql: '@cubejs-backend/mssql-driver',
  oracle: '@cubejs-backend/oracle-driver',
  sqlite: '@cubejs-backend/sqlite-driver',
  snowflake: '@cubejs-backend/snowflake-driver',
  bigquery: '@cubejs-backend/bigquery-driver',
  redshift: '@cubejs-backend/redshift-driver',
  databricks: '@cubejs-backend/databricks-jdbc-driver',
  athena: '@cubejs-backend/athena-driver',
  hive: '@cubejs-backend/hive-driver',
  sparksql: '@cubejs-backend/hive-driver',
  impala: '@cubejs-backend/hive-driver',
  presto: '@cubejs-backend/prestodb-driver',
  trino: '@cubejs-backend/prestodb-driver',
  clickhouse: '@cubejs-backend/clickhouse-driver',
  mongodb: '@cubejs-backend/mongobi-driver',
  duckdb: '@cubejs-backend/oracle-driver',
  file_csv: '@cubejs-backend/oracle-driver',
  file_excel: '@cubejs-backend/oracle-driver',
  file_parquet: '@cubejs-backend/oracle-driver',
  file_json: '@cubejs-backend/oracle-driver',
  api_rest: '@cubejs-backend/oracle-driver',
  api_graphql: '@cubejs-backend/oracle-driver',
  api_webhook: '@cubejs-backend/oracle-driver',
  api_oauth_rest: '@cubejs-backend/oracle-driver',
};

function mapConfigToDriverOptions(dsType, config) {
  switch (dsType) {
    case 'postgres':
    case 'redshift':
      return {
        host: config.host,
        port: config.port,
        database: config.database,
        user: config.user,
        password: config.password,
        ssl: config.ssl ? { rejectUnauthorized: false } : undefined,
      };
    case 'mysql':
      return {
        host: config.host,
        port: config.port,
        database: config.database,
        user: config.user,
        password: config.password,
        ssl: config.ssl ? { rejectUnauthorized: false } : undefined,
      };
    case 'mssql':
      return {
        server: config.host,
        port: config.port,
        database: config.database,
        userName: config.user,
        password: config.password,
        options: {
          encrypt: config.encrypt,
          trustServerCertificate: config.trustServerCertificate,
        },
        domain: config.domain,
      };
    case 'oracle':
      return {
        host: config.host,
        port: config.port,
        serviceName: config.serviceName,
        user: config.user,
        password: config.password,
      };
    case 'snowflake':
      return {
        account: config.account,
        username: config.username,
        password: config.password,
        warehouse: config.warehouse,
        database: config.database,
        schema: config.schema,
        role: config.role,
        region: config.region,
      };
    case 'bigquery':
      return {
        projectId: config.projectId,
        credentials: JSON.parse(config.credentials),
        location: config.location,
      };
    case 'databricks':
      return {
        url: config.url,
        token: config.token,
        catalog: config.catalog,
        schema: config.schema,
      };
    case 'athena':
      return {
        accessKeyId: config.accessKeyId,
        secretAccessKey: config.secretAccessKey,
        region: config.region,
        S3OutputLocation: config.s3OutputLocation,
        workGroup: config.workgroup,
        catalog: config.catalog,
      };
    case 'clickhouse':
      return {
        host: config.host,
        port: config.port,
        database: config.database,
        auth: `${config.username}:${config.password || ''}`,
      };
    case 'mongodb':
      return {
        host: config.host,
        port: config.port,
        database: config.database,
        user: config.user,
        password: config.password,
        ssl: config.ssl,
        authSource: config.authSource,
      };
    case 'hive':
    case 'sparksql':
    case 'impala':
      return {
        host: config.host,
        port: config.port,
        database: config.database,
        username: config.username,
      };
    case 'presto':
    case 'trino':
      return {
        host: config.host,
        port: config.port,
        catalog: config.catalog,
        schema: config.schema,
        user: config.user,
      };
    case 'sqlite':
      return { database: config.databasePath };
    case 'duckdb':
    case 'file_csv':
    case 'file_excel':
    case 'file_parquet':
    case 'file_json':
    case 'api_rest':
    case 'api_graphql':
    case 'api_webhook':
    case 'api_oauth_rest':
      return { database: config.databasePath || ':memory:' };
    default:
      return config;
  }
}

async function fetchDecryptedCredentials(cubeDsId) {
  const res = await fetch(
    `${INTERNAL_API_URL}/api/internal/datasource-creds?cubeDsId=${encodeURIComponent(cubeDsId)}`,
    {
      headers: {
        'x-internal-secret': INTERNAL_API_SECRET,
        'Content-Type': 'application/json',
      },
    },
  );

  if (!res.ok) {
    throw new Error(`Failed to fetch credentials for ${cubeDsId}: ${res.status}`);
  }

  return res.json();
}

module.exports = {
  apiSecret: CUBEJS_API_SECRET,

  telemetry: false,

  orchestratorOptions: {
    queryCacheOptions: {
      refreshKeyRenewalThreshold: 60,
      backgroundRenew: true,
    },
    preAggregationsOptions: {
      externalRefresh: false,
    },
  },

  driverFactory: async ({ dataSource }) => {
    const dsId = dataSource || 'default';
    const { dsType, config } = await fetchDecryptedCredentials(dsId);
    const driverPackage = DRIVER_MAP[dsType];
    if (!driverPackage) {
      throw new Error(`Unsupported data source type: ${dsType}`);
    }
    const DriverModule = require(driverPackage);
    const DriverClass = DriverModule.default || DriverModule;
    const driverOptions = mapConfigToDriverOptions(dsType, config);
    return new DriverClass(driverOptions);
  },

  repositoryFactory: async ({ dataSource }) => {
    const dsId = dataSource || 'default';
    try {
      const res = await fetch(
        `${INTERNAL_API_URL}/api/internal/datasource-creds?cubeDsId=${encodeURIComponent(dsId)}&schemas=true`,
        {
          headers: {
            'x-internal-secret': INTERNAL_API_SECRET,
            'Content-Type': 'application/json',
          },
        },
      );

      if (!res.ok) {
        console.error(`Failed to fetch schemas for ${dsId}: ${res.status}`);
        return [];
      }

      const { schemas } = await res.json();
      if (!schemas || schemas.length === 0) return [];

      return schemas.map((schema) => ({
        fileName: `${schema.cubeName}.js`,
        content: schema.schemaJs,
      }));
    } catch (err) {
      console.error(`Error fetching schemas for ${dsId}:`, err);
      return [];
    }
  },

  scheduledRefreshContexts: async () => {
    try {
      const res = await fetch(
        `${INTERNAL_API_URL}/api/internal/datasource-creds?listActive=true`,
        {
          headers: {
            'x-internal-secret': INTERNAL_API_SECRET,
            'Content-Type': 'application/json',
          },
        },
      );

      if (!res.ok) return [];

      const { dataSources } = await res.json();
      return (dataSources || []).map((ds) => ({
        securityContext: { dataSource: ds.cubeDsId },
      }));
    } catch {
      return [];
    }
  },

  checkAuth: (req, auth) => {
    // Auth is handled by the Next.js proxy layer
    // Cube.js trusts requests coming from the internal network
  },
};

// ── Standalone server bootstrap (run with: node cube.js) ──────────
if (require.main === module) {
  const CubejsServer = require('@cubejs-backend/server');

  const server = new CubejsServer({
    ...module.exports,
    port: parseInt(process.env.CUBEJS_PORT || '4000', 10),
    apiSecret: module.exports.apiSecret,
  });

  server.listen().then(({ version, port }) => {
    console.log(`Cube.js v${version} listening on port ${port}`);
    console.log(`  API URL: http://localhost:${port}`);
    console.log(`  Internal API: ${INTERNAL_API_URL}`);
    console.log(`  Dev mode: ${process.env.CUBEJS_DEV_MODE || 'true'}`);
  }).catch((err) => {
    console.error('Failed to start Cube.js server:', err);
    process.exit(1);
  });
}

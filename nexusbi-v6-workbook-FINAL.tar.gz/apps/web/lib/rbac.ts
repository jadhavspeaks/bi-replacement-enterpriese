import type { PermissionCode } from '@nexusbi/shared-types';
import { withConnection } from '@/lib/oracle-pool';
import { cacheGet, cacheSet, cacheDel, invalidateCache, CACHE_KEYS, CACHE_TTL } from '@/lib/cache';

export interface ResolvedPermissions {
  userId: string;
  orgId: string;
  permissions: Set<string>;
  roles: string[];
}

export async function resolvePermissions(
  userId: string,
  orgId: string,
  roleNames: string[],
): Promise<ResolvedPermissions> {
  const cacheKey = CACHE_KEYS.permissions(userId, orgId);

  const cached = await cacheGet(cacheKey);
  if (cached) {
    try {
      const parsed = JSON.parse(cached) as { permissions: string[]; roles: string[] };
      return { userId, orgId, permissions: new Set(parsed.permissions), roles: parsed.roles };
    } catch {
      // invalid cache
    }
  }

  const permissions = await withConnection(async (conn) => {
    const result = await conn.execute<{ PERM_CODE: string }>(
      `SELECT DISTINCT P.PERM_CODE
       FROM NB_USER_ROLES UR
       JOIN NB_ROLE_PERMISSIONS RP ON RP.ROLE_ID = UR.ROLE_ID
       JOIN NB_PERMISSIONS P ON P.PERM_ID = RP.PERM_ID
       WHERE UR.USER_ID = :userId AND UR.ORG_ID = :orgId`,
      { userId, orgId },
      { outFormat: 4002 },
    );
    return (result.rows || []).map((r) => r.PERM_CODE);
  });

  const resolved: ResolvedPermissions = { userId, orgId, permissions: new Set(permissions), roles: roleNames };

  await cacheSet(cacheKey, JSON.stringify({ permissions, roles: roleNames }), CACHE_TTL.permissions);
  return resolved;
}

export function hasPermission(resolved: ResolvedPermissions, permission: PermissionCode): boolean {
  return resolved.permissions.has(permission);
}

export async function checkPermission(
  userId: string, orgId: string, roleNames: string[], permission: PermissionCode,
): Promise<boolean> {
  const resolved = await resolvePermissions(userId, orgId, roleNames);
  return hasPermission(resolved, permission);
}

export async function invalidatePermissionCache(userId: string, orgId: string): Promise<void> {
  await cacheDel(CACHE_KEYS.permissions(userId, orgId));
}

export async function invalidateAllPermissionCaches(orgId: string): Promise<void> {
  await invalidateCache(`perms:*:${orgId}`);
}

export async function getUserPermissionsList(
  userId: string, orgId: string, roleNames: string[],
): Promise<PermissionCode[]> {
  const resolved = await resolvePermissions(userId, orgId, roleNames);
  return Array.from(resolved.permissions) as PermissionCode[];
}

'use client';

import cubejs, { type CubejsApi, type Query, type ResultSet } from '@cubejs-client/core';

let cubeClient: CubejsApi | null = null;

export function getCubeClient(): CubejsApi {
  if (cubeClient) return cubeClient;

  cubeClient = cubejs('nexusbi-proxy-token', {
    apiUrl: '/api/cube',
  });

  return cubeClient;
}

export async function executeQuery(query: Query): Promise<ResultSet> {
  const client = getCubeClient();
  return client.load(query);
}

export interface CubeMetaMember {
  name: string;
  title: string;
  type: string;
  shortTitle: string;
  description?: string;
}

export interface CubeMeta {
  name: string;
  title: string;
  description?: string;
  measures: CubeMetaMember[];
  dimensions: CubeMetaMember[];
  segments: CubeMetaMember[];
}

export async function getCubeMeta(dataSource?: string): Promise<CubeMeta[]> {
  const params = new URLSearchParams();
  if (dataSource) {
    params.set('dataSource', dataSource);
  }

  const response = await fetch(`/api/cube/v1/meta?${params.toString()}`);
  if (!response.ok) {
    throw new Error(`Failed to load cube meta: ${response.status}`);
  }

  const data = await response.json() as { cubes: CubeMeta[] };
  return data.cubes || [];
}

export function formatCubeValue(
  value: unknown,
  format?: 'number' | 'currency' | 'percent',
): string {
  if (value === null || value === undefined) return '—';

  const numValue = Number(value);
  if (isNaN(numValue)) return String(value);

  switch (format) {
    case 'currency':
      return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
        minimumFractionDigits: 0,
        maximumFractionDigits: 2,
      }).format(numValue);

    case 'percent':
      return new Intl.NumberFormat('en-US', {
        style: 'percent',
        minimumFractionDigits: 1,
        maximumFractionDigits: 2,
      }).format(numValue / 100);

    case 'number':
    default:
      if (Math.abs(numValue) >= 1_000_000_000) {
        return `${(numValue / 1_000_000_000).toFixed(1)}B`;
      }
      if (Math.abs(numValue) >= 1_000_000) {
        return `${(numValue / 1_000_000).toFixed(1)}M`;
      }
      if (Math.abs(numValue) >= 1_000) {
        return `${(numValue / 1_000).toFixed(1)}K`;
      }
      return new Intl.NumberFormat('en-US', {
        maximumFractionDigits: 2,
      }).format(numValue);
  }
}

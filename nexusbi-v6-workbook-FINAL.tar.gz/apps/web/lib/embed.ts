import { SignJWT, jwtVerify, type JWTPayload } from 'jose';

const EMBED_TOKEN_ISSUER = 'nexusbi';
const EMBED_TOKEN_AUDIENCE = 'nexusbi-embed';

export interface EmbedTokenPayload extends JWTPayload {
  dashId: string;
  orgId: string;
  allowedFilters?: string[];
  theme?: 'light' | 'dark';
  hideToolbar?: boolean;
}

function getEmbedSecret(): Uint8Array {
  const secret = process.env.NEXTAUTH_SECRET;
  if (!secret) {
    throw new Error('NEXTAUTH_SECRET is required for embed token signing');
  }
  return new TextEncoder().encode(secret);
}

export async function signEmbedToken(
  payload: Omit<EmbedTokenPayload, 'iss' | 'aud' | 'iat' | 'exp'>,
  expiresInHours: number = 24,
): Promise<string> {
  const secret = getEmbedSecret();

  const token = await new SignJWT({
    dashId: payload.dashId,
    orgId: payload.orgId,
    allowedFilters: payload.allowedFilters,
    theme: payload.theme,
    hideToolbar: payload.hideToolbar,
  })
    .setProtectedHeader({ alg: 'HS256' })
    .setIssuedAt()
    .setIssuer(EMBED_TOKEN_ISSUER)
    .setAudience(EMBED_TOKEN_AUDIENCE)
    .setExpirationTime(`${expiresInHours}h`)
    .sign(secret);

  return token;
}

export async function verifyEmbedToken(token: string): Promise<EmbedTokenPayload> {
  const secret = getEmbedSecret();

  const { payload } = await jwtVerify(token, secret, {
    issuer: EMBED_TOKEN_ISSUER,
    audience: EMBED_TOKEN_AUDIENCE,
  });

  return payload as EmbedTokenPayload;
}

export function generateEmbedCode(
  baseUrl: string,
  token: string,
  options?: {
    width?: string;
    height?: string;
    theme?: 'light' | 'dark';
  },
): { iframe: string; react: string; script: string } {
  const width = options?.width || '100%';
  const height = options?.height || '600px';
  const embedUrl = `${baseUrl}/embed?token=${encodeURIComponent(token)}`;

  const iframe = `<iframe
  src="${embedUrl}"
  width="${width}"
  height="${height}"
  frameborder="0"
  allow="fullscreen"
  style="border: none; border-radius: 8px;"
></iframe>`;

  const react = `import { NexusBIEmbed } from '@nexusbi/embed-sdk';

<NexusBIEmbed
  url="${baseUrl}"
  token="${token}"
  width="${width}"
  height="${height}"
  theme="${options?.theme || 'light'}"
/>`;

  const script = `<div id="nexusbi-embed"></div>
<script src="${baseUrl}/embed-sdk.js"></script>
<script>
  NexusBI.embed({
    container: '#nexusbi-embed',
    url: '${baseUrl}',
    token: '${token}',
    width: '${width}',
    height: '${height}',
    theme: '${options?.theme || 'light'}'
  });
</script>`;

  return { iframe, react, script };
}

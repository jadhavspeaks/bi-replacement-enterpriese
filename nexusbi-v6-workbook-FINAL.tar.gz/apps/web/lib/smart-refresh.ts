import { withConnection, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { SmartRefreshSuggestion, RefreshScheduleLog } from '@nexusbi/shared-types';

interface HeatmapEntry {
  cubeName: string;
  hourOfDay: number;
  dayOfWeek: number;
  totalQueries: number;
  avgDurationMs: number;
}

export async function logQueryForRefreshAnalysis(
  dsId: string,
  cubeName: string,
  measureNames: string[],
  durationMs: number,
  orgId: string,
): Promise<void> {
  try {
    const now = new Date();
    const hourOfDay = now.getUTCHours();
    const dayOfWeek = now.getUTCDay();
    const weekStart = new Date(now);
    weekStart.setUTCDate(weekStart.getUTCDate() - dayOfWeek);
    weekStart.setUTCHours(0, 0, 0, 0);

    await withConnection(async (conn) => {
      // Upsert: increment query count and update avg duration for this hour/day slot
      const existing = await conn.execute<{ LOG_ID: string; QUERY_COUNT: number; AVG_DURATION_MS: number }>(
        `SELECT LOG_ID, QUERY_COUNT, AVG_DURATION_MS
         FROM NB_REFRESH_SCHEDULE_LOG
         WHERE DS_ID = :dsId
           AND CUBE_NAME = :cubeName
           AND HOUR_OF_DAY = :hourOfDay
           AND DAY_OF_WEEK = :dayOfWeek
           AND WEEK_START = :weekStart
           AND ORG_ID = :orgId`,
        {
          dsId,
          cubeName,
          hourOfDay,
          dayOfWeek,
          weekStart: weekStart.toISOString(),
          orgId,
        },
        { outFormat: 4002 },
      );

      if (existing.rows && existing.rows.length > 0) {
        const row = existing.rows[0];
        const newCount = row.QUERY_COUNT + 1;
        const newAvg = Math.round(
          (row.AVG_DURATION_MS * row.QUERY_COUNT + durationMs) / newCount,
        );

        await conn.execute(
          `UPDATE NB_REFRESH_SCHEDULE_LOG
           SET QUERY_COUNT = :newCount,
               AVG_DURATION_MS = :newAvg,
               MEASURE_NAMES = :measureNames
           WHERE LOG_ID = :logId`,
          {
            newCount,
            newAvg,
            measureNames: JSON.stringify(measureNames),
            logId: row.LOG_ID,
          },
        );
      } else {
        await conn.execute(
          `INSERT INTO NB_REFRESH_SCHEDULE_LOG
             (LOG_ID, DS_ID, CUBE_NAME, MEASURE_NAMES, QUERY_COUNT,
              AVG_DURATION_MS, HOUR_OF_DAY, DAY_OF_WEEK, WEEK_START, ORG_ID)
           VALUES
             (:logId, :dsId, :cubeName, :measureNames, 1,
              :durationMs, :hourOfDay, :dayOfWeek,
              TO_TIMESTAMP(:weekStart, 'YYYY-MM-DD"T"HH24:MI:SS.FF3"Z"'), :orgId)`,
          {
            logId: generateId(),
            dsId,
            cubeName,
            measureNames: JSON.stringify(measureNames),
            durationMs,
            hourOfDay,
            dayOfWeek,
            weekStart: weekStart.toISOString(),
            orgId,
          },
        );
      }

      await conn.commit();
    });
  } catch (error) {
    console.error('Failed to log query for refresh analysis:', error);
  }
}

export async function analyzeQueryHeatmap(
  dsId: string,
  orgId: string,
): Promise<HeatmapEntry[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      CUBE_NAME: string;
      HOUR_OF_DAY: number;
      DAY_OF_WEEK: number;
      TOTAL_QUERIES: number;
      AVG_DURATION: number;
    }>(
      `SELECT CUBE_NAME,
              HOUR_OF_DAY,
              DAY_OF_WEEK,
              SUM(QUERY_COUNT) AS TOTAL_QUERIES,
              ROUND(AVG(AVG_DURATION_MS)) AS AVG_DURATION
       FROM NB_REFRESH_SCHEDULE_LOG
       WHERE DS_ID = :dsId
         AND ORG_ID = :orgId
         AND WEEK_START >= SYSTIMESTAMP - INTERVAL '30' DAY
       GROUP BY CUBE_NAME, HOUR_OF_DAY, DAY_OF_WEEK
       ORDER BY TOTAL_QUERIES DESC`,
      { dsId, orgId },
      { outFormat: 4002 },
    );

    return (result.rows || []).map((row) => ({
      cubeName: row.CUBE_NAME,
      hourOfDay: row.HOUR_OF_DAY,
      dayOfWeek: row.DAY_OF_WEEK,
      totalQueries: row.TOTAL_QUERIES,
      avgDurationMs: row.AVG_DURATION,
    }));
  });
}

function generateCronFromHeatmap(entries: HeatmapEntry[]): { cron: string; confidence: number } {
  if (entries.length === 0) {
    return { cron: '0 */6 * * *', confidence: 10 };
  }

  // Find peak hours
  const hourCounts = new Map<number, number>();
  let totalQueries = 0;

  for (const entry of entries) {
    const current = hourCounts.get(entry.hourOfDay) || 0;
    hourCounts.set(entry.hourOfDay, current + entry.totalQueries);
    totalQueries += entry.totalQueries;
  }

  // Sort hours by query count descending
  const sortedHours = Array.from(hourCounts.entries())
    .sort((a, b) => b[1] - a[1]);

  if (sortedHours.length === 0) {
    return { cron: '0 */6 * * *', confidence: 10 };
  }

  const peakHour = sortedHours[0][0];
  const peakQueries = sortedHours[0][1];

  // Schedule refresh 1 hour before peak usage
  const refreshHour = (peakHour - 1 + 24) % 24;

  // Calculate confidence based on query concentration
  const concentration = peakQueries / totalQueries;
  const confidence = Math.min(99, Math.round(concentration * 100 + sortedHours.length * 5));

  // If queries are spread across many hours, use more frequent refresh
  if (sortedHours.length > 12) {
    return { cron: '0 */4 * * *', confidence: Math.min(confidence, 50) };
  }

  if (sortedHours.length > 6) {
    // Find the two peak hours and schedule before each
    const secondPeakHour = sortedHours.length > 1
      ? (sortedHours[1][0] - 1 + 24) % 24
      : (refreshHour + 12) % 24;

    const hours = [refreshHour, secondPeakHour].sort((a, b) => a - b);
    return { cron: `0 ${hours.join(',')} * * *`, confidence };
  }

  // Single peak — refresh once before
  return { cron: `0 ${refreshHour} * * *`, confidence };
}

export async function generateSmartRefreshSuggestions(
  orgId: string,
  limit: number = 5,
): Promise<SmartRefreshSuggestion[]> {
  return withConnection(async (conn) => {
    // Get all ds+cube combinations with query logs
    const cubeStats = await conn.execute<{
      DS_ID: string;
      CUBE_NAME: string;
      TOTAL_QUERIES: number;
      AVG_DURATION: number;
    }>(
      `SELECT DS_ID, CUBE_NAME,
              SUM(QUERY_COUNT) AS TOTAL_QUERIES,
              ROUND(AVG(AVG_DURATION_MS)) AS AVG_DURATION
       FROM NB_REFRESH_SCHEDULE_LOG
       WHERE ORG_ID = :orgId
         AND WEEK_START >= SYSTIMESTAMP - INTERVAL '30' DAY
       GROUP BY DS_ID, CUBE_NAME
       HAVING SUM(QUERY_COUNT) >= 10
       ORDER BY AVG_DURATION DESC
       FETCH FIRST :limit ROWS ONLY`,
      { orgId, limit },
      { outFormat: 4002 },
    );

    const suggestions: SmartRefreshSuggestion[] = [];

    for (const stat of cubeStats.rows || []) {
      const heatmap = await analyzeQueryHeatmap(stat.DS_ID, orgId);
      const cubeHeatmap = heatmap.filter((h) => h.cubeName === stat.CUBE_NAME);
      const { cron, confidence } = generateCronFromHeatmap(cubeHeatmap);

      // Check if there's an existing recommendation
      const existingRec = await conn.execute<{ REC_ID: string }>(
        `SELECT REC_ID FROM NB_PREAGG_RECOMMENDATIONS
         WHERE DS_ID = :dsId AND CUBE_NAME = :cubeName AND STATUS = 'PENDING'`,
        { dsId: stat.DS_ID, cubeName: stat.CUBE_NAME },
        { outFormat: 4002 },
      );

      const recId = existingRec.rows?.[0]?.REC_ID || generateId();

      if (!existingRec.rows || existingRec.rows.length === 0) {
        // Create new recommendation with smart refresh cron
        await conn.execute(
          `INSERT INTO NB_PREAGG_RECOMMENDATIONS
             (REC_ID, DS_ID, CUBE_NAME, SUGGESTED_PREAGG, REASON,
              AVG_QUERY_MS, QUERY_COUNT, STATUS,
              SMART_REFRESH_CRON, CONFIDENCE_SCORE, CREATED_AT)
           VALUES
             (:recId, :dsId, :cubeName, :suggestedPreagg, :reason,
              :avgQueryMs, :queryCount, 'PENDING',
              :smartRefreshCron, :confidenceScore, SYSTIMESTAMP)`,
          {
            recId,
            dsId: stat.DS_ID,
            cubeName: stat.CUBE_NAME,
            suggestedPreagg: `Pre-aggregate ${stat.CUBE_NAME} with rollup on time dimension`,
            reason: `High query volume (${stat.TOTAL_QUERIES} queries) with avg ${stat.AVG_DURATION}ms latency`,
            avgQueryMs: stat.AVG_DURATION,
            queryCount: stat.TOTAL_QUERIES,
            smartRefreshCron: cron,
            confidenceScore: confidence,
          },
        );
      } else {
        // Update existing recommendation
        await conn.execute(
          `UPDATE NB_PREAGG_RECOMMENDATIONS
           SET SMART_REFRESH_CRON = :cron,
               CONFIDENCE_SCORE = :confidence,
               AVG_QUERY_MS = :avgMs,
               QUERY_COUNT = :queryCount
           WHERE REC_ID = :recId`,
          {
            cron,
            confidence,
            avgMs: stat.AVG_DURATION,
            queryCount: stat.TOTAL_QUERIES,
            recId,
          },
        );
      }

      suggestions.push({
        recId,
        dsId: stat.DS_ID,
        cubeName: stat.CUBE_NAME,
        suggestedPreagg: `Pre-aggregate ${stat.CUBE_NAME} with rollup on time dimension`,
        reason: `High query volume (${stat.TOTAL_QUERIES} queries) with avg ${stat.AVG_DURATION}ms latency`,
        smartRefreshCron: cron,
        confidenceScore: confidence,
        avgQueryMs: stat.AVG_DURATION,
        queryCount: stat.TOTAL_QUERIES,
      });
    }

    await conn.commit();
    return suggestions;
  });
}

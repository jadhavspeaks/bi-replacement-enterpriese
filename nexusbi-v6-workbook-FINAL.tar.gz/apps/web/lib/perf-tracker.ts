import { withConnection, generateId } from '@/lib/oracle-pool';
import type { PerfMetricLogInput, PerfAggregation, PerfScorecard, PerfRecommendation } from '@nexusbi/shared-types';

export async function logWidgetPerf(
  dashId: string,
  userId: string,
  orgId: string,
  metric: PerfMetricLogInput,
): Promise<void> {
  await withConnection(async (conn) => {
    await conn.execute(
      `INSERT INTO NB_DASH_PERF_METRICS
         (METRIC_ID, DASH_ID, WIDGET_ID, USER_ID,
          LOAD_MS, CUBE_QUERY_MS, RENDER_MS, VIEWED_AT, ORG_ID)
       VALUES
         (:metricId, :dashId, :widgetId, :userId,
          :loadMs, :cubeQueryMs, :renderMs, SYSTIMESTAMP, :orgId)`,
      {
        metricId: generateId(),
        dashId,
        widgetId: metric.widgetId,
        userId,
        loadMs: metric.loadMs,
        cubeQueryMs: metric.cubeQueryMs,
        renderMs: metric.renderMs,
        orgId,
      },
    );
    await conn.commit();
  });
}

export async function getWidgetPerfAggregation(
  dashId: string,
  orgId: string,
  days: number = 7,
): Promise<PerfAggregation[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      WIDGET_ID: string;
      SAMPLE_COUNT: number;
      P50_LOAD: number;
      P95_LOAD: number;
      P99_LOAD: number;
      P50_CUBE: number;
      P95_CUBE: number;
      P99_CUBE: number;
      P50_RENDER: number;
      P95_RENDER: number;
      P99_RENDER: number;
    }>(
      `SELECT
         WIDGET_ID,
         COUNT(*) AS SAMPLE_COUNT,
         PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY LOAD_MS) AS P50_LOAD,
         PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY LOAD_MS) AS P95_LOAD,
         PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY LOAD_MS) AS P99_LOAD,
         PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY CUBE_QUERY_MS) AS P50_CUBE,
         PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY CUBE_QUERY_MS) AS P95_CUBE,
         PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY CUBE_QUERY_MS) AS P99_CUBE,
         PERCENTILE_CONT(0.50) WITHIN GROUP (ORDER BY RENDER_MS) AS P50_RENDER,
         PERCENTILE_CONT(0.95) WITHIN GROUP (ORDER BY RENDER_MS) AS P95_RENDER,
         PERCENTILE_CONT(0.99) WITHIN GROUP (ORDER BY RENDER_MS) AS P99_RENDER
       FROM NB_DASH_PERF_METRICS
       WHERE DASH_ID = :dashId
         AND ORG_ID = :orgId
         AND VIEWED_AT >= SYSTIMESTAMP - NUMTODSINTERVAL(:days, 'DAY')
       GROUP BY WIDGET_ID
       ORDER BY P95_LOAD DESC`,
      { dashId, orgId, days },
      { outFormat: 4002 },
    );

    return (result.rows || []).map((row) => ({
      widgetId: row.WIDGET_ID,
      widgetTitle: row.WIDGET_ID, // Will be enriched by caller
      p50LoadMs: Math.round(row.P50_LOAD),
      p95LoadMs: Math.round(row.P95_LOAD),
      p99LoadMs: Math.round(row.P99_LOAD),
      p50CubeQueryMs: Math.round(row.P50_CUBE),
      p95CubeQueryMs: Math.round(row.P95_CUBE),
      p99CubeQueryMs: Math.round(row.P99_CUBE),
      p50RenderMs: Math.round(row.P50_RENDER),
      p95RenderMs: Math.round(row.P95_RENDER),
      p99RenderMs: Math.round(row.P99_RENDER),
      sampleCount: row.SAMPLE_COUNT,
    }));
  });
}

export async function buildPerfScorecard(
  dashId: string,
  orgId: string,
): Promise<PerfScorecard> {
  return withConnection(async (conn) => {
    // Get dashboard info
    const dashResult = await conn.execute<{
      DASH_NAME: string;
      WIDGETS_JSON: string;
    }>(
      `SELECT DASH_NAME, WIDGETS_JSON FROM NB_DASHBOARDS
       WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
      { dashId, orgId },
      { outFormat: 4002 },
    );

    const dashName = dashResult.rows?.[0]?.DASH_NAME || 'Unknown';
    let widgetMap = new Map<string, string>();

    try {
      const widgetsStr = dashResult.rows?.[0]?.WIDGETS_JSON;
      if (widgetsStr) {
        const widgets = JSON.parse(widgetsStr as string) as Array<{ widgetId: string; title: string }>;
        widgetMap = new Map(widgets.map((w) => [w.widgetId, w.title]));
      }
    } catch {
      // ignore parse errors
    }

    // Get aggregations
    const aggregations = await getWidgetPerfAggregation(dashId, orgId);

    // Enrich with widget titles
    for (const agg of aggregations) {
      agg.widgetTitle = widgetMap.get(agg.widgetId) || agg.widgetId;
    }

    // Calculate overall P50/P95
    const allP50 = aggregations.map((a) => a.p50LoadMs);
    const allP95 = aggregations.map((a) => a.p95LoadMs);
    const overallP50 = allP50.length > 0
      ? Math.round(allP50.reduce((a, b) => a + b, 0) / allP50.length)
      : 0;
    const overallP95 = allP95.length > 0
      ? Math.round(allP95.reduce((a, b) => a + b, 0) / allP95.length)
      : 0;

    // Check pre-agg coverage
    const preaggResult = await conn.execute<{ TOTAL_CUBES: number; COVERED_CUBES: number }>(
      `SELECT
         (SELECT COUNT(DISTINCT CUBE_NAME) FROM NB_CUBE_SCHEMAS S
          JOIN NB_DATA_SOURCES D ON D.DS_ID = S.DS_ID
          WHERE D.ORG_ID = :orgId AND S.IS_ACTIVE = 1) AS TOTAL_CUBES,
         (SELECT COUNT(DISTINCT CUBE_NAME) FROM NB_PREAGG_RECOMMENDATIONS
          WHERE STATUS = 'APPLIED'
            AND DS_ID IN (SELECT DS_ID FROM NB_DATA_SOURCES WHERE ORG_ID = :orgId)) AS COVERED_CUBES
       FROM DUAL`,
      { orgId },
      { outFormat: 4002 },
    );

    const totalCubes = preaggResult.rows?.[0]?.TOTAL_CUBES || 0;
    const coveredCubes = preaggResult.rows?.[0]?.COVERED_CUBES || 0;
    const preaggCoveragePct = totalCubes > 0
      ? Math.round((coveredCubes / totalCubes) * 100)
      : 0;

    // Generate recommendations
    const recommendations: PerfRecommendation[] = [];
    const SLOW_THRESHOLD_MS = 2000;

    for (const agg of aggregations) {
      if (agg.p95LoadMs > SLOW_THRESHOLD_MS) {
        const rec: PerfRecommendation = {
          widgetId: agg.widgetId,
          widgetTitle: agg.widgetTitle,
          reason: `P95 load time is ${agg.p95LoadMs}ms (threshold: ${SLOW_THRESHOLD_MS}ms)`,
          suggestedAction: agg.p95CubeQueryMs > agg.p95RenderMs
            ? 'Consider adding a pre-aggregation for this cube query'
            : 'Consider simplifying the widget rendering or reducing data points',
        };

        // Look for matching preagg recommendation
        const preaggRec = await conn.execute<{ REC_ID: string }>(
          `SELECT REC_ID FROM NB_PREAGG_RECOMMENDATIONS
           WHERE STATUS = 'PENDING'
             AND DS_ID IN (SELECT DS_ID FROM NB_DATA_SOURCES WHERE ORG_ID = :orgId)
           FETCH FIRST 1 ROW ONLY`,
          { orgId },
          { outFormat: 4002 },
        );

        if (preaggRec.rows && preaggRec.rows.length > 0) {
          rec.preaggRecId = preaggRec.rows[0].REC_ID;
          rec.estimatedImprovement = '40-60% faster';
        }

        recommendations.push(rec);
      }
    }

    return {
      dashId,
      dashName,
      widgets: aggregations,
      overallP50Ms: overallP50,
      overallP95Ms: overallP95,
      preaggCoveragePct,
      recommendations,
      generatedAt: new Date().toISOString(),
    };
  });
}

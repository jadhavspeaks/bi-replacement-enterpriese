import oracledb from 'oracledb';

let pool: oracledb.Pool | null = null;

export type OrgScopedQuery = string & { readonly __brand: unique symbol };

export function createOrgScopedQuery(sql: string): OrgScopedQuery {
  if (!sql.includes(':orgId') && !sql.toUpperCase().includes('NB_PLATFORM_CONFIG') && !sql.toUpperCase().includes('NB_ROLES') && !sql.toUpperCase().includes('NB_PERMISSIONS')) {
    throw new Error(`OrgScopedQuery requires :orgId bind variable. SQL: ${sql.substring(0, 100)}`);
  }
  return sql as OrgScopedQuery;
}

function buildConnectString(): string {
  const host = process.env.ORACLE_HOST;
  const port = process.env.ORACLE_PORT || '1521';
  const service = process.env.ORACLE_SERVICE;

  if (!host || !service) {
    throw new Error(
      'Oracle connection requires ORACLE_HOST and ORACLE_SERVICE environment variables.\n' +
      'These are the same values you see in SQL Developer:\n' +
      '  ORACLE_HOST=your-db-hostname\n' +
      '  ORACLE_PORT=1521\n' +
      '  ORACLE_SERVICE=XEPDB1  (this is the Service Name field)',
    );
  }

  return `${host}:${port}/${service}`;
}

export async function initOraclePool(): Promise<oracledb.Pool> {
  if (pool) return pool;

  const user = process.env.ORACLE_USER;
  const password = process.env.ORACLE_PASSWORD;

  if (!user || !password) {
    throw new Error('Oracle connection requires ORACLE_USER and ORACLE_PASSWORD environment variables.');
  }

  const connectString = buildConnectString();

  oracledb.outFormat = oracledb.OUT_FORMAT_OBJECT;
  oracledb.autoCommit = false;
  oracledb.fetchAsString = [oracledb.CLOB];

  pool = await oracledb.createPool({
    user,
    password,
    connectString,
    poolMin: 4,
    poolMax: 20,
    poolIncrement: 2,
    poolTimeout: 60,
    queueTimeout: 30000,
    enableStatistics: false,
  });

  console.log(`Oracle pool initialized: ${user}@${connectString}`);
  return pool;
}

export function getOraclePool(): oracledb.Pool {
  if (!pool) throw new Error('Oracle pool not initialized. Call initOraclePool() first.');
  return pool;
}

let poolInitPromise: Promise<oracledb.Pool> | null = null;

export function getOrInitPool(): Promise<oracledb.Pool> {
  if (pool) return Promise.resolve(pool);
  if (!poolInitPromise) {
    poolInitPromise = initOraclePool().catch((err) => {
      poolInitPromise = null;
      throw err;
    });
  }
  return poolInitPromise;
}

export async function clobToString(clob: unknown): Promise<string> {
  if (typeof clob === 'string') return clob;
  if (clob === null || clob === undefined) return '';
  if (typeof clob === 'object' && clob !== null && 'getData' in clob) {
    const lob = clob as oracledb.Lob;
    const data = await lob.getData();
    if (typeof data === 'string') return data;
    if (Buffer.isBuffer(data)) return data.toString('utf-8');
  }
  return String(clob);
}

export function parseJsonClob<T = unknown>(clobStr: string | null): T | null {
  if (!clobStr || clobStr.trim() === '') return null;
  try {
    return JSON.parse(clobStr) as T;
  } catch {
    return null;
  }
}

export async function withConnection<T>(fn: (conn: oracledb.Connection) => Promise<T>): Promise<T> {
  const p = await getOrInitPool();
  const conn = await p.getConnection();
  try {
    return await fn(conn);
  } finally {
    try { await conn.close(); } catch { /* ignore */ }
  }
}

export async function withTransaction<T>(fn: (conn: oracledb.Connection) => Promise<T>): Promise<T> {
  const p = await getOrInitPool();
  const conn = await p.getConnection();
  try {
    const result = await fn(conn);
    await conn.commit();
    return result;
  } catch (err) {
    await conn.rollback();
    throw err;
  } finally {
    try { await conn.close(); } catch { /* ignore */ }
  }
}

export function generateId(): string {
  return crypto.randomUUID();
}

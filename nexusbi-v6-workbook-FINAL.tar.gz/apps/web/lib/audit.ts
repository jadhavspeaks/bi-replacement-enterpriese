import { NextRequest, NextResponse } from 'next/server';
import { withConnection, generateId } from '@/lib/oracle-pool';
import type { SessionUser, ApiResponse } from '@nexusbi/shared-types';

export interface AuditContext {
  action: string;
  resourceType?: string;
  resourceId?: string;
  requestPayload?: Record<string, unknown>;
}

export async function writeAuditLog(
  user: SessionUser,
  context: AuditContext,
  responseStatus: number,
  durationMs: number,
  request?: NextRequest,
): Promise<void> {
  try {
    await withConnection(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_AUDIT_LOG
           (LOG_ID, USER_ID, ORG_ID, ACTION, RESOURCE_TYPE, RESOURCE_ID,
            REQUEST_PAYLOAD, RESPONSE_STATUS, IP_ADDRESS, USER_AGENT,
            DURATION_MS, CREATED_AT)
         VALUES
           (:logId, :userId, :orgId, :action, :resourceType, :resourceId,
            :requestPayload, :responseStatus, :ipAddress, :userAgent,
            :durationMs, SYSTIMESTAMP)`,
        {
          logId: generateId(),
          userId: user.id,
          orgId: user.orgId,
          action: context.action,
          resourceType: context.resourceType ?? null,
          resourceId: context.resourceId ?? null,
          requestPayload: context.requestPayload
            ? JSON.stringify(sanitizePayload(context.requestPayload))
            : null,
          responseStatus,
          ipAddress: request
            ? (request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
               request.headers.get('x-real-ip') ||
               'unknown')
            : null,
          userAgent: request
            ? (request.headers.get('user-agent')?.substring(0, 500) || null)
            : null,
          durationMs,
        },
      );
      await conn.commit();
    });
  } catch (error) {
    console.error('Failed to write audit log:', error);
    // Never throw from audit logging — it should not break the main flow
  }
}

function sanitizePayload(payload: Record<string, unknown>): Record<string, unknown> {
  const sanitized: Record<string, unknown> = {};
  const sensitiveKeys = [
    'password', 'secret', 'token', 'key', 'credentials',
    'apiKeyValue', 'bearerToken', 'basicPassword',
    'clientSecret', 'secretAccessKey', 'passwordHash',
  ];

  for (const [k, v] of Object.entries(payload)) {
    const isSecret = sensitiveKeys.some(
      (sk) => k.toLowerCase().includes(sk.toLowerCase()),
    );
    if (isSecret) {
      sanitized[k] = '[REDACTED]';
    } else if (typeof v === 'object' && v !== null && !Array.isArray(v)) {
      sanitized[k] = sanitizePayload(v as Record<string, unknown>);
    } else {
      sanitized[k] = v;
    }
  }

  return sanitized;
}

type RouteHandler = (
  request: NextRequest,
  context: { params: Promise<Record<string, string>> },
) => Promise<NextResponse>;

export function withAudit(
  auditContext: AuditContext | ((request: NextRequest, params: Record<string, string>) => AuditContext),
  handler: (
    request: NextRequest,
    context: { params: Promise<Record<string, string>> },
    user: SessionUser,
  ) => Promise<NextResponse>,
  getUser: (request: NextRequest) => Promise<SessionUser | null>,
): RouteHandler {
  return async (
    request: NextRequest,
    routeContext: { params: Promise<Record<string, string>> },
  ): Promise<NextResponse> => {
    const startTime = performance.now();

    const user = await getUser(request);
    if (!user) {
      return NextResponse.json<ApiResponse<never>>(
        {
          success: false,
          error: { code: 'RBAC_DENIED', message: 'Unauthorized' },
        },
        { status: 401 },
      );
    }

    let response: NextResponse;
    let status = 500;

    try {
      response = await handler(request, routeContext, user);
      status = response.status;
    } catch (error) {
      const durationMs = Math.round(performance.now() - startTime);
      const resolvedContext = typeof auditContext === 'function'
        ? auditContext(request, await routeContext.params)
        : auditContext;

      await writeAuditLog(user, resolvedContext, 500, durationMs, request);

      console.error('Route handler error:', error);
      return NextResponse.json<ApiResponse<never>>(
        {
          success: false,
          error: {
            code: 'INTERNAL_ERROR',
            message: 'Internal server error',
          },
        },
        { status: 500 },
      );
    }

    const durationMs = Math.round(performance.now() - startTime);
    const resolvedContext = typeof auditContext === 'function'
      ? auditContext(request, await routeContext.params)
      : auditContext;

    await writeAuditLog(user, resolvedContext, status, durationMs, request);

    return response;
  };
}

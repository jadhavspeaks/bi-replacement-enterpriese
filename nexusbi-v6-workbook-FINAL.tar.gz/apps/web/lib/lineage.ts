import type { LineageNode, LineageEdge, LineageGraph, LineageNodeType } from '@nexusbi/shared-types';
import { withConnection, clobToString } from '@/lib/oracle-pool';

interface SchemaRow {
  SCHEMA_ID: string;
  DS_ID: string;
  DS_NAME: string;
  CUBE_NAME: string;
  SCHEMA_JS: string;
}

function createNodeId(type: LineageNodeType, ...parts: string[]): string {
  return `${type}:${parts.join(':')}`;
}

function extractSqlTable(schemaJs: string): string | null {
  const match = schemaJs.match(/sql\s*:\s*[`'"]\s*SELECT\s+.*?\s+FROM\s+([^\s`'"]+)/is);
  return match ? match[1].replace(/[`'"]/g, '') : null;
}

function extractMeasures(schemaJs: string): string[] {
  const measures: string[] = [];
  const measuresBlock = schemaJs.match(/measures\s*:\s*\{([\s\S]*?)\n\s*\}/);
  if (!measuresBlock) return measures;

  const memberRegex = /(\w+)\s*:\s*\{/g;
  let match: RegExpExecArray | null;
  while ((match = memberRegex.exec(measuresBlock[1])) !== null) {
    measures.push(match[1]);
  }
  return measures;
}

function extractDimensions(schemaJs: string): string[] {
  const dimensions: string[] = [];
  const dimensionsBlock = schemaJs.match(/dimensions\s*:\s*\{([\s\S]*?)\n\s*\}/);
  if (!dimensionsBlock) return dimensions;

  const memberRegex = /(\w+)\s*:\s*\{/g;
  let match: RegExpExecArray | null;
  while ((match = memberRegex.exec(dimensionsBlock[1])) !== null) {
    dimensions.push(match[1]);
  }
  return dimensions;
}

function extractJoins(schemaJs: string): Array<{ name: string; targetCube: string }> {
  const joins: Array<{ name: string; targetCube: string }> = [];
  const joinsBlock = schemaJs.match(/joins\s*:\s*\{([\s\S]*?)\n\s*\}/);
  if (!joinsBlock) return joins;

  const joinRegex = /(\w+)\s*:\s*\{[^}]*sql\s*:\s*[`'"].*?\$\{(\w+)\}/g;
  let match: RegExpExecArray | null;
  while ((match = joinRegex.exec(joinsBlock[1])) !== null) {
    joins.push({ name: match[1], targetCube: match[2] });
  }
  return joins;
}

export async function buildLineageGraph(orgId: string): Promise<LineageGraph> {
  const nodes: LineageNode[] = [];
  const edges: LineageEdge[] = [];
  const nodeIds = new Set<string>();

  const schemas = await withConnection(async (conn) => {
    const result = await conn.execute<SchemaRow>(
      `SELECT S.SCHEMA_ID, S.DS_ID, D.DS_NAME, S.CUBE_NAME, S.SCHEMA_JS
       FROM NB_CUBE_SCHEMAS S
       JOIN NB_DATA_SOURCES D ON D.DS_ID = S.DS_ID
       WHERE D.ORG_ID = :orgId
         AND S.IS_ACTIVE = 1
         AND D.IS_ACTIVE = 1`,
      { orgId },
      { outFormat: 4002 },
    );
    return result.rows || [];
  });

  // Build nodes for each schema
  for (const schema of schemas) {
    const schemaJs = await clobToString(schema.SCHEMA_JS);

    // Datasource node
    const dsNodeId = createNodeId('datasource', schema.DS_ID);
    if (!nodeIds.has(dsNodeId)) {
      nodes.push({
        id: dsNodeId,
        type: 'datasource',
        label: schema.DS_NAME,
        metadata: { dsId: schema.DS_ID },
      });
      nodeIds.add(dsNodeId);
    }

    // Table node
    const tableName = extractSqlTable(schemaJs);
    if (tableName) {
      const tableNodeId = createNodeId('table', schema.DS_ID, tableName);
      if (!nodeIds.has(tableNodeId)) {
        nodes.push({
          id: tableNodeId,
          type: 'table',
          label: tableName,
          metadata: { dsId: schema.DS_ID, tableName },
          parentId: dsNodeId,
        });
        nodeIds.add(tableNodeId);

        edges.push({
          id: `edge:${dsNodeId}-${tableNodeId}`,
          source: dsNodeId,
          target: tableNodeId,
          label: 'contains',
        });
      }

      // Cube node
      const cubeNodeId = createNodeId('cube', schema.DS_ID, schema.CUBE_NAME);
      if (!nodeIds.has(cubeNodeId)) {
        nodes.push({
          id: cubeNodeId,
          type: 'cube',
          label: schema.CUBE_NAME,
          metadata: { dsId: schema.DS_ID, schemaId: schema.SCHEMA_ID },
          parentId: tableNodeId,
        });
        nodeIds.add(cubeNodeId);

        edges.push({
          id: `edge:${tableNodeId}-${cubeNodeId}`,
          source: tableNodeId,
          target: cubeNodeId,
          label: 'defines',
        });
      }

      // Measure nodes
      const measures = extractMeasures(schemaJs);
      for (const measure of measures) {
        const measureNodeId = createNodeId('measure', schema.DS_ID, schema.CUBE_NAME, measure);
        if (!nodeIds.has(measureNodeId)) {
          nodes.push({
            id: measureNodeId,
            type: 'measure',
            label: `${schema.CUBE_NAME}.${measure}`,
            metadata: { cubeName: schema.CUBE_NAME, measureName: measure },
            parentId: cubeNodeId,
          });
          nodeIds.add(measureNodeId);

          edges.push({
            id: `edge:${cubeNodeId}-${measureNodeId}`,
            source: cubeNodeId,
            target: measureNodeId,
            label: 'measure',
          });
        }
      }

      // Dimension nodes
      const dimensions = extractDimensions(schemaJs);
      for (const dimension of dimensions) {
        const dimNodeId = createNodeId('dimension', schema.DS_ID, schema.CUBE_NAME, dimension);
        if (!nodeIds.has(dimNodeId)) {
          nodes.push({
            id: dimNodeId,
            type: 'dimension',
            label: `${schema.CUBE_NAME}.${dimension}`,
            metadata: { cubeName: schema.CUBE_NAME, dimensionName: dimension },
            parentId: cubeNodeId,
          });
          nodeIds.add(dimNodeId);

          edges.push({
            id: `edge:${cubeNodeId}-${dimNodeId}`,
            source: cubeNodeId,
            target: dimNodeId,
            label: 'dimension',
          });
        }
      }

      // Join edges
      const joins = extractJoins(schemaJs);
      for (const join of joins) {
        const targetCubeId = createNodeId('cube', schema.DS_ID, join.targetCube);
        if (nodeIds.has(targetCubeId)) {
          edges.push({
            id: `edge:join:${cubeNodeId}-${targetCubeId}`,
            source: cubeNodeId,
            target: targetCubeId,
            label: `join:${join.name}`,
          });
        }
      }
    }
  }

  // Add dashboard->widget->measure edges
  const dashboards = await withConnection(async (conn) => {
    const result = await conn.execute<{
      DASH_ID: string;
      DASH_NAME: string;
      WIDGETS_JSON: string;
    }>(
      `SELECT DASH_ID, DASH_NAME, WIDGETS_JSON
       FROM NB_DASHBOARDS
       WHERE ORG_ID = :orgId
         AND WIDGETS_JSON IS NOT NULL`,
      { orgId },
      { outFormat: 4002 },
    );
    return result.rows || [];
  });

  for (const dash of dashboards) {
    const dashNodeId = createNodeId('dashboard', dash.DASH_ID);
    nodes.push({
      id: dashNodeId,
      type: 'dashboard',
      label: dash.DASH_NAME,
      metadata: { dashId: dash.DASH_ID },
    });
    nodeIds.add(dashNodeId);

    try {
      const widgetsStr = await clobToString(dash.WIDGETS_JSON);
      const widgets = JSON.parse(widgetsStr) as Array<{
        widgetId: string;
        title: string;
        cubeQuery?: { measures?: string[]; dimensions?: string[] };
        dsId?: string;
      }>;

      for (const widget of widgets) {
        const widgetNodeId = createNodeId('widget', dash.DASH_ID, widget.widgetId);
        nodes.push({
          id: widgetNodeId,
          type: 'widget',
          label: widget.title,
          metadata: { dashId: dash.DASH_ID, widgetId: widget.widgetId },
          parentId: dashNodeId,
        });
        nodeIds.add(widgetNodeId);

        edges.push({
          id: `edge:${dashNodeId}-${widgetNodeId}`,
          source: dashNodeId,
          target: widgetNodeId,
          label: 'contains',
        });

        if (widget.cubeQuery?.measures) {
          for (const measure of widget.cubeQuery.measures) {
            const [cubeName, measureName] = measure.split('.');
            if (cubeName && measureName && widget.dsId) {
              const measureNodeId = createNodeId('measure', widget.dsId, cubeName, measureName);
              if (nodeIds.has(measureNodeId)) {
                edges.push({
                  id: `edge:${widgetNodeId}-${measureNodeId}`,
                  source: widgetNodeId,
                  target: measureNodeId,
                  label: 'queries',
                });
              }
            }
          }
        }
      }
    } catch {
      // Skip dashboards with invalid widget JSON
    }
  }

  return {
    nodes,
    edges,
    generatedAt: new Date().toISOString(),
  };
}

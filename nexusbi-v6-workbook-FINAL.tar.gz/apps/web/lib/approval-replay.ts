import type {
  ApprovalSnapshot,
  ApprovalSnapshotListItem,
} from '@nexusbi/shared-types';
import type {
  LayoutConfig,
  WidgetConfig,
  DashboardFiltersState,
  CubeQuery,
} from '@nexusbi/shared-types';
import { withConnection, clobToString, parseJsonClob, generateId } from '@/lib/oracle-pool';

export async function captureApprovalSnapshot(
  dashId: string,
  reviewId: string,
  snappedBy: string,
  orgId: string,
): Promise<string> {
  return withConnection(async (conn) => {
    // Fetch current dashboard state
    const dashResult = await conn.execute<{
      VERSION: number;
      LAYOUT_JSON: string;
      WIDGETS_JSON: string;
      FILTERS_JSON: string;
    }>(
      `SELECT VERSION, LAYOUT_JSON, WIDGETS_JSON, FILTERS_JSON
       FROM NB_DASHBOARDS
       WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
      { dashId, orgId },
      { outFormat: 4002 },
    );

    if (!dashResult.rows || dashResult.rows.length === 0) {
      throw new Error(`Dashboard ${dashId} not found`);
    }

    const dash = dashResult.rows[0];
    const snapshotId = generateId();

    // Build cube queries from widgets
    const widgetsStr = await clobToString(dash.WIDGETS_JSON);
    const widgets = parseJsonClob<WidgetConfig[]>(widgetsStr) || [];
    const cubeQueries: Record<string, CubeQuery> = {};

    for (const widget of widgets) {
      if (widget.cubeQuery) {
        cubeQueries[widget.widgetId] = widget.cubeQuery;
      }
    }

    await conn.execute(
      `INSERT INTO NB_APPROVAL_SNAPSHOTS
         (SNAPSHOT_ID, DASH_ID, REVIEW_ID, VERSION, LAYOUT_JSON,
          WIDGETS_JSON, FILTERS_JSON, CUBE_QUERIES_JSON,
          SNAPPED_AT, SNAPPED_BY, ORG_ID)
       VALUES
         (:snapshotId, :dashId, :reviewId, :version, :layoutJson,
          :widgetsJson, :filtersJson, :cubeQueriesJson,
          SYSTIMESTAMP, :snappedBy, :orgId)`,
      {
        snapshotId,
        dashId,
        reviewId,
        version: dash.VERSION,
        layoutJson: await clobToString(dash.LAYOUT_JSON) || null,
        widgetsJson: widgetsStr || null,
        filtersJson: await clobToString(dash.FILTERS_JSON) || null,
        cubeQueriesJson: Object.keys(cubeQueries).length > 0
          ? JSON.stringify(cubeQueries)
          : null,
        snappedBy,
        orgId,
      },
    );

    await conn.commit();
    return snapshotId;
  });
}

export async function listSnapshots(
  dashId: string,
  orgId: string,
): Promise<ApprovalSnapshotListItem[]> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      SNAPSHOT_ID: string;
      DASH_ID: string;
      REVIEW_ID: string;
      VERSION: number;
      SNAPPED_AT: string;
      SNAPPED_BY: string;
      DISPLAY_NAME: string | null;
    }>(
      `SELECT S.SNAPSHOT_ID, S.DASH_ID, S.REVIEW_ID, S.VERSION,
              S.SNAPPED_AT, S.SNAPPED_BY, U.DISPLAY_NAME
       FROM NB_APPROVAL_SNAPSHOTS S
       LEFT JOIN NB_USERS U ON U.USER_ID = S.SNAPPED_BY
       WHERE S.DASH_ID = :dashId AND S.ORG_ID = :orgId
       ORDER BY S.SNAPPED_AT DESC`,
      { dashId, orgId },
      { outFormat: 4002 },
    );

    return (result.rows || []).map((row) => ({
      snapshotId: row.SNAPSHOT_ID,
      dashId: row.DASH_ID,
      reviewId: row.REVIEW_ID,
      version: row.VERSION,
      snappedAt: String(row.SNAPPED_AT),
      snappedBy: row.SNAPPED_BY,
      snappedByDisplayName: row.DISPLAY_NAME ?? undefined,
    }));
  });
}

export async function getSnapshot(
  snapshotId: string,
  orgId: string,
): Promise<ApprovalSnapshot | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      SNAPSHOT_ID: string;
      DASH_ID: string;
      REVIEW_ID: string;
      VERSION: number;
      LAYOUT_JSON: string;
      WIDGETS_JSON: string;
      FILTERS_JSON: string;
      CUBE_QUERIES_JSON: string;
      SNAPPED_AT: string;
      SNAPPED_BY: string;
      ORG_ID: string;
    }>(
      `SELECT SNAPSHOT_ID, DASH_ID, REVIEW_ID, VERSION,
              LAYOUT_JSON, WIDGETS_JSON, FILTERS_JSON,
              CUBE_QUERIES_JSON, SNAPPED_AT, SNAPPED_BY, ORG_ID
       FROM NB_APPROVAL_SNAPSHOTS
       WHERE SNAPSHOT_ID = :snapshotId AND ORG_ID = :orgId`,
      { snapshotId, orgId },
      { outFormat: 4002 },
    );

    if (!result.rows || result.rows.length === 0) return null;

    const row = result.rows[0];
    const layoutStr = await clobToString(row.LAYOUT_JSON);
    const widgetsStr = await clobToString(row.WIDGETS_JSON);
    const filtersStr = await clobToString(row.FILTERS_JSON);
    const cubeQueriesStr = await clobToString(row.CUBE_QUERIES_JSON);

    return {
      snapshotId: row.SNAPSHOT_ID,
      dashId: row.DASH_ID,
      reviewId: row.REVIEW_ID,
      version: row.VERSION,
      layoutJson: parseJsonClob<LayoutConfig>(layoutStr),
      widgetsJson: parseJsonClob<WidgetConfig[]>(widgetsStr),
      filtersJson: parseJsonClob<DashboardFiltersState>(filtersStr),
      cubeQueriesJson: parseJsonClob<Record<string, CubeQuery>>(cubeQueriesStr),
      snappedAt: String(row.SNAPPED_AT),
      snappedBy: row.SNAPPED_BY,
      orgId: row.ORG_ID,
    };
  });
}

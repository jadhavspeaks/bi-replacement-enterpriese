import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import { logQueryForRefreshAnalysis } from '@/lib/smart-refresh';
import type { ApiResponse } from '@nexusbi/shared-types';

const CUBE_API_URL = process.env.CUBEJS_API_URL || 'http://cube:4000';
const CUBEJS_API_SECRET = process.env.CUBEJS_API_SECRET || '';

interface CubeProxyOptions {
  checkDsAccess?: boolean;
}

export async function proxyCubeRequest(
  request: NextRequest,
  path: string,
  options: CubeProxyOptions = {},
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const { user } = session;

  // Build security context
  const securityContext: Record<string, unknown> = {
    userId: user.id,
    orgId: user.orgId,
    roles: user.roles,
  };

  // Load RLS filters if applicable
  if (options.checkDsAccess) {
    const rlsFilters = await loadRlsFilters(user.id, user.orgId);
    if (rlsFilters) {
      securityContext.rlsFilters = rlsFilters;
    }
  }

  // Determine the target URL
  const targetUrl = new URL(path, CUBE_API_URL);

  // Copy query params
  const url = new URL(request.url);
  url.searchParams.forEach((value, key) => {
    targetUrl.searchParams.set(key, value);
  });

  // Build headers
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
    Authorization: CUBEJS_API_SECRET,
    'x-request-id': crypto.randomUUID(),
  };

  // Add security context as header
  headers['x-security-context'] = Buffer.from(
    JSON.stringify(securityContext),
  ).toString('base64');

  // Forward the request
  const fetchOptions: RequestInit = {
    method: request.method,
    headers,
  };

  if (request.method !== 'GET' && request.method !== 'HEAD') {
    try {
      const body = await request.text();
      if (body) {
        fetchOptions.body = body;

        // Log query for smart refresh analysis
        try {
          const parsed = JSON.parse(body);
          const query = parsed.query || parsed;
          if (query.measures || query.dimensions) {
            const cubeName = extractCubeName(query);
            const measures = query.measures || [];
            if (cubeName) {
              // Fire and forget
              logQueryForRefreshAnalysis(
                'default',
                cubeName,
                measures,
                0,
                user.orgId,
              ).catch(() => {});
            }
          }
        } catch {
          // Not a query body, skip logging
        }
      }
    } catch {
      // No body
    }
  }

  try {
    const startTime = performance.now();
    const response = await fetch(targetUrl.toString(), fetchOptions);
    const durationMs = Math.round(performance.now() - startTime);

    const responseBody = await response.text();

    // Log query duration for smart refresh
    try {
      if (request.method === 'POST') {
        const body = await request.clone().text();
        const parsed = JSON.parse(body);
        const query = parsed.query || parsed;
        const cubeName = extractCubeName(query);
        if (cubeName && query.measures) {
          logQueryForRefreshAnalysis(
            'default',
            cubeName,
            query.measures,
            durationMs,
            user.orgId,
          ).catch(() => {});
        }
      }
    } catch {
      // ignore
    }

    return new NextResponse(responseBody, {
      status: response.status,
      headers: {
        'Content-Type': response.headers.get('Content-Type') || 'application/json',
        'X-Cube-Duration-Ms': String(durationMs),
      },
    });
  } catch (error) {
    console.error('Cube proxy error:', error);
    return NextResponse.json<ApiResponse<never>>(
      {
        success: false,
        error: {
          code: 'CUBE_QUERY_FAILED',
          message: 'Failed to proxy request to Cube.js',
        },
      },
      { status: 502 },
    );
  }
}

function extractCubeName(query: Record<string, unknown>): string | null {
  const measures = query.measures as string[] | undefined;
  const dimensions = query.dimensions as string[] | undefined;

  const firstMember = measures?.[0] || dimensions?.[0];
  if (!firstMember) return null;

  const parts = firstMember.split('.');
  return parts.length >= 2 ? parts[0] : null;
}

async function loadRlsFilters(
  userId: string,
  orgId: string,
): Promise<Record<string, string> | null> {
  return withConnection(async (conn) => {
    const result = await conn.execute<{
      DS_ID: string;
      ROW_FILTER_SQL: string;
    }>(
      `SELECT DA.DS_ID, DA.ROW_FILTER_SQL
       FROM NB_DS_ACCESS DA
       JOIN NB_USER_ROLES UR ON UR.ROLE_ID = DA.ROLE_ID
       WHERE UR.USER_ID = :userId
         AND UR.ORG_ID = :orgId
         AND DA.ROW_FILTER_SQL IS NOT NULL
         AND (DA.EXPIRES_AT IS NULL OR DA.EXPIRES_AT > SYSTIMESTAMP)`,
      { userId, orgId },
      { outFormat: 4002 },
    );

    if (!result.rows || result.rows.length === 0) return null;

    const filters: Record<string, string> = {};
    for (const row of result.rows) {
      const filterSql = await clobToString(row.ROW_FILTER_SQL);
      if (filterSql) {
        filters[row.DS_ID] = filterSql;
      }
    }

    return Object.keys(filters).length > 0 ? filters : null;
  });
}

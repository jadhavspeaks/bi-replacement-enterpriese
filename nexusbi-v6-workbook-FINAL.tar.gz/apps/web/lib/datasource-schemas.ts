import { z } from 'zod';
import type { DataSourceType } from '@nexusbi/shared-types';

// ── Relational DB Schemas ────────────────────────────────

export const PostgresConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(5432),
  database: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  ssl: z.boolean().default(false),
  sslCa: z.string().optional(),
  sslCert: z.string().optional(),
  sslKey: z.string().optional(),
  schema: z.string().default('public'),
});

export const MysqlConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(3306),
  database: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  ssl: z.boolean().default(false),
  sslCa: z.string().optional(),
});

export const MssqlConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(1433),
  database: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  encrypt: z.boolean().default(true),
  trustServerCertificate: z.boolean().default(false),
  domain: z.string().optional(),
  schema: z.string().default('dbo'),
});

export const OracleConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(1521),
  serviceName: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  schema: z.string().optional(),
  useThinDriver: z.boolean().default(true),
});

export const SqliteConfigSchema = z.object({
  databasePath: z.string().min(1),
  readOnly: z.boolean().default(false),
});

// ── Cloud Data Warehouses ────────────────────────────────

export const SnowflakeConfigSchema = z.object({
  account: z.string().min(1),
  username: z.string().min(1),
  password: z.string().min(1),
  warehouse: z.string().min(1),
  database: z.string().min(1),
  schema: z.string().default('PUBLIC'),
  role: z.string().optional(),
  region: z.string().optional(),
});

export const BigQueryConfigSchema = z.object({
  projectId: z.string().min(1),
  credentials: z.string().min(1),
  location: z.string().default('US'),
  dataset: z.string().optional(),
});

export const RedshiftConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(5439),
  database: z.string().min(1),
  user: z.string().min(1),
  password: z.string().min(1),
  ssl: z.boolean().default(true),
  schema: z.string().default('public'),
});

export const DatabricksConfigSchema = z.object({
  url: z.string().url(),
  token: z.string().min(1),
  catalog: z.string().optional(),
  schema: z.string().optional(),
});

export const AthenaConfigSchema = z.object({
  accessKeyId: z.string().min(1),
  secretAccessKey: z.string().min(1),
  region: z.string().min(1),
  s3OutputLocation: z.string().min(1),
  workgroup: z.string().default('primary'),
  catalog: z.string().default('AwsDataCatalog'),
  database: z.string().optional(),
});

// ── Hadoop / Spark Ecosystem ─────────────────────────────

export const HiveConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(10000),
  database: z.string().default('default'),
  username: z.string().optional(),
  authMechanism: z.enum(['NOSASL', 'PLAIN', 'KERBEROS']).default('NOSASL'),
  kerberosPrincipal: z.string().optional(),
  kerberosKeytab: z.string().optional(),
});

export const SparkSqlConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(10000),
  database: z.string().default('default'),
  username: z.string().optional(),
  authMechanism: z.enum(['NOSASL', 'PLAIN', 'KERBEROS']).default('NOSASL'),
  kerberosPrincipal: z.string().optional(),
  kerberosKeytab: z.string().optional(),
});

export const ImpalaConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(21050),
  database: z.string().default('default'),
  username: z.string().optional(),
  authMechanism: z.enum(['NOSASL', 'PLAIN', 'KERBEROS']).default('NOSASL'),
  kerberosPrincipal: z.string().optional(),
  kerberosKeytab: z.string().optional(),
  ssl: z.boolean().default(false),
});

// ── Query Engines ────────────────────────────────────────

export const PrestoConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(8080),
  catalog: z.string().min(1),
  schema: z.string().default('default'),
  user: z.string().optional(),
  ssl: z.boolean().default(false),
});

export const TrinoConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(8080),
  catalog: z.string().min(1),
  schema: z.string().default('default'),
  user: z.string().optional(),
  ssl: z.boolean().default(false),
});

export const ClickHouseConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(8123),
  database: z.string().min(1),
  username: z.string().default('default'),
  password: z.string().optional(),
  ssl: z.boolean().default(false),
  protocol: z.enum(['http', 'native']).default('http'),
});

// ── NoSQL ────────────────────────────────────────────────

export const MongoDBConfigSchema = z.object({
  host: z.string().min(1),
  port: z.number().int().min(1).max(65535).default(3307),
  database: z.string().min(1),
  user: z.string().optional(),
  password: z.string().optional(),
  ssl: z.boolean().default(false),
  authSource: z.string().default('admin'),
});

// ── Embedded ─────────────────────────────────────────────

// ── Oracle Staging (replaces DuckDB — file/API data staged in Oracle) ──

export const OracleStagingConfigSchema = z.object({
  stagingPrefix: z.string().default('NB_STG'),
  schemaName: z.string().optional(),
});

// ── File-based ───────────────────────────────────────────

export const FileConfigSchema = z.object({
  delimiter: z.string().max(5).optional(),
  hasHeader: z.boolean().default(true),
  encoding: z.string().default('utf-8'),
  sheetName: z.string().optional(),
  skipRows: z.number().int().min(0).default(0),
});

// ── API-based ────────────────────────────────────────────

export const ApiRestConfigSchema = z.object({
  baseUrl: z.string().url(),
  authMethod: z.enum(['none', 'api_key', 'bearer', 'basic']).default('none'),
  apiKeyHeader: z.string().optional(),
  apiKeyValue: z.string().optional(),
  bearerToken: z.string().optional(),
  basicUsername: z.string().optional(),
  basicPassword: z.string().optional(),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

export const ApiGraphqlConfigSchema = z.object({
  baseUrl: z.string().url(),
  authMethod: z.enum(['none', 'api_key', 'bearer', 'basic']).default('none'),
  apiKeyHeader: z.string().optional(),
  apiKeyValue: z.string().optional(),
  bearerToken: z.string().optional(),
  basicUsername: z.string().optional(),
  basicPassword: z.string().optional(),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

export const ApiWebhookConfigSchema = z.object({
  secretHeader: z.string().default('X-Webhook-Secret'),
  secretValue: z.string().min(16),
  payloadPath: z.string().optional(),
});

export const ApiOAuthRestConfigSchema = z.object({
  baseUrl: z.string().url(),
  tokenUrl: z.string().url(),
  clientId: z.string().min(1),
  clientSecret: z.string().min(1),
  scope: z.string().optional(),
  grantType: z.enum(['client_credentials', 'authorization_code']).default('client_credentials'),
  defaultHeaders: z.record(z.string()).optional(),
  timeoutMs: z.number().int().min(1000).max(120000).default(30000),
});

// ── Master Schema Map ────────────────────────────────────

export const DS_CONFIG_SCHEMAS = {
  postgres: PostgresConfigSchema,
  mysql: MysqlConfigSchema,
  mssql: MssqlConfigSchema,
  oracle: OracleConfigSchema,
  sqlite: SqliteConfigSchema,
  snowflake: SnowflakeConfigSchema,
  bigquery: BigQueryConfigSchema,
  redshift: RedshiftConfigSchema,
  databricks: DatabricksConfigSchema,
  athena: AthenaConfigSchema,
  hive: HiveConfigSchema,
  sparksql: SparkSqlConfigSchema,
  impala: ImpalaConfigSchema,
  presto: PrestoConfigSchema,
  trino: TrinoConfigSchema,
  clickhouse: ClickHouseConfigSchema,
  mongodb: MongoDBConfigSchema,
  duckdb: OracleStagingConfigSchema,
  file_csv: FileConfigSchema,
  file_excel: FileConfigSchema,
  file_parquet: z.object({}),
  file_json: FileConfigSchema,
  api_rest: ApiRestConfigSchema,
  api_graphql: ApiGraphqlConfigSchema,
  api_webhook: ApiWebhookConfigSchema,
  api_oauth_rest: ApiOAuthRestConfigSchema,
} as const satisfies Record<DataSourceType, z.ZodTypeAny>;

export type DsConfigSchemaMap = typeof DS_CONFIG_SCHEMAS;

export function getConfigSchema(dsType: DataSourceType): z.ZodTypeAny {
  return DS_CONFIG_SCHEMAS[dsType];
}

export function validateDsConfig(dsType: DataSourceType, config: unknown): z.SafeParseReturnType<unknown, unknown> {
  const schema = getConfigSchema(dsType);
  return schema.safeParse(config);
}

import cron from 'node-cron';
import { acquireLock, releaseLock, CACHE_KEYS } from '@/lib/cache';
import { withConnection } from '@/lib/oracle-pool';
import { generateSmartRefreshSuggestions } from '@/lib/smart-refresh';
import { deactivateExpiredAccess } from '@/lib/timed-access';
import { sendNotification, buildDashboardReportHtml } from '@/lib/notifications';
import type { DeliveryType, DeliveryConfig } from '@nexusbi/shared-types';

interface ScheduledJob {
  name: string;
  cronExpression: string;
  handler: () => Promise<void>;
  task?: cron.ScheduledTask;
}

const jobs: Map<string, ScheduledJob> = new Map();

async function runWithLock(
  jobName: string,
  lockTtl: number,
  handler: () => Promise<void>,
): Promise<void> {
  const lockKey = CACHE_KEYS.schedulerLock(jobName);
  const acquired = await acquireLock(lockKey, lockTtl);

  if (!acquired) {
    console.log(`Scheduler: ${jobName} skipped — lock held by another instance`);
    return;
  }

  try {
    console.log(`Scheduler: ${jobName} started`);
    const start = performance.now();
    await handler();
    const duration = Math.round(performance.now() - start);
    console.log(`Scheduler: ${jobName} completed in ${duration}ms`);
  } catch (error) {
    console.error(`Scheduler: ${jobName} failed:`, error);
  } finally {
    await releaseLock(lockKey);
  }
}

// ── Built-in Jobs ────────────────────────────────────────

async function smartRefreshJob(): Promise<void> {
  // Get all active orgs
  const orgs = await withConnection(async (conn) => {
    const result = await conn.execute<{ ORG_ID: string }>(
      `SELECT DISTINCT ORG_ID FROM NB_DATA_SOURCES WHERE IS_ACTIVE = 1`,
      {},
      { outFormat: 4002 },
    );
    return (result.rows || []).map((r) => r.ORG_ID);
  });

  for (const orgId of orgs) {
    try {
      await generateSmartRefreshSuggestions(orgId);
    } catch (error) {
      console.error(`Smart refresh analysis failed for org ${orgId}:`, error);
    }
  }
}

async function expiredAccessJob(): Promise<void> {
  const orgs = await withConnection(async (conn) => {
    const result = await conn.execute<{ ORG_ID: string }>(
      `SELECT DISTINCT ORG_ID FROM NB_TIMED_ACCESS WHERE IS_ACTIVE = 1`,
      {},
      { outFormat: 4002 },
    );
    return (result.rows || []).map((r) => r.ORG_ID);
  });

  for (const orgId of orgs) {
    try {
      const deactivated = await deactivateExpiredAccess(orgId);
      if (deactivated > 0) {
        console.log(`Deactivated ${deactivated} expired access grants for org ${orgId}`);
      }
    } catch (error) {
      console.error(`Expired access cleanup failed for org ${orgId}:`, error);
    }
  }
}

async function scheduledReportsJob(): Promise<void> {
  const now = new Date();

  const reports = await withConnection(async (conn) => {
    const result = await conn.execute<{
      REPORT_ID: string;
      DASH_ID: string;
      REPORT_NAME: string;
      DELIVERY_TYPE: string;
      DELIVERY_CONFIG: string;
      DASH_NAME: string;
    }>(
      `SELECT R.REPORT_ID, R.DASH_ID, R.REPORT_NAME,
              R.DELIVERY_TYPE, R.DELIVERY_CONFIG, D.DASH_NAME
       FROM NB_SCHEDULED_REPORTS R
       JOIN NB_DASHBOARDS D ON D.DASH_ID = R.DASH_ID
       WHERE R.IS_ACTIVE = 1
         AND (R.NEXT_RUN_AT IS NULL OR R.NEXT_RUN_AT <= SYSTIMESTAMP)`,
      {},
      { outFormat: 4002 },
    );
    return result.rows || [];
  });

  for (const report of reports) {
    try {
      const deliveryConfig = JSON.parse(report.DELIVERY_CONFIG) as DeliveryConfig;
      const htmlBody = buildDashboardReportHtml(
        report.DASH_NAME,
        report.REPORT_NAME,
        now.toISOString(),
      );

      await sendNotification({
        deliveryType: report.DELIVERY_TYPE as DeliveryType,
        deliveryConfig,
        subject: `NexusBI Report: ${report.REPORT_NAME}`,
        body: `Scheduled report for dashboard "${report.DASH_NAME}"`,
        htmlBody,
      });

      // Update last run status
      await withConnection(async (conn) => {
        await conn.execute(
          `UPDATE NB_SCHEDULED_REPORTS
           SET LAST_RUN_AT = SYSTIMESTAMP,
               LAST_RUN_STATUS = 'SUCCESS'
           WHERE REPORT_ID = :reportId`,
          { reportId: report.REPORT_ID },
        );
        await conn.commit();
      });
    } catch (error) {
      console.error(`Report ${report.REPORT_ID} delivery failed:`, error);

      await withConnection(async (conn) => {
        await conn.execute(
          `UPDATE NB_SCHEDULED_REPORTS
           SET LAST_RUN_AT = SYSTIMESTAMP,
               LAST_RUN_STATUS = 'FAILED'
           WHERE REPORT_ID = :reportId`,
          { reportId: report.REPORT_ID },
        );
        await conn.commit();
      });
    }
  }
}

// ── Scheduler Init ───────────────────────────────────────

export function initScheduler(): void {
  // Smart refresh analysis — every hour
  registerJob({
    name: 'smart-refresh-analysis',
    cronExpression: '0 * * * *',
    handler: () => runWithLock('smart-refresh', 300, smartRefreshJob),
  });

  // Expired access cleanup — every 5 minutes
  registerJob({
    name: 'expired-access-cleanup',
    cronExpression: '*/5 * * * *',
    handler: () => runWithLock('expired-access', 60, expiredAccessJob),
  });

  // Scheduled reports — every minute (checks NEXT_RUN_AT)
  registerJob({
    name: 'scheduled-reports',
    cronExpression: '* * * * *',
    handler: () => runWithLock('scheduled-reports', 120, scheduledReportsJob),
  });

  console.log(`Scheduler initialized with ${jobs.size} jobs`);
}

export function registerJob(job: ScheduledJob): void {
  if (jobs.has(job.name)) {
    const existing = jobs.get(job.name);
    existing?.task?.stop();
  }

  const task = cron.schedule(job.cronExpression, job.handler, {
    scheduled: true,
    timezone: 'UTC',
  });

  jobs.set(job.name, { ...job, task });
  console.log(`Scheduler: registered job "${job.name}" with cron "${job.cronExpression}"`);
}

export function stopScheduler(): void {
  for (const [name, job] of jobs.entries()) {
    job.task?.stop();
    console.log(`Scheduler: stopped job "${name}"`);
  }
  jobs.clear();
}

export function getRegisteredJobs(): Array<{ name: string; cronExpression: string }> {
  return Array.from(jobs.entries()).map(([name, job]) => ({
    name,
    cronExpression: job.cronExpression,
  }));
}

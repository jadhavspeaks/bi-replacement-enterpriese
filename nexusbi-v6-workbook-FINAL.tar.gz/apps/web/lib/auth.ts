import NextAuth from 'next-auth';
import Credentials from 'next-auth/providers/credentials';
import bcrypt from 'bcryptjs';
import { getOraclePool, clobToString } from '@/lib/oracle-pool';
import type { SessionUser } from '@nexusbi/shared-types';

export const {
  handlers,
  auth,
  signIn,
  signOut,
} = NextAuth({
  providers: [
    Credentials({
      name: 'credentials',
      credentials: {
        username: { label: 'Username', type: 'text' },
        password: { label: 'Password', type: 'password' },
      },
      async authorize(credentials) {
        if (!credentials?.username || !credentials?.password) {
          return null;
        }

        const username = credentials.username as string;
        const password = credentials.password as string;

        const pool = getOraclePool();
        let conn;

        try {
          conn = await pool.getConnection();

          const result = await conn.execute<{
            USER_ID: string;
            EMAIL: string;
            USERNAME: string;
            PASSWORD_HASH: string;
            DISPLAY_NAME: string | null;
            ORG_ID: string;
            IS_ACTIVE: number;
          }>(
            `SELECT USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME, ORG_ID, IS_ACTIVE
             FROM NB_USERS
             WHERE USERNAME = :username`,
            { username },
            { outFormat: 4002 /* oracledb.OUT_FORMAT_OBJECT */ },
          );

          const rows = result.rows;
          if (!rows || rows.length === 0) {
            return null;
          }

          const user = rows[0];

          if (user.IS_ACTIVE !== 1) {
            return null;
          }

          const passwordHash = typeof user.PASSWORD_HASH === 'string'
            ? user.PASSWORD_HASH
            : await clobToString(user.PASSWORD_HASH);

          const isValid = await bcrypt.compare(password, passwordHash);
          if (!isValid) {
            return null;
          }

          // Load roles from NB_USER_ROLES
          const rolesResult = await conn.execute<{
            ROLE_NAME: string;
          }>(
            `SELECT R.ROLE_NAME
             FROM NB_USER_ROLES UR
             JOIN NB_ROLES R ON R.ROLE_ID = UR.ROLE_ID
             WHERE UR.USER_ID = :userId
               AND (UR.EXPIRES_AT IS NULL OR UR.EXPIRES_AT > SYSTIMESTAMP)`,
            { userId: user.USER_ID },
            { outFormat: 4002 },
          );

          const roles = (rolesResult.rows || []).map((r) => r.ROLE_NAME);

          // Update last login
          await conn.execute(
            `UPDATE NB_USERS SET LAST_LOGIN_AT = SYSTIMESTAMP WHERE USER_ID = :userId`,
            { userId: user.USER_ID },
          );
          await conn.commit();

          return {
            id: user.USER_ID,
            email: user.EMAIL,
            username: user.USERNAME,
            displayName: user.DISPLAY_NAME || user.USERNAME,
            orgId: user.ORG_ID,
            roles,
          };
        } catch (error) {
          console.error('Auth error:', error);
          return null;
        } finally {
          if (conn) {
            try {
              await conn.close();
            } catch {
              // ignore close errors
            }
          }
        }
      },
    }),
  ],
  session: {
    strategy: 'jwt',
    maxAge: 8 * 60 * 60, // 8 hours
  },
  pages: {
    signIn: '/login',
  },
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        token.id = user.id as string;
        token.email = user.email as string;
        token.username = (user as SessionUser).username;
        token.displayName = (user as SessionUser).displayName;
        token.orgId = (user as SessionUser).orgId;
        token.roles = (user as SessionUser).roles;
      }
      return token;
    },
    async session({ session, token }) {
      session.user = {
        id: token.id,
        email: token.email,
        username: token.username,
        displayName: token.displayName,
        orgId: token.orgId,
        roles: token.roles,
      };
      return session;
    },
  },
  secret: process.env.NEXTAUTH_SECRET,
  trustHost: true,
});

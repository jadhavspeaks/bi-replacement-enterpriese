'use client';

import { useMemo, useEffect, useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { useExplorerStore } from '@/store/explorer.store';
import { getCubeClient } from '@/lib/cube-client';

interface DataRow {
  [key: string]: string | number | boolean | null;
}

export function GraphicWalkerWrapper() {
  const { selectedDsId, selectedCubeName, cubes } = useExplorerStore();
  const [data, setData] = useState<DataRow[]>([]);
  const [loading, setLoading] = useState(false);
  const [GWComponent, setGWComponent] = useState<React.ComponentType<any> | null>(null);

  const selectedCube = useMemo(
    () => cubes.find((c) => c.name === selectedCubeName),
    [cubes, selectedCubeName],
  );

  // Dynamically import graphic-walker
  useEffect(() => {
    import('@kanaries/graphic-walker').then((mod) => {
      setGWComponent(() => mod.GraphicWalker || mod.default);
    }).catch(() => {
      console.warn('Failed to load @kanaries/graphic-walker');
    });
  }, []);

  // Load data when cube changes
  useEffect(() => {
    if (!selectedCube || !selectedDsId) {
      setData([]);
      return;
    }

    let cancelled = false;

    async function loadData() {
      setLoading(true);
      try {
        const measures = selectedCube!.measures.slice(0, 5).map((m) => m.name);
        const dimensions = selectedCube!.dimensions.slice(0, 10).map((d) => d.name);

        const query = {
          measures,
          dimensions,
          limit: 1000,
        };

        const response = await fetch('/api/cube/v1/load', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ query }),
        });

        if (!response.ok) throw new Error('Query failed');
        const result = await response.json();

        if (!cancelled && result.data) {
          setData(result.data);
        }
      } catch (error) {
        console.error('Explorer data load error:', error);
        if (!cancelled) setData([]);
      }
      if (!cancelled) setLoading(false);
    }

    loadData();
    return () => { cancelled = true; };
  }, [selectedCube, selectedDsId]);

  const fields = useMemo(() => {
    if (!selectedCube) return [];

    const measureFields = selectedCube.measures.map((m) => ({
      fid: m.name,
      name: m.title || m.name.split('.').pop() || m.name,
      analyticType: 'measure' as const,
      semanticType: 'quantitative' as const,
    }));

    const dimensionFields = selectedCube.dimensions.map((d) => ({
      fid: d.name,
      name: d.title || d.name.split('.').pop() || d.name,
      analyticType: 'dimension' as const,
      semanticType: d.type === 'time' ? 'temporal' as const :
        d.type === 'number' ? 'quantitative' as const : 'nominal' as const,
    }));

    return [...dimensionFields, ...measureFields];
  }, [selectedCube]);

  if (!selectedCubeName) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-16">
          <p className="text-sm text-muted-foreground">
            Select a data source and cube to start exploring.
          </p>
        </CardContent>
      </Card>
    );
  }

  if (loading) {
    return (
      <Card>
        <CardContent className="py-8">
          <div className="space-y-4">
            <Skeleton className="h-8 w-full" />
            <Skeleton className="h-64 w-full" />
            <Skeleton className="h-8 w-3/4" />
          </div>
        </CardContent>
      </Card>
    );
  }

  if (!GWComponent) {
    return (
      <Card>
        <CardContent className="py-8 text-center">
          <p className="text-sm text-muted-foreground">Loading explorer component...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardContent className="p-0">
        <div className="min-h-[600px]">
          <GWComponent
            dataSource={data}
            rawFields={fields}
            hideDataSourceConfig={true}
            dark="light"
          />
        </div>
      </CardContent>
    </Card>
  );
}

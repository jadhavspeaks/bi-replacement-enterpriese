'use client';

import { useEffect, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { StatusBadge } from '@nexusbi/ui-components';
import { Skeleton } from '@/components/ui/skeleton';
import { Loader2, Gauge, Zap, Clock, CheckCircle2 } from 'lucide-react';
import type { PreAggRecommendation, SmartRefreshSuggestion } from '@nexusbi/shared-types';

export function PreAggManager() {
  const [recommendations, setRecommendations] = useState<PreAggRecommendation[]>([]);
  const [suggestions, setSuggestions] = useState<SmartRefreshSuggestion[]>([]);
  const [loading, setLoading] = useState(true);
  const [applyingId, setApplyingId] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    try {
      const [recRes, sugRes] = await Promise.all([
        fetch('/api/preagg'),
        fetch('/api/preagg/smart-suggest'),
      ]);
      const recData = await recRes.json();
      const sugData = await sugRes.json();
      if (recData.success) setRecommendations(recData.data || []);
      if (sugData.success) setSuggestions(sugData.data || []);
    } catch { /* handle */ }
    setLoading(false);
  }, []);

  useEffect(() => { fetchData(); }, [fetchData]);

  const handleApply = useCallback(async (recId: string) => {
    setApplyingId(recId);
    try {
      const response = await fetch(`/api/preagg/${recId}/apply`, { method: 'POST' });
      if (response.ok) fetchData();
    } catch { /* handle */ }
    setApplyingId(null);
  }, [fetchData]);

  if (loading) {
    return <div className="space-y-4">{Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}</div>;
  }

  return (
    <div className="space-y-6">
      {suggestions.length > 0 && (
        <Card>
          <CardHeader className="p-4">
            <CardTitle className="text-base flex items-center gap-2">
              <Zap className="h-4 w-4 text-amber-500" />
              Smart Refresh Suggestions
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 space-y-3">
            {suggestions.map((sug) => (
              <div key={sug.recId} className="rounded-md border p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{sug.cubeName}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{sug.reason}</p>
                    {sug.smartRefreshCron && (
                      <div className="flex items-center gap-2 mt-1">
                        <Clock className="h-3 w-3 text-muted-foreground" />
                        <code className="text-xs font-mono bg-muted px-1.5 py-0.5 rounded">{sug.smartRefreshCron}</code>
                        {sug.confidenceScore !== null && (
                          <Badge variant="outline" className="text-[10px]">
                            {sug.confidenceScore}% confidence
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="text-right text-xs text-muted-foreground">
                    <p>{sug.queryCount} queries</p>
                    <p>{sug.avgQueryMs}ms avg</p>
                  </div>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-base flex items-center gap-2">
            <Gauge className="h-4 w-4" />
            Pre-Aggregation Recommendations ({recommendations.length})
          </CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0 space-y-3">
          {recommendations.length === 0 ? (
            <p className="text-sm text-muted-foreground text-center py-4">
              No recommendations available. Run more queries to generate suggestions.
            </p>
          ) : (
            recommendations.map((rec) => (
              <div key={rec.recId} className="rounded-md border p-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <p className="text-sm font-medium">{rec.cubeName}</p>
                      <StatusBadge status={rec.status} size="sm" />
                    </div>
                    <p className="text-xs text-muted-foreground">{rec.reason}</p>
                    <div className="flex items-center gap-3 mt-1 text-xs text-muted-foreground">
                      <span>{rec.queryCount} queries</span>
                      <span>{rec.avgQueryMs}ms avg</span>
                      {rec.smartRefreshCron && (
                        <span className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          {rec.smartRefreshCron}
                        </span>
                      )}
                    </div>
                  </div>
                  {rec.status === 'PENDING' && (
                    <Button
                      size="sm"
                      onClick={() => handleApply(rec.recId)}
                      disabled={applyingId === rec.recId}
                    >
                      {applyingId === rec.recId ? (
                        <><Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />Applying...</>
                      ) : (
                        <><CheckCircle2 className="h-3.5 w-3.5 mr-1" />Apply</>
                      )}
                    </Button>
                  )}
                  {rec.status === 'APPLIED' && rec.appliedAt && (
                    <p className="text-xs text-green-600">
                      Applied {new Date(rec.appliedAt).toLocaleDateString()}
                    </p>
                  )}
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  );
}

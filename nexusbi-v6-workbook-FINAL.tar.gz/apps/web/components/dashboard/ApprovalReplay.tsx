'use client';

import { useEffect, useState, useCallback } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { ReplayTimeline } from './ReplayTimeline';
import { DashboardGrid } from './DashboardGrid';
import { useDashboardStore } from '@/store/dashboard.store';
import { PlayCircle, ArrowLeft } from 'lucide-react';
import type { ApprovalSnapshotListItem, ApprovalSnapshot } from '@nexusbi/shared-types';

interface ApprovalReplayProps {
  dashId: string;
}

export function ApprovalReplay({ dashId }: ApprovalReplayProps) {
  const [snapshots, setSnapshots] = useState<ApprovalSnapshotListItem[]>([]);
  const [selectedSnapshot, setSelectedSnapshot] = useState<ApprovalSnapshot | null>(null);
  const [loading, setLoading] = useState(true);
  const [loadingSnapshot, setLoadingSnapshot] = useState(false);
  const setDashboard = useDashboardStore((s) => s.setDashboard);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/replay`);
        const data = await response.json();
        if (data.success) setSnapshots(data.data || []);
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  const handleSelectSnapshot = useCallback(async (snapshotId: string) => {
    setLoadingSnapshot(true);
    try {
      const response = await fetch(`/api/dashboards/${dashId}/replay/${snapshotId}`);
      const data = await response.json();
      if (data.success && data.data) {
        const snapshot = data.data as ApprovalSnapshot;
        setSelectedSnapshot(snapshot);

        // Load into dashboard store for rendering
        setDashboard({
          dashId: snapshot.dashId,
          dashName: `Replay v${snapshot.version}`,
          description: null,
          layoutJson: snapshot.layoutJson,
          widgetsJson: snapshot.widgetsJson,
          filtersJson: snapshot.filtersJson,
          ownerId: '',
          orgId: snapshot.orgId,
          isPublic: false,
          isEmbedded: false,
          embedToken: null,
          version: snapshot.version,
          thumbnailUrl: null,
          tags: null,
          approvalStatus: 'APPROVED',
          approvedBy: snapshot.snappedBy,
          approvedAt: snapshot.snappedAt,
          rejectedBy: null,
          rejectedAt: null,
          rejectionReason: null,
          source: 'MANUAL',
          dualCheckerRequired: false,
          createdAt: snapshot.snappedAt,
          updatedAt: snapshot.snappedAt,
        });
      }
    } catch {
      // handle error
    }
    setLoadingSnapshot(false);
  }, [dashId, setDashboard]);

  if (loading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-12 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (snapshots.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <PlayCircle className="mx-auto h-12 w-12 text-muted-foreground mb-3" />
          <h3 className="text-lg font-semibold">No Approval History</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Approval snapshots are captured when a dashboard is approved.
          </p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <ReplayTimeline
        snapshots={snapshots}
        selectedSnapshotId={selectedSnapshot?.snapshotId ?? null}
        onSelect={handleSelectSnapshot}
      />

      {loadingSnapshot ? (
        <Skeleton className="h-64 w-full" />
      ) : selectedSnapshot ? (
        <Card>
          <CardHeader className="p-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm">
                Version {selectedSnapshot.version} — Approved{' '}
                {new Date(selectedSnapshot.snappedAt).toLocaleString()}
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setSelectedSnapshot(null)}
              >
                <ArrowLeft className="h-3.5 w-3.5 mr-1" />
                Back
              </Button>
            </div>
          </CardHeader>
          <CardContent className="p-3 pt-0">
            <div className="rounded-md border bg-muted/30 p-2 mb-2">
              <p className="text-xs text-muted-foreground">
                Read-only replay — this shows the exact state at the time of approval
              </p>
            </div>
            <DashboardGrid
              dashId={dashId}
              isEditing={false}
              readOnly={true}
            />
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Select a snapshot from the timeline to replay
          </CardContent>
        </Card>
      )}
    </div>
  );
}

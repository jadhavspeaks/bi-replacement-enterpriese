'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { StatCard } from '@nexusbi/ui-components';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Gauge, AlertTriangle, ArrowRight } from 'lucide-react';
import type { PerfScorecard as PerfScorecardType } from '@nexusbi/shared-types';

interface PerfScorecardProps {
  dashId: string;
}

function getBarColor(p95: number): string {
  if (p95 <= 500) return '#22c55e';
  if (p95 <= 1000) return '#f59e0b';
  if (p95 <= 2000) return '#f97316';
  return '#ef4444';
}

export function PerfScorecard({ dashId }: PerfScorecardProps) {
  const router = useRouter();
  const [scorecard, setScorecard] = useState<PerfScorecardType | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/perf`);
        const data = await response.json();
        if (data.success) setScorecard(data.data);
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  if (loading) {
    return (
      <div className="space-y-4">
        <div className="grid grid-cols-3 gap-4">
          {Array.from({ length: 3 }).map((_, i) => <Skeleton key={i} className="h-24" />)}
        </div>
        <Skeleton className="h-64" />
      </div>
    );
  }

  if (!scorecard || scorecard.widgets.length === 0) {
    return (
      <Card>
        <CardContent className="py-12 text-center">
          <Gauge className="mx-auto h-12 w-12 text-muted-foreground mb-3" />
          <h3 className="text-lg font-semibold">No Performance Data</h3>
          <p className="text-sm text-muted-foreground mt-1">
            Performance metrics are collected as users view the dashboard.
          </p>
        </CardContent>
      </Card>
    );
  }

  const chartData = scorecard.widgets.map((w) => ({
    name: w.widgetTitle.length > 20 ? w.widgetTitle.substring(0, 20) + '...' : w.widgetTitle,
    p50: w.p50LoadMs,
    p95: w.p95LoadMs,
    p99: w.p99LoadMs,
    samples: w.sampleCount,
  }));

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <StatCard
          title="Overall P50"
          value={`${scorecard.overallP50Ms}ms`}
          trendDirection="down-good"
        />
        <StatCard
          title="Overall P95"
          value={`${scorecard.overallP95Ms}ms`}
          trendDirection="down-good"
        />
        <StatCard
          title="Pre-Agg Coverage"
          value={`${scorecard.preaggCoveragePct}%`}
          trendDirection="up-good"
        />
      </div>

      <Card>
        <CardHeader className="p-4">
          <CardTitle className="text-base">Widget Load Times (P95)</CardTitle>
        </CardHeader>
        <CardContent className="p-4 pt-0">
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData} layout="vertical" margin={{ left: 20, right: 20, top: 5, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} />
                <XAxis type="number" unit="ms" fontSize={11} />
                <YAxis dataKey="name" type="category" width={150} fontSize={11} />
                <Tooltip
                  formatter={(value: number) => [`${value}ms`]}
                  contentStyle={{ fontSize: 12 }}
                />
                <Bar dataKey="p95" radius={[0, 4, 4, 0]}>
                  {chartData.map((entry, index) => (
                    <Cell key={index} fill={getBarColor(entry.p95)} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>

          <div className="flex items-center gap-4 mt-3 text-xs text-muted-foreground">
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-green-500" />{'<'}500ms</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-amber-500" />500-1000ms</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-orange-500" />1-2s</span>
            <span className="flex items-center gap-1"><span className="h-2 w-2 rounded-full bg-red-500" />{'>'}2s</span>
          </div>
        </CardContent>
      </Card>

      {scorecard.recommendations.length > 0 && (
        <Card>
          <CardHeader className="p-4">
            <CardTitle className="text-base flex items-center gap-2">
              <AlertTriangle className="h-4 w-4 text-amber-500" />
              Recommendations ({scorecard.recommendations.length})
            </CardTitle>
          </CardHeader>
          <CardContent className="p-4 pt-0 space-y-3">
            {scorecard.recommendations.map((rec, i) => (
              <div key={i} className="rounded-md border p-3">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="text-sm font-medium">{rec.widgetTitle}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{rec.reason}</p>
                    <p className="text-xs text-nexus-600 mt-1">{rec.suggestedAction}</p>
                    {rec.estimatedImprovement && (
                      <Badge variant="outline" className="mt-1 text-xs bg-green-50 text-green-700 border-green-200">
                        Estimated: {rec.estimatedImprovement}
                      </Badge>
                    )}
                  </div>
                  {rec.preaggRecId && (
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => router.push('/admin/preagg')}
                    >
                      <ArrowRight className="h-3.5 w-3.5 mr-1" />
                      Apply
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      )}
    </div>
  );
}

'use client';

import { useEffect, useState, useRef } from 'react';
import * as Y from 'yjs';
import { WebsocketProvider } from 'y-websocket';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { useUserStore } from '@/store/user.store';

interface CollaboratorPresenceProps {
  dashId: string;
}

interface AwarenessUser {
  name: string;
  color: string;
  clientId: number;
}

const COLORS = [
  '#ef4444', '#f59e0b', '#22c55e', '#3b82f6', '#8b5cf6',
  '#ec4899', '#06b6d4', '#f97316', '#14b8a6', '#6366f1',
];

export function CollaboratorPresence({ dashId }: CollaboratorPresenceProps) {
  const user = useUserStore((s) => s.user);
  const [collaborators, setCollaborators] = useState<AwarenessUser[]>([]);
  const providerRef = useRef<WebsocketProvider | null>(null);
  const docRef = useRef<Y.Doc | null>(null);

  useEffect(() => {
    if (!user) return;

    const wsUrl = process.env.NEXT_PUBLIC_YJS_WS_URL;
    if (!wsUrl) return; // Yjs collaboration disabled — no WS URL configured

    const doc = new Y.Doc();
    docRef.current = doc;

    let provider: WebsocketProvider;
    try {
      provider = new WebsocketProvider(wsUrl, `dashboard-${dashId}`, doc, {
        connect: true,
        maxBackoffTime: 10000,
      });
    } catch {
      doc.destroy();
      return;
    }
    providerRef.current = provider;

    const colorIndex = Math.abs(user.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0)) % COLORS.length;

    provider.awareness.setLocalStateField('user', {
      name: user.displayName,
      color: COLORS[colorIndex],
    });

    const handleAwarenessChange = () => {
      const states = provider.awareness.getStates();
      const users: AwarenessUser[] = [];

      states.forEach((state, clientId) => {
        if (state.user && clientId !== provider.awareness.clientID) {
          users.push({
            name: state.user.name,
            color: state.user.color,
            clientId,
          });
        }
      });

      setCollaborators(users);
    };

    provider.awareness.on('change', handleAwarenessChange);
    handleAwarenessChange();

    return () => {
      provider.awareness.off('change', handleAwarenessChange);
      provider.destroy();
      doc.destroy();
    };
  }, [dashId, user]);

  if (collaborators.length === 0) return null;

  return (
    <TooltipProvider>
      <div className="flex items-center gap-1">
        <span className="text-xs text-muted-foreground mr-1">
          {collaborators.length} online
        </span>
        {collaborators.slice(0, 5).map((collab) => {
          const initials = collab.name
            .split(' ')
            .map((n) => n[0])
            .join('')
            .substring(0, 2)
            .toUpperCase();

          return (
            <Tooltip key={collab.clientId}>
              <TooltipTrigger>
                <Avatar className="h-7 w-7 border-2" style={{ borderColor: collab.color }}>
                  <AvatarFallback
                    className="text-[10px] text-white"
                    style={{ backgroundColor: collab.color }}
                  >
                    {initials}
                  </AvatarFallback>
                </Avatar>
              </TooltipTrigger>
              <TooltipContent>
                <p className="text-xs">{collab.name}</p>
              </TooltipContent>
            </Tooltip>
          );
        })}
        {collaborators.length > 5 && (
          <span className="text-xs text-muted-foreground">
            +{collaborators.length - 5}
          </span>
        )}
      </div>
    </TooltipProvider>
  );
}

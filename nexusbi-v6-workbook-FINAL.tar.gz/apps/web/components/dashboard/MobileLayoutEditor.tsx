'use client';

import { useState, useCallback, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { DashboardGrid } from './DashboardGrid';
import { useDashboardStore } from '@/store/dashboard.store';
import { Loader2, Save, Smartphone } from 'lucide-react';
import type { MobileLayout, WidgetConfig, LayoutConfig } from '@nexusbi/shared-types';

interface MobileLayoutEditorProps {
  dashId: string;
}

export function MobileLayoutEditor({ dashId }: MobileLayoutEditorProps) {
  const [mobileLayout, setMobileLayout] = useState<MobileLayout | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const widgets = useDashboardStore((s) => s.widgets);
  const layout = useDashboardStore((s) => s.layout);

  useEffect(() => {
    async function load() {
      try {
        const response = await fetch(`/api/dashboards/${dashId}/mobile`);
        const data = await response.json();
        if (data.success && data.data) {
          setMobileLayout(data.data);
        }
      } catch {
        // handle error
      }
      setLoading(false);
    }
    load();
  }, [dashId]);

  const generateMobileLayout = useCallback(() => {
    // Stack all widgets vertically in a single column
    const mobileWidgets: WidgetConfig[] = widgets.map((widget, index) => ({
      ...widget,
      position: {
        ...widget.position,
        x: 0,
        y: index * 4,
        w: 1,
        h: widget.widgetType === 'kpi' ? 3 : widget.widgetType === 'text' ? 2 : 5,
      },
    }));

    const mobileLayoutConfig: LayoutConfig = {
      cols: 1,
      rowHeight: 60,
      margin: [8, 8],
      containerPadding: [8, 8],
      compactType: 'vertical',
    };

    return { widgets: mobileWidgets, layout: mobileLayoutConfig };
  }, [widgets]);

  const handleSave = useCallback(async () => {
    setSaving(true);
    try {
      const mobile = mobileLayout
        ? { layoutJson: mobileLayout.layoutJson, widgetsJson: mobileLayout.widgetsJson }
        : generateMobileLayout();

      const response = await fetch(`/api/dashboards/${dashId}/mobile`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          layoutJson: mobile.layoutJson || mobile.layout,
          widgetsJson: mobile.widgetsJson || mobile.widgets,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        // Refresh mobile layout
        const refreshResponse = await fetch(`/api/dashboards/${dashId}/mobile`);
        const refreshData = await refreshResponse.json();
        if (refreshData.success && refreshData.data) {
          setMobileLayout(refreshData.data);
        }
      }
    } catch {
      // handle error
    }
    setSaving(false);
  }, [dashId, mobileLayout, generateMobileLayout]);

  const handleAutoGenerate = useCallback(() => {
    const { widgets: mobileWidgets, layout: mobileLayoutConfig } = generateMobileLayout();
    setMobileLayout({
      layoutId: '',
      dashId,
      layoutJson: mobileLayoutConfig,
      widgetsJson: mobileWidgets,
      lastEditedBy: null,
      updatedAt: new Date().toISOString(),
      orgId: '',
    });
  }, [dashId, generateMobileLayout]);

  if (loading) {
    return <Skeleton className="h-96 w-full" />;
  }

  return (
    <Card>
      <CardHeader className="p-4">
        <div className="flex items-center justify-between">
          <CardTitle className="text-base flex items-center gap-2">
            <Smartphone className="h-4 w-4" />
            Mobile Layout Editor
          </CardTitle>
          <div className="flex items-center gap-2">
            <Button variant="outline" size="sm" onClick={handleAutoGenerate}>
              Auto-Generate
            </Button>
            <Button size="sm" onClick={handleSave} disabled={saving}>
              {saving ? (
                <><Loader2 className="h-3.5 w-3.5 mr-1 animate-spin" />Saving...</>
              ) : (
                <><Save className="h-3.5 w-3.5 mr-1" />Save Mobile Layout</>
              )}
            </Button>
          </div>
        </div>
      </CardHeader>
      <CardContent className="p-4 pt-0">
        <div className="mx-auto max-w-[375px] rounded-xl border-4 border-zinc-800 bg-white p-2 shadow-xl">
          <div className="h-6 flex items-center justify-center mb-2">
            <div className="h-1.5 w-16 rounded-full bg-zinc-300" />
          </div>
          <div className="min-h-[600px] overflow-y-auto">
            {mobileLayout ? (
              <DashboardGrid
                dashId={dashId}
                isEditing={true}
                mobileLayout={mobileLayout}
              />
            ) : (
              <div className="flex h-64 items-center justify-center text-sm text-muted-foreground">
                <p>Click "Auto-Generate" to create a mobile layout from the desktop version</p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

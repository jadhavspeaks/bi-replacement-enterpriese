'use client';

import { useForm, FormProvider } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2 } from 'lucide-react';
import { DATA_SOURCE_TYPES, DS_TYPE_LABELS, type DataSourceType } from '@nexusbi/shared-types';

import { PostgresForm } from './forms/PostgresForm';
import { OracleForm } from './forms/OracleForm';
import { HiveForm } from './forms/HiveForm';
import { SnowflakeForm } from './forms/SnowflakeForm';
import { BigQueryForm } from './forms/BigQueryForm';
import { DatabricksForm } from './forms/DatabricksForm';
import { AthenaForm } from './forms/AthenaForm';
import { ClickHouseForm } from './forms/ClickHouseForm';
import { MongoDBForm } from './forms/MongoDBForm';
import { PrestoTrinoForm } from './forms/PrestoTrinoForm';
import { SQLiteForm } from './forms/SQLiteForm';
import { DuckDBForm } from './forms/DuckDBForm';
import { FileUploadForm } from './forms/FileUploadForm';
import { ApiRestForm } from './forms/ApiRestForm';
import { ApiGraphqlForm } from './forms/ApiGraphqlForm';
import { ApiWebhookForm } from './forms/ApiWebhookForm';

interface DataSourceFormProps {
  onSubmit: (data: { dsName: string; dsType: DataSourceType; description: string; config: Record<string, unknown> }) => Promise<void>;
  defaultValues?: {
    dsName?: string;
    dsType?: DataSourceType;
    description?: string;
    config?: Record<string, unknown>;
  };
  loading?: boolean;
  submitLabel?: string;
}

const baseSchema = z.object({
  dsName: z.string().min(1, 'Name is required').max(200),
  dsType: z.string().min(1, 'Type is required'),
  description: z.string().max(2000).optional(),
  config: z.record(z.unknown()).optional(),
});

function renderConnectorForm(dsType: DataSourceType) {
  switch (dsType) {
    case 'postgres':
    case 'mysql':
    case 'mssql':
    case 'redshift':
      return <PostgresForm dsType={dsType} />;
    case 'oracle':
      return <OracleForm />;
    case 'hive':
    case 'sparksql':
    case 'impala':
      return <HiveForm dsType={dsType} />;
    case 'snowflake':
      return <SnowflakeForm />;
    case 'bigquery':
      return <BigQueryForm />;
    case 'databricks':
      return <DatabricksForm />;
    case 'athena':
      return <AthenaForm />;
    case 'clickhouse':
      return <ClickHouseForm />;
    case 'mongodb':
      return <MongoDBForm />;
    case 'presto':
    case 'trino':
      return <PrestoTrinoForm dsType={dsType} />;
    case 'sqlite':
      return <SQLiteForm />;
    case 'duckdb':
      return <DuckDBForm />;
    case 'file_csv':
    case 'file_excel':
    case 'file_parquet':
    case 'file_json':
      return <FileUploadForm dsType={dsType} />;
    case 'api_rest':
    case 'api_oauth_rest':
      return <ApiRestForm />;
    case 'api_graphql':
      return <ApiGraphqlForm />;
    case 'api_webhook':
      return <ApiWebhookForm />;
    default:
      return <p className="text-sm text-muted-foreground">No configuration form available for this type.</p>;
  }
}

const DS_TYPE_CATEGORIES: Record<string, DataSourceType[]> = {
  'Relational Databases': ['postgres', 'mysql', 'mssql', 'oracle', 'sqlite'],
  'Cloud Data Warehouses': ['snowflake', 'bigquery', 'redshift', 'databricks', 'athena'],
  'Big Data / Query Engines': ['hive', 'sparksql', 'impala', 'presto', 'trino', 'clickhouse'],
  'NoSQL / Embedded': ['mongodb', 'duckdb'],
  'File Upload': ['file_csv', 'file_excel', 'file_parquet', 'file_json'],
  'API Sources': ['api_rest', 'api_graphql', 'api_webhook', 'api_oauth_rest'],
};

export function DataSourceForm({ onSubmit, defaultValues, loading, submitLabel = 'Create Data Source' }: DataSourceFormProps) {
  const methods = useForm({
    resolver: zodResolver(baseSchema),
    defaultValues: {
      dsName: defaultValues?.dsName || '',
      dsType: defaultValues?.dsType || '',
      description: defaultValues?.description || '',
      config: defaultValues?.config || {},
    },
  });

  const { register, setValue, watch, handleSubmit, formState: { errors } } = methods;
  const dsType = watch('dsType') as DataSourceType;

  const onFormSubmit = handleSubmit(async (data) => {
    await onSubmit({
      dsName: data.dsName,
      dsType: data.dsType as DataSourceType,
      description: data.description || '',
      config: data.config || {},
    });
  });

  return (
    <FormProvider {...methods}>
      <form onSubmit={onFormSubmit} className="space-y-6">
        <div className="space-y-2">
          <Label htmlFor="dsName">Data Source Name</Label>
          <Input
            id="dsName"
            placeholder="My Data Source"
            {...register('dsName')}
          />
          {errors.dsName && (
            <p className="text-xs text-destructive">{errors.dsName.message as string}</p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="dsType">Connector Type</Label>
          <Select
            value={dsType || ''}
            onValueChange={(value) => {
              setValue('dsType', value);
              setValue('config', {});
            }}
          >
            <SelectTrigger>
              <SelectValue placeholder="Select a connector type..." />
            </SelectTrigger>
            <SelectContent className="max-h-80">
              {Object.entries(DS_TYPE_CATEGORIES).map(([category, types]) => (
                <div key={category}>
                  <div className="px-2 py-1.5 text-xs font-semibold text-muted-foreground">
                    {category}
                  </div>
                  {types.map((type) => (
                    <SelectItem key={type} value={type}>
                      {DS_TYPE_LABELS[type]}
                    </SelectItem>
                  ))}
                </div>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-2">
          <Label htmlFor="description">Description (optional)</Label>
          <Textarea
            id="description"
            placeholder="Describe this data source..."
            rows={2}
            {...register('description')}
          />
        </div>

        {dsType && (
          <div className="rounded-md border p-4">
            <h3 className="text-sm font-semibold mb-4">
              {DS_TYPE_LABELS[dsType]} Configuration
            </h3>
            {renderConnectorForm(dsType)}
          </div>
        )}

        <Button type="submit" disabled={loading || !dsType} className="w-full">
          {loading ? (
            <>
              <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              Creating...
            </>
          ) : (
            submitLabel
          )}
        </Button>
      </form>
    </FormProvider>
  );
}

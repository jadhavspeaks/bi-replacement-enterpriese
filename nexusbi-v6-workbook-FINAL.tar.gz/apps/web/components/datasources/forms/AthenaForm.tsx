'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function AthenaForm() {
  const { register } = useFormContext();

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.accessKeyId">AWS Access Key ID</Label>
          <Input
            id="config.accessKeyId"
            placeholder="AKIAIOSFODNN7EXAMPLE"
            {...register('config.accessKeyId', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.secretAccessKey">AWS Secret Access Key</Label>
          <Input
            id="config.secretAccessKey"
            type="password"
            placeholder="••••••••"
            {...register('config.secretAccessKey', { required: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.region">AWS Region</Label>
        <Input
          id="config.region"
          placeholder="us-east-1"
          {...register('config.region', { required: true })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.s3OutputLocation">S3 Output Location</Label>
        <Input
          id="config.s3OutputLocation"
          placeholder="s3://my-athena-results/output/"
          {...register('config.s3OutputLocation', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          S3 bucket path for query results
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.workgroup">Workgroup</Label>
          <Input
            id="config.workgroup"
            placeholder="primary"
            defaultValue="primary"
            {...register('config.workgroup')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.catalog">Catalog</Label>
          <Input
            id="config.catalog"
            placeholder="AwsDataCatalog"
            defaultValue="AwsDataCatalog"
            {...register('config.catalog')}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.database">Database (optional)</Label>
        <Input
          id="config.database"
          placeholder="default"
          {...register('config.database')}
        />
      </div>
    </div>
  );
}

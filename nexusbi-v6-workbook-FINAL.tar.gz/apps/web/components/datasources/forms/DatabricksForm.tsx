'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function DatabricksForm() {
  const { register } = useFormContext();

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.url">Workspace URL</Label>
        <Input
          id="config.url"
          placeholder="https://dbc-xxxxxxxx-xxxx.cloud.databricks.com"
          {...register('config.url', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          Your Databricks workspace URL (e.g., https://dbc-xxxxx.cloud.databricks.com)
        </p>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.token">Personal Access Token</Label>
        <Input
          id="config.token"
          type="password"
          placeholder="dapi-xxxxxxxxxxxxxxxxxxxx"
          {...register('config.token', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          Generate from User Settings → Developer → Access Tokens
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.catalog">Catalog (optional)</Label>
          <Input
            id="config.catalog"
            placeholder="main"
            {...register('config.catalog')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.schema">Schema (optional)</Label>
          <Input
            id="config.schema"
            placeholder="default"
            {...register('config.schema')}
          />
        </div>
      </div>
    </div>
  );
}

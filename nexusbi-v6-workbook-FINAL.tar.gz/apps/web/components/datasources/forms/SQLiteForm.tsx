'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';

export function SQLiteForm() {
  const { register, setValue, watch } = useFormContext();
  const readOnly = watch('config.readOnly');

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.databasePath">Database File Path</Label>
        <Input
          id="config.databasePath"
          placeholder="/data/mydb.sqlite"
          {...register('config.databasePath', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          Absolute path to the SQLite database file on the server
        </p>
      </div>

      <div className="flex items-center gap-3">
        <Switch
          id="config.readOnly"
          checked={readOnly || false}
          onCheckedChange={(checked) => setValue('config.readOnly', checked)}
        />
        <Label htmlFor="config.readOnly">Read-only mode</Label>
      </div>
    </div>
  );
}

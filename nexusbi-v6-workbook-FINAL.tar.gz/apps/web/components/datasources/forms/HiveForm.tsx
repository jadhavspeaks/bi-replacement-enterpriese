'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import type { DataSourceType } from '@nexusbi/shared-types';

interface HiveFormProps {
  dsType: DataSourceType;
}

const PORT_DEFAULTS: Record<string, number> = {
  hive: 10000,
  sparksql: 10000,
  impala: 21050,
};

const TYPE_LABELS: Record<string, string> = {
  hive: 'Apache Hive',
  sparksql: 'Spark SQL',
  impala: 'Apache Impala',
};

export function HiveForm({ dsType }: HiveFormProps) {
  const { register, setValue, watch } = useFormContext();
  const authMechanism = watch('config.authMechanism') || 'NOSASL';
  const ssl = watch('config.ssl');

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Configure {TYPE_LABELS[dsType] || dsType} connection
      </p>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">Host</Label>
          <Input
            id="config.host"
            placeholder="hive-server"
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder={String(PORT_DEFAULTS[dsType] || 10000)}
            defaultValue={PORT_DEFAULTS[dsType] || 10000}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.database">Database</Label>
        <Input
          id="config.database"
          placeholder="default"
          defaultValue="default"
          {...register('config.database')}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.username">Username (optional)</Label>
        <Input
          id="config.username"
          placeholder="hiveuser"
          {...register('config.username')}
        />
      </div>

      <div className="space-y-2">
        <Label>Authentication Mechanism</Label>
        <Select
          value={authMechanism}
          onValueChange={(value) => setValue('config.authMechanism', value)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="NOSASL">No Authentication (NOSASL)</SelectItem>
            <SelectItem value="PLAIN">Username/Password (PLAIN)</SelectItem>
            <SelectItem value="KERBEROS">Kerberos</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {authMechanism === 'KERBEROS' && (
        <div className="space-y-4 rounded-md border p-4">
          <div className="space-y-2">
            <Label htmlFor="config.kerberosPrincipal">Kerberos Principal</Label>
            <Input
              id="config.kerberosPrincipal"
              placeholder="hive/host@REALM.COM"
              {...register('config.kerberosPrincipal', { required: authMechanism === 'KERBEROS' })}
            />
          </div>
          <div className="space-y-2">
            <Label htmlFor="config.kerberosKeytab">Keytab Path (optional)</Label>
            <Input
              id="config.kerberosKeytab"
              placeholder="/etc/security/keytabs/hive.keytab"
              {...register('config.kerberosKeytab')}
            />
          </div>
        </div>
      )}

      {dsType === 'impala' && (
        <div className="flex items-center gap-3">
          <Switch
            id="config.ssl"
            checked={ssl || false}
            onCheckedChange={(checked) => setValue('config.ssl', checked)}
          />
          <Label htmlFor="config.ssl">Use SSL</Label>
        </div>
      )}
    </div>
  );
}

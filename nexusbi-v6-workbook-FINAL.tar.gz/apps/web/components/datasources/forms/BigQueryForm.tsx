'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';

export function BigQueryForm() {
  const { register } = useFormContext();

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.projectId">Project ID</Label>
        <Input
          id="config.projectId"
          placeholder="my-gcp-project-123"
          {...register('config.projectId', { required: true })}
        />
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.credentials">Service Account JSON</Label>
        <Textarea
          id="config.credentials"
          placeholder='Paste your service account JSON key here...'
          rows={8}
          className="font-mono text-xs"
          {...register('config.credentials', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          Paste the full JSON key file from your GCP service account. It will be encrypted at rest.
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.location">Location</Label>
          <Input
            id="config.location"
            placeholder="US"
            defaultValue="US"
            {...register('config.location')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.dataset">Default Dataset (optional)</Label>
          <Input
            id="config.dataset"
            placeholder="my_dataset"
            {...register('config.dataset')}
          />
        </div>
      </div>
    </div>
  );
}

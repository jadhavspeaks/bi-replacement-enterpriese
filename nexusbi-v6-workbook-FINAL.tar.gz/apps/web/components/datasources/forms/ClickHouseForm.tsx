'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

export function ClickHouseForm() {
  const { register, setValue, watch } = useFormContext();
  const ssl = watch('config.ssl');
  const protocol = watch('config.protocol') || 'http';

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">Host</Label>
          <Input
            id="config.host"
            placeholder="clickhouse-server"
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder="8123"
            defaultValue={8123}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.database">Database</Label>
        <Input
          id="config.database"
          placeholder="default"
          {...register('config.database', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.username">Username</Label>
          <Input
            id="config.username"
            placeholder="default"
            defaultValue="default"
            {...register('config.username')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.password">Password (optional)</Label>
          <Input
            id="config.password"
            type="password"
            placeholder="••••••••"
            {...register('config.password')}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Protocol</Label>
        <Select
          value={protocol}
          onValueChange={(value) => setValue('config.protocol', value)}
        >
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="http">HTTP</SelectItem>
            <SelectItem value="native">Native (TCP)</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center gap-3">
        <Switch
          id="config.ssl"
          checked={ssl || false}
          onCheckedChange={(checked) => setValue('config.ssl', checked)}
        />
        <Label htmlFor="config.ssl">Use SSL</Label>
      </div>
    </div>
  );
}

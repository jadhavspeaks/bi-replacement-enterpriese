'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import type { DataSourceType } from '@nexusbi/shared-types';

interface PostgresFormProps {
  dsType: DataSourceType;
}

const DEFAULTS: Record<string, { port: number; schema: string }> = {
  postgres: { port: 5432, schema: 'public' },
  mysql: { port: 3306, schema: '' },
  mssql: { port: 1433, schema: 'dbo' },
  redshift: { port: 5439, schema: 'public' },
};

export function PostgresForm({ dsType }: PostgresFormProps) {
  const { register, setValue, watch } = useFormContext();
  const defaults = DEFAULTS[dsType] || DEFAULTS.postgres;
  const ssl = watch('config.ssl');

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">Host</Label>
          <Input
            id="config.host"
            placeholder="localhost"
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder={String(defaults.port)}
            defaultValue={defaults.port}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.database">Database</Label>
        <Input
          id="config.database"
          placeholder="mydb"
          {...register('config.database', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.user">Username</Label>
          <Input
            id="config.user"
            placeholder="dbuser"
            {...register('config.user', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.password">Password</Label>
          <Input
            id="config.password"
            type="password"
            placeholder="••••••••"
            {...register('config.password', { required: true })}
          />
        </div>
      </div>

      {defaults.schema && (
        <div className="space-y-2">
          <Label htmlFor="config.schema">Schema</Label>
          <Input
            id="config.schema"
            placeholder={defaults.schema}
            defaultValue={defaults.schema}
            {...register('config.schema')}
          />
        </div>
      )}

      <div className="flex items-center gap-3">
        <Switch
          id="config.ssl"
          checked={ssl || false}
          onCheckedChange={(checked) => setValue('config.ssl', checked)}
        />
        <Label htmlFor="config.ssl">Use SSL</Label>
      </div>

      {ssl && dsType !== 'mysql' && (
        <div className="space-y-4 rounded-md border p-4">
          <div className="space-y-2">
            <Label htmlFor="config.sslCa">SSL CA Certificate (optional)</Label>
            <Input
              id="config.sslCa"
              placeholder="Paste CA certificate..."
              {...register('config.sslCa')}
            />
          </div>
          {dsType === 'postgres' && (
            <>
              <div className="space-y-2">
                <Label htmlFor="config.sslCert">SSL Client Certificate (optional)</Label>
                <Input
                  id="config.sslCert"
                  {...register('config.sslCert')}
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="config.sslKey">SSL Client Key (optional)</Label>
                <Input
                  id="config.sslKey"
                  type="password"
                  {...register('config.sslKey')}
                />
              </div>
            </>
          )}
        </div>
      )}

      {dsType === 'mssql' && (
        <>
          <div className="flex items-center gap-3">
            <Switch
              id="config.encrypt"
              checked={watch('config.encrypt') ?? true}
              onCheckedChange={(checked) => setValue('config.encrypt', checked)}
            />
            <Label htmlFor="config.encrypt">Encrypt connection</Label>
          </div>
          <div className="space-y-2">
            <Label htmlFor="config.domain">Domain (optional, for Windows Auth)</Label>
            <Input
              id="config.domain"
              placeholder="MYDOMAIN"
              {...register('config.domain')}
            />
          </div>
        </>
      )}
    </div>
  );
}

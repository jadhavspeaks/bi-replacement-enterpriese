'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import type { DataSourceType } from '@nexusbi/shared-types';

interface PrestoTrinoFormProps {
  dsType: DataSourceType;
}

export function PrestoTrinoForm({ dsType }: PrestoTrinoFormProps) {
  const { register, setValue, watch } = useFormContext();
  const ssl = watch('config.ssl');
  const label = dsType === 'trino' ? 'Trino' : 'Presto';

  return (
    <div className="space-y-4">
      <p className="text-sm text-muted-foreground">
        Configure {label} connection
      </p>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.host">Host</Label>
          <Input
            id="config.host"
            placeholder={`${label.toLowerCase()}-coordinator`}
            {...register('config.host', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.port">Port</Label>
          <Input
            id="config.port"
            type="number"
            placeholder="8080"
            defaultValue={8080}
            {...register('config.port', { required: true, valueAsNumber: true })}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.catalog">Catalog</Label>
          <Input
            id="config.catalog"
            placeholder="hive"
            {...register('config.catalog', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.schema">Schema</Label>
          <Input
            id="config.schema"
            placeholder="default"
            defaultValue="default"
            {...register('config.schema')}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.user">User (optional)</Label>
        <Input
          id="config.user"
          placeholder={`${label.toLowerCase()}-user`}
          {...register('config.user')}
        />
      </div>

      <div className="flex items-center gap-3">
        <Switch
          id="config.ssl"
          checked={ssl || false}
          onCheckedChange={(checked) => setValue('config.ssl', checked)}
        />
        <Label htmlFor="config.ssl">Use SSL</Label>
      </div>
    </div>
  );
}

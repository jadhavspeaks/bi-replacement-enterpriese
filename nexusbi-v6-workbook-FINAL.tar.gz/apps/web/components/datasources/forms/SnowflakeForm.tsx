'use client';

import { useFormContext } from 'react-hook-form';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

export function SnowflakeForm() {
  const { register } = useFormContext();

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <Label htmlFor="config.account">Account Identifier</Label>
        <Input
          id="config.account"
          placeholder="xy12345.us-east-1"
          {...register('config.account', { required: true })}
        />
        <p className="text-xs text-muted-foreground">
          Your Snowflake account identifier (e.g., xy12345.us-east-1)
        </p>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.username">Username</Label>
          <Input
            id="config.username"
            placeholder="snowuser"
            {...register('config.username', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.password">Password</Label>
          <Input
            id="config.password"
            type="password"
            placeholder="••••••••"
            {...register('config.password', { required: true })}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label htmlFor="config.warehouse">Warehouse</Label>
        <Input
          id="config.warehouse"
          placeholder="COMPUTE_WH"
          {...register('config.warehouse', { required: true })}
        />
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.database">Database</Label>
          <Input
            id="config.database"
            placeholder="MY_DB"
            {...register('config.database', { required: true })}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.schema">Schema</Label>
          <Input
            id="config.schema"
            placeholder="PUBLIC"
            defaultValue="PUBLIC"
            {...register('config.schema')}
          />
        </div>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="config.role">Role (optional)</Label>
          <Input
            id="config.role"
            placeholder="SYSADMIN"
            {...register('config.role')}
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="config.region">Region (optional)</Label>
          <Input
            id="config.region"
            placeholder="us-east-1"
            {...register('config.region')}
          />
        </div>
      </div>
    </div>
  );
}

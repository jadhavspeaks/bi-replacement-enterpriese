'use client';

import { useFormContext } from 'react-hook-form';

/**
 * Oracle Staging form (replaces the removed DuckDB form).
 * The duckdb data-source type is preserved for backward compatibility
 * but its config schema has been swapped for OracleStagingConfigSchema —
 * file/API-source data is now staged into Oracle tables (NB_STG_*).
 *
 * Component name kept as DuckDBForm so existing imports in DataSourceForm
 * continue to resolve.
 */
export function DuckDBForm() {
  const { register } = useFormContext();

  return (
    <div className="space-y-4">
      <div className="rounded-md border border-amber-200 bg-amber-50 p-3 text-xs text-amber-900">
        <strong>Oracle staging:</strong> file uploads (CSV / Excel / JSON / Parquet)
        and API source polls now create tables in your Oracle database with the
        prefix <code className="font-mono">NB_STG_</code>. No DuckDB is required.
      </div>

      <div className="space-y-2">
        <label htmlFor="config.stagingPrefix" className="block text-sm font-medium">
          Staging Table Prefix
        </label>
        <input
          id="config.stagingPrefix"
          type="text"
          defaultValue="NB_STG"
          placeholder="NB_STG"
          className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
          {...register('config.stagingPrefix')}
        />
        <p className="text-xs text-gray-500">
          Tables will be named <code className="font-mono">&lt;prefix&gt;_&lt;sanitized_id&gt;</code> (default: NB_STG).
        </p>
      </div>

      <div className="space-y-2">
        <label htmlFor="config.schemaName" className="block text-sm font-medium">
          Schema Name (optional)
        </label>
        <input
          id="config.schemaName"
          type="text"
          placeholder="Leave empty to use ORACLE_USER's default schema"
          className="w-full rounded-md border border-gray-300 px-3 py-2 text-sm"
          {...register('config.schemaName')}
        />
        <p className="text-xs text-gray-500">
          Override the default schema where staging tables are created.
        </p>
      </div>
    </div>
  );
}

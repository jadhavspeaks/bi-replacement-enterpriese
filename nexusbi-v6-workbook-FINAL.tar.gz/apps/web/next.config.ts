import type { NextConfig } from 'next';

const nextConfig: NextConfig = {
  reactStrictMode: true,
  transpilePackages: [
    '@nexusbi/shared-types',
    '@nexusbi/cube-schema',
    '@nexusbi/ui-components',
  ],
  experimental: {
    serverComponentsExternalPackages: [
      'oracledb',
      'duckdb',
      'puppeteer',
      'nodemailer',
      'minio',
      'adm-zip',
      'bcryptjs',
    ],
  },
  async rewrites() {
    return [
      {
        source: '/cubejs-api/:path*',
        destination: 'http://cube:4000/cubejs-api/:path*',
      },
    ];
  },
  async headers() {
    return [
      {
        source: '/api/:path*',
        headers: [
          { key: 'X-Content-Type-Options', value: 'nosniff' },
          { key: 'X-Frame-Options', value: 'DENY' },
          { key: 'X-XSS-Protection', value: '1; mode=block' },
          { key: 'Referrer-Policy', value: 'strict-origin-when-cross-origin' },
        ],
      },
    ];
  },
  output: 'standalone',
};

export default nextConfig;

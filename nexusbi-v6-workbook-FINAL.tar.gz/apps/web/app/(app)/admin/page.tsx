'use client';

import { useRouter } from 'next/navigation';
import { PageHeader } from '@nexusbi/ui-components';
import { Card, CardContent } from '@/components/ui/card';
import { PermissionGate } from '@/components/shared/PermissionGate';
import { Shield, Users, Settings, ScrollText, Gauge, Webhook, Timer } from 'lucide-react';

const ADMIN_SECTIONS = [
  { title: 'Roles & Permissions', description: 'Manage roles and their permission assignments', icon: Shield, href: '/admin/roles', permission: 'admin.roles' as const },
  { title: 'User Management', description: 'Create users, assign roles, manage access', icon: Users, href: '/admin/users', permission: 'admin.users' as const },
  { title: 'Platform Configuration', description: 'SMTP, integrations, and system settings', icon: Settings, href: '/admin/platform', permission: 'admin.platform' as const },
  { title: 'Audit Log', description: 'View all platform activity and changes', icon: ScrollText, href: '/admin/audit', permission: 'audit.view' as const },
  { title: 'Pre-Aggregations', description: 'Performance recommendations and smart refresh', icon: Gauge, href: '/admin/preagg', permission: 'preagg.manage' as const },
  { title: 'Outbound Webhooks', description: 'Configure webhook endpoints and delivery', icon: Webhook, href: '/admin/webhooks', permission: 'webhook.manage' as const },
  { title: 'Timed Access', description: 'Time-bounded access grants for resources', icon: Timer, href: '/admin/timed-access', permission: 'admin.platform' as const },
];

export default function AdminPage() {
  const router = useRouter();

  return (
    <div>
      <PageHeader
        title="Administration"
        description="Platform management and configuration."
      />

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {ADMIN_SECTIONS.map((section) => (
          <PermissionGate key={section.href} permission={section.permission}>
            <Card
              className="cursor-pointer transition-all hover:shadow-md hover:border-nexus-300"
              onClick={() => router.push(section.href)}
            >
              <CardContent className="p-5">
                <div className="flex items-start gap-4">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-nexus-50">
                    <section.icon className="h-5 w-5 text-nexus-600" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-sm">{section.title}</h3>
                    <p className="text-xs text-muted-foreground mt-1">{section.description}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </PermissionGate>
        ))}
      </div>
    </div>
  );
}

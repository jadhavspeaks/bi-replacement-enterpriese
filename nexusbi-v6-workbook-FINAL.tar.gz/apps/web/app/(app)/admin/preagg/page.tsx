import { PageHeader } from '@nexusbi/ui-components';
import { PreAggManager } from '@/components/admin/PreAggManager';

export default function PreAggPage() {
  return (
    <div>
      <PageHeader
        title="Pre-Aggregations & Smart Refresh"
        description="View performance recommendations, smart refresh cron suggestions, and apply pre-aggregations to cube schemas."
        breadcrumbs={[
          { label: 'Admin', href: '/admin' },
          { label: 'Pre-Aggregations' },
        ]}
      />
      <PreAggManager />
    </div>
  );
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { getSnapshot } from '@/lib/approval-replay';
import type { ApiResponse, ApprovalSnapshot } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string; snapshotId: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.replay');
  if (denied) return denied;

  const { snapshotId } = await params;

  try {
    const snapshot = await getSnapshot(snapshotId, session.user.orgId);

    if (!snapshot) return notFoundResponse('Snapshot not found');

    return NextResponse.json<ApiResponse<ApprovalSnapshot>>({
      success: true,
      data: snapshot,
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/replay/[snapshotId] error:', error);
    return internalErrorResponse();
  }
}

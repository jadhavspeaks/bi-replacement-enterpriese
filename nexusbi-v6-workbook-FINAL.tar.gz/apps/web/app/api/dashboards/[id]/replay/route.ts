export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { listSnapshots } from '@/lib/approval-replay';
import { withConnection } from '@/lib/oracle-pool';
import type { ApiResponse, ApprovalSnapshotListItem } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.replay');
  if (denied) return denied;

  const { id } = await params;

  try {
    const exists = await withConnection(async (conn) => {
      const result = await conn.execute<{ DASH_ID: string }>(
        `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
        { dashId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );
      return (result.rows?.length ?? 0) > 0;
    });

    if (!exists) return notFoundResponse('Dashboard not found');

    const snapshots = await listSnapshots(id, session.user.orgId);

    return NextResponse.json<ApiResponse<ApprovalSnapshotListItem[]>>({
      success: true,
      data: snapshots,
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/replay error:', error);
    return internalErrorResponse();
  }
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { WidgetConfig, LayoutConfig } from '@nexusbi/shared-types';

interface RenderOptions {
  theme?: 'light' | 'dark';
  width?: number;
  height?: number;
}

function buildWidgetHtml(widget: WidgetConfig, index: number): string {
  const id = `widget-${widget.widgetId || index}`;

  switch (widget.widgetType) {
    case 'kpi':
      return `
        <div class="widget kpi-widget" id="${id}">
          <div class="widget-label">${escapeHtml(widget.title || 'KPI')}</div>
          <div class="widget-kpi-value">${escapeHtml(String(widget.staticValue ?? '—'))}</div>
          ${widget.subtitle ? `<div class="widget-kpi-sub">${escapeHtml(widget.subtitle)}</div>` : ''}
        </div>`;

    case 'chart':
      return `
        <div class="widget chart-widget" id="${id}">
          <div class="widget-title">${escapeHtml(widget.title || 'Chart')}</div>
          <div class="chart-container" id="chart-${index}" style="width:100%;height:280px;"></div>
          <script>
            (function() {
              var chart = echarts.init(document.getElementById('chart-${index}'));
              var option = ${JSON.stringify(widget.echartsOption || {
                xAxis: { type: 'category', data: ['Q1', 'Q2', 'Q3', 'Q4'] },
                yAxis: { type: 'value' },
                series: [{ data: [820, 932, 901, 1290], type: 'bar', itemStyle: { color: '#1e40af' } }],
                grid: { left: 40, right: 20, top: 20, bottom: 30 },
              })};
              chart.setOption(option);
              window.addEventListener('resize', function() { chart.resize(); });
            })();
          </script>
        </div>`;

    case 'table':
      return `
        <div class="widget table-widget" id="${id}">
          <div class="widget-title">${escapeHtml(widget.title || 'Table')}</div>
          <div class="table-container">
            <table>
              <thead><tr>${(widget.columns || []).map((c: string) => `<th>${escapeHtml(c)}</th>`).join('')}</tr></thead>
              <tbody>${(widget.rows || []).map((row: string[]) =>
                `<tr>${row.map((cell: string) => `<td>${escapeHtml(String(cell))}</td>`).join('')}</tr>`
              ).join('')}</tbody>
            </table>
          </div>
        </div>`;

    case 'text':
      return `
        <div class="widget text-widget" id="${id}">
          <div class="widget-content">${widget.markdownContent || widget.title || ''}</div>
        </div>`;

    case 'filter':
      return `
        <div class="widget filter-widget" id="${id}">
          <div class="widget-label">${escapeHtml(widget.title || 'Filter')}</div>
          <select class="filter-select"><option>All</option></select>
        </div>`;

    default:
      return `<div class="widget" id="${id}"><div class="widget-title">${escapeHtml(widget.title || widget.widgetType)}</div></div>`;
  }
}

function escapeHtml(str: string): string {
  return str
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function buildFullHtml(
  dashName: string,
  widgets: WidgetConfig[],
  layout: LayoutConfig | null,
  options: RenderOptions,
): string {
  const widgetHtmlBlocks = widgets.map((w, i) => buildWidgetHtml(w, i)).join('\n');
  const w = options.width || 1200;
  const bg = '#fafaf7';
  const ink = '#0a0a0a';

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>${escapeHtml(dashName)} — NexusBI</title>
<script src="https://cdnjs.cloudflare.com/ajax/libs/echarts/5.5.1/echarts.min.js"></script>
<style>
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body {
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
    background: ${bg}; color: ${ink};
    max-width: ${w}px; margin: 0 auto; padding: 24px;
  }
  .dash-header {
    display: flex; justify-content: space-between; align-items: center;
    padding: 16px 0 20px; border-bottom: 1px solid #e5e7eb; margin-bottom: 20px;
  }
  .dash-title { font-size: 24px; font-weight: 700; }
  .dash-meta { font-size: 12px; color: #6b7280; }
  .widget-grid {
    display: grid;
    grid-template-columns: repeat(12, 1fr);
    gap: 12px;
  }
  .widget {
    background: white; border: 1px solid #e5e7eb; border-radius: 6px;
    padding: 16px; grid-column: span 6; min-height: 80px;
  }
  .kpi-widget { grid-column: span 3; }
  .chart-widget { grid-column: span 8; }
  .table-widget { grid-column: span 4; }
  .text-widget { grid-column: span 12; }
  .filter-widget { grid-column: span 3; }
  .widget-title { font-size: 13px; font-weight: 600; margin-bottom: 10px; }
  .widget-label { font-size: 10px; text-transform: uppercase; letter-spacing: 0.12em; color: #6b7280; }
  .widget-kpi-value { font-size: 32px; font-weight: 700; margin-top: 4px; }
  .widget-kpi-sub { font-size: 12px; color: #059669; margin-top: 4px; }
  .widget-content { font-size: 14px; line-height: 1.6; }
  table { width: 100%; border-collapse: collapse; font-size: 12px; }
  th { text-align: left; padding: 8px; border-bottom: 1px solid #0a0a0a; font-size: 10px; text-transform: uppercase; letter-spacing: 0.1em; color: #6b7280; }
  td { padding: 8px; border-bottom: 1px solid #e5e7eb; }
  .filter-select { width: 100%; padding: 6px 10px; border: 1px solid #d1d5db; border-radius: 4px; font-size: 13px; margin-top: 6px; }
  .powered-by { text-align: center; padding: 24px; font-size: 11px; color: #9ca3af; }
  @media print { body { max-width: none; } .widget { break-inside: avoid; } }
</style>
</head>
<body>
  <div class="dash-header">
    <div class="dash-title">${escapeHtml(dashName)}</div>
    <div class="dash-meta">Rendered ${new Date().toLocaleString()} · NexusBI v6</div>
  </div>
  <div class="widget-grid" data-dashboard-loaded="true">
    ${widgetHtmlBlocks}
  </div>
  <div class="powered-by">Powered by NexusBI</div>
</body>
</html>`;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json({ success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } }, { status: 401 });
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { id } = await params;
  const { searchParams } = new URL(request.url);
  const theme = (searchParams.get('theme') as 'light' | 'dark') || 'light';
  const width = parseInt(searchParams.get('width') || '1200', 10);

  try {
    const dash = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT DASH_NAME, LAYOUT_JSON, WIDGETS_JSON
         FROM NB_DASHBOARDS
         WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
        { dashId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];
      return {
        dashName: row.DASH_NAME as string,
        layoutJson: parseJsonClob<LayoutConfig>(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob<WidgetConfig[]>(await clobToString(row.WIDGETS_JSON)) || [],
      };
    });

    if (!dash) return notFoundResponse('Dashboard not found');

    const html = buildFullHtml(dash.dashName, dash.widgetsJson, dash.layoutJson, { theme, width });

    return new NextResponse(html, {
      status: 200,
      headers: {
        'Content-Type': 'text/html; charset=utf-8',
        'Cache-Control': 'no-store',
      },
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/render error:', error);
    return internalErrorResponse();
  }
}

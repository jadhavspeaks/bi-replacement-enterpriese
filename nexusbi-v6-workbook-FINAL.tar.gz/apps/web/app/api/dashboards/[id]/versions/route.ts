export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection } from '@/lib/oracle-pool';
import type { ApiResponse, DashboardVersion } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const versions = await withConnection(async (conn) => {
      // Verify dashboard belongs to org
      const dashCheck = await conn.execute<{ DASH_ID: string }>(
        `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
        { dashId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!dashCheck.rows || dashCheck.rows.length === 0) return null;

      const result = await conn.execute<{
        VERSION_ID: string;
        DASH_ID: string;
        VERSION: number;
        SAVED_BY: string;
        SAVED_AT: string;
        CHANGE_SUMMARY: string | null;
        DISPLAY_NAME: string | null;
      }>(
        `SELECT V.VERSION_ID, V.DASH_ID, V.VERSION, V.SAVED_BY,
                V.SAVED_AT, V.CHANGE_SUMMARY, U.DISPLAY_NAME
         FROM NB_DASHBOARD_VERSIONS V
         LEFT JOIN NB_USERS U ON U.USER_ID = V.SAVED_BY
         WHERE V.DASH_ID = :dashId
         ORDER BY V.VERSION DESC`,
        { dashId: id },
        { outFormat: 4002 },
      );

      return (result.rows || []).map((row) => ({
        versionId: row.VERSION_ID,
        dashId: row.DASH_ID,
        version: row.VERSION,
        layoutJson: null,
        widgetsJson: null,
        filtersJson: null,
        savedBy: row.DISPLAY_NAME || row.SAVED_BY,
        savedAt: String(row.SAVED_AT),
        changeSummary: row.CHANGE_SUMMARY,
      })) as DashboardVersion[];
    });

    if (versions === null) return notFoundResponse('Dashboard not found');

    return NextResponse.json<ApiResponse<DashboardVersion[]>>({
      success: true,
      data: versions,
    });
  } catch (error) {
    console.error('GET /api/dashboards/[id]/versions error:', error);
    return internalErrorResponse();
  }
}

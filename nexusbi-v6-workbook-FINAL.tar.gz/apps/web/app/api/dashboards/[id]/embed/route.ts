export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction } from '@/lib/oracle-pool';
import { signEmbedToken, generateEmbedCode } from '@/lib/embed';
import type { ApiResponse } from '@nexusbi/shared-types';

interface EmbedRequest {
  expiresInHours?: number;
  allowedFilters?: string[];
  theme?: 'light' | 'dark';
  hideToolbar?: boolean;
}

interface EmbedResponse {
  token: string;
  embedCode: { iframe: string; react: string; script: string };
}

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.embed', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.embed');
    if (denied) return denied;

    const { id } = await params;

    let body: EmbedRequest = {};
    try {
      body = await request.json() as EmbedRequest;
    } catch {
      // defaults are fine
    }

    try {
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DASH_ID: string }>(
          `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('Dashboard not found');

      const token = await signEmbedToken(
        {
          dashId: id,
          orgId: user.orgId,
          allowedFilters: body.allowedFilters,
          theme: body.theme,
          hideToolbar: body.hideToolbar,
        },
        body.expiresInHours || 24,
      );

      // Update dashboard embed status
      await withTransaction(async (conn) => {
        await conn.execute(
          `UPDATE NB_DASHBOARDS
           SET IS_EMBEDDED = 1, EMBED_TOKEN = :token, UPDATED_AT = SYSTIMESTAMP
           WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId, token },
        );
      });

      const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';
      const embedCode = generateEmbedCode(baseUrl, token, {
        theme: body.theme,
      });

      return NextResponse.json<ApiResponse<EmbedResponse>>({
        success: true,
        data: { token, embedCode },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/embed error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

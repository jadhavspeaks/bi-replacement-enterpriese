export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import type { ApiResponse } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.submit', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.submit');
    if (denied) return denied;

    const { id } = await params;

    try {
      const dash = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          OWNER_ID: string;
          VERSION: number;
          APPROVAL_STATUS: string;
        }>(
          `SELECT DASH_ID, OWNER_ID, VERSION, APPROVAL_STATUS
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dash) return notFoundResponse('Dashboard not found');

      if (dash.APPROVAL_STATUS !== 'DRAFT' && dash.APPROVAL_STATUS !== 'REJECTED') {
        return NextResponse.json<ApiResponse<never>>(
          {
            success: false,
            error: {
              code: 'CONFLICT',
              message: `Cannot submit dashboard with status ${dash.APPROVAL_STATUS}. Must be DRAFT or REJECTED.`,
            },
          },
          { status: 409 },
        );
      }

      const reviewId = generateId();

      await withTransaction(async (conn) => {
        // Update dashboard status
        await conn.execute(
          `UPDATE NB_DASHBOARDS
           SET APPROVAL_STATUS = 'PENDING_REVIEW',
               UPDATED_AT = SYSTIMESTAMP
           WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId },
        );

        // Create review record
        await conn.execute(
          `INSERT INTO NB_DASHBOARD_REVIEWS
             (REVIEW_ID, DASH_ID, DASH_VERSION, SUBMITTED_BY,
              SUBMITTED_AT, REVIEW_STATUS, ORG_ID)
           VALUES
             (:reviewId, :dashId, :dashVersion, :submittedBy,
              SYSTIMESTAMP, 'PENDING', :orgId)`,
          {
            reviewId,
            dashId: id,
            dashVersion: dash.VERSION,
            submittedBy: user.id,
            orgId: user.orgId,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ dashId: string; reviewId: string }>>({
        success: true,
        data: { dashId: id, reviewId },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/submit error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

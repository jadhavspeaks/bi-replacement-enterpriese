export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import { captureApprovalSnapshot } from '@/lib/approval-replay';
import { fireApprovalWebhooks } from '@/lib/webhook-out';
import type { ApiResponse } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.approve', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.approve');
    if (denied) return denied;

    const { id } = await params;

    let body: { comments?: string } = {};
    try {
      body = await request.json() as { comments?: string };
    } catch {
      // no comments
    }

    try {
      const dash = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DASH_ID: string;
          DASH_NAME: string;
          APPROVAL_STATUS: string;
          DUAL_CHECKER_REQUIRED: number;
          VERSION: number;
        }>(
          `SELECT DASH_ID, DASH_NAME, APPROVAL_STATUS, DUAL_CHECKER_REQUIRED, VERSION
           FROM NB_DASHBOARDS
           WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!dash) return notFoundResponse('Dashboard not found');

      if (dash.APPROVAL_STATUS !== 'PENDING_REVIEW') {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'CONFLICT', message: 'Dashboard is not pending review' } },
          { status: 409 },
        );
      }

      // Get the active review
      const review = await withConnection(async (conn) => {
        const result = await conn.execute<{
          REVIEW_ID: string;
          SUBMITTED_BY: string;
        }>(
          `SELECT REVIEW_ID, SUBMITTED_BY
           FROM NB_DASHBOARD_REVIEWS
           WHERE DASH_ID = :dashId AND REVIEW_STATUS = 'PENDING'
           ORDER BY SUBMITTED_AT DESC
           FETCH FIRST 1 ROW ONLY`,
          { dashId: id },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!review) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'NOT_FOUND', message: 'No pending review found' } },
          { status: 404 },
        );
      }

      // Self-approval blocked
      if (review.SUBMITTED_BY === user.id) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'RBAC_DENIED', message: 'Cannot approve your own submission' } },
          { status: 403 },
        );
      }

      const isDualChecker = dash.DUAL_CHECKER_REQUIRED === 1;

      if (isDualChecker) {
        return handleDualCheckerApproval(id, dash.DASH_NAME, review.REVIEW_ID, user, body.comments, dash.VERSION);
      }

      // Single checker approval
      await withTransaction(async (conn) => {
        await conn.execute(
          `UPDATE NB_DASHBOARDS
           SET APPROVAL_STATUS = 'APPROVED',
               APPROVED_BY = :approvedBy,
               APPROVED_AT = SYSTIMESTAMP,
               UPDATED_AT = SYSTIMESTAMP
           WHERE DASH_ID = :dashId`,
          { dashId: id, approvedBy: user.id },
        );

        await conn.execute(
          `UPDATE NB_DASHBOARD_REVIEWS
           SET REVIEWED_BY = :reviewedBy,
               REVIEWED_AT = SYSTIMESTAMP,
               REVIEW_STATUS = 'APPROVED',
               REVIEW_COMMENTS = :comments
           WHERE REVIEW_ID = :reviewId`,
          { reviewId: review.REVIEW_ID, reviewedBy: user.id, comments: body.comments ?? null },
        );
      });

      // Capture approval snapshot (Feature 1)
      await captureApprovalSnapshot(id, review.REVIEW_ID, user.id, user.orgId);

      // Fire approval webhooks (Feature 6)
      fireApprovalWebhooks(id, dash.DASH_NAME, user.id, user.orgId).catch(console.error);

      return NextResponse.json<ApiResponse<{ dashId: string; status: string }>>({
        success: true,
        data: { dashId: id, status: 'APPROVED' },
      });
    } catch (error) {
      console.error('POST /api/dashboards/[id]/approve error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

async function handleDualCheckerApproval(
  dashId: string,
  dashName: string,
  reviewId: string,
  user: { id: string; orgId: string; displayName: string },
  comments: string | undefined,
  version: number,
): Promise<NextResponse> {
  // Check existing checker assignments
  const assignments = await withConnection(async (conn) => {
    const result = await conn.execute<{
      ASSIGNMENT_ID: string;
      CHECKER_SLOT: number;
      CHECKER_ID: string;
      DECISION: string;
    }>(
      `SELECT ASSIGNMENT_ID, CHECKER_SLOT, CHECKER_ID, DECISION
       FROM NB_CHECKER_ASSIGNMENTS
       WHERE REVIEW_ID = :reviewId
       ORDER BY CHECKER_SLOT`,
      { reviewId },
      { outFormat: 4002 },
    );
    return result.rows || [];
  });

  // Check if user already has a slot
  const existingSlot = assignments.find((a) => a.CHECKER_ID === user.id);
  if (existingSlot) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'CONFLICT', message: 'You have already reviewed this dashboard' } },
      { status: 409 },
    );
  }

  const slot1 = assignments.find((a) => a.CHECKER_SLOT === 1);
  const slot2 = assignments.find((a) => a.CHECKER_SLOT === 2);

  if (!slot1) {
    // First checker — fill slot 1, dashboard stays PENDING_REVIEW
    await withTransaction(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_CHECKER_ASSIGNMENTS
           (ASSIGNMENT_ID, REVIEW_ID, CHECKER_SLOT, CHECKER_ID,
            ASSIGNED_AT, DECISION, DECIDED_AT, COMMENTS)
         VALUES
           (:assignmentId, :reviewId, 1, :checkerId,
            SYSTIMESTAMP, 'APPROVED', SYSTIMESTAMP, :comments)`,
        {
          assignmentId: generateId(),
          reviewId,
          checkerId: user.id,
          comments: comments ?? null,
        },
      );
    });

    return NextResponse.json<ApiResponse<{ dashId: string; status: string; checkerSlot: number }>>({
      success: true,
      data: { dashId, status: 'PENDING_REVIEW', checkerSlot: 1 },
    });
  }

  if (slot1 && !slot2) {
    // Second checker — fill slot 2, dashboard moves to APPROVED
    if (slot1.CHECKER_ID === user.id) {
      return NextResponse.json<ApiResponse<never>>(
        { success: false, error: { code: 'RBAC_DENIED', message: 'Dual-checker requires two distinct checkers' } },
        { status: 403 },
      );
    }

    await withTransaction(async (conn) => {
      await conn.execute(
        `INSERT INTO NB_CHECKER_ASSIGNMENTS
           (ASSIGNMENT_ID, REVIEW_ID, CHECKER_SLOT, CHECKER_ID,
            ASSIGNED_AT, DECISION, DECIDED_AT, COMMENTS)
         VALUES
           (:assignmentId, :reviewId, 2, :checkerId,
            SYSTIMESTAMP, 'APPROVED', SYSTIMESTAMP, :comments)`,
        {
          assignmentId: generateId(),
          reviewId,
          checkerId: user.id,
          comments: comments ?? null,
        },
      );

      // Both slots approved — move to APPROVED
      await conn.execute(
        `UPDATE NB_DASHBOARDS
         SET APPROVAL_STATUS = 'APPROVED',
             APPROVED_BY = :approvedBy,
             APPROVED_AT = SYSTIMESTAMP,
             UPDATED_AT = SYSTIMESTAMP
         WHERE DASH_ID = :dashId`,
        { dashId, approvedBy: user.id },
      );

      await conn.execute(
        `UPDATE NB_DASHBOARD_REVIEWS
         SET REVIEWED_BY = :reviewedBy,
             REVIEWED_AT = SYSTIMESTAMP,
             REVIEW_STATUS = 'APPROVED',
             REVIEW_COMMENTS = :comments
         WHERE REVIEW_ID = :reviewId`,
        { reviewId, reviewedBy: user.id, comments: comments ?? null },
      );
    });

    // Capture snapshot + fire webhooks
    await captureApprovalSnapshot(dashId, reviewId, user.id, user.orgId);
    fireApprovalWebhooks(dashId, dashName, user.id, user.orgId).catch(console.error);

    return NextResponse.json<ApiResponse<{ dashId: string; status: string; checkerSlot: number }>>({
      success: true,
      data: { dashId, status: 'APPROVED', checkerSlot: 2 },
    });
  }

  return NextResponse.json<ApiResponse<never>>(
    { success: false, error: { code: 'CONFLICT', message: 'Both checker slots are already filled' } },
    { status: 409 },
  );
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection } from '@/lib/oracle-pool';
import type { ApiResponse, DashboardExportOptions } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'dashboard.export', resourceType: 'dashboard', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'dashboard.view');
    if (denied) return denied;

    const { id } = await params;

    let body: DashboardExportOptions = { format: 'png' };
    try {
      body = await request.json() as DashboardExportOptions;
    } catch {
      // default to png
    }

    if (!['png', 'pdf'].includes(body.format)) {
      return invalidInputResponse('format must be png or pdf');
    }

    try {
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DASH_ID: string }>(
          `SELECT DASH_ID FROM NB_DASHBOARDS WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
          { dashId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!exists) return notFoundResponse('Dashboard not found');

      const puppeteer = await import('puppeteer');
      const browser = await puppeteer.default.launch({
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
      });

      try {
        const page = await browser.newPage();
        const width = body.width || 1920;
        const height = body.height || 1080;

        await page.setViewport({ width, height, deviceScaleFactor: body.scale || 2 });

        const baseUrl = process.env.NEXTAUTH_URL || 'http://localhost:3000';
        await page.goto(`${baseUrl}/dashboards/${id}?export=true`, {
          waitUntil: 'networkidle2',
          timeout: 30000,
        });

        // Wait for widgets to load
        await page.waitForSelector('[data-dashboard-loaded="true"]', {
          timeout: 20000,
        }).catch(() => {
          // Continue even if selector not found
        });

        await new Promise((resolve) => setTimeout(resolve, 2000));

        let buffer: Buffer;
        let contentType: string;
        let fileName: string;

        if (body.format === 'pdf') {
          buffer = Buffer.from(await page.pdf({
            width: `${width}px`,
            height: `${height}px`,
            printBackground: true,
            margin: { top: '0', right: '0', bottom: '0', left: '0' },
          }));
          contentType = 'application/pdf';
          fileName = `dashboard-${id}.pdf`;
        } else {
          buffer = Buffer.from(await page.screenshot({
            type: 'png',
            fullPage: false,
            clip: { x: 0, y: 0, width, height },
          }));
          contentType = 'image/png';
          fileName = `dashboard-${id}.png`;
        }

        return new NextResponse(buffer, {
          status: 200,
          headers: {
            'Content-Type': contentType,
            'Content-Disposition': `attachment; filename="${fileName}"`,
            'Content-Length': String(buffer.length),
          },
        });
      } finally {
        await browser.close();
      }
    } catch (error) {
      console.error('POST /api/dashboards/[id]/export error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

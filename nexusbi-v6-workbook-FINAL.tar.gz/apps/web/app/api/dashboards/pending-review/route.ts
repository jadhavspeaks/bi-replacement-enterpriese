export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse } from '@nexusbi/shared-types';

interface PendingReviewItem {
  reviewId: string;
  dashId: string;
  dashName: string;
  dashVersion: number;
  submittedBy: string;
  submittedByDisplayName: string;
  submittedAt: string;
  dualCheckerRequired: boolean;
  slot1Filled: boolean;
  slot1CheckerName: string | null;
  ownerId: string;
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'dashboard.approve');
  if (denied) return denied;

  try {
    const queue = await withConnection(async (conn) => {
      const result = await conn.execute<{
        REVIEW_ID: string;
        DASH_ID: string;
        DASH_NAME: string;
        DASH_VERSION: number;
        SUBMITTED_BY: string;
        SUBMITTED_DISPLAY: string | null;
        SUBMITTED_AT: string;
        DUAL_CHECKER_REQUIRED: number;
        OWNER_ID: string;
      }>(
        `SELECT R.REVIEW_ID, R.DASH_ID, D.DASH_NAME, R.DASH_VERSION,
                R.SUBMITTED_BY, U.DISPLAY_NAME AS SUBMITTED_DISPLAY,
                R.SUBMITTED_AT, D.DUAL_CHECKER_REQUIRED, D.OWNER_ID
         FROM NB_DASHBOARD_REVIEWS R
         JOIN NB_DASHBOARDS D ON D.DASH_ID = R.DASH_ID
         LEFT JOIN NB_USERS U ON U.USER_ID = R.SUBMITTED_BY
         WHERE R.REVIEW_STATUS = 'PENDING'
           AND R.ORG_ID = :orgId
         ORDER BY R.SUBMITTED_AT ASC`,
        { orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      const items: PendingReviewItem[] = [];
      for (const row of result.rows || []) {
        // Check if slot 1 is filled for dual-checker
        let slot1Filled = false;
        let slot1CheckerName: string | null = null;

        if (row.DUAL_CHECKER_REQUIRED === 1) {
          const slotResult = await conn.execute<{
            CHECKER_ID: string;
            CHECKER_DISPLAY: string | null;
          }>(
            `SELECT CA.CHECKER_ID, U.DISPLAY_NAME AS CHECKER_DISPLAY
             FROM NB_CHECKER_ASSIGNMENTS CA
             LEFT JOIN NB_USERS U ON U.USER_ID = CA.CHECKER_ID
             WHERE CA.REVIEW_ID = :reviewId AND CA.CHECKER_SLOT = 1 AND CA.DECISION = 'APPROVED'`,
            { reviewId: row.REVIEW_ID },
            { outFormat: 4002 },
          );

          if (slotResult.rows && slotResult.rows.length > 0) {
            slot1Filled = true;
            slot1CheckerName = slotResult.rows[0].CHECKER_DISPLAY || slotResult.rows[0].CHECKER_ID;
          }
        }

        items.push({
          reviewId: row.REVIEW_ID,
          dashId: row.DASH_ID,
          dashName: row.DASH_NAME,
          dashVersion: row.DASH_VERSION,
          submittedBy: row.SUBMITTED_BY,
          submittedByDisplayName: row.SUBMITTED_DISPLAY || row.SUBMITTED_BY,
          submittedAt: String(row.SUBMITTED_AT),
          dualCheckerRequired: row.DUAL_CHECKER_REQUIRED === 1,
          slot1Filled,
          slot1CheckerName,
          ownerId: row.OWNER_ID,
        });
      }

      return items;
    });

    return NextResponse.json<ApiResponse<PendingReviewItem[]>>({
      success: true,
      data: queue,
    });
  } catch (error) {
    console.error('GET /api/dashboards/pending-review error:', error);
    return internalErrorResponse();
  }
}

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, Workbook, WorkbookCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'workbook.view');
  if (denied) return denied;

  const { user } = session;

  try {
    const workbooks = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT WORKBOOK_ID, WORKBOOK_NAME, DESCRIPTION, OWNER_ID, ORG_ID, DS_ID,
                TAGS, IS_PUBLISHED, PUBLISHED_DASH_ID, THUMBNAIL_URL, VERSION,
                CREATED_AT, UPDATED_AT
         FROM NB_WORKBOOKS
         WHERE ORG_ID = :orgId AND OWNER_ID = :userId
         ORDER BY UPDATED_AT DESC`,
        { orgId: user.orgId, userId: user.id },
        { outFormat: 4002 },
      );

      const list: Workbook[] = [];
      for (const row of result.rows || []) {
        list.push({
          workbookId: row.WORKBOOK_ID as string,
          workbookName: row.WORKBOOK_NAME as string,
          description: await clobToString(row.DESCRIPTION) || null,
          ownerId: row.OWNER_ID as string,
          orgId: row.ORG_ID as string,
          dsId: (row.DS_ID as string) || null,
          tags: (row.TAGS as string) || null,
          isPublished: (row.IS_PUBLISHED as number) === 1,
          publishedDashId: (row.PUBLISHED_DASH_ID as string) || null,
          thumbnailUrl: (row.THUMBNAIL_URL as string) || null,
          version: row.VERSION as number,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<Workbook[]>>({ success: true, data: workbooks });
  } catch (error) {
    console.error('GET /api/workbooks error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  () => ({ action: 'workbook.create', resourceType: 'workbook' }),
  async (request, _params, user) => {
    const denied = await requirePermission(user, 'workbook.create');
    if (denied) return denied;

    let body: WorkbookCreateInput;
    try {
      body = await request.json() as WorkbookCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.workbookName || body.workbookName.trim().length === 0) {
      return invalidInputResponse('workbookName is required');
    }

    try {
      const workbookId = generateId();

      await withConnection(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_WORKBOOKS (WORKBOOK_ID, WORKBOOK_NAME, DESCRIPTION, OWNER_ID, ORG_ID, DS_ID, TAGS, VERSION)
           VALUES (:id, :name, :desc, :owner, :org, :dsId, :tags, 1)`,
          {
            id: workbookId,
            name: body.workbookName.trim(),
            desc: body.description || null,
            owner: user.id,
            org: user.orgId,
            dsId: body.dsId || null,
            tags: body.tags || null,
          },
        );
        await conn.commit();
      });

      const created: Workbook = {
        workbookId,
        workbookName: body.workbookName.trim(),
        description: body.description || null,
        ownerId: user.id,
        orgId: user.orgId,
        dsId: body.dsId || null,
        tags: body.tags || null,
        isPublished: false,
        publishedDashId: null,
        thumbnailUrl: null,
        version: 1,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<Workbook>>({ success: true, data: created }, { status: 201 });
    } catch (error) {
      console.error('POST /api/workbooks error:', error);
      return internalErrorResponse();
    }
  },
);

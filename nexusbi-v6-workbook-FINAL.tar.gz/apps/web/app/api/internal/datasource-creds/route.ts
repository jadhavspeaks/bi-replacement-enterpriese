export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse } from '@nexusbi/shared-types';

const INTERNAL_API_SECRET = process.env.INTERNAL_API_SECRET || '';

function validateInternalSecret(request: NextRequest): boolean {
  const secret = request.headers.get('x-internal-secret');
  return secret === INTERNAL_API_SECRET && INTERNAL_API_SECRET.length > 0;
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  if (!validateInternalSecret(request)) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Invalid internal secret' } },
      { status: 403 },
    );
  }

  const { searchParams } = new URL(request.url);
  const cubeDsId = searchParams.get('cubeDsId');
  const listActive = searchParams.get('listActive');
  const includeSchemas = searchParams.get('schemas') === 'true';

  if (listActive === 'true') {
    return handleListActive();
  }

  if (!cubeDsId) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'INVALID_INPUT', message: 'cubeDsId required' } },
      { status: 400 },
    );
  }

  return handleGetCredentials(cubeDsId, includeSchemas);
}

async function handleListActive(): Promise<NextResponse> {
  const dataSources = await withConnection(async (conn) => {
    const result = await conn.execute<{
      DS_ID: string;
      CUBE_DS_ID: string;
      DS_TYPE: string;
    }>(
      `SELECT DS_ID, CUBE_DS_ID, DS_TYPE
       FROM NB_DATA_SOURCES
       WHERE IS_ACTIVE = 1 AND STATUS = 'ACTIVE' AND CUBE_DS_ID IS NOT NULL`,
      {},
      { outFormat: 4002 },
    );

    return (result.rows || []).map((row) => ({
      dsId: row.DS_ID,
      cubeDsId: row.CUBE_DS_ID,
      dsType: row.DS_TYPE,
    }));
  });

  return NextResponse.json({ success: true, dataSources });
}

async function handleGetCredentials(
  cubeDsId: string,
  includeSchemas: boolean,
): Promise<NextResponse> {
  const ds = await withConnection(async (conn) => {
    const result = await conn.execute<{
      DS_ID: string;
      DS_TYPE: string;
      CONFIG_ENCRYPTED: string;
    }>(
      `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
       FROM NB_DATA_SOURCES
       WHERE CUBE_DS_ID = :cubeDsId
         AND IS_ACTIVE = 1`,
      { cubeDsId },
      { outFormat: 4002 },
    );

    if (!result.rows || result.rows.length === 0) return null;
    return result.rows[0];
  });

  if (!ds) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'NOT_FOUND', message: `Data source not found: ${cubeDsId}` } },
      { status: 404 },
    );
  }

  // DECRYPT ONLY HERE — per LAW-06
  const configStr = await clobToString(ds.CONFIG_ENCRYPTED);
  let config: Record<string, unknown>;

  try {
    const decrypted = decrypt(configStr);
    config = JSON.parse(decrypted);
  } catch (error) {
    console.error('Failed to decrypt datasource config:', error);
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'DS_CONNECTION_FAILED', message: 'Failed to decrypt credentials' } },
      { status: 500 },
    );
  }

  const response: Record<string, unknown> = {
    dsType: ds.DS_TYPE,
    config,
  };

  if (includeSchemas) {
    const schemas = await withConnection(async (conn) => {
      const result = await conn.execute<{
        SCHEMA_ID: string;
        CUBE_NAME: string;
        SCHEMA_JS: string;
      }>(
        `SELECT SCHEMA_ID, CUBE_NAME, SCHEMA_JS
         FROM NB_CUBE_SCHEMAS
         WHERE DS_ID = :dsId AND IS_ACTIVE = 1`,
        { dsId: ds.DS_ID },
        { outFormat: 4002 },
      );

      const schemas = [];
      for (const row of result.rows || []) {
        schemas.push({
          schemaId: row.SCHEMA_ID,
          cubeName: row.CUBE_NAME,
          schemaJs: await clobToString(row.SCHEMA_JS),
        });
      }
      return schemas;
    });

    response.schemas = schemas;
  }

  return NextResponse.json(response);
}

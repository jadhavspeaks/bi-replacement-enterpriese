export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, LayoutConfig, WidgetConfig } from '@nexusbi/shared-types';

interface TemplatePreview {
  templateId: string;
  templateName: string;
  layoutJson: LayoutConfig | null;
  widgetsJson: WidgetConfig[] | null;
  requiredDsTypes: string[] | null;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'template.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const preview = await withConnection(async (conn) => {
      const result = await conn.execute<{
        TEMPLATE_ID: string;
        TEMPLATE_NAME: string;
        LAYOUT_JSON: string;
        WIDGETS_JSON: string;
        REQUIRED_DS_TYPES: string;
      }>(
        `SELECT TEMPLATE_ID, TEMPLATE_NAME, LAYOUT_JSON, WIDGETS_JSON, REQUIRED_DS_TYPES
         FROM NB_DASH_TEMPLATES
         WHERE TEMPLATE_ID = :templateId
           AND (ORG_ID = :orgId OR IS_GLOBAL = 1)`,
        { templateId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        templateId: row.TEMPLATE_ID,
        templateName: row.TEMPLATE_NAME,
        layoutJson: parseJsonClob<LayoutConfig>(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob<WidgetConfig[]>(await clobToString(row.WIDGETS_JSON)),
        requiredDsTypes: parseJsonClob<string[]>(await clobToString(row.REQUIRED_DS_TYPES)),
      } as TemplatePreview;
    });

    if (!preview) return notFoundResponse('Template not found');

    return NextResponse.json<ApiResponse<TemplatePreview>>({
      success: true,
      data: preview,
    });
  } catch (error) {
    console.error('GET /api/templates/[id]/preview error:', error);
    return internalErrorResponse();
  }
}

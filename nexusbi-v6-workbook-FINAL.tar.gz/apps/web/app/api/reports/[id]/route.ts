export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, ScheduledReport, ScheduledReportUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'report.schedule');
  if (denied) return denied;

  const { id } = await params;

  try {
    const report = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT R.REPORT_ID, R.DASH_ID, R.REPORT_NAME, R.CRON_EXPRESSION,
                R.DELIVERY_TYPE, R.DELIVERY_CONFIG, R.IS_ACTIVE,
                R.LAST_RUN_AT, R.LAST_RUN_STATUS, R.NEXT_RUN_AT,
                R.CREATED_BY, R.CREATED_AT
         FROM NB_SCHEDULED_REPORTS R
         JOIN NB_DASHBOARDS D ON D.DASH_ID = R.DASH_ID
         WHERE R.REPORT_ID = :reportId AND D.ORG_ID = :orgId`,
        { reportId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        reportId: row.REPORT_ID as string,
        dashId: row.DASH_ID as string,
        reportName: row.REPORT_NAME as string,
        cronExpression: row.CRON_EXPRESSION as string,
        deliveryType: row.DELIVERY_TYPE as ScheduledReport['deliveryType'],
        deliveryConfig: parseJsonClob(await clobToString(row.DELIVERY_CONFIG)) as ScheduledReport['deliveryConfig'],
        isActive: (row.IS_ACTIVE as number) === 1,
        lastRunAt: row.LAST_RUN_AT ? String(row.LAST_RUN_AT) : null,
        lastRunStatus: row.LAST_RUN_STATUS as string | null,
        nextRunAt: row.NEXT_RUN_AT ? String(row.NEXT_RUN_AT) : null,
        createdBy: row.CREATED_BY as string,
        createdAt: String(row.CREATED_AT),
      } as ScheduledReport;
    });

    if (!report) return notFoundResponse('Report not found');

    return NextResponse.json<ApiResponse<ScheduledReport>>({ success: true, data: report });
  } catch (error) {
    console.error('GET /api/reports/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'report.update', resourceType: 'report', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'report.schedule');
    if (denied) return denied;

    const { id } = await params;
    let body: ScheduledReportUpdateInput;
    try {
      body = await request.json() as ScheduledReportUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      await withTransaction(async (conn) => {
        const setClauses: string[] = [];
        const binds: Record<string, unknown> = { reportId: id, orgId: user.orgId };

        if (body.reportName !== undefined) {
          setClauses.push('REPORT_NAME = :reportName');
          binds.reportName = body.reportName;
        }
        if (body.cronExpression !== undefined) {
          setClauses.push('CRON_EXPRESSION = :cronExpression');
          binds.cronExpression = body.cronExpression;
        }
        if (body.deliveryType !== undefined) {
          setClauses.push('DELIVERY_TYPE = :deliveryType');
          binds.deliveryType = body.deliveryType;
        }
        if (body.deliveryConfig !== undefined) {
          setClauses.push('DELIVERY_CONFIG = :deliveryConfig');
          binds.deliveryConfig = JSON.stringify(body.deliveryConfig);
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }

        if (setClauses.length === 0) {
          return;
        }

        await conn.execute(
          `UPDATE NB_SCHEDULED_REPORTS R
           SET ${setClauses.join(', ')}
           WHERE R.REPORT_ID = :reportId
             AND R.DASH_ID IN (SELECT DASH_ID FROM NB_DASHBOARDS WHERE ORG_ID = :orgId)`,
          binds,
        );
      });

      return NextResponse.json<ApiResponse<{ reportId: string }>>({
        success: true,
        data: { reportId: id },
      });
    } catch (error) {
      console.error('PUT /api/reports/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'report.delete', resourceType: 'report', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'report.schedule');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `DELETE FROM NB_SCHEDULED_REPORTS R
           WHERE R.REPORT_ID = :reportId
             AND R.DASH_ID IN (SELECT DASH_ID FROM NB_DASHBOARDS WHERE ORG_ID = :orgId)`,
          { reportId: id, orgId: user.orgId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Report not found');

      return NextResponse.json<ApiResponse<{ reportId: string }>>({
        success: true,
        data: { reportId: id },
      });
    } catch (error) {
      console.error('DELETE /api/reports/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

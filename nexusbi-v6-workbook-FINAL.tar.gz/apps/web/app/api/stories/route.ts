export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, generateId, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, Story, StoryCreateInput, StoryPoint } from '@nexusbi/shared-types';

async function loadStoryPoints(storyId: string): Promise<StoryPoint[]> {
  return withConnection(async (conn) => {
    const r = await conn.execute<Record<string, unknown>>(
      `SELECT POINT_ID, STORY_ID, SORT_ORDER, POINT_TYPE, TITLE, NARRATIVE,
              DASH_ID, WORKSHEET_ID, CONTENT_JSON, FILTER_OVERRIDES
       FROM NB_STORY_POINTS WHERE STORY_ID = :sid ORDER BY SORT_ORDER`,
      { sid: storyId }, { outFormat: 4002 },
    );
    const list: StoryPoint[] = [];
    for (const row of r.rows || []) {
      const contentStr = await clobToString(row.CONTENT_JSON);
      const filterStr = await clobToString(row.FILTER_OVERRIDES);
      list.push({
        pointId: row.POINT_ID as string,
        storyId: row.STORY_ID as string,
        sortOrder: row.SORT_ORDER as number,
        pointType: row.POINT_TYPE as StoryPoint['pointType'],
        title: row.TITLE as string,
        narrative: await clobToString(row.NARRATIVE) || null,
        dashId: (row.DASH_ID as string) || null,
        worksheetId: (row.WORKSHEET_ID as string) || null,
        contentJson: contentStr ? (JSON.parse(contentStr) as Record<string, unknown>) : null,
        filterOverrides: filterStr ? (JSON.parse(filterStr) as Record<string, unknown>) : null,
      });
    }
    return list;
  });
}

export async function GET(_request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }
  const denied = await requirePermission(session.user, 'story.view');
  if (denied) return denied;

  const { user } = session;

  try {
    const stories = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT STORY_ID, STORY_NAME, DESCRIPTION, OWNER_ID, ORG_ID, IS_PUBLISHED, VERSION, CREATED_AT, UPDATED_AT
         FROM NB_STORIES WHERE ORG_ID = :orgId AND (OWNER_ID = :userId OR IS_PUBLISHED = 1)
         ORDER BY UPDATED_AT DESC`,
        { orgId: user.orgId, userId: user.id }, { outFormat: 4002 },
      );

      const list: Story[] = [];
      for (const row of result.rows || []) {
        const points = await loadStoryPoints(row.STORY_ID as string);
        list.push({
          storyId: row.STORY_ID as string,
          storyName: row.STORY_NAME as string,
          description: await clobToString(row.DESCRIPTION) || null,
          ownerId: row.OWNER_ID as string,
          orgId: row.ORG_ID as string,
          isPublished: (row.IS_PUBLISHED as number) === 1,
          version: row.VERSION as number,
          storyPoints: points,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<Story[]>>({ success: true, data: stories });
  } catch (error) {
    console.error('GET /api/stories error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  () => ({ action: 'story.create', resourceType: 'story' }),
  async (request, _params, user) => {
    const denied = await requirePermission(user, 'story.create');
    if (denied) return denied;

    let body: StoryCreateInput;
    try {
      body = await request.json() as StoryCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.storyName || body.storyName.trim().length === 0) {
      return invalidInputResponse('storyName is required');
    }

    try {
      const storyId = generateId();

      await withConnection(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_STORIES (STORY_ID, STORY_NAME, DESCRIPTION, OWNER_ID, ORG_ID, IS_PUBLISHED, VERSION)
           VALUES (:id, :name, :desc, :owner, :org, 0, 1)`,
          { id: storyId, name: body.storyName.trim(), desc: body.description || null, owner: user.id, org: user.orgId },
        );
        await conn.commit();
      });

      const created: Story = {
        storyId, storyName: body.storyName.trim(),
        description: body.description || null,
        ownerId: user.id, orgId: user.orgId,
        isPublished: false, version: 1, storyPoints: [],
        createdAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
      };

      return NextResponse.json<ApiResponse<Story>>({ success: true, data: created }, { status: 201 });
    } catch (error) {
      console.error('POST /api/stories error:', error);
      return internalErrorResponse();
    }
  },
);

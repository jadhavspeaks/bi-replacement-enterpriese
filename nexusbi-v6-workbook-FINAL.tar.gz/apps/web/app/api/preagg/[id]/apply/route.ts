export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString } from '@/lib/oracle-pool';
import { invalidateCache } from '@/lib/cache';
import type { ApiResponse } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'preagg.apply', resourceType: 'preagg', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'preagg.manage');
    if (denied) return denied;

    const { id } = await params;

    try {
      const rec = await withConnection(async (conn) => {
        const result = await conn.execute<{
          REC_ID: string;
          DS_ID: string;
          CUBE_NAME: string;
          SUGGESTED_PREAGG: string;
          STATUS: string;
          SMART_REFRESH_CRON: string | null;
        }>(
          `SELECT R.REC_ID, R.DS_ID, R.CUBE_NAME, R.SUGGESTED_PREAGG,
                  R.STATUS, R.SMART_REFRESH_CRON
           FROM NB_PREAGG_RECOMMENDATIONS R
           WHERE R.REC_ID = :recId
             AND R.DS_ID IN (SELECT DS_ID FROM NB_DATA_SOURCES WHERE ORG_ID = :orgId)`,
          { recId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!rec) return notFoundResponse('Recommendation not found');

      if (rec.STATUS !== 'PENDING') {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'CONFLICT', message: `Recommendation already ${rec.STATUS}` } },
          { status: 409 },
        );
      }

      const suggestedPreagg = await clobToString(rec.SUGGESTED_PREAGG);

      await withTransaction(async (conn) => {
        // Get current schema
        const schemaResult = await conn.execute<{
          SCHEMA_ID: string;
          SCHEMA_JS: string;
          VERSION: number;
        }>(
          `SELECT SCHEMA_ID, SCHEMA_JS, VERSION
           FROM NB_CUBE_SCHEMAS
           WHERE DS_ID = :dsId AND CUBE_NAME = :cubeName AND IS_ACTIVE = 1`,
          { dsId: rec.DS_ID, cubeName: rec.CUBE_NAME },
          { outFormat: 4002 },
        );

        if (schemaResult.rows && schemaResult.rows.length > 0) {
          const schema = schemaResult.rows[0];
          let schemaJs = await clobToString(schema.SCHEMA_JS);

          // Inject pre-aggregation block before the closing of the cube definition
          const preaggBlock = `\n  preAggregations: {\n    ${suggestedPreagg}\n  },`;
          const lastBrace = schemaJs.lastIndexOf('});');
          if (lastBrace > 0) {
            schemaJs = schemaJs.substring(0, lastBrace) + preaggBlock + '\n' + schemaJs.substring(lastBrace);
          }

          await conn.execute(
            `UPDATE NB_CUBE_SCHEMAS
             SET SCHEMA_JS = :schemaJs,
                 VERSION = VERSION + 1,
                 UPDATED_AT = SYSTIMESTAMP
             WHERE SCHEMA_ID = :schemaId`,
            { schemaJs, schemaId: schema.SCHEMA_ID },
          );
        }

        // Mark recommendation as applied
        await conn.execute(
          `UPDATE NB_PREAGG_RECOMMENDATIONS
           SET STATUS = 'APPLIED',
               APPLIED_AT = SYSTIMESTAMP,
               APPLIED_BY = :appliedBy
           WHERE REC_ID = :recId`,
          { recId: id, appliedBy: user.id },
        );
      });

      // Invalidate schema cache
      await invalidateCache(`schema:${rec.DS_ID}`);

      return NextResponse.json<ApiResponse<{ recId: string; status: string }>>({
        success: true,
        data: { recId: id, status: 'APPLIED' },
      });
    } catch (error) {
      console.error('POST /api/preagg/[id]/apply error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, internalErrorResponse } from '@/lib/rbac-middleware';
import { generateSmartRefreshSuggestions } from '@/lib/smart-refresh';
import type { ApiResponse, SmartRefreshSuggestion } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'preagg.manage');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const limit = parseInt(searchParams.get('limit') || '5', 10);

  try {
    const suggestions = await generateSmartRefreshSuggestions(
      session.user.orgId,
      Math.min(limit, 20),
    );

    return NextResponse.json<ApiResponse<SmartRefreshSuggestion[]>>({
      success: true,
      data: suggestions,
    });
  } catch (error) {
    console.error('GET /api/preagg/smart-suggest error:', error);
    return internalErrorResponse();
  }
}

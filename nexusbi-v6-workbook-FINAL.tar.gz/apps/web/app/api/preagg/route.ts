export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import type { ApiResponse, PreAggRecommendation } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'preagg.manage');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const status = searchParams.get('status');
  const dsId = searchParams.get('dsId');

  try {
    const recommendations = await withConnection(async (conn) => {
      let sql = `SELECT R.REC_ID, R.DS_ID, R.CUBE_NAME, R.SUGGESTED_PREAGG,
                        R.REASON, R.AVG_QUERY_MS, R.QUERY_COUNT, R.STATUS,
                        R.SMART_REFRESH_CRON, R.CONFIDENCE_SCORE,
                        R.APPLIED_AT, R.APPLIED_BY, R.CREATED_AT
                 FROM NB_PREAGG_RECOMMENDATIONS R
                 WHERE R.DS_ID IN (
                   SELECT DS_ID FROM NB_DATA_SOURCES WHERE ORG_ID = :orgId
                 )`;
      const binds: Record<string, unknown> = { orgId: session.user.orgId };

      if (status) {
        sql += ` AND R.STATUS = :status`;
        binds.status = status;
      }
      if (dsId) {
        sql += ` AND R.DS_ID = :dsId`;
        binds.dsId = dsId;
      }

      sql += ` ORDER BY R.AVG_QUERY_MS DESC`;

      const result = await conn.execute<{
        REC_ID: string;
        DS_ID: string;
        CUBE_NAME: string;
        SUGGESTED_PREAGG: string;
        REASON: string;
        AVG_QUERY_MS: number;
        QUERY_COUNT: number;
        STATUS: string;
        SMART_REFRESH_CRON: string | null;
        CONFIDENCE_SCORE: number | null;
        APPLIED_AT: string | null;
        APPLIED_BY: string | null;
        CREATED_AT: string;
      }>(sql, binds, { outFormat: 4002 });

      const recs: PreAggRecommendation[] = [];
      for (const row of result.rows || []) {
        recs.push({
          recId: row.REC_ID,
          dsId: row.DS_ID,
          cubeName: row.CUBE_NAME,
          suggestedPreagg: await clobToString(row.SUGGESTED_PREAGG),
          reason: await clobToString(row.REASON),
          avgQueryMs: row.AVG_QUERY_MS,
          queryCount: row.QUERY_COUNT,
          status: row.STATUS as PreAggRecommendation['status'],
          smartRefreshCron: row.SMART_REFRESH_CRON,
          confidenceScore: row.CONFIDENCE_SCORE,
          appliedAt: row.APPLIED_AT ? String(row.APPLIED_AT) : null,
          appliedBy: row.APPLIED_BY,
          createdAt: String(row.CREATED_AT),
        });
      }
      return recs;
    });

    return NextResponse.json<ApiResponse<PreAggRecommendation[]>>({
      success: true,
      data: recommendations,
    });
  } catch (error) {
    console.error('GET /api/preagg error:', error);
    return internalErrorResponse();
  }
}

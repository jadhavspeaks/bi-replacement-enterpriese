export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString } from '@/lib/oracle-pool';
import { validateCubeSchema, sanitizeSchemaJs } from '@nexusbi/cube-schema/src/validator';
import type { ApiResponse, CubeSchema, CubeSchemaCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'schema.view');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const dsId = searchParams.get('dsId');

  try {
    const schemas = await withConnection(async (conn) => {
      let sql = `SELECT S.SCHEMA_ID, S.DS_ID, S.CUBE_NAME, S.SCHEMA_JS,
                        S.IS_ACTIVE, S.VERSION, S.CREATED_BY, S.CREATED_AT, S.UPDATED_AT
                 FROM NB_CUBE_SCHEMAS S
                 JOIN NB_DATA_SOURCES D ON D.DS_ID = S.DS_ID
                 WHERE D.ORG_ID = :orgId AND S.IS_ACTIVE = 1`;
      const binds: Record<string, unknown> = { orgId: session.user.orgId };

      if (dsId) {
        sql += ` AND S.DS_ID = :dsId`;
        binds.dsId = dsId;
      }

      sql += ` ORDER BY S.CUBE_NAME`;

      const result = await conn.execute<{
        SCHEMA_ID: string;
        DS_ID: string;
        CUBE_NAME: string;
        SCHEMA_JS: string;
        IS_ACTIVE: number;
        VERSION: number;
        CREATED_BY: string;
        CREATED_AT: string;
        UPDATED_AT: string;
      }>(sql, binds, { outFormat: 4002 });

      const list: CubeSchema[] = [];
      for (const row of result.rows || []) {
        list.push({
          schemaId: row.SCHEMA_ID,
          dsId: row.DS_ID,
          cubeName: row.CUBE_NAME,
          schemaJs: await clobToString(row.SCHEMA_JS),
          isActive: row.IS_ACTIVE === 1,
          version: row.VERSION,
          createdBy: row.CREATED_BY,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<CubeSchema[]>>({
      success: true,
      data: schemas,
    });
  } catch (error) {
    console.error('GET /api/schemas error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'schema.create', resourceType: 'schema' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'schema.edit');
    if (denied) return denied;

    let body: CubeSchemaCreateInput;
    try {
      body = await request.json() as CubeSchemaCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsId || !body.cubeName || !body.schemaJs) {
      return invalidInputResponse('dsId, cubeName, and schemaJs are required');
    }

    // Sanitize and validate
    const sanitized = sanitizeSchemaJs(body.schemaJs);
    const validation = validateCubeSchema(sanitized);

    if (!validation.valid) {
      return NextResponse.json<ApiResponse<never>>(
        {
          success: false,
          error: {
            code: 'SCHEMA_INVALID',
            message: 'Schema validation failed',
            details: { errors: validation.errors, warnings: validation.warnings },
          },
        },
        { status: 400 },
      );
    }

    try {
      // Verify datasource exists
      const dsExists = await withConnection(async (conn) => {
        const result = await conn.execute<{ DS_ID: string }>(
          `SELECT DS_ID FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND ORG_ID = :orgId AND IS_ACTIVE = 1`,
          { dsId: body.dsId, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return (result.rows?.length ?? 0) > 0;
      });

      if (!dsExists) {
        return invalidInputResponse('Data source not found');
      }

      const schemaId = generateId();

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_CUBE_SCHEMAS
             (SCHEMA_ID, DS_ID, CUBE_NAME, SCHEMA_JS, IS_ACTIVE,
              VERSION, CREATED_BY, CREATED_AT, UPDATED_AT)
           VALUES
             (:schemaId, :dsId, :cubeName, :schemaJs, 1,
              1, :createdBy, SYSTIMESTAMP, SYSTIMESTAMP)`,
          {
            schemaId,
            dsId: body.dsId,
            cubeName: validation.cubeName || body.cubeName,
            schemaJs: sanitized,
            createdBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ schemaId: string; cubeName: string }>>(
        {
          success: true,
          data: {
            schemaId,
            cubeName: validation.cubeName || body.cubeName,
          },
        },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/schemas error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

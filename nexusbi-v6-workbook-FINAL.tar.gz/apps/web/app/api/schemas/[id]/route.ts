export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString } from '@/lib/oracle-pool';
import { validateCubeSchema, sanitizeSchemaJs } from '@nexusbi/cube-schema/src/validator';
import { invalidateCache } from '@/lib/cache';
import type { ApiResponse, CubeSchema, CubeSchemaUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'schema.view');
  if (denied) return denied;

  const { id } = await params;

  try {
    const schema = await withConnection(async (conn) => {
      const result = await conn.execute<{
        SCHEMA_ID: string;
        DS_ID: string;
        CUBE_NAME: string;
        SCHEMA_JS: string;
        IS_ACTIVE: number;
        VERSION: number;
        CREATED_BY: string;
        CREATED_AT: string;
        UPDATED_AT: string;
      }>(
        `SELECT S.SCHEMA_ID, S.DS_ID, S.CUBE_NAME, S.SCHEMA_JS,
                S.IS_ACTIVE, S.VERSION, S.CREATED_BY, S.CREATED_AT, S.UPDATED_AT
         FROM NB_CUBE_SCHEMAS S
         JOIN NB_DATA_SOURCES D ON D.DS_ID = S.DS_ID
         WHERE S.SCHEMA_ID = :schemaId AND D.ORG_ID = :orgId`,
        { schemaId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        schemaId: row.SCHEMA_ID,
        dsId: row.DS_ID,
        cubeName: row.CUBE_NAME,
        schemaJs: await clobToString(row.SCHEMA_JS),
        isActive: row.IS_ACTIVE === 1,
        version: row.VERSION,
        createdBy: row.CREATED_BY,
        createdAt: String(row.CREATED_AT),
        updatedAt: String(row.UPDATED_AT),
      } as CubeSchema;
    });

    if (!schema) return notFoundResponse('Schema not found');

    return NextResponse.json<ApiResponse<CubeSchema>>({
      success: true,
      data: schema,
    });
  } catch (error) {
    console.error('GET /api/schemas/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'schema.update', resourceType: 'schema', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'schema.edit');
    if (denied) return denied;

    const { id } = await params;
    let body: CubeSchemaUpdateInput;
    try {
      body = await request.json() as CubeSchemaUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      const existing = await withConnection(async (conn) => {
        const result = await conn.execute<{ SCHEMA_ID: string; DS_ID: string; VERSION: number }>(
          `SELECT S.SCHEMA_ID, S.DS_ID, S.VERSION
           FROM NB_CUBE_SCHEMAS S
           JOIN NB_DATA_SOURCES D ON D.DS_ID = S.DS_ID
           WHERE S.SCHEMA_ID = :schemaId AND D.ORG_ID = :orgId`,
          { schemaId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!existing) return notFoundResponse('Schema not found');

      if (body.schemaJs) {
        const sanitized = sanitizeSchemaJs(body.schemaJs);
        const validation = validateCubeSchema(sanitized);

        if (!validation.valid) {
          return NextResponse.json<ApiResponse<never>>(
            {
              success: false,
              error: {
                code: 'SCHEMA_INVALID',
                message: 'Schema validation failed',
                details: { errors: validation.errors, warnings: validation.warnings },
              },
            },
            { status: 400 },
          );
        }

        body.schemaJs = sanitized;
        if (validation.cubeName && !body.cubeName) {
          body.cubeName = validation.cubeName;
        }
      }

      await withTransaction(async (conn) => {
        const setClauses: string[] = [
          'UPDATED_AT = SYSTIMESTAMP',
          'VERSION = VERSION + 1',
        ];
        const binds: Record<string, unknown> = { schemaId: id };

        if (body.cubeName !== undefined) {
          setClauses.push('CUBE_NAME = :cubeName');
          binds.cubeName = body.cubeName;
        }
        if (body.schemaJs !== undefined) {
          setClauses.push('SCHEMA_JS = :schemaJs');
          binds.schemaJs = body.schemaJs;
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }

        await conn.execute(
          `UPDATE NB_CUBE_SCHEMAS SET ${setClauses.join(', ')}
           WHERE SCHEMA_ID = :schemaId`,
          binds,
        );
      });

      // Invalidate schema cache
      await invalidateCache(`schema:${existing.DS_ID}`);

      return NextResponse.json<ApiResponse<{ schemaId: string }>>({
        success: true,
        data: { schemaId: id },
      });
    } catch (error) {
      console.error('PUT /api/schemas/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'schema.delete', resourceType: 'schema', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'schema.edit');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `UPDATE NB_CUBE_SCHEMAS S
           SET S.IS_ACTIVE = 0, S.UPDATED_AT = SYSTIMESTAMP
           WHERE S.SCHEMA_ID = :schemaId
             AND S.DS_ID IN (
               SELECT DS_ID FROM NB_DATA_SOURCES WHERE ORG_ID = :orgId
             )`,
          { schemaId: id, orgId: user.orgId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Schema not found');

      return NextResponse.json<ApiResponse<{ schemaId: string }>>({
        success: true,
        data: { schemaId: id },
      });
    } catch (error) {
      console.error('DELETE /api/schemas/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import type { ApiResponse, ColumnTag, ColumnTagInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'schema.view');
  if (denied) return denied;

  const { searchParams } = new URL(request.url);
  const dsId = searchParams.get('dsId');
  const cubeName = searchParams.get('cubeName');

  try {
    const tags = await withConnection(async (conn) => {
      let sql = `SELECT T.TAG_ID, T.DS_ID, T.CUBE_NAME, T.COLUMN_NAME,
                        T.SENSITIVITY, T.TAG_DESCRIPTION, T.TAGGED_BY, T.TAGGED_AT
                 FROM NB_COLUMN_TAGS T
                 JOIN NB_DATA_SOURCES D ON D.DS_ID = T.DS_ID
                 WHERE D.ORG_ID = :orgId`;
      const binds: Record<string, unknown> = { orgId: session.user.orgId };

      if (dsId) {
        sql += ` AND T.DS_ID = :dsId`;
        binds.dsId = dsId;
      }
      if (cubeName) {
        sql += ` AND T.CUBE_NAME = :cubeName`;
        binds.cubeName = cubeName;
      }

      sql += ` ORDER BY T.CUBE_NAME, T.COLUMN_NAME`;

      const result = await conn.execute<{
        TAG_ID: string;
        DS_ID: string;
        CUBE_NAME: string;
        COLUMN_NAME: string;
        SENSITIVITY: string;
        TAG_DESCRIPTION: string | null;
        TAGGED_BY: string;
        TAGGED_AT: string;
      }>(sql, binds, { outFormat: 4002 });

      return (result.rows || []).map((row) => ({
        tagId: row.TAG_ID,
        dsId: row.DS_ID,
        cubeName: row.CUBE_NAME,
        columnName: row.COLUMN_NAME,
        sensitivity: row.SENSITIVITY as ColumnTag['sensitivity'],
        tagDescription: row.TAG_DESCRIPTION,
        taggedBy: row.TAGGED_BY,
        taggedAt: String(row.TAGGED_AT),
      }));
    });

    return NextResponse.json<ApiResponse<ColumnTag[]>>({
      success: true,
      data: tags,
    });
  } catch (error) {
    console.error('GET /api/columns/tags error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'column.tag', resourceType: 'column_tag' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'column.tag');
    if (denied) return denied;

    let body: ColumnTagInput;
    try {
      body = await request.json() as ColumnTagInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsId || !body.cubeName || !body.columnName || !body.sensitivity) {
      return invalidInputResponse('dsId, cubeName, columnName, and sensitivity are required');
    }

    const validSensitivities = ['PII', 'CONFIDENTIAL', 'INTERNAL', 'PUBLIC'];
    if (!validSensitivities.includes(body.sensitivity)) {
      return invalidInputResponse(`sensitivity must be one of: ${validSensitivities.join(', ')}`);
    }

    try {
      const tagId = generateId();

      await withTransaction(async (conn) => {
        // Upsert: delete existing tag for same column, then insert
        await conn.execute(
          `DELETE FROM NB_COLUMN_TAGS
           WHERE DS_ID = :dsId AND CUBE_NAME = :cubeName AND COLUMN_NAME = :columnName`,
          { dsId: body.dsId, cubeName: body.cubeName, columnName: body.columnName },
        );

        await conn.execute(
          `INSERT INTO NB_COLUMN_TAGS
             (TAG_ID, DS_ID, CUBE_NAME, COLUMN_NAME, SENSITIVITY,
              TAG_DESCRIPTION, TAGGED_BY, TAGGED_AT)
           VALUES
             (:tagId, :dsId, :cubeName, :columnName, :sensitivity,
              :tagDescription, :taggedBy, SYSTIMESTAMP)`,
          {
            tagId,
            dsId: body.dsId,
            cubeName: body.cubeName,
            columnName: body.columnName,
            sensitivity: body.sensitivity,
            tagDescription: body.tagDescription ?? null,
            taggedBy: user.id,
          },
        );
      });

      return NextResponse.json<ApiResponse<{ tagId: string }>>(
        { success: true, data: { tagId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/columns/tags error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

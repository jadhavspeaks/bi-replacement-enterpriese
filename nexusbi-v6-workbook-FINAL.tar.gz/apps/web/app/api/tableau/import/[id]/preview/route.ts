export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import type { ApiResponse, WidgetConfig, LayoutConfig } from '@nexusbi/shared-types';

interface DashboardPreview {
  dashId: string;
  dashName: string;
  layoutJson: LayoutConfig | null;
  widgetsJson: WidgetConfig[] | null;
  source: string;
}

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const { id } = await params;

  try {
    const preview = await withConnection(async (conn) => {
      // Get the import to find the dashboard
      const impResult = await conn.execute<{ DASH_ID: string | null }>(
        `SELECT DASH_ID FROM NB_TABLEAU_IMPORTS
         WHERE IMPORT_ID = :importId AND ORG_ID = :orgId AND IMPORT_STATUS = 'COMPLETE'`,
        { importId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!impResult.rows || impResult.rows.length === 0 || !impResult.rows[0].DASH_ID) {
        return null;
      }

      const dashId = impResult.rows[0].DASH_ID;

      const dashResult = await conn.execute<{
        DASH_ID: string;
        DASH_NAME: string;
        LAYOUT_JSON: string;
        WIDGETS_JSON: string;
        SOURCE: string;
      }>(
        `SELECT DASH_ID, DASH_NAME, LAYOUT_JSON, WIDGETS_JSON, SOURCE
         FROM NB_DASHBOARDS
         WHERE DASH_ID = :dashId AND ORG_ID = :orgId`,
        { dashId, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!dashResult.rows || dashResult.rows.length === 0) return null;
      const row = dashResult.rows[0];

      return {
        dashId: row.DASH_ID,
        dashName: row.DASH_NAME,
        layoutJson: parseJsonClob<LayoutConfig>(await clobToString(row.LAYOUT_JSON)),
        widgetsJson: parseJsonClob<WidgetConfig[]>(await clobToString(row.WIDGETS_JSON)),
        source: row.SOURCE,
      } as DashboardPreview;
    });

    if (!preview) return notFoundResponse('Import preview not available');

    return NextResponse.json<ApiResponse<DashboardPreview>>({
      success: true,
      data: preview,
    });
  } catch (error) {
    console.error('GET /api/tableau/import/[id]/preview error:', error);
    return internalErrorResponse();
  }
}

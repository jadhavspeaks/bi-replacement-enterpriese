export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { renewTimedAccess } from '@/lib/timed-access';
import type { ApiResponse, TimedAccess, TimedAccessRenewInput } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'timed_access.renew', resourceType: 'timed_access', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'admin.platform');
    if (denied) return denied;

    const { id } = await params;

    let body: TimedAccessRenewInput;
    try {
      body = await request.json() as TimedAccessRenewInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.expiresAt) {
      return invalidInputResponse('expiresAt is required');
    }

    try {
      const renewed = await renewTimedAccess(id, body.expiresAt, user.orgId);

      if (!renewed) return notFoundResponse('Timed access grant not found');

      return NextResponse.json<ApiResponse<TimedAccess>>({
        success: true,
        data: renewed,
      });
    } catch (error) {
      console.error('POST /api/admin/timed-access/[id]/renew error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { listTimedAccess, grantTimedAccess } from '@/lib/timed-access';
import type { ApiResponse, TimedAccess, TimedAccessCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'admin.platform');
  if (denied) return denied;

  try {
    const accessList = await listTimedAccess(session.user.orgId);

    return NextResponse.json<ApiResponse<TimedAccess[]>>({
      success: true,
      data: accessList,
    });
  } catch (error) {
    console.error('GET /api/admin/timed-access error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'timed_access.grant', resourceType: 'timed_access' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'admin.platform');
    if (denied) return denied;

    let body: TimedAccessCreateInput;
    try {
      body = await request.json() as TimedAccessCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.resourceType || !body.resourceId || !body.expiresAt) {
      return invalidInputResponse('resourceType, resourceId, and expiresAt are required');
    }

    if (!body.roleId && !body.userId) {
      return invalidInputResponse('Either roleId or userId is required');
    }

    const validTypes = ['datasource', 'dashboard'];
    if (!validTypes.includes(body.resourceType)) {
      return invalidInputResponse(`resourceType must be one of: ${validTypes.join(', ')}`);
    }

    try {
      const access = await grantTimedAccess(body, user.id, user.orgId);

      return NextResponse.json<ApiResponse<TimedAccess>>(
        { success: true, data: access },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/admin/timed-access error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

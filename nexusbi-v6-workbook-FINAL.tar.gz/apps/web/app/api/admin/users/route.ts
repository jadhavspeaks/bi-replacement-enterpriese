export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, generateId } from '@/lib/oracle-pool';
import { hashPassword, validatePasswordStrength } from '@/lib/password';
import type { ApiResponse } from '@nexusbi/shared-types';

interface UserListItem {
  userId: string;
  email: string;
  username: string;
  displayName: string | null;
  orgId: string;
  isActive: boolean;
  lastLoginAt: string | null;
  createdAt: string;
  roles: string[];
}

interface CreateUserInput {
  email: string;
  username: string;
  password: string;
  displayName?: string;
  roleIds?: string[];
}

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'admin.users');
  if (denied) return denied;

  try {
    const users = await withConnection(async (conn) => {
      const result = await conn.execute<{
        USER_ID: string;
        EMAIL: string;
        USERNAME: string;
        DISPLAY_NAME: string | null;
        ORG_ID: string;
        IS_ACTIVE: number;
        LAST_LOGIN_AT: string | null;
        CREATED_AT: string;
      }>(
        `SELECT USER_ID, EMAIL, USERNAME, DISPLAY_NAME, ORG_ID,
                IS_ACTIVE, LAST_LOGIN_AT, CREATED_AT
         FROM NB_USERS
         WHERE ORG_ID = :orgId
         ORDER BY USERNAME`,
        { orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      const list: UserListItem[] = [];
      for (const row of result.rows || []) {
        const rolesResult = await conn.execute<{ ROLE_NAME: string }>(
          `SELECT R.ROLE_NAME
           FROM NB_USER_ROLES UR
           JOIN NB_ROLES R ON R.ROLE_ID = UR.ROLE_ID
           WHERE UR.USER_ID = :userId AND UR.ORG_ID = :orgId`,
          { userId: row.USER_ID, orgId: session.user.orgId },
          { outFormat: 4002 },
        );

        list.push({
          userId: row.USER_ID,
          email: row.EMAIL,
          username: row.USERNAME,
          displayName: row.DISPLAY_NAME,
          orgId: row.ORG_ID,
          isActive: row.IS_ACTIVE === 1,
          lastLoginAt: row.LAST_LOGIN_AT ? String(row.LAST_LOGIN_AT) : null,
          createdAt: String(row.CREATED_AT),
          roles: (rolesResult.rows || []).map((r) => r.ROLE_NAME),
        });
      }
      return list;
    });

    return NextResponse.json<ApiResponse<UserListItem[]>>({ success: true, data: users });
  } catch (error) {
    console.error('GET /api/admin/users error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'user.create', resourceType: 'user' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'admin.users');
    if (denied) return denied;

    let body: CreateUserInput;
    try {
      body = await request.json() as CreateUserInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.email || !body.username || !body.password) {
      return invalidInputResponse('email, username, and password are required');
    }

    const passwordCheck = validatePasswordStrength(body.password);
    if (!passwordCheck.valid) {
      return invalidInputResponse('Password does not meet requirements', {
        errors: passwordCheck.errors,
      });
    }

    try {
      // Check uniqueness
      const exists = await withConnection(async (conn) => {
        const result = await conn.execute<{ CNT: number }>(
          `SELECT COUNT(*) AS CNT FROM NB_USERS
           WHERE EMAIL = :email OR USERNAME = :username`,
          { email: body.email, username: body.username },
          { outFormat: 4002 },
        );
        return (result.rows?.[0]?.CNT || 0) > 0;
      });

      if (exists) {
        return NextResponse.json<ApiResponse<never>>(
          { success: false, error: { code: 'CONFLICT', message: 'Email or username already exists' } },
          { status: 409 },
        );
      }

      const userId = generateId();
      const passwordHash = await hashPassword(body.password);

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_USERS
             (USER_ID, EMAIL, USERNAME, PASSWORD_HASH, DISPLAY_NAME,
              ORG_ID, IS_ACTIVE, CREATED_AT, UPDATED_AT)
           VALUES
             (:userId, :email, :username, :passwordHash, :displayName,
              :orgId, 1, SYSTIMESTAMP, SYSTIMESTAMP)`,
          {
            userId,
            email: body.email,
            username: body.username,
            passwordHash,
            displayName: body.displayName ?? body.username,
            orgId: user.orgId,
          },
        );

        if (body.roleIds && body.roleIds.length > 0) {
          for (const roleId of body.roleIds) {
            await conn.execute(
              `INSERT INTO NB_USER_ROLES (USER_ID, ROLE_ID, ORG_ID, ASSIGNED_AT, ASSIGNED_BY)
               VALUES (:userId, :roleId, :orgId, SYSTIMESTAMP, :assignedBy)`,
              { userId, roleId, orgId: user.orgId, assignedBy: user.id },
            );
          }
        }
      });

      return NextResponse.json<ApiResponse<{ userId: string }>>(
        { success: true, data: { userId } },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/admin/users error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

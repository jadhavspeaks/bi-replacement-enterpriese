export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, withTransaction, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { hashPassword } from '@/lib/password';
import type { ApiResponse, WebhookEndpoint, WebhookEndpointUpdateInput } from '@nexusbi/shared-types';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> },
): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'webhook.manage');
  if (denied) return denied;

  const { id } = await params;

  try {
    const endpoint = await withConnection(async (conn) => {
      const result = await conn.execute<Record<string, unknown>>(
        `SELECT ENDPOINT_ID, ENDPOINT_NAME, URL, TRIGGER_TYPE,
                TRIGGER_CONFIG, IS_ACTIVE, ORG_ID, CREATED_BY, CREATED_AT
         FROM NB_WEBHOOK_ENDPOINTS
         WHERE ENDPOINT_ID = :endpointId AND ORG_ID = :orgId`,
        { endpointId: id, orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      if (!result.rows || result.rows.length === 0) return null;
      const row = result.rows[0];

      return {
        endpointId: row.ENDPOINT_ID as string,
        endpointName: row.ENDPOINT_NAME as string,
        url: row.URL as string,
        secretHash: '********',
        triggerType: row.TRIGGER_TYPE as WebhookEndpoint['triggerType'],
        triggerConfig: parseJsonClob(await clobToString(row.TRIGGER_CONFIG)),
        isActive: (row.IS_ACTIVE as number) === 1,
        orgId: row.ORG_ID as string,
        createdBy: row.CREATED_BY as string,
        createdAt: String(row.CREATED_AT),
      } as WebhookEndpoint;
    });

    if (!endpoint) return notFoundResponse('Webhook endpoint not found');

    return NextResponse.json<ApiResponse<WebhookEndpoint>>({ success: true, data: endpoint });
  } catch (error) {
    console.error('GET /api/webhooks/[id] error:', error);
    return internalErrorResponse();
  }
}

export const PUT = withAudit(
  (req, p) => ({ action: 'webhook_endpoint.update', resourceType: 'webhook_endpoint', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'webhook.manage');
    if (denied) return denied;

    const { id } = await params;
    let body: WebhookEndpointUpdateInput;
    try {
      body = await request.json() as WebhookEndpointUpdateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    try {
      await withTransaction(async (conn) => {
        const setClauses: string[] = [];
        const binds: Record<string, unknown> = { endpointId: id, orgId: user.orgId };

        if (body.endpointName !== undefined) {
          setClauses.push('ENDPOINT_NAME = :endpointName');
          binds.endpointName = body.endpointName;
        }
        if (body.url !== undefined) {
          setClauses.push('URL = :url');
          binds.url = body.url;
        }
        if (body.secret !== undefined) {
          setClauses.push('SECRET_HASH = :secretHash');
          binds.secretHash = await hashPassword(body.secret);
        }
        if (body.triggerType !== undefined) {
          setClauses.push('TRIGGER_TYPE = :triggerType');
          binds.triggerType = body.triggerType;
        }
        if (body.triggerConfig !== undefined) {
          setClauses.push('TRIGGER_CONFIG = :triggerConfig');
          binds.triggerConfig = JSON.stringify(body.triggerConfig);
        }
        if (body.isActive !== undefined) {
          setClauses.push('IS_ACTIVE = :isActive');
          binds.isActive = body.isActive ? 1 : 0;
        }

        if (setClauses.length === 0) return;

        await conn.execute(
          `UPDATE NB_WEBHOOK_ENDPOINTS SET ${setClauses.join(', ')}
           WHERE ENDPOINT_ID = :endpointId AND ORG_ID = :orgId`,
          binds,
        );
      });

      return NextResponse.json<ApiResponse<{ endpointId: string }>>({
        success: true,
        data: { endpointId: id },
      });
    } catch (error) {
      console.error('PUT /api/webhooks/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const DELETE = withAudit(
  (req, p) => ({ action: 'webhook_endpoint.delete', resourceType: 'webhook_endpoint', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'webhook.manage');
    if (denied) return denied;

    const { id } = await params;

    try {
      const deleted = await withTransaction(async (conn) => {
        const result = await conn.execute(
          `DELETE FROM NB_WEBHOOK_ENDPOINTS
           WHERE ENDPOINT_ID = :endpointId AND ORG_ID = :orgId`,
          { endpointId: id, orgId: user.orgId },
        );
        return (result.rowsAffected ?? 0) > 0;
      });

      if (!deleted) return notFoundResponse('Webhook endpoint not found');

      return NextResponse.json<ApiResponse<{ endpointId: string }>>({
        success: true,
        data: { endpointId: id },
      });
    } catch (error) {
      console.error('DELETE /api/webhooks/[id] error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { pollApiSource } from '@/lib/api-source-ingest';
import type { ApiResponse, ApiSource, ApiPollResult } from '@nexusbi/shared-types';

export const POST = withAudit(
  (req, p) => ({ action: 'api_source.poll', resourceType: 'api_source', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'api.source.edit');
    if (denied) return denied;

    const { id } = await params;

    try {
      const sourceData = await withConnection(async (conn) => {
        const result = await conn.execute<Record<string, unknown>>(
          `SELECT SOURCE_ID, SOURCE_NAME, API_TYPE, BASE_URL,
                  AUTH_CONFIG, REQUEST_CONFIG, RESPONSE_MAPPING,
                  POLL_CRON, STAGING_TABLE, DS_ID, ORG_ID,
                  CREATED_BY, CREATED_AT, UPDATED_AT, IS_ACTIVE
           FROM NB_API_SOURCES
           WHERE SOURCE_ID = :sourceId AND ORG_ID = :orgId AND IS_ACTIVE = 1`,
          { sourceId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );

        if (!result.rows || result.rows.length === 0) return null;
        const row = result.rows[0];

        return {
          source: {
            sourceId: row.SOURCE_ID as string,
            sourceName: row.SOURCE_NAME as string,
            apiType: row.API_TYPE as ApiSource['apiType'],
            baseUrl: row.BASE_URL as string,
            authConfig: null,
            requestConfig: parseJsonClob(await clobToString(row.REQUEST_CONFIG)),
            responseMapping: parseJsonClob(await clobToString(row.RESPONSE_MAPPING)),
            pollCron: row.POLL_CRON as string | null,
            stagingTable: row.STAGING_TABLE as string | null,
            lastPolledAt: null,
            lastPollStatus: null,
            lastRowCount: null,
            dsId: row.DS_ID as string | null,
            orgId: row.ORG_ID as string,
            createdBy: row.CREATED_BY as string,
            createdAt: String(row.CREATED_AT),
            updatedAt: String(row.UPDATED_AT),
            isActive: true,
          } as ApiSource,
          authConfigEncrypted: await clobToString(row.AUTH_CONFIG),
        };
      });

      if (!sourceData) return notFoundResponse('API source not found');

      const pollResult = await pollApiSource(
        sourceData.source,
        sourceData.authConfigEncrypted || null,
      );

      return NextResponse.json<ApiResponse<ApiPollResult>>({
        success: true,
        data: pollResult,
      });
    } catch (error) {
      console.error('POST /api/api-sources/[id]/poll error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

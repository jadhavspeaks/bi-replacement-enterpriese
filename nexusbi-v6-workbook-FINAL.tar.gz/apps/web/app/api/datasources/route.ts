export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, invalidInputResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit, writeAuditLog } from '@/lib/audit';
import { withConnection, withTransaction, generateId, clobToString, parseJsonClob } from '@/lib/oracle-pool';
import { encryptJson, maskConfig } from '@/lib/encryption';
import { validateDsConfig } from '@/lib/datasource-schemas';
import type { ApiResponse, DataSource, DataSourceCreateInput } from '@nexusbi/shared-types';

export async function GET(request: NextRequest): Promise<NextResponse> {
  const session = await getServerSession();
  if (!session?.user) {
    return NextResponse.json<ApiResponse<never>>(
      { success: false, error: { code: 'RBAC_DENIED', message: 'Unauthorized' } },
      { status: 401 },
    );
  }

  const denied = await requirePermission(session.user, 'datasource.view');
  if (denied) return denied;

  try {
    const dataSources = await withConnection(async (conn) => {
      const result = await conn.execute<{
        DS_ID: string;
        DS_NAME: string;
        DS_TYPE: string;
        DESCRIPTION: string;
        CONFIG_MASKED: string;
        STATUS: string;
        LAST_TESTED_AT: string | null;
        LAST_TEST_RESULT: string | null;
        LAST_ERROR_MSG: string;
        CUBE_DS_ID: string | null;
        ORG_ID: string;
        CREATED_BY: string;
        CREATED_AT: string;
        UPDATED_AT: string;
        IS_ACTIVE: number;
      }>(
        `SELECT DS_ID, DS_NAME, DS_TYPE, DESCRIPTION, CONFIG_MASKED,
                STATUS, LAST_TESTED_AT, LAST_TEST_RESULT, LAST_ERROR_MSG,
                CUBE_DS_ID, ORG_ID, CREATED_BY, CREATED_AT, UPDATED_AT, IS_ACTIVE
         FROM NB_DATA_SOURCES
         WHERE ORG_ID = :orgId AND IS_ACTIVE = 1
         ORDER BY DS_NAME`,
        { orgId: session.user.orgId },
        { outFormat: 4002 },
      );

      const sources: DataSource[] = [];
      for (const row of result.rows || []) {
        sources.push({
          dsId: row.DS_ID,
          dsName: row.DS_NAME,
          dsType: row.DS_TYPE as DataSource['dsType'],
          description: await clobToString(row.DESCRIPTION) || null,
          configEncrypted: '',
          configMasked: await clobToString(row.CONFIG_MASKED) || null,
          status: row.STATUS as DataSource['status'],
          lastTestedAt: row.LAST_TESTED_AT ? String(row.LAST_TESTED_AT) : null,
          lastTestResult: row.LAST_TEST_RESULT,
          lastErrorMsg: await clobToString(row.LAST_ERROR_MSG) || null,
          cubeDsId: row.CUBE_DS_ID,
          orgId: row.ORG_ID,
          createdBy: row.CREATED_BY,
          createdAt: String(row.CREATED_AT),
          updatedAt: String(row.UPDATED_AT),
          isActive: row.IS_ACTIVE === 1,
        });
      }

      return sources;
    });

    return NextResponse.json<ApiResponse<DataSource[]>>(
      { success: true, data: dataSources },
    );
  } catch (error) {
    console.error('GET /api/datasources error:', error);
    return internalErrorResponse();
  }
}

export const POST = withAudit(
  { action: 'datasource.create', resourceType: 'datasource' },
  async (request, _context, user) => {
    const denied = await requirePermission(user, 'datasource.create');
    if (denied) return denied;

    let body: DataSourceCreateInput;
    try {
      body = await request.json() as DataSourceCreateInput;
    } catch {
      return invalidInputResponse('Invalid JSON body');
    }

    if (!body.dsName || !body.dsType || !body.config) {
      return invalidInputResponse('dsName, dsType, and config are required');
    }

    // Validate config against Zod schema
    const validation = validateDsConfig(body.dsType, body.config);
    if (!validation.success) {
      return invalidInputResponse('Invalid configuration', {
        errors: (validation as { error: { errors: unknown[] } }).error.errors,
      });
    }

    try {
      const dsId = generateId();
      const cubeDsId = `ds_${dsId.replace(/-/g, '_')}`;
      const configEncrypted = encryptJson(body.config as Record<string, unknown>);
      const configMasked = JSON.stringify(maskConfig(body.config as Record<string, unknown>));

      await withTransaction(async (conn) => {
        await conn.execute(
          `INSERT INTO NB_DATA_SOURCES
             (DS_ID, DS_NAME, DS_TYPE, DESCRIPTION, CONFIG_ENCRYPTED,
              CONFIG_MASKED, STATUS, CUBE_DS_ID, ORG_ID, CREATED_BY,
              CREATED_AT, UPDATED_AT, IS_ACTIVE)
           VALUES
             (:dsId, :dsName, :dsType, :description, :configEncrypted,
              :configMasked, 'INACTIVE', :cubeDsId, :orgId, :createdBy,
              SYSTIMESTAMP, SYSTIMESTAMP, 1)`,
          {
            dsId,
            dsName: body.dsName,
            dsType: body.dsType,
            description: body.description || null,
            configEncrypted,
            configMasked,
            cubeDsId,
            orgId: user.orgId,
            createdBy: user.id,
          },
        );
      });

      const ds: Partial<DataSource> = {
        dsId,
        dsName: body.dsName,
        dsType: body.dsType,
        description: body.description || null,
        configMasked,
        status: 'INACTIVE',
        cubeDsId,
        orgId: user.orgId,
        createdBy: user.id,
        isActive: true,
      };

      return NextResponse.json<ApiResponse<Partial<DataSource>>>(
        { success: true, data: ds },
        { status: 201 },
      );
    } catch (error) {
      console.error('POST /api/datasources error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { getServerSession } from '@/lib/auth-options';
import { requirePermission, notFoundResponse, internalErrorResponse } from '@/lib/rbac-middleware';
import { withAudit } from '@/lib/audit';
import { withConnection, clobToString } from '@/lib/oracle-pool';
import { decrypt } from '@/lib/encryption';
import type { ApiResponse, ConnectionTestResult } from '@nexusbi/shared-types';

async function testConnection(
  dsType: string,
  config: Record<string, unknown>,
): Promise<ConnectionTestResult> {
  const startTime = performance.now();

  try {
    switch (dsType) {
      case 'postgres':
      case 'mysql':
      case 'mssql':
      case 'oracle':
      case 'redshift':
      case 'clickhouse':
      case 'snowflake': {
        // For database connections, attempt a simple query via the Cube.js internal API
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: true,
          latencyMs,
          tableCount: null,
          errorMessage: null,
        };
      }
      case 'bigquery':
      case 'databricks':
      case 'athena': {
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: true,
          latencyMs,
          tableCount: null,
          errorMessage: null,
        };
      }
      case 'api_rest':
      case 'api_graphql':
      case 'api_oauth_rest': {
        const baseUrl = config.baseUrl as string;
        const response = await fetch(baseUrl, {
          method: 'HEAD',
          signal: AbortSignal.timeout(10000),
        });
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: response.ok || response.status === 405,
          latencyMs,
          tableCount: null,
          errorMessage: response.ok ? null : `HTTP ${response.status}`,
        };
      }
      case 'sqlite':
      case 'duckdb': {
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: true,
          latencyMs,
          tableCount: null,
          errorMessage: null,
        };
      }
      case 'file_csv':
      case 'file_excel':
      case 'file_parquet':
      case 'file_json': {
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: true,
          latencyMs,
          tableCount: null,
          errorMessage: null,
        };
      }
      default: {
        const latencyMs = Math.round(performance.now() - startTime);
        return {
          success: true,
          latencyMs,
          tableCount: null,
          errorMessage: null,
        };
      }
    }
  } catch (error) {
    const latencyMs = Math.round(performance.now() - startTime);
    return {
      success: false,
      latencyMs,
      tableCount: null,
      errorMessage: error instanceof Error ? error.message : 'Unknown error',
    };
  }
}

export const POST = withAudit(
  (req, p) => ({ action: 'datasource.test', resourceType: 'datasource', resourceId: p.id }),
  async (request, { params }, user) => {
    const denied = await requirePermission(user, 'datasource.test');
    if (denied) return denied;

    const { id } = await params;

    try {
      const ds = await withConnection(async (conn) => {
        const result = await conn.execute<{
          DS_ID: string;
          DS_TYPE: string;
          CONFIG_ENCRYPTED: string;
        }>(
          `SELECT DS_ID, DS_TYPE, CONFIG_ENCRYPTED
           FROM NB_DATA_SOURCES
           WHERE DS_ID = :dsId AND ORG_ID = :orgId`,
          { dsId: id, orgId: user.orgId },
          { outFormat: 4002 },
        );
        return result.rows?.[0] || null;
      });

      if (!ds) return notFoundResponse('Data source not found');

      const configStr = await clobToString(ds.CONFIG_ENCRYPTED);
      let config: Record<string, unknown>;
      try {
        config = JSON.parse(decrypt(configStr));
      } catch {
        return NextResponse.json<ApiResponse<ConnectionTestResult>>({
          success: true,
          data: {
            success: false,
            latencyMs: 0,
            tableCount: null,
            errorMessage: 'Failed to decrypt credentials',
          },
        });
      }

      const testResult = await testConnection(ds.DS_TYPE, config);

      // Update datasource with test result
      await withConnection(async (conn) => {
        await conn.execute(
          `UPDATE NB_DATA_SOURCES
           SET LAST_TESTED_AT = SYSTIMESTAMP,
               LAST_TEST_RESULT = :testResult,
               LAST_ERROR_MSG = :errorMsg,
               STATUS = CASE WHEN :success = 1 THEN 'ACTIVE' ELSE 'ERROR' END,
               UPDATED_AT = SYSTIMESTAMP
           WHERE DS_ID = :dsId AND ORG_ID = :orgId`,
          {
            dsId: id,
            orgId: user.orgId,
            testResult: testResult.success ? 'SUCCESS' : 'FAILED',
            errorMsg: testResult.errorMessage,
            success: testResult.success ? 1 : 0,
          },
        );
        await conn.commit();
      });

      return NextResponse.json<ApiResponse<ConnectionTestResult>>({
        success: true,
        data: testResult,
      });
    } catch (error) {
      console.error('POST /api/datasources/[id]/test error:', error);
      return internalErrorResponse();
    }
  },
  async () => {
    const session = await getServerSession();
    return session?.user ?? null;
  },
);

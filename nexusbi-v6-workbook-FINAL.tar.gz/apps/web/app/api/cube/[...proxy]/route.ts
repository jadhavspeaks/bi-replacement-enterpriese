export const runtime = 'nodejs';

import { NextRequest, NextResponse } from 'next/server';
import { proxyCubeRequest } from '@/lib/cube-proxy';

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ proxy: string[] }> },
): Promise<NextResponse> {
  const { proxy } = await params;
  const path = `/cubejs-api/${proxy.join('/')}`;
  return proxyCubeRequest(request, path, { checkDsAccess: true });
}

export async function POST(
  request: NextRequest,
  { params }: { params: Promise<{ proxy: string[] }> },
): Promise<NextResponse> {
  const { proxy } = await params;
  const path = `/cubejs-api/${proxy.join('/')}`;
  return proxyCubeRequest(request, path, { checkDsAccess: true });
}

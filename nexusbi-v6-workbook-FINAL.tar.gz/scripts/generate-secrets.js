#!/usr/bin/env node
/**
 * NexusBI v6 — Secret Generator
 * Run:  node scripts/generate-secrets.js
 * Replaces openssl rand commands. No external tools required.
 */
const crypto = require('crypto');

const secrets = {
  NEXTAUTH_SECRET: crypto.randomBytes(48).toString('base64'),
  ENCRYPTION_KEY: crypto.randomBytes(32).toString('hex'),
  CUBEJS_API_SECRET: crypto.randomBytes(32).toString('base64'),
  INTERNAL_API_SECRET: crypto.randomBytes(32).toString('base64'),
};

console.log('');
console.log('╔══════════════════════════════════════════════════════════════╗');
console.log('║            NexusBI v6 — Generated Secrets                   ║');
console.log('╚══════════════════════════════════════════════════════════════╝');
console.log('');
console.log('Copy these into apps/web/.env.local:');
console.log('');

for (const [key, value] of Object.entries(secrets)) {
  console.log(`${key}=${value}`);
}

console.log('');
console.log('All secrets generated using Node.js crypto.randomBytes().');
console.log('');
